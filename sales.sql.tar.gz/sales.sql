--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Debian 16.1-1+b1)
-- Dumped by pg_dump version 16.1 (Debian 16.1-1+b1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.document_items DROP CONSTRAINT IF EXISTS "products_商品id_fkey";
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS "products_单号id_fkey";
ALTER TABLE IF EXISTS ONLY public.pout_items DROP CONSTRAINT IF EXISTS pout_items_fk;
ALTER TABLE IF EXISTS ONLY public.kp_items DROP CONSTRAINT IF EXISTS "kp_items_单号id_fkey";
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS "documents_客商id_fkey";
ALTER TABLE IF EXISTS ONLY public.document_items DROP CONSTRAINT IF EXISTS "document_items_商品id_fkey";
ALTER TABLE IF EXISTS ONLY public.document_items DROP CONSTRAINT IF EXISTS "document_items_单号id_fkey";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "用户_pkey";
ALTER TABLE IF EXISTS ONLY public.tree DROP CONSTRAINT IF EXISTS tree_pkey;
ALTER TABLE IF EXISTS ONLY public.tableset DROP CONSTRAINT IF EXISTS tableset2_pkey;
ALTER TABLE IF EXISTS ONLY public.products DROP CONSTRAINT IF EXISTS products_pk;
ALTER TABLE IF EXISTS ONLY public.pout_items DROP CONSTRAINT IF EXISTS pout_items_pk;
ALTER TABLE IF EXISTS ONLY public.lu DROP CONSTRAINT IF EXISTS lu_pkey;
ALTER TABLE IF EXISTS ONLY public.kp_items DROP CONSTRAINT IF EXISTS kp_items_pkey;
ALTER TABLE IF EXISTS ONLY public.help DROP CONSTRAINT IF EXISTS help_pkey;
ALTER TABLE IF EXISTS ONLY public.document_items DROP CONSTRAINT IF EXISTS document_items_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customer_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS buy_documents_pkey;
ALTER TABLE IF EXISTS public.tableset ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.help ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.customers ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.tree;
DROP TABLE IF EXISTS public.tmp;
DROP SEQUENCE IF EXISTS public.tableset2_id_seq;
DROP TABLE IF EXISTS public.tableset;
DROP TABLE IF EXISTS public.products;
DROP TABLE IF EXISTS public.pout_items;
DROP TABLE IF EXISTS public.lu;
DROP TABLE IF EXISTS public.kp_items;
DROP SEQUENCE IF EXISTS public.help_id_seq;
DROP TABLE IF EXISTS public.help;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.document_items;
DROP SEQUENCE IF EXISTS public."customers_ID_seq";
DROP TABLE IF EXISTS public.customers;
DROP FUNCTION IF EXISTS public.cut_length();
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: cut_length(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cut_length() RETURNS TABLE("物料号" text, "切分次数" bigint, "长度合计" bigint, "理重合计" real)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    select pout_items.物料号, sum(数量) as 切分次数, sum(长度*数量) as 长度合计, sum(理重) as 理重合计
    from pout_items
    join documents on 单号id=单号
    where 文本字段10 <> ''
    group by pout_items.物料号;
END;
$$;


ALTER FUNCTION public.cut_length() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    "名称" text DEFAULT ''::text,
    "联系人" text DEFAULT ''::text,
    "电话" text DEFAULT ''::text,
    "地址" text DEFAULT ''::text,
    "税率" real DEFAULT 0.15,
    "含税" boolean,
    "优惠折扣" real DEFAULT 1,
    "信用评价" text DEFAULT ''::text,
    "地区" text DEFAULT ''::text,
    "停用" boolean DEFAULT false,
    "备注" text DEFAULT ''::text,
    "助记码" text DEFAULT ''::text,
    "文本字段1" text DEFAULT ''::text,
    "文本字段2" text DEFAULT ''::text,
    "文本字段3" text DEFAULT ''::text,
    "文本字段4" text DEFAULT ''::text,
    "文本字段5" text DEFAULT ''::text,
    "文本字段6" text DEFAULT ''::text,
    "文本字段7" text DEFAULT ''::text,
    "文本字段8" text DEFAULT ''::text,
    "文本字段9" text DEFAULT ''::text,
    "文本字段10" text DEFAULT ''::text,
    "整数字段1" integer DEFAULT 0,
    "整数字段2" integer DEFAULT 0,
    "整数字段3" integer DEFAULT 0,
    "整数字段4" integer DEFAULT 0,
    "整数字段5" integer DEFAULT 0,
    "整数字段6" integer DEFAULT 0,
    "实数字段1" real DEFAULT 0,
    "实数字段2" real DEFAULT 0,
    "实数字段3" real DEFAULT 0,
    "实数字段4" real DEFAULT 0,
    "实数字段5" real DEFAULT 0,
    "实数字段6" real DEFAULT 0,
    "布尔字段1" boolean DEFAULT false,
    "布尔字段2" boolean DEFAULT false,
    "布尔字段3" boolean DEFAULT false,
    "类别" text
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."customers_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."customers_ID_seq" OWNER TO postgres;

--
-- Name: customers_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."customers_ID_seq" OWNED BY public.customers.id;


--
-- Name: document_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "单号id" text NOT NULL,
    "单价" real DEFAULT 0,
    "数量" integer DEFAULT 0,
    "备注" text DEFAULT ''::text,
    "顺序" integer DEFAULT 0,
    "重量" real DEFAULT 0,
    "长度" integer DEFAULT 0,
    "商品id" text NOT NULL,
    "规格" text DEFAULT ''::text,
    "状态" text DEFAULT ''::text,
    "理重" real DEFAULT 0,
    "炉号" text DEFAULT ''::text,
    "执行标准" text DEFAULT ''::text,
    "出库完成" boolean DEFAULT false
);


ALTER TABLE public.document_items OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    "单号" text NOT NULL,
    "客商id" integer NOT NULL,
    "日期" text NOT NULL,
    "应结金额" real DEFAULT 0,
    "已结金额" real DEFAULT 0,
    "是否含税" boolean DEFAULT false,
    "是否欠款" boolean DEFAULT true,
    "其他费用" real DEFAULT 0,
    "已记账" boolean DEFAULT false,
    "经办人" text DEFAULT ''::text,
    "备注" text DEFAULT ''::text,
    "开单时间" timestamp without time zone DEFAULT LOCALTIMESTAMP,
    "文本字段1" text DEFAULT ''::text,
    "文本字段2" text DEFAULT ''::text,
    "文本字段3" text DEFAULT ''::text,
    "文本字段4" text DEFAULT ''::text,
    "文本字段5" text DEFAULT ''::text,
    "文本字段6" text DEFAULT ''::text,
    "文本字段7" text DEFAULT ''::text,
    "文本字段8" text DEFAULT ''::text,
    "文本字段9" text DEFAULT ''::text,
    "文本字段10" text DEFAULT ''::text,
    "整数字段1" integer DEFAULT 0,
    "整数字段2" integer DEFAULT 0,
    "整数字段3" integer DEFAULT 0,
    "整数字段4" integer DEFAULT 0,
    "整数字段5" integer DEFAULT 0,
    "实数字段1" real DEFAULT 0,
    "实数字段2" real DEFAULT 0,
    "实数字段3" real DEFAULT 0,
    "实数字段4" real DEFAULT 0,
    "实数字段5" real DEFAULT 0,
    "布尔字段1" boolean DEFAULT false,
    "布尔字段2" boolean DEFAULT false,
    "布尔字段3" boolean DEFAULT false,
    "类别" text,
    "整数字段6" integer DEFAULT 0,
    "实数字段6" real DEFAULT 0,
    "文本字段11" text DEFAULT ''::text,
    "文本字段12" text DEFAULT ''::text
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: help; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.help (
    id integer NOT NULL,
    page_name text NOT NULL,
    tips text NOT NULL,
    show_order integer
);


ALTER TABLE public.help OWNER TO postgres;

--
-- Name: help_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.help_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.help_id_seq OWNER TO postgres;

--
-- Name: help_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.help_id_seq OWNED BY public.help.id;


--
-- Name: kp_items; Type: TABLE; Schema: public; Owner: sam
--

CREATE TABLE public.kp_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "单号id" text NOT NULL,
    "名称" text DEFAULT ''::text,
    "规格" text DEFAULT ''::text,
    "单位" text DEFAULT 'kg'::text,
    "单价" real DEFAULT 0,
    "数量" real DEFAULT 0,
    "税率" text DEFAULT '13%'::text,
    "顺序" text
);


ALTER TABLE public.kp_items OWNER TO sam;

--
-- Name: lu; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lu (
    "炉号" text NOT NULL,
    "质保书" text NOT NULL
);


ALTER TABLE public.lu OWNER TO postgres;

--
-- Name: pout_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pout_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "单号id" text NOT NULL,
    "物料号" text,
    "长度" integer,
    "数量" integer,
    "重量" real,
    "备注" text DEFAULT ''::text,
    "顺序" integer,
    "理重" real,
    "单价" real DEFAULT 0,
    xsid text DEFAULT ''::text
);


ALTER TABLE public.pout_items OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    "商品id" text NOT NULL,
    "规格型号" text DEFAULT ''::text,
    "出售价格" real DEFAULT 0,
    "库存下限" real DEFAULT 0,
    "停用" boolean DEFAULT false,
    "备注" text DEFAULT ''::text,
    "单位" text DEFAULT ''::text,
    "文本字段1" text DEFAULT ''::text NOT NULL,
    "文本字段2" text DEFAULT ''::text,
    "文本字段3" text DEFAULT ''::text,
    "文本字段4" text DEFAULT ''::text,
    "整数字段1" integer DEFAULT 0,
    "整数字段2" integer DEFAULT 0,
    "整数字段3" integer DEFAULT 0,
    "实数字段1" real DEFAULT 0,
    "实数字段2" real DEFAULT 0,
    "实数字段3" real DEFAULT 0,
    "文本字段5" text DEFAULT ''::text,
    "文本字段6" text DEFAULT ''::text,
    "文本字段7" text DEFAULT ''::text,
    "文本字段8" text DEFAULT ''::text,
    "文本字段9" text DEFAULT ''::text,
    "文本字段10" text DEFAULT ''::text,
    "整数字段4" integer DEFAULT 0,
    "整数字段5" integer DEFAULT 0,
    "整数字段6" integer DEFAULT 0,
    "实数字段4" real DEFAULT 0,
    "实数字段5" real DEFAULT 0,
    "实数字段6" real DEFAULT 0,
    "布尔字段1" boolean DEFAULT false,
    "布尔字段2" boolean DEFAULT false,
    "布尔字段3" boolean DEFAULT false,
    "库位" text DEFAULT ''::text,
    "单号id" text
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: tableset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tableset (
    id integer NOT NULL,
    table_name text,
    field_name text,
    data_type text,
    show_name text,
    show_width real,
    ctr_type text,
    option_value text DEFAULT ''::text,
    is_show boolean,
    show_order integer,
    inout_show boolean,
    inout_order integer,
    default_value text DEFAULT ''::text,
    all_edit boolean DEFAULT true,
    is_use boolean,
    inout_width real
);


ALTER TABLE public.tableset OWNER TO postgres;

--
-- Name: tableset2_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tableset2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tableset2_id_seq OWNER TO postgres;

--
-- Name: tableset2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tableset2_id_seq OWNED BY public.tableset.id;


--
-- Name: tmp; Type: TABLE; Schema: public; Owner: sam
--

CREATE TABLE public.tmp (
    id integer,
    table_name text,
    field_name text,
    data_type text,
    show_name text,
    show_width real,
    ctr_type text,
    option_value text,
    is_show boolean,
    show_order integer,
    inout_show boolean,
    inout_order integer,
    default_value text,
    all_edit boolean,
    is_use boolean,
    inout_width real
);


ALTER TABLE public.tmp OWNER TO sam;

--
-- Name: tree; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tree (
    num text NOT NULL,
    pnum text NOT NULL,
    node_name text,
    pinyin text,
    not_use boolean DEFAULT false
);


ALTER TABLE public.tree OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    name text NOT NULL,
    password text,
    phone text DEFAULT ''::text,
    failed integer DEFAULT 0,
    get_pass integer DEFAULT 0,
    rights text DEFAULT ''::text,
    confirm boolean DEFAULT false,
    theme text DEFAULT ''::text,
    area text DEFAULT '天津'::text,
    duty text DEFAULT ''::text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public."customers_ID_seq"'::regclass);


--
-- Name: help id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.help ALTER COLUMN id SET DEFAULT nextval('public.help_id_seq'::regclass);


--
-- Name: tableset id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tableset ALTER COLUMN id SET DEFAULT nextval('public.tableset2_id_seq'::regclass);


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, "名称", "联系人", "电话", "地址", "税率", "含税", "优惠折扣", "信用评价", "地区", "停用", "备注", "助记码", "文本字段1", "文本字段2", "文本字段3", "文本字段4", "文本字段5", "文本字段6", "文本字段7", "文本字段8", "文本字段9", "文本字段10", "整数字段1", "整数字段2", "整数字段3", "整数字段4", "整数字段5", "整数字段6", "实数字段1", "实数字段2", "实数字段3", "实数字段4", "实数字段5", "实数字段6", "布尔字段1", "布尔字段2", "布尔字段3", "类别") FROM stdin;
0	本公司				0.15	\N	1			f													0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户供应商
27	鞍山申阔机械制造有限公司	崔立健	18641270600	辽宁省鞍山市铁西区双德街45号	0.15	\N	1	崔立健	18641270600	f		asskjxzzyxgs		鞍山银行实业支行	7200 0000 0085 3077		崔立健	18641270600	鞍山申阔	辽宁省鞍山市铁西区双德街45号 鞍山申阔 	辽宁省鞍山市铁西区双德街45号 鞍山申阔 		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
28	成都若克石油技术开发有限公司	林静	18180975876	成都市新都区工业东区虎桥路199号B3-2	0.15	\N	1	林静	18180975876	f		cdrksyjskfyxgs					林静	18180975876	成都若克	成都市新都区工业东区虎桥路199号B3-2	成都市新都区工业东区虎桥路199号B3-2		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
31	天津市三一兴石油机械有限公司 	 	 18526444313	天津市津南区葛沽镇福南路29号	0.15	\N	1	 	 	f	 	tjssyxsyjxyxgs	91120112MA7EHH4G85	中国农业银行股份有限公司天津葛沽支行	02030701040025782	 	 	 	三一兴	 	 		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
26	德阳鼎宏科技有限责任公司	王晓明	13678388523	德阳市工农街道千佛村九组	0.15	\N	1	王晓明	13678388523	f	 	dydhkjyxzrgs	915106006783812067	长城华西银行股份有限公司德阳长江支行	2010100001630112	313658010028	王晓明	13678388523	 德阳鼎宏	德阳市旌阳区工农街道千佛村九组（德阳鼎宏	德阳市旌阳区工农街道千佛村九组（德阳鼎宏）		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
30	天津顺得来机械工程有限公司 	程相征	13602187847	天津市滨海新区开发区天龙路9号尼罗石油院内	0.15	\N	1	程相征	13602187847	f	 	tjsdljxgcyxgs	91120116MA05JCK64E	中国建设银行股份有限公司天津贻成豪庭支行	12050110057400000062	 	程相征	13602187847	 天津顺得来	天津市滨海新区开发区天龙路9号尼罗石油院内	天津市滨海新区开发区天龙路9号尼罗石油院内		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
29	河南逸唐石油机械有限公司	杨总	15639936535	郑州高新技术开发区金菊路16号34幢东1单元10层28号	0.15	\N	1	 	 	f	 	hnytsyjxyxgs	91410100MA44Y90Y6Q	郑州银行股份有限公司长椿路支行	90501880190448315	 	 	 	 逸唐石油	 	 		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
25	天津彩虹石油机械有限公司	 	 	 	0.15	\N	1	 	 	f	内部单位	tjchsyjxyxgs	 	 	 	 	 	 	 彩虹石油	 	 		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
32	青岛瑞信石油设备有限公司	于素娟	0532-82597816-8008	青岛即墨市蓝村镇幸福路东首南侧	0.15	\N	1	于素娟	18661602003	f		qdrxsysbyxgs	91370282794010795T	中国农业银行山东省即墨市蓝村分理处	3812 2801 0400 05567		于素娟	18661602003	青岛瑞信	山东省青岛市即墨市蓝村镇西部工业园青岛瑞信石油设备有限公司	山东省青岛市即墨市蓝村镇西部工业园青岛瑞信石油设备有限公司		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
33	天津鑫威斯特石油机械有限公司	徐超	15522118082 	天津市津南区北闸口镇国家自主创新示范区高营路8号A区	0.15	\N	1	徐超	15522118082 	f		tjxwstsyjxyxgs	91120112MA06Y5R895	中国建设银行股份有限公司天津津南支行	12050180080000002440		徐超	15522118082 	鑫威斯特	津南区八里台工业园南区春经路	津南区八里台工业园南区春经路		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
34	北京航天兴达精密机械有限公司	霍总	13552758402	北京市丰台区造甲街110号31幢一层A1-206	0.15	\N	1	霍守成	13552758482	f		bjhtxdjmjxyxgs	91110106061291235W	中国建设银行股份有限公司北京菜市口南街支行	11001176400053000248				北京航天兴达		河北省张家口市万全区东红庙小区西侧万全京仪院内		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
35	荆州诚达石油工具有限公司		0716-8080120	荆州市荆州区西环路135号	0.15	\N	1	胡蕾	177 2038 9392	f		jzcdsygjyxgs	91421000679772137J	建行北湖支行	42001626508053000680		肖魏		荆州诚达	荆州市荆州区西环路 135号 荆州诚达石油工具有限公司	荆州市荆州区西环路 135号 荆州诚达石油工具有限公司		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
36	抚顺特殊钢股份有限公司	王佳俊	13134131210		0.15	\N	1			f		fstsggfyxgs	抚钢										0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	供应商
39	江苏常宝普莱森钢管有限公司	周昊	18706140017		0.15	\N	1			f		jscbplsggyxgs	常宝										0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	供应商
40	中航上大高温合金股份有限公司	陈国伟	19832107995	 	0.15	\N	1			f	 	zhsdgwhjgfyxgs	 上大										0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	供应商
41	衡阳华菱钢管有限公司	周黎黎	13575105587		0.15	\N	1			f		hyhlggyxgs	衡钢										0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	供应商
42	天津市鑫东航通钢铁贸易有限公司	 	13642074115	天津市北辰区青光镇韩家墅钢材市场C区后道43号	0.15	\N	1	 	 	f	 	tjsxdhtgtmyyxgs	91120113MACQ4A17G	中国农业银行股份有限公司天津津西支行	02020201040029480	 	 	 	鑫东航通	 	 		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
43	天津市克赛斯工贸有限公司		022-28328875	天津市津南区八里台镇科达一路16号	0.15	\N	1			f		tjskssgmyxgs	91120222744035214D	建行天津中塘支行	12001765901052501404				克赛斯				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
44	东营市博鸿石油机械有限公司		15254696743	山东省东营市垦利区黄河路以东宜兴路以南黄河口汽配城11幢3号	0.15	\N	1			f		dysbhsyjxyxgs	91370521MA3W905C08	垦利乐安村镇银行股份有限公司开发区支行	928070100100003488				博鸿石油				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
45	天津市通盈石油技术开发有限公司		022-65611229	天津市滨海新区旅游区鬓旅产业园13号楼五层550-3房间	0.15	\N	1			f		tjstysyjskfyxgs	91120116075901452U	中国工商银行天津市翠亨广场支行	0302098209100035371				通盈石油				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
46	天津瑞琪森石油设备有限公司			天津东疆保税港区亚洲路6975号金融贸易中心南区1-1-916	0.15	\N	1			f		tjrqssysbyxgs	91120118MA06XBDK9N	中国银行天津河西支行	280489810470				瑞琪森				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
37	大冶特殊钢有限公司-钢管	曾九全	18772261998	 	0.15	\N	1			f	 	dytsgyxgsgg	冶钢-钢管										0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	供应商
47	天津跃峰科技股份有限公司		29656335	天津市宝坻区大唐庄镇（工业园区内）	0.15	\N	1			f		tjyfkjgfyxgs	91120224566143633M	中国工商银行股份有限公司天津宝坻支行	0302096109300314549	102110000898			跃峰科技				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
48	荆州市赛瑞能源技术有限公司	田学虎	0716-8011501	荆州市沙市区工业新区十三号路银湖中小企业城B5	0.15	\N	1	田学虎	13972331343	f		jzssrnyjsyxgs	91421000698046130E	工商银行荆州市分行汇通支行	1813021109035026305		田学虎	13972331343	荆州赛瑞	荆州市沙市区318国道银湖工业区B5栋荆州市赛瑞能源技术有限公司	荆州市沙市区318国道银湖工业区B5栋荆州市赛瑞能源技术有限公司		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
49	邯郸标库金属有限责任公司		15132932976 	河北省邯郸市丛台区人民东路 77 号嘉禾鑫岭大厦十三层 1303 号	0.15	\N	1			f		hdbkjsyxzrgs	91130403MA0FWAWQ95	中信银行邯郸分行营业部	8111801012400818789				邯郸标库				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
65	天津滨海雷克斯激光科技发展有限公司		022-25323956	天津开发区睦宁路70号厂房1栋1层5号	0.15	\N	1			f		tjbhlksjgkjfzyxgs	911201166630712727	渤海银行股份有限公司天津滨海新区分行	2000092068000186				雷克斯激光				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
50	东营市瑞丰石油技术发展有限責任公司	 	 	 	0.15	\N	1	 	 	f	 	dysrfsyjsfzyxrgs	 	 	 	 	 	 	 瑞丰	 	 		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
51	山东宏继源石油装备有限公司		13869294760	山东省德州市经济技术开发区袁桥镇崇德十大道88号院内2号车间	0.15	\N	1			f		sdhjysyzbyxgs	91371403MAC89LXP7B	中国工商银行股份有限公司德州科技支行	1612075409100067329				山东宏继源石油				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
52	湖南苏普锐油气装备科技有限公司	宴经理		益阳市高新区东部产业园H区	0.15	\N	1			f		hnspryqzbkjyxgs		中国工商银行股份有限公司益阳银城支行	1912032009200185876				苏普锐				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
53	杭州途晟物资有限公司		0571-87569303	杭州市江干区鑫运时代金座3 幢808A室	0.15	\N	1			f		hztswzyxgs	91330104MA27WE5P69	农行杭州笕桥支行	19019001040002419		潘生	13003660322	杭州途晟	杭州市江干区笕丁路 168号17栋2单元402			0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
54	天津隆凯来石油设备有限公司	袁俪华	022-68690382  	天津市静海经济开发区广海道17号	0.15	\N	1			f		tjlklsysbyxgs	91120223MA06L2NP31	中国银行天津静海支行 	270088283384				隆凯来				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
55	宝鸡聚能石油机械有限公司		0917-3266861	陕西省宝鸡市高新开发区钛城路郭家村工业园18号	0.15	\N	1			f		bjjnsyjxyxgs	91610301088244834X	中国建设银行宝鸡高新技术产业开发区支行	6100 1628 9080 5250 7181				宝鸡聚能				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
56	天津天屹能源科技有限公司		18002088239	天津市津南区小站镇宁园道12号4号厂房	0.15	\N	1			f		tjtynykjyxgs	91120116684726127M	中国工商银行天津市翠亨广场支行	0302098209100005130				天屹能源				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
57	辽宁富美石油机械制造有限公司		024-24733942	辽宁省沈抚示范区深井子镇西靠山村	0.15	\N	1			f		lnfmsyjxzzyxgs	912101007984978791	沈阳农村商业银行股份有限公司大东支行 开	132312010105738383				辽宁富美				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
38	大冶特殊钢有限公司-圆钢	朱小飞	13597711352	 	0.15	\N	1			f	 	dytsgyxgsyg	冶钢-圆钢										0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	供应商
58	无锡劝诚特钢有限公司				0.15	\N	1			f		wxqctgyxgs	劝诚										0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	供应商
60	天津盛杰斯国际贸易有限公司	冯总	022-84472426	天津市滨海新区新城镇津沽公路北侧与迎新路交口	0.15	\N	1			f		tjsjsgjmyyxgs	91120116300626013L	建行天津东丽支行营业部	12001780800052521568				盛杰斯				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
61	荆州市瑞驰石油机械有限公司				0.15	\N	1			f		jzsrcsyjxyxgs	91421000MA4950MD64	中国银行荆州沙市支行	中国银行荆州沙市支行				荆州瑞驰				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
62	俱准（天津）机械设备有限公司		15822885205	天津开发区西区工业园标准厂房3号东侧	0.15	\N	1			f		jztjjxsbyxgs	91120116MA06R8YU3B	中国建设银行天津开发分行	12050183510000002920				俱准机械				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
66	天津瑞莱富德石油机械制造有限公司		15122993109	天津市津南区葛沽镇福企道39号6号厂房	0.15	\N	1			f		tjrlfdsyjxzzyxgs	91120112MA05U57W5D	中国建设银行股份有限公司天津葛沽支行	12050180570100000100				瑞莱富德				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
63	天津德瑞克石油工具有限公司	张泽	 	天津市武清区京滨工业园民丰道6号	0.15	\N	1	张泽	 	f	 	tjdrksygjyxgs	 	中国工商银行天津京滨支行	0302099609100003589	 	张泽	 	德瑞克石油	 	 		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
64	天津康坦石油设备科技有限公司		022-66203339	天津滨海新区塘沽海洋高新区新北路4668号创新创业圆11-A	0.15	\N	1			f		tjktsysbkjyxgs	911201160587206842	工商银行天津宏达支行	0302 0905 0930 0137 556				康坦石油				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
67	天津朝彭盛世科技发展有限公司	022-25227633		天津滨海高新区塘沽海洋科技园华山道与宁海路交口西南侧北方黄金珠宝园场区内4号库	0.15	\N	1			f		tjcpsskjfzyxgs	91120102MA06FN47X2	天津银行杭州道支行	106901201080919974				朝彭盛世				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
68	山东九玺金属制造有限公司		0635-8882343	山东省聊城市高新区许营镇尹堂村143号	0.15	\N	1			f		sdjxjszzyxgs	91371500MACL9H7WXT	中国工商银行股份有限公司聊城柳园南路支行	1611015509200022533				九玺金属				0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
59	深圳威晟海南分公司	周丽娇	 	 	0.15	\N	1	周丽娇	13857994068	f	 	szwshnfgs	 	 	 	 	 	 	 海南威晟	 	海南省澄迈县老城镇（龙盘油田内）		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
69	欧亚汇通（天津）商贸有限公司	丁总	022-58709132	天津市北辰区北仓镇长瀛商业广场4-1007	0.15	\N	1	丁总	13512283998	f		oyhttjsmyxgs	91120113MA06H353XP	上海浦东发展银行天津浦德支行	77090154740023631		丁总	13512283998	欧亚汇通	天津市北辰区北仓镇	天津市北辰区北仓镇		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
70	山东宸丰瑞晟精密机械加工有限公司	司立民	15621250872	山东省德州市德城区二屯镇工业路1号广驰工业园三区29号车间	0.15	\N	1	司立民	15621250872	f		sdcfrsjmjxjgyxgs	91371402MACPL01W45	中国银行德州德城支行	210448986727		司立民	15621250872	宸丰瑞晟精密机械	山东省德州市德城区广驰工业园29#车间	山东省德州市德城区广驰工业园29#车间		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
71	天津达利普石油管材有限公司	袁丽华	18722411544	天津静海	0.15	\N	1			f		tjdlpsygcyxgs	达利普										0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	供应商
72	陕西众诚汇智油气工程技术有限公司	焦云风	029-34057611	陕西省咸阳市乾县城关街道办工业区玖犁汇智中心	0.15	\N	1	焦云风	15829446000	f		sxzchzyqgcjsyxgs	91610424MA6XY9WQ4X	中国工商银行股份有限公司乾县支行	2604031209200063088	102795440138	焦云风	15829446000	陕西众诚汇智	陕西咸阳市乾县城关街道乾县城关街道工业区玖犁汇智中心D-1 	陕西咸阳市乾县城关街道乾县城关街道工业区玖犁汇智中心D-1 		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
73	无锡贝来石油专用管有限公司	薛骑	0510-83218150	无锡市惠山区钱桥街道钱洛路3号	0.15	\N	1	薛骑	15161518190	f		wxblsyzygyxgs	913202063312976038	中国农业银行无锡钱桥支行	10652401040043714		薛骑	15161518190	无锡贝来	无锡市惠山区钱桥街道钱洛路3号	无锡市惠山区钱桥街道钱洛路3号		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
74	天津市达利普石油管材有限公司	袁总	 022-68690381	天津市静海县静海镇北华路北侧	0.15	\N	1	袁总	18722411544	f		tjsdlpsygcyxgs	911202236714965611	中国农业银行天津静海支行营业部	02-070001040048756		袁总	18722411544	达利普石油	天津市静海经济凯大区广海道17号	天津市静海经济凯大区广海道17号		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
75	天津德瑞克石油工具有限公司	张泽	022-59699306	天津市武清区京滨工业园民丰道6号	0.15	\N	1	张泽	18920480870	f		tjdrksygjyxgs	91120222578325477G	工行天津武清支行	0302099609100003589		张泽	18920480870	德瑞克石油	天津市武清区京滨工业园民丰道6号	天津市武清区京滨工业园民丰道6号		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
76	北京乐富特科技有限公司	彭通	13366822095	北京市朝阳区锦芳路1号院7号楼4层405	0.15	\N	1	彭通	13311300432	f		bjlftkjyxgs	91110105MA00C71P22	招商银行股份有限公司北京国贸东支行	110927154810601		彭通	13311300432	北京乐富特	河北省廊坊市大厂县潮白河工业区正景自动化有限公司6号厂房南端	河北省廊坊市大厂县潮白河工业区正景自动化有限公司6号厂房南端		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
77	江苏赛维斯石油科技有限公司	张雷	13401336276	常州市武进区礼嘉镇武阳村委前巷526-1号	0.15	\N	1	莫工	18912319650	f		jsswssykjyxgs	91320412MA1MB2LM84	江苏银行股份有限公司常州大学城科技支行	83500188000099373		莫工	18912319650	江苏赛维斯	江苏省常州市武进区板上蒲工业园96号	江苏省常州市武进区板上蒲工业园96号		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
78	济南华菱劲通钢管有限公司	蒋卫东	0531-86510390	中国（山东）自由贸易试验区济南片区龙奥北路8号玉兰广场3号楼1601室	0.15	\N	1	许建辉	18670474652	f		jnhljtggyxgs	913701007874424936	建行济南新区支行	37001618806050148544		马金艳	15269178316	济南华菱劲通	济南华菱劲通钢管有限公司中国山东自由贸易试验区济南片区龙奥北路8号玉兰广场3号楼1601室	中国（山东）自由贸易试验区济南片区龙奥北路8号玉兰广场3号楼1601室		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
79	三河市华夏恒泰电子科技有限公司	田敬辉	010-61590876	河北省廊坊市三河市燕郊开发区燕昌路西侧，欧森工业园院内A2厂房	0.15	\N	1	田敬辉	15226661859	f		shshxhtdzkjyxgs	911310826652920445	工行廊坊市燕郊支行	0410001409225009597		田敬辉	15226661859	三河华夏恒泰电子	河北省廊坊市三河市燕郊开发区燕昌路西侧，欧森工业园院内A2厂房	河北省廊坊市三河市燕郊开发区燕昌路西侧，欧森工业园院内A2厂房		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
80	井星（天津）能源技术有限公司	022-58956474	杨森伟	天津市滨海新区临港经济区渤海26路1469号综合办公楼南侧302室	0.15	\N	1	杨志钢	17702276318	f		jxtjnyjsyxgs	91120118MA05PBL28Q	中国银行天津融合广场支行	280483817880		杨志钢	17702276318	井星能源	天津市滨海新区临港经济区渤海26路1469号	天津市滨海新区临港经济区渤海26路1469号		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
81	长葛市金博机械化工有限公司 	陈总	0374-6631219	长葛市石固镇东关	0.15	\N	1	陈世杰	13523289303	f		cgsjbjxhgyxgs	914110827167833119	市工行	1708026009048078935		陈世杰	13523289303	长葛金博机械	河南省长葛市建设路南段瑞景新城小区	长葛市石固镇东关		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
82	天津远海采油科技有限公司	阮经理	022-66320918	天津滨海高新区塘沽海洋科技园新北路4668号创新创业园17-A号厂房东侧	0.15	\N	1	阮经理	15222616080	f		tjyhcykjyxgs	91120116055278747X	中国银行股份有限公司天津滨海支行	277870636319		阮经理	15222616080	远海采油	天津滨海高新区塘沽海洋科技园新北路4668号创新创业园17-A号厂房东侧	天津滨海高新区塘沽海洋科技园新北路4668号创新创业园17-A号厂房东侧		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
83	江苏宏扬镍基金属制品有限公司	衣经理	0510-81819123	无锡市锡山经济开发区芙蓉三路223号	0.15	\N	1	衣经理	13656194567	f		jshynjjszpyxgs	91320205354523247Y	江苏银行无锡北环路支行	20560188000260995		衣经理	13656194567	江苏宏扬镍基金属	无锡市东昌府区辽河路东钢材市场（大东大厦322室）	无锡市东昌府区辽河路东钢材市场（大东大厦322室）		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
84	桑姆机电设备（河北）有限公司	白永建	15100875745	河北省沧州市运河区泰大国际1503	0.15	\N	1	白永建	15100875745	f		smjdsbhbyxgs	91130903MA0FR8BW14	中国农业银行	50604101040040749		白永建	15100875745	桑姆机电	河北省沧州市运河区泰大国际1503	河北省沧州市运河区泰大国际1503		0	0	0	0	0	0	0	0	0	0	0	0	f	f	f	客户
\.


--
-- Data for Name: document_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_items (id, "单号id", "单价", "数量", "备注", "顺序", "重量", "长度", "商品id", "规格", "状态", "理重", "炉号", "执行标准", "出库完成") FROM stdin;
315900c6-49f3-44aa-82bb-c7fca9c2e368	XS202312-26	29	1		1	0	93450	4_103	159*35	调质-80KSI	10000		0	f
260db98e-ea06-4f49-aa9e-e880ceaf8ebd	XS202312-28	30	1	料头	1	0	380	4_103	133*35	调质-80KSI	32.1		0	f
5140568d-3537-4229-b381-d919aeb210cd	XS202312-05	50	1		1	30.2	150	3_104	180	调质-110KSI	30.2			f
534ae633-dbe0-4b9e-8eda-154562f93b29	XS202312-27	13	1		1	0	720	3_105	120	调质110KSI	64		0	f
7283487b-0d13-461a-b788-260ab8ae0eaa	XS202312-08	11.5	1	切1410*6+余料	1	0	9630	3_105	170	调质110KSI	1717.2			f
7a86708e-cc31-474a-ba2a-da0764936fcd	FH2401-001	12	2		1	13.2	194	4_102	89*20	调质-110KSI	13.2	TX22-06236LG		f
fa582ce5-b3d2-428c-8f42-fb9e14b783b5	FH2401-002	12	37		1	0	95	4_102	219*28	调质110KSI	463.6	TX22-06529LG		f
831b9b1f-a4d5-462d-bef2-eeaec08b21db	FH2401-002	12	37		2	0	95	4_102	219*28	调质110KSI	463.6	TX22-06529LG		f
48cb1f5a-1417-4f76-82c0-1b857f94f1b2	FH2401-002	12	14	第1.2.3项重量	3	1100	95	4_102	219*28	调质110KSI	175.4	TX22-06529LG		f
1eff2859-5e21-4e5c-9680-fd8805713c62	FH2401-004	50	1		1	83	278	3_104	220	调质-110KSI	83.5	23209121074		f
f32ebee2-680c-427b-9ef7-0324872d335c	CG2401-001	10	0		1	744	28000	4_102	139.7*7.72	调质-110KSI	0		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
e6ef4294-406c-4cd7-89f9-56d2c46fc6d3	FH2401-007	12	138		1	204.24	25	4_102	121*25	调质-110KSI	204.2	622120689ZT		f
910034b0-cf15-4bf3-b4a2-d08caf251213	FH2401-007	75	20		2	378	267	4_101	219*14	固溶时效，28-32HRC	380.4	2MALV21118		f
e06cf8f0-d482-4c1d-a76a-8a4686636aed	FH202312-01	50	1		1	34.6	115	3_104	220	调质-110KSI	34.6	21209122762		f
fa21fc48-b190-489e-8a4c-955566990728	XS202312-55	12	138	线缆卡子	1	0	25	4_102	121*25	调质-110KSI	204.2		0	t
f303cecd-395c-4901-a498-38bf22e207f9	XS202312-55	75	20	卡瓦架	2	0	267	4_101	219*14	固溶时效，28-32HRC	380.4		XTG-JY-C-036-2020	t
7963d483-3019-4fda-af01-52fd63989e98	XS202312-55	33	1	限位键2	3	0	680	3_101	200	固溶时效	168.9		0	t
e9441fb6-1523-452e-ac9a-8205a4236a83	XS202312-54	33	27	压帽	1	0	237	4_103	195.5*28	调质80KSI	740.1		XYGN4972-2022-01	t
b4fafcd7-7280-40d1-adc1-20add3f815be	FH2401-007	33	1		3	167.7	680	3_101	200	固溶时效	168.9			f
572a8987-55a4-42a5-b176-27435a4fa5be	XS202312-16	50	23	上接头	1	0	560	3_104	170	调质-110KSI	2311.4			t
f30f13b7-9b15-484b-8999-21bc9cc6ee4a	XS202312-16	25	24	中心管	2	0	990	3_103	80	调质-80KSI	938.2			t
6e8326e9-1644-4f97-b5df-6af3d7827509	XS202312-16	25	25	壳体	3	0	820	3_103	170	调质-80KSI	3655.4			t
c6c7efa0-1ce6-44f1-adc7-ce813af096f2	XS2401-015	33	8		1	0	267	4_103	219*13	调质80KSI	141.1		XYGN4972-2022-01	t
62cee1a5-3726-4d18-be98-7a08541fabe9	XS2401-012	25	1	主体	1	180	603	3_103	220	调质-80KSI	180.1		QJ/DT01.24412-2020-B/0	t
90c1a914-f8a5-4fca-a7b9-ff70241367cf	XS2401-012	25	1	主体	2	180	603	3_103	220	调质-80KSI	180.1		QJ/DT01.24412-2020-B/0	t
f655b061-4f1d-4a00-bf38-70968ca834ce	CG202312-01	16.429	0	不超过30%短尺可接受	3	5000	0	3_108	115	调质-80KSI	0		QJ/DT01.24669-2021-C/0	f
7984bd16-32da-416d-808c-d27da4d44431	CG202312-01	16.429	0	不超过30%短尺可接受	4	10000	0	3_108	135	调质-80KSI	0		QJ/DT01.24669-2021-C/0	f
cff58a74-ddc2-4fdb-92a9-9c7961d27441	XS202312-03	11.5	1	整支	1	0	7770	4_102	159*24	调质-110KSI	620.8			f
8dc844be-2375-4cd2-9684-d38a72576398	XS202312-03	11.5	1	整支	2	0	7840	4_102	159*24	调质-110KSI	626.4			f
b1f7e6db-f660-40a9-930a-3f314d5f754e	XS202312-03	11.5	1	整支	3	0	7670	4_102	159*24	调质-110KSI	612.8			f
e0e29c3d-cc6a-47c9-9307-5137103b5650	XS202312-03	11.5	1	整支	4	0	7130	4_102	127*35	调质110KSI	566.2			f
4f267bc6-4f20-4485-b5d3-f476d9edfc63	XS202312-03	11.5	1	整支	5	0	7175	4_102	127*35	调质110KSI	569.7			f
e46cf454-078d-4ddc-9108-a7a55d7b15d6	CG202312-01	16.429	0	不超过30%短尺可接受	5	10000	0	3_108	155	调质-80KSI	0		QJ/DT01.24669-2021-C/0	f
97b679f9-07cb-4ec4-b2b7-61eb4621034a	FH202312-02	50	1		1	34.6	115	3_104	220	调质-110KSI	34.6	21209122762		f
be5083a0-8f6a-44f5-babc-bc933e95bfd6	CG202312-01	16.429	0	不超过30%短尺可接受	6	10000	0	3_108	220	调质-80KSI	0		QJ/DT01.24669-2021-C/0	f
bb924abe-1eec-49ae-b1aa-bc805996cb86	XS202312-28	30	1	料头	2	0	190	4_103	133*35	调质-80KSI	16.1		0	f
8fa0d3a9-fcc3-4a8b-883f-802fc213a0cd	XS202312-28	30	1	料头	3	0	2610	4_103	159*24	调质-80KSI	208.5		0	f
fadf25ab-efb9-47a0-bc37-7e238a8ae4f2	XS202312-28	30	1	料头	4	0	1220	4_103	159*22	调质-80KSI	90.7		0	f
f5440e68-e843-4005-8a0c-529d73329e00	XS202312-28	30	1	料头	5	0	3900	4_103	108*24	调质-80KSI	193.9		0	f
6d553609-2f9a-4e87-93f2-114ae4084d98	XS202312-28	30	1	料头	6	0	2620	4_103	122*20	调质-80KSI	131.8		0	f
22730841-3d44-48dd-88cb-e52a7387ea3c	XS202312-25	10.5	10000		1	0	44800	3_105	190	调质-110KSI	10000		0	f
3dd4031e-a3bf-4e53-b215-7e17d2fc879f	XS202312-25	10.5	10000		2	0	33557	3_105	220	调质-110KSI	10000		0	f
2451053a-0198-4f5a-8b48-40ed56d73fc7	FH202312-03	13	1	由壬接头1	1	31.3	298	3_105	140	调质110KSI	36	F22306309XA		f
5cb9ba27-7f85-43a5-9d99-1057fc51f6a4	FH202312-05	13	1	140*50.8	1	31.3	298	3_105	140	调质110KSI	36	F22306309XA		f
a6a00dbd-0b74-4515-a4f6-490be477c92a	XS202312-38	50	1		1	15.4	390	3_104	80	调质-110KSI	15.5		0	f
1bf86d28-5b41-4bdb-9fd9-d308b06e1573	FH202312-07	50	1		1	30	150	3_104	180	调质-110KSI	30.2	21209111778		f
74b360ea-59c5-437d-baf9-5d7467155225	XS202312-22	50	1	护环	1	0	200	3_104	200	调质-110KSI	49.7		QJ/DT01.24548-2021-A/0	f
45f01933-f89e-4dcd-b713-21e453b253e4	XS202312-28	32.5	1	切	7	0	3000	4_103	136*21	调质-80KSI	178.7		0	f
7a2a2fcd-3a67-4164-a323-f6665333eda0	XS202312-28	32.5	1	切	8	0	3000	4_103	186*20	调质-80KSI	245.6		0	f
cf651196-268e-4d80-8320-d9f192504aae	XS202312-23	31	1	1510倍尺切	1	0	6770	4_103	116*22	调质-80KSI	345.2		0	f
e2f45322-c362-4df9-a51b-99e715390504	FH202312-15	50	1		1	15.4	390	3_104	80	调质-110KSI	15.5	21209111837		f
4c4c14bd-8826-4739-bf22-ab3698f9d4a6	FH202312-16	31	1	3030+余料	1	355	6770	4_103	116*22	调质-80KSI	345.2	3072161M		f
12f608c6-9771-4b6c-abe1-a29a1cf88c53	XS202312-50	13	2		1	0	950	3_105	220	调质110KSI	567.4		0	t
ce696fef-bf1c-440c-bd66-33a0bab3d125	XS202312-50	13	4		2	0	4060	3_105	190	调质110KSI	3617.2		0	t
c3851241-77b5-4986-8eea-f57fba2830df	XS202312-50	13	6		3	0	810	3_105	160	调质110KSI	767.6		0	t
691e6faf-ce16-4556-89bf-5541c57814f3	XS202312-46	30	1		1	522.6	6300	4_103	203*18	调质-80KSI	517.3		0	t
c28051f6-16cc-41b4-a181-76d4b8e5d0bc	XS202312-33	25	20	下连接体	2	1642	275	3_103	220	调质-80KSI	1642.5		QJ/DT01.24412-2020-B/0	t
4f1fc4ac-b76b-416e-8d81-530472b38fd6	XS202312-04	13	1	料头	1	0	298	3_105	140	调质110KSI	31.3			f
cae3d21f-daea-4e5a-919f-4bb190eaba83	FH202312-11	26.5	1		1	0	6780	4_103	127*9.19	调质-80KSI	181	20M1499V		f
5a51bdb6-0013-42ad-87c9-c4ede39e6612	FH202312-11	26.5	1		2	0	6770	4_103	127*9.19	调质-80KSI	180.8	20M1499V		f
d22c1bd1-f88f-4fbd-8949-9aa9e4218464	CG202312-01	16.429	0	不超过30%短尺可接受	2	5000	0	3_108	100	调质-80KSI	0		QJ/DT01.24669-2021-C/0	t
259585bf-72a1-4e21-ac8f-558e186360cb	FH202312-11	26.5	1		3	0	6770	4_103	127*9.19	调质-80KSI	180.8	20M1499V		f
0b1f5d0a-43c0-4bbc-8ba9-36d72bbbe128	FH202312-11	26.5	1	第1.2.3.4项重量	4	729.5	6790	4_103	127*9.19	调质-80KSI	181.3	20M1499V		f
d63a1bb7-6338-4caf-a29b-17a5cb8f7baf	XS202312-02	50	1		1	0	1620	3_104	120	调质-110KSI	144.9			f
201ea848-8381-4bd1-a45f-39fdcd2d9d81	XS202312-02	50	1		2	0	1620	3_104	100	调质-110KSI	143.9			f
215e8046-ba1d-48c4-b601-09cad00cd9b0	XS202312-29	68	1		1	0	6400	4_101	219*14	固溶时效，28-32HRC	388.3		0	f
4cd4538f-6aec-4d16-ae67-f0797fee0da2	XS202312-29	30	1		2	0	980	4_103	203*18	调质-80KSI	80.5		0	f
9b481665-8f1c-40c1-9db3-c258fb832363	FH2401-003	12	1		1	7.1	310	4_102	83*14	调质110KSI	7.4	3016362Z		f
e5a68aa4-d3f2-4c3e-bfeb-0ec7d74022b5	XS202312-11	13	2		1	0	510	3_105	110	调质-110KSI	76.2			f
f743f5f4-e581-4099-abf0-bc2a57fb0806	FH202312-12	68	1	3300+3100	1	485.8	6400	4_101	219*14	固溶时效，28-32HRC	455.9	2MALV21118		f
3f54170f-1e3e-4665-935e-42987116b953	FH202312-12	30	1		2	75	980	4_103	203*18	调质-80KSI	80.5	2074733T		f
a92a0f39-4308-444d-a51e-1e58af04c9a3	XS202312-33	33	20	止动套	1	258	98	4_103	219*28	调质80KSI	258.5		XYGN4972-2022-01	t
6d30a77a-f957-4064-a5bc-704e21fdd536	XS202312-06	45	1		1	0	8340	3_104	155	调质-110KSI	1244.2			f
13de5a9a-63b8-4d6f-842e-4d37650c2513	XS202312-06	45	1		2	0	8485	3_104	155	调质-110KSI	1265.8			f
cea4587e-f111-46ca-9d57-6bbc3cb4a028	XS202312-06	45	1		3	0	8535	3_104	155	调质-110KSI	1273.3			f
16ad3768-482c-40a7-843c-67d66b5fc5bd	XS202312-06	45	1		4	0	3500	3_104	110	调质-110KSI	263			f
fe4da9ba-9fc1-408a-9032-005a33e01c0c	FH202312-04	12	2	140*50.8	1	106.6	508	3_105	140	调质110KSI	122.9	F22306309XA		f
f697e197-a1c7-48fd-987c-3696071fbf9f	FH202312-04	12	2	140*50.8	2	106.6	508	3_105	140	调质110KSI	122.9	F22306309XA		f
1fc2731f-5dc6-4a3a-ad09-a06777b6ec40	FH2401-003	25	2		2	70.8	990	3_103	80	调质-80KSI	78.2	22209122737		f
cf2d494a-1152-44a1-84b8-33b5ddd010c5	FH2401-006	33	3		1	52.8	267	4_103	219*13	调质-80KSI	52.9	2MALV21099		f
6eb6b289-e647-403d-99ed-67140c65df8e	FH2401-006	13	4		2	191.6	460	3_105	130	调质	191.9	3017454Z		f
2cc208cd-ab88-493f-984c-984bdae02ddc	XS202312-07	26.5	1		1	0	6780	4_103	127*9.19	调质-80KSI	181			f
514f6d8b-3f13-4071-9049-10ceedc1d915	XS202312-07	26.5	2		2	0	6770	4_103	127*9.19	调质-80KSI	361.5			f
b9fe60ef-2222-49a6-af29-68db33846810	XS202312-07	26.5	1		3	0	6790	4_103	127*9.19	调质-80KSI	181.3			f
e6902ed9-501f-443b-951d-4ce66d7341b0	XS202312-32	30.5	1		3	0	8260	4_103	219*28	调质-80KSI	1089.3		0	t
190116a2-9a47-44f1-85c4-cda24ebdfa26	XS202312-32	30.5	1		4	0	6270	4_103	95*22.5	调质-80KSI	252.2		0	t
e7e50f88-b693-44c4-a80e-0cb0ff697242	XS202312-13	12	2	钻杆变扣	1	0	508	3_105	140	调质110KSI	106.6			f
4148e4f7-e67a-458e-9118-aa818b69d34b	XS202312-13	12	2	钻杆变扣	2	0	508	3_105	140	调质110KSI	106.6			f
91a76d3b-0848-4dd1-a5d1-dd57230062ef	XS202312-30	50	5	加厚2-7/8接箍	1	0	250	3_104	110	调质-110KSI	93.9		QJ/DT01.24548-2021-A/0	f
eed7ca4a-0e08-4694-8c1d-374acabd3208	XS202312-32	30.5	1		5	0	6180	4_103	95*22.5	调质-80KSI	248.6		0	t
cc63b86d-34a7-4cfb-9b20-26ec43e1af3c	XS202312-18	12	2	钻杆变扣	1	0	508	3_105	140	调质110KSI	122.9			f
8f9f8113-e487-4ae2-8e94-c5ff09d9e5ae	XS202312-18	12	2	钻杆变扣	2	0	508	3_105	140	调质110KSI	122.9			f
e94dcc7c-f1cd-45cb-915a-5bcb436969d1	XS202312-32	30.5	1		6	0	7900	4_103	108*30	调质-80KSI	455.9		0	t
e4de8351-5d44-4c08-9253-41420936cec4	XS202312-17	12	80	变扣内管	1	0	512	4_102	121*25	调质110KSI	2424.2			f
a9d20f5a-4566-4025-b4ad-fdc568161075	XS202312-17	12	160	挡环	2	0	30	4_102	146*22	调质110KSI	322.9			f
f36f56ba-f90a-4ae4-b2dc-4382b436d440	XS202312-17	12	2	无补偿隔热管	3	0	3010	4_102	98*20	调质110KSI	231.6			f
adb3d679-6787-4d94-b5d0-96bffe1439c1	XS202312-17	12	2	无补偿隔热管	4	0	2700	4_102	121*20	调质110KSI	269			f
ff115eef-acc3-44cf-85c8-5df71fe54beb	XS202312-17	12	4	凸耳座	5	0	122	4_102	159*24	调质110KSI	39			f
016be8b5-7763-4e27-a628-f1743ad1bde1	XS202312-17	33	12	卡瓦架	6	0	267	4_103	219*13	调质-80KSI	211.6			f
f528260c-e187-4bb8-b1b8-7669e1fc214e	XS202312-17	25	2	主体	7	0	603	3_103	220	调质-80KSI	360.1			f
87f7e788-eede-417f-b9ce-6f06e5e90080	XS202312-17	12	2	光管	8	0	810	4_102	121*25	调质-110KSI	95.9			f
81409c6a-38f3-4a8c-9c9c-deed79dd9e52	XS202312-32	68	1		2	0	5940	4_101	178*15	固溶时效，28-32HRC	360.4		0	t
fdfa1827-7159-44e4-8efd-13baee327da5	XS202312-32	68	1		1	0	5935	4_101	178*15	固溶时效，28-32HRC	360.11		0	t
6fdb60fc-2d77-4516-aa40-3b5bcb703d93	XS202312-32	43.8	1		7	0	5185	3_104	230	调质-110KSI	1703.2		0	t
a3b37882-ccc3-4082-ae14-d4101c3bc835	XS202312-32	43.8	1		8	0	5175	3_104	230	调质-110KSI	1699.9		0	t
cd48acf4-76bb-4b53-b9fd-dc87ec082974	XS202312-32	43.8	1		9	0	3465	3_104	230	调质-110KSI	1138.2		0	t
563b8f44-5591-46e0-ab59-6994c202d511	XS202312-32	43.8	3		10	0	5190	3_104	230	调质-110KSI	5114.5		0	t
3ce3f024-5cf3-4299-b455-82477f3486cf	XS202312-32	43.8	1		11	0	5680	3_104	230	调质-110KSI	1865.8		0	t
e639fb5f-0917-4dc3-8857-9462d7c5fe81	FH202312-13	30	1		1	0	380	4_103	133*35	调质-80KSI	32.1	3070668M		f
e33ce93e-0b8f-4fb5-954a-245acef0092e	FH202312-13	30	1	第1.2项重量	2	50.3	190	4_103	133*35	调质-80KSI	16.1	3070668M		f
b2c9fce5-ec52-4e8d-92c2-5b649b4fc453	FH202312-13	30	1		3	214.2	2610	4_103	159*24	调质-80KSI	208.5	3050376M		f
65185d7b-de13-4874-99b8-2957ec9093d5	FH202312-13	30	1		4	196.5	3900	4_103	108*24	调质-80KSI	193.9	3074934M		f
ca0e254c-cf20-4093-a7d0-920a4ee252bc	FH202312-13	30	1		5	130.3	2620	4_103	122*20	调质-80KSI	131.8	2050997M		f
b98a70b0-e335-464e-8e82-88dd33347e64	FH202312-13	32.5	1		6	187.5	3000	4_103	136*21	调质-80KSI	178.7	3074205A		f
41e4aa66-c4ed-4a0b-947b-bf79ff474d58	FH202312-13	32.5	1		7	247	3000	4_103	186*20	调质-80KSI	245.6	3073626A		f
a25bb34d-cae8-442f-ad61-41526d989f80	FH202312-13	30	1		8	0	510	4_103	159*22	调质-80KSI	37.9	2050595M		f
422a9c8d-5023-4170-bada-4ec8c79b2ac1	FH202312-13	30	1	第8.9项重量	9	91	710	4_103	159*22	调质-80KSI	52.8	2050595M		f
0e4c9032-7740-48de-b293-dfe1dc0d4a79	XS202312-36	20	5		4	0	0	4_111	-	-	0			f
4b321d95-c69c-4330-8b6f-c82ce55ac6b8	XS202312-45	45.5	1		1	0	5010	3_104	220	调质-110KSI	1505.7		0	f
910f3405-498c-46bf-adc8-23bcfe432bb2	XS202312-45	45.4	1		2	3048.5	5160	3_104	220	调质-110KSI	1550.8		0	f
df108197-a716-4777-8b41-149a819fc482	XS202312-45	45.4	1		3	1851.6	6770	3_104	210	调质-110KSI	1853.9		0	f
757ef24f-3139-4da4-8e68-93c009b9f2b3	FH2401-005	50	10		1	45	15	3_104	220	调质-110KSI	45.1	23209121074		f
fcea527b-4bdd-4841-bd23-c5176ecc7598	FH2401-008	33	27		1	739.8	237	4_103	195.5*28	调质-80KSI	740.1	3074011M		f
b341cff5-9f89-4d61-9134-4d636b34cf6b	FH2401-011	12	1		1	149.8	1080	3_107	150	热轧	149.9			f
bcb2aa2c-d458-4d58-84ed-857c03255ffd	XS202312-56	50	20	胶筒下压套	1	0	80	3_104	220	调质-110KSI	480.9		QJ/DT01.24548-2021-B/0	f
66ac7ba5-9d5c-4631-b0b7-607b7dd8bb78	XS202312-56	33	16	坐封套	2	0	797	4_103	219*20	调质80KSI	1251.6		XYGN4972-2022-01	f
010528ad-3fcd-41ee-bd97-1cd084d3ff6e	XS202312-56	10	3	变扣接头	3	0	310	3_102	210	退火态	253.1		GB/T 3077-2015	f
8a810ba2-c5e1-4d48-a345-0216161c541e	FH2401-012	50	1		1	95.8	350	3_104	210	调质-110KSI	95.8	21209111769		f
f0dff4dd-d0ef-410b-8e23-5de2a47e71a7	XS202312-56	33	7	弹性卡爪	4	0	380	3_101	210	固溶+时效1100	728.4		ZHSD/JT-20-0136/0	f
09f02f2b-c7fb-4e5b-8e86-cee0228eaf97	XS202312-16	25	25	弹簧上座	5	0	26	3_103	140	调质-80KSI	78.6			t
eded87cd-4d13-42fe-8a9a-81b315907e6f	XS202312-16	25	25	下接头	6	0	425	3_103	170	调质-80KSI	1894.6			t
e6d178ab-19d2-4536-85f8-3eca20b834e0	XS202312-16	25	25	弹簧下座	4	80	36	3_103	120	调质-80KSI	80			t
4b5a9f53-ddaa-4798-aca0-88a30d5b6940	XS202401-05	23	1		1	0	6600	3_103	120	调质-80KSI	1970.9		0	f
517181b3-61d6-4c7c-a1e5-3e2b4e43a73f	XS202401-05	23	1		2	0	6045	3_103	120	调质-80KSI	537.1		0	f
943da12a-e5a1-4c5b-81eb-02e81a0d4c08	FH202312-14	30.5	1		1	1101.8	8260	4_103	219*28	调质-80KSI	1089.3	2055208M		f
297d9675-43e6-4e05-9957-e1e54dc4f90e	FH202312-14	30.5	1		2	0	6270	4_103	95*22.5	调质-80KSI	252.2	3052308M		f
cda0c422-ea73-4920-8a5e-5a4bc21bd696	FH202312-14	30.5	1	第2.3项重量	3	493.7	6180	4_103	95*22.5	调质-80KSI	248.6	3052308M		f
a9dc7212-849a-49dd-8bf2-009707a9e5fa	XS202401-05	23	1		3	1672	6010	3_103	120	调质-80KSI	534		0	f
2b32c91b-9559-402b-b0a3-f297979a5c8c	XS202401-05	11.5	1		4	1155	9650	3_105	140	调质-110KSI	1167		0	f
a0745e47-35bb-45cb-a60b-f8a6736bb2a1	XS202401-05	11.5	1		5	1516	9650	3_105	160	调质110KSI	1524.2		0	f
10b67473-dd9a-41e9-b4db-34c8458df10a	XS202312-34	12	2	坐挂套	2	160.2	764	4_102	159*34	调质110KSI	160.1		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
504e52c2-8b68-446b-ac33-409d0b6b11c1	XS202312-34	25	2	密封限制套	3	21.6	275	3_103	80	调质-80KSI	21.7		QJ/DT01.24412-2020-B/0	t
6b08584f-1b9b-4f01-9600-6c4113abb445	XS202312-42	13	4	变扣	1	355.2	1000	3_105	120	调质110KSI	355.4		XYGN5189.3-2023-01	t
445f7b3e-9a63-4aba-9859-e638c7814eeb	XS202312-21	50	1		1	72	1160	3_104	100	调质-110KSI	72		0	t
ef9dcb8e-950b-40fd-b5e5-02cb4bf8b33a	XS202312-55	75	1	限位键3	5	0	160	4_101	178*15	固溶时效H1100	9.7			t
6e33c994-459b-453c-adb5-5d99b5fe80c3	XS202312-55	33	3	打捞筒	6	0	470	4_103	219*36	调质80KSI	229.1		XYGN4972-2022-01	t
a4c137a3-29f2-4d60-8ffd-df0566562998	XS202312-55	33	1	限位键2	7	0	360	4_103	186*20	调质80KSI	29.5		XYGN4972-2022-01	t
7d34755f-4e3e-4155-8134-334356f95935	XS202312-34	12	2	回接筒	1	175.2	1430	4_102	156*18	调质110KSI	175.2		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
271fc21d-27a1-401c-8da2-7bcc8606a2a9	FH202312-14	30.5	1		4	451	7900	4_103	108*30	调质-80KSI	455.9	3050615M		f
4d754fd6-75c4-4fb6-b1e5-c61a7bd91558	FH202312-14	68	1		5	0	5940	4_101	178*15	固溶时效，28-32HRC	360.4	2MALV21118		f
d03398ec-741b-485a-a744-f2878bd80356	FH2401-037	13	2		1	0	620	3_105	110	调质110KSI	92.6	2031049Z		f
c43edcf4-7ec0-440e-9b0e-220949557c29	XS202312-55	12	16	接箍	8	0	210	4_102	156*18	调质110KSI	205.8		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
d137b2bf-66fc-481f-9d4c-ac1722a4a32f	XS202312-39	33	2	4.5套管接箍	1	0	185	4_103	135*16	调质80KSI	17.4		XYGN4972-2022-01	t
a46940c8-3505-4d3b-8dca-cbfb1909ff6b	FH202312-06	12	1	卡瓦	1	6.5	87	3_110	110	热轧	6.5	179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000		f
f07b43b9-221a-48f8-bdec-4f2ee0459071	XS202312-01	50	1	料头	1	0	0	3_104	220	调质-110KSI	0			f
9a255188-413a-405e-986e-24cd6b37f672	XS202312-39	10	4	打孔40-外连接筒	2	0	310	3_102	105	热轧	84.4		GB/T3077-2015	t
c329b2d8-2cf4-4d41-8dbc-06b13ec5e58c	XS202312-53	330	25	密封套	1	8.9	125	3_109	35	固溶时效	24.8			t
56a8f51a-88b6-4c13-a825-e276f572f6f4	FH2401-037	13	2		2	0	310	3_105	110	调质110KSI	46.3	2031049Z		f
7907766c-a08c-4d22-90af-b0bf8639c0a4	XS202312-55	33	6	胶筒隔环	4	12	15	4_103	219*28	调质80KSI	11.9		XYGN4972-2022-01	t
fa2b2db8-09fa-44eb-ad94-0b0f1cdb8201	FH202312-08	50	1		1	34.6	115	3_104	220	调质-110KSI	34.6	21209122762		f
1d9cd35a-f1bc-41b9-ad25-fc0727b4fd0c	FH202312-09	45	1		1	600.4	6750	3_104	120	调质-110KSI	603.6	23209121037		f
4b581bf7-0cff-41dc-ace7-44cd94c271d8	FH202312-10	11.5	1		1	123	2190	4_102	116*25	调质-110KSI	122.9	623050389ZT		f
4e8a0300-6e24-448b-b8c5-12d4d1438fcc	FH202312-10	11.5	1		2	0	9940	4_102	143*25	调质110KSI	723.1	TZ23-03584LG		f
8893b425-8638-45d9-b105-d5569cfe59c6	FH202312-10	11.5	1		3	1462	9940	4_102	143*25	调质110KSI	723.1	TZ23-03584LG		f
bca119de-1da5-4876-94b9-f5a3b0f8a5d5	XS202312-24	11.5	1	均分3段	1	0	9940	4_102	143*25	调质-110KSI	723.1		0	f
716ab238-255f-4d47-9118-2a7d59862a2f	XS202312-24	11.5	1	均分3段	2	0	9940	4_102	143*25	调质-110KSI	723.1		0	f
ab34124a-1274-4cea-aab5-0803ca501912	XS202312-24	11.5	1		3	0	2190	4_102	116*25	调质110KSI	122.9		0	f
43b5c5b1-36f9-4417-9e54-321d4c6dadd6	XS202312-19	12	1	卡瓦	1	0	87	3_110	110	热轧	6.5			f
8f3f9543-091e-4a0f-94d0-136ffe95bbaa	FH202312-14	68	1	第5.6项重量	6	783	5935	4_101	178*15	固溶时效，28-32HRC	360.1	2MALV21118		f
ff95bfd0-1a1d-4628-8663-95f8227c522d	FH202312-14	43.8	1		7	1697	5185	3_104	230	调质-110KSI	1703.2	22209121255		f
447a6cca-43c9-4e8c-bc94-9db8215aaa5c	FH202312-14	43.8	1		8	0	5190	3_104	230	调质-110KSI	1704.8	22209121255		f
e0fd7b82-7ec6-4641-b421-9039d7a74214	FH202312-14	43.8	1		9	1123	3465	3_104	230	调质-110KSI	1138.2	22209121255		f
a9d61491-b4bc-4060-ac00-6c95fe1fd660	FH202312-14	43.8	1		10	0	5190	3_104	230	调质-110KSI	1704.8	22209121255		f
6a88846f-94a0-4fc0-8749-4dd215399fc8	FH202312-14	43.8	1	第10.11项重量	11	3388.7	5190	3_104	230	调质-110KSI	1704.8	22209121255		f
961c94c1-3e51-44f4-acd4-00879100ac89	XS202312-31	50	1		1	54.4	450	3_104	140	调质-110KSI	54.8		QJ/DT01.24548-2021-A/0	f
aff8dd4d-23e3-4019-96c4-bfdedd99710b	XS202312-31	50	1		2	44.8	505	3_104	120	调质-110KSI	45.2		QJ/DT01.24548-2021-A/0	f
d06c803b-c785-49aa-945a-33cc73c00a85	FH202312-14	43.8	1	第8.12项重量	12	3406.5	5190	3_104	230	调质-110KSI	1704.8	22209121255		f
029feaf5-87c1-4260-9356-663dca86e31c	FH202312-14	43.8	1		13	1857	5680	3_104	230	调质-110KSI	1865.8	23209120491		f
1466327f-0074-42f9-905b-34222b17bca8	FH202312-14	43.8	1		14	1036.2	3440	3_104	220	调质-110KSI	1033.9	23209120039		f
c100f47e-088a-41b0-9505-a316b1353c25	FH202312-14	43.8	1		15	527	7030	3_104	110	调质-110KSI	528.2	22209112176		f
3e569351-3652-444a-9690-b87cae8a8ac0	FH2401-006	13	2		3	25.8	80	3_105	180	调质110KSI	32	2016234Z		f
c1a04f61-3598-48f3-9919-3d4bb2969470	FH2401-006	10	1		4	23.9	80	3_102	220	热轧	23.9	2018358Z		f
6041601f-70f6-4747-b3c3-38d4d75731f1	FH2401-006	12	2		5	318.8	1425	4_102	190*28	调质-110KSI	318.8	TZ23-03586LG		f
204c5bab-a994-4324-ab14-a181e3360c71	XS202312-20	45	1		1	0	6750	3_104	120	调质-110KSI	603.6		0	f
ac7fac0b-ce1d-4f68-8653-19f712ee83a7	CG202312-02	9	0	贲有	1	10000	200	4_102	114*20	调质-110KSI	0		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
5e72c40f-898a-4f3e-8006-d371f2022933	XS202312-67	50	1		1	83	280	3_104	220	调质-110KSI	84.2		0	t
02dbdf8e-ae21-4d99-8ebf-eee83419ee52	XS202312-10	44	1	3435切开	1	0	6100	3_104	120	调质-110KSI	545.4			t
d9cc44c3-eb3e-467e-a85e-d87a261bd3d9	XS202312-10	44	1	3620切开	2	0	6510	3_104	100	调质-110KSI	404.2			t
1a8891dc-92df-4718-84ed-a7ad1e9d6d8d	XS202312-32	43.8	1		12	0	3440	3_104	220	调质-110KSI	1033.9		0	t
16b372ab-a587-49f4-af3e-cd058742d262	XS202312-32	43.8	1		13	0	7030	3_104	110	调质-110KSI	528.2		0	t
a9daeee8-97dd-48e7-b8c2-cbfd413dbd83	XS202312-32	43.8	1		14	0	6575	3_104	120	调质-110KSI	587.9		0	t
deca3494-a604-448e-9e2a-a3e52b89a3f7	XS202312-32	33.5	5		15	0	3450	4_103	203*18	调质-80KSI	1416.5		0	t
9d7005aa-0284-4483-991c-b17dbda5a883	FH202312-14	43.8	1		16	577	6575	3_104	120	调质-110KSI	587.9	23209121037		f
09283e39-8207-42e1-8a83-3d63c100b8fa	FH202312-14	33.5	1		17	0	3450	4_103	203*18	调质-80KSI	283.3	2074733T		f
285aa4c6-e450-4721-b0b3-972148042cef	FH202312-14	33.5	2		18	0	3450	4_103	203*18	调质-80KSI	566.6	2053669M		f
777a3de2-de80-486a-bee1-770d1cddd9f3	FH202312-14	33.5	2	第17.18.19项重量	19	1422.4	3450	4_103	203*18	调质-80KSI	566.6	2053669M		f
bf51ed45-f824-401b-9879-6511315b1d7e	XS202312-10	49.47	1	切定尺	3	0	2426	3_104	100	调质-110KSI	150.6			t
ced9f23f-fa80-49f5-9267-5655c0d40e88	FH2401-016	23	1		1	0	6600	3_103	120	调质-80KSI	586.4	23210023136		f
86e32238-4c5b-4938-ba90-fab49931b4b2	FH202312-17	51.7	1		1	181.2	1500	3_104	140	调质-110KSI	182.6	23209121054		f
fd5122a6-68c9-4cf1-ae7f-a784ba276203	XS202312-37	51.7	1		1	181.2	1500	3_104	140	调质-110KSI	182.6		0	f
8bd40b0b-2822-405a-84e3-fefd93715197	XS202312-51	20	8		5	0	0	4_111	-	-	0			f
5253e000-c2d7-46a1-8c98-016c5a9e9c0f	FH202312-19	13	1		1	21.4	240	3_105	120	调质110KSI	21.3	2031049Z		f
c045fc9e-4919-4738-a591-2fac0f39832c	FH202312-19	13	1		2	29	210	3_105	150	调质110KSI	29.2	3018946Z		f
37124c8a-6f0c-411a-847e-ed0fd308e96e	XS202312-36	11.5	1	3040+余料	1	0	6380	4_102	203*28	调质110KSI	770.9		0	t
9526039c-083b-42ca-ba9c-51db06e44f7b	XS202312-36	12	1		2	0	1520	4_102	203*28	调质110KSI	183.7		0	t
9aa69baa-e67d-4098-8575-475bd3a6f72a	XS202312-36	12	1		3	0	1430	4_102	219*20	调质110KSI	140.3		0	t
361bec07-0f50-4868-a04d-44257eed6a68	FH2401-016	23	1		2	0	6045	3_103	120	调质-80KSI	537.1	23210023136		f
a171f58e-8ca8-431a-9488-6142fb63c0c6	FH2401-016	23	1	第1.2.3项重量	3	1672	6010	3_103	120	调质-80KSI	534	23210023136		f
3b0a1ce7-c444-41ea-b30c-7906b14ff9c6	FH2401-016	11.5	1		4	1155	9650	3_105	140	调质-110KSI	1167	3018947Z		f
f2ccb799-6e17-4d1c-aa92-be042a1a4e60	FH2401-016	11.5	1		5	1516	9650	3_105	160	调质	1524.2	3017454E		f
f4a03834-e57f-4d21-a91a-91d80a065a31	FH2401-018	45	1		1	1023.6	3450	3_104	220	调质-110KSI	1036.9	23209120039		f
a2bd05b1-c0a2-4f9a-ba90-fc1f610b2948	FH2401-018	30.5	1		2	554	7835	4_103	219*13	调质-80KSI	517.4	2MALV21099		f
208ea0f3-cebf-4e25-a9f7-43ec7e5cf551	FH2401-019	25	1		1	220.4	1400	3_103	160	调质-80KSI	221.1	23210010659		f
81ec594a-5646-470f-ba0a-d97c6a28fa5a	FH2401-020	28	1		1	104.7	578	3_108	170	调质-80KSI	103.1	22210023879		f
e0da9dfc-83c2-4636-a822-32e41d4b369c	FH2401-031	44	1		1	552	6100	3_104	120	调质-110KSI	545.4	23209121037		f
aac9661f-0293-40f7-8d99-3905ec8f695b	FH2401-031	44	1		2	403	6510	3_104	100	调质110KSI	404.2	23209121257		f
3236cc8d-889a-4e50-be1f-bed9a3ff4327	XS2401-004	13	2		1	0	620	3_105	110	调质	92.6		0	t
79aa0f36-63db-4fde-b97b-1eae2ad01d1b	XS202312-57	13	2	解封块	3	0	80	3_105	180	调质110KSI	19.3		XYGN5189.3-2023-01	t
c2296f26-b53c-42b3-932e-67b29ddba974	XS202312-52	26.5	1	中间断开	1	638.3	7800	3_108	115	调质-80KSI	636.5		0	t
d207f7c4-030b-48ac-b674-ccfe18043f68	XS202312-51	28	2		2	0	434	3_108	170	调质-80KSI	154.8		0	t
b6204b7d-522c-4ca7-b3b7-02d83a30e90e	XS202312-51	28	2		4	425.3	1886	3_108	135	调质-80KSI	424.2		0	t
6751d4a6-c893-4840-81c0-e8eaeb5913bd	XS202312-51	28	2		3	624.3	768	3_108	170	调质-80KSI	273.9		0	t
6c7eb440-35c0-4500-9274-4805a4b32e4e	XS202312-51	28	2		1	0	534	3_108	170	调质-80KSI	190.4		0	t
87627862-b34f-4227-b480-662f9743ccca	XS202312-43	12	10	下压套	1	114	95	4_102	219*25	调质110KSI	113.6		0	t
c5f5611e-1eb4-4f97-a0d1-ac4647eccad4	CG202312-03	33	0		1	11.9	141260	4_103	159*24	调质80KSI	0		XYGN5203-2022-01	t
e2fd9323-7786-4586-9a78-8c5a9f5f1653	CG202312-04	33	0		1	13.206	97200	4_103	190*35	调质80KSI	0		XYGN5203-2022-01	t
fbf6bf27-be00-44d6-864c-c2137d6a94fa	CG202312-05	33	0		1	7.07	70500	4_103	219*20	调质80KSI	0		XYGN4972-2022-01	t
c8d57727-e0a5-4aa3-a6dc-beb40b04b5ef	XS202312-57	10	1	解封块偏心工装	4	0	80	3_102	220	退火态	23.9		GB/T 3077-2015	t
54b78d83-678d-46b3-b6b0-806a2b157ff5	CG202312-06	33	0		1	3532	18516	4_103	273*32	调质80KSI	0		XYGN4972-2022-01	t
59fdb62d-2865-45a3-a7d2-38e27ff4ee11	XS202312-57	12	2	芯轴	5	0	1425	4_102	190*28	调质-110KSI	318.8		0	t
c1d066b6-14b1-451b-872d-698c6b39ffdb	XS202312-40	50	1	隔环	1	95.8	350	3_104	210	调质-110KSI	95.8		QJ/DT01.24548-2021-B/0	t
20f55203-198c-4164-a2e4-7b0cbfe7018b	XS202312-57	33	3	卡瓦架	1	0	267	4_103	219*13	调质80KSI	52.9		XYGN4972-2022-01	t
15344807-601c-41cb-bd68-4bdadf37f3b3	XS202312-57	13	4	投放杆	2	0	460	3_105	130	调质110KSI	191.9		XYGN5189.3-2023-01	t
3f3c0ca1-1f87-4826-86b2-09fc01e62093	XS202312-41	12	1	卡瓦	1	149.8	1080	3_107	150	热轧	149.9			t
f8301a80-c7d5-476b-aac8-e0c571ef22a4	XS202312-62	12	2	卡爪笼	1	13.2	194	4_102	89*20	调质110KSI	13.2		API SPEC 5CT & FS-T-M-011C	t
6759a12a-73ca-47e5-9f6e-2ada804987df	XS202312-58	50	10	胶筒隔环	1	45	15	3_104	220	调质-110KSI	45.1		QJ/DT01.24548-2021-B/0	t
53af7b77-939d-4e67-8c45-ddaba0f2042a	XS202312-59	50	1	液缸	1	83	278	3_104	220	调质-110KSI	83.5		QJ/DT01.24548-2021-B/0	t
3f00ede0-6caf-46da-bec8-a4cb1aa5c578	XS202312-60	25	2	中心管	2	70.8	990	3_103	80	调质-80KSI	78.2		QJ/DT01.24412-2020-B/0	t
ce733b5a-52fb-417b-83e5-1b3348efab33	XS202312-60	12	1	变扣接头	1	7.1	310	4_102	83*14	调质110KSI	7.4		0	t
c1a917d5-f14c-4614-b307-b1f3d35a92d8	XS202312-61	12	88	下压套	1	1100	95	4_102	219*28	调质110KSI	1102.5		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
ce8fdc22-6cf9-46e5-a544-baefec21e818	FH2401-007	75	1		4	9.6	160	4_101	178*15	固溶时效，28-32HRC	9.7	2MALV21118		f
04dde0ca-616d-481a-aab7-ce3b1201f2ca	FH2401-007	33	3		5	229.2	470	4_103	219*36	调质80KSI	229.1	3074014M		f
222e4809-32db-49d3-8be4-808c5f24ec63	FH2401-007	33	1		6	29.5	360	4_103	186*20	调质-80KSI	29.5	3073626A		f
36d07d19-8199-42fe-83ec-432d9c14d3e0	FH2401-007	12	16		7	206.4	210	4_102	156*18	调质-110KSI	205.8	22504783HL		f
b30fbbdb-3b21-4306-9326-05de18f924e7	FH2401-007	33	6		8	12	15	4_103	219*28	调质-80KSI	11.9	2055208M		f
09a5d8d5-32a6-4f24-a39e-a73c65f77c86	FH2401-009	12	10		1	114	95	4_102	219*25	调质110KSI	113.6			f
2d3bf431-9ccf-45af-bab4-f29b9d154224	FH2401-014	12	2	回接筒	1	175.2	1430	4_102	156*18	调质-110KSI	175.2	22504783HL		f
34012836-6bc4-4bf1-a9e3-1747129154e0	FH2401-014	12	2	坐挂套	2	160.2	764	4_102	159*34	调质-110KSI	160.1	2308235MJL		f
9d085373-a011-4abc-abae-22f920bd132c	FH2401-014	25	1	密封限制套	3	0	275	3_103	80	调质-80KSI	10.9	22209122737		f
b31b2b5a-085f-4dc1-92bc-0d3821550e0f	FH2401-014	25	1	第3.4项重量	4	21.6	275	3_103	80	调质-80KSI	10.9	22209122737		f
ca014070-4096-4df8-9aa0-da05686a8755	XS2401-007	12	2		4	0	3010	4_102	98*20	调质-110KSI	231.6		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
8f3674ea-de08-4d1e-8663-3e553c9de10f	XS2401-007	12	2		5	0	2700	4_102	128*25	调质-110KSI	342.9		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
80049bd3-8b59-44a4-8d48-f0c23a36e4bb	XS2401-007	12	4		6	0	122	4_102	159*24	调质-110KSI	39		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
d9b1d021-b15d-4909-b644-3e56ef907b7f	XS2401-007	33	12		7	0	267	4_103	219*13	调质-80KSI	211.6		XYGN4972-2022-01	t
e87ec6ff-a005-41e3-b5cc-ca3975b151ca	XS2401-007	25	2		8	0	603	3_103	220	调质-80KSI	360.1		QJ/DT01.24412-2020-B/0	t
31339295-b161-4145-b876-3296addcd03c	XS2401-007	12	2		9	0	810	4_102	121*25	调质-110KSI	95.9		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
736b6c46-7366-456b-8959-0eb8fb75f1e2	XS2401-005	28.5	1		10	0	1900	4_103	108*30	调质-80KSI	109.6		0	t
a6ee1e97-4997-46db-bfe4-bce07c2b80f3	XS2401-005	28.5	1		11	0	345	4_103	108*30	调质-80KSI	19.9		0	t
c927e9e0-2768-4bad-afe3-112e64a1daf2	XS2401-005	28.5	1		12	0	8300	4_103	108*30	调质-80KSI	478.9		0	t
aa147494-bdcb-4104-bf17-c2e6efa1a5b4	XS2401-005	21.5	1		13	0	6860	3_103	210	调质-80KSI	1866.6		0	t
4047c5a1-31cf-4d00-9674-405061d8f543	XS2401-005	21.5	1		14	0	8640	3_103	160	调质-80KSI	1364.7		0	t
c9ec9809-c453-449e-a69b-5a9bdc567805	XS2401-005	21.5	1		15	0	7290	3_103	120	调质-80KSI	647.7		0	t
549a842b-f73f-4efc-905b-c602fee3335d	XS2401-005	21.5	1		16	0	5895	3_103	120	调质-80KSI	523.8		0	t
48e35081-22b6-489b-944f-68c7dc6ad1ed	CG2401-003	33	0		7	9.412	94000	4_103	215.9*22.225	调质-80KSI	0		XYGN4972-2022-01	t
86065067-8f48-48ba-80e4-55eadb3b3064	XS202312-21	11	1		2	141	1000	3_110	150	热轧	138.8		0	t
35ff26a2-e675-45d5-be77-9930562ea0c6	FH2401-037	13	2	第1.2.3项重量	3	227	610	3_105	110	调质110KSI	91.1	2031049Z		f
0fdc310d-8621-457e-9e20-a3eaf1a7d9c5	FH2401-023	300	1		1	5	1238	3_109	25	固溶时效120KSI	5	7D70138		f
435a5daa-5dfd-459a-a467-a4b774cacb1b	FH2401-032	50	1		1	141.8	1620	3_104	120	调质-110KSI	144.9	23209121037		f
03473ed0-f6dd-432a-a63b-73a37c4914a2	FH2401-032	50	1		2	100.6	1620	3_104	100	调质110KSI	100.6	23209121257		f
844810ae-992f-4c71-ba61-9b54aa8e4fe2	XS2401-004	13	2		2	0	310	3_105	110	调质	46.3		0	t
ea01b9b1-7a0e-49b5-9a1d-d70860fdd848	XS2401-004	13	2		3	0	610	3_105	110	调质	91.1		0	t
92b22b2d-db48-454f-ac9f-459d02a44228	XS2401-018	17.5	1		1	0	3350	4_107	127*7.52	调质-80KSI	74.2		0	t
c35b3edc-f99f-44a4-8307-feef62eb95bc	XS2401-018	17.5	1		2	0	2150	4_107	127*7.52	调质-80KSI	47.6		0	t
86b3ffee-6af2-4e9b-a5fe-b25ab5b535e2	XS2401-019	11.5	1		1	0	8470	4_102	128*25	调质-110KSI	537.8		0	t
26f16405-ac8b-48ab-a04f-a6d1cd37791a	XS2401-019	11.5	1		2	0	3100	4_102	128*25	调质-110KSI	196.8		0	t
0ad97e19-4d4c-4182-8134-93bb91a29eb2	XS2401-019	11.5	1		3	0	2490	4_102	128*25	调质-110KSI	158.1		0	t
db1d226d-37bc-4c95-b72d-fff8b1dd990c	XS2401-019	11.5	2		4	0	7100	4_102	127*35	调质-110KSI	1127.6		0	t
15521dfa-3782-4038-9b63-2b90617eebd4	XS2401-019	11.5	1		5	0	6570	4_102	146*28	调质-110KSI	535.3		0	t
4d77de24-bf98-4471-abec-2fc8a15210fc	XS2401-019	11.5	1		6	0	6625	4_102	146*28	调质-110KSI	539.8		0	t
fca83b92-7326-4c19-bb74-d5a5e60103ec	XS2401-019	11.5	1		7	0	6660	4_102	146*28	调质-110KSI	542.6		0	t
c004e442-77d3-4577-8929-d7b2fe91c2fa	FH2401-044	25	5		9	161.5	268	3_103	140	调质-80KSI	162	23210010659		f
4692b9a5-7dcb-43f5-8b7e-857e3e2ce6a2	XS2401-027	33	2		1	0	35	3_101	150	固溶+时效1100	9.8		ZHSD/JT-20-0136/0	f
d0eacdbf-4073-423f-ba5c-b0e45063ef73	XS2401-027	12	3		2	0	440	4_102	108*25	调质-110KSI	67.5		0	f
9120c345-8ede-4581-9727-3714c2ecdac1	XS2401-027	12	1		3	0	510	4_102	133*20	调质110KSI	28.4		API SPEC 5CT 10th PSL2 & FS-T-M-011B	f
c0964011-a1c8-4b65-9861-cfac23ef0c2c	XS2401-027	12	1		4	0	2654	4_102	184*20	调质110KSI	214.7		API SPEC 5CT 10th PSL2 & FS-T-M-011B	f
87745ed6-eee2-4bd9-b13e-9d087c043a70	XS2401-027	10	1		5	0	230	3_102	210	退火态	62.6		GB/T 3077-2015	f
9515a003-bed1-45ed-87e9-c58425eb2d5d	XS2401-027	13	1		6	0	810	3_105	110	调质110KSI	60.5		XYGN5189.3-2023-01	f
6e8e4a9e-effd-404e-9a68-8444fb766b30	XS2401-027	12	1		7	0	90	4_102	128*25	调质110KSI	5.7		API SPEC 5CT 10th PSL2 & FS-T-M-011B	f
b56d72f2-68ff-400f-9dc3-651fe3675d14	XS2401-027	10	3		8	0	260	4_102	121*16	热轧	32.3		0	f
3f0a4da3-623b-4b79-8f0e-d6bdd06c7d7d	XS2401-027	12	1		9	0	95	4_102	159*34	调质110KSI	10		API SPEC 5CT 10th PSL2 & FS-T-M-011B	f
856c6014-248a-438f-87ad-3ac12b8ba09c	FH2401-049	13	2	中心管	1	409.4	1694	3_105	140	调质-110KSI	409.7	3018947Z		f
8804bf9f-7c1c-45ae-9c9b-0fedfa8c1c1f	FH2401-051	25	1	第10.11.12.13项重量	13	3652.5	820	3_103	170	调质-80KSI	146.2	23210020566		f
925c967a-e34c-4474-aa36-1e0947b896ca	FH2401-051	25	25		14	77.5	26	3_103	140	调质-80KSI	78.6	23210010659		f
3b0a64ab-1ed7-4325-af3e-7014c0969236	FH2401-051	25	14		15	0	425	3_103	170	调质-80KSI	1061	23210020566		f
ba7f1e3d-b097-4f0d-9a18-196c1a86cc78	XS2401-007	10	80		1	0	350	4_102	139.7*7.72	调质-110KSI	703.5		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
df9404ee-f025-47a2-b467-c544ad81632a	FH2401-010	13	4		1	355.2	1000	3_105	120	调质110KSI	355.4	2031049Z		f
e2786837-4a37-41d7-b813-735af8921ebd	XS202312-68	25	1		2	1669	2125	3_103	80	调质-80KSI	83.9		0	t
a4cdd3a7-d48d-4744-bfc8-27276babcbe1	CG202401-01	9300	0	11月采购	1	5	-800	4_102	114.3*25.4	调质	0		XYGN4018.2-2021-02	f
42934598-4abf-44fd-8f01-50a9394c30e1	XS2401-007	12	80		2	0	512	4_102	121*25	调质-110KSI	2424.2		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
3a17d13b-4fa3-4b7b-9b6b-6a223d91d963	XS2401-007	12	160		3	0	30	4_102	143*25	调质-110KSI	349.2		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
24ee5d4a-e5d8-4d89-8216-1d6743e0d282	XS202312-71	17.5	1		1	89.6	300	3_113	220	退火态	89.6		0	t
cc6bf00f-6273-4753-9a04-cd10b9120ae9	XS202401-01	12	1		1	0	1010	4_102	219*25	调质-110KSI	120.8		0	t
fb000743-349c-4d60-83dc-12a10a984f6b	XS202312-71	11	1		2	1139	9200	4_105	219*25	热轧	1100.3		0	t
89a88983-ca55-41ec-a737-58e0c4f4856f	XS202312-68	25	19		1	0	2112	3_103	80	调质-80KSI	1584.6		0	t
f53323a9-8586-4080-b63e-c88504cc5a13	FH2401-013	33	2		1	17.4	185	4_103	135*16	调质-80KSI	17.4	2016505Z		f
7b5455d9-4643-423a-adb3-688f96db0570	FH2401-013	10	2		2	0	310	3_102	105	未调	42.2			f
192b29d6-3972-4ff6-9e42-8735d3e19315	FH2401-039	11.5	1		1	38	1090	4_102	89*20	调质-110KSI	37.1	TX22-06236LG		f
0f818a18-db56-4542-a733-3545ca0bceee	FH2401-039	11.5	1		2	12.3	208	4_102	116*25	调质-110KSI	11.7	623050389ZT		f
f64e0f0a-5699-42b2-bc1a-fca3b7413fe8	FH2401-040	12	1		1	71	1200	4_102	108*30	调质-110KSI	69.2	623040107ZT		f
3aae09f6-6ff3-4632-86c6-4e18214724d9	FH2401-040	12	1		2	50.6	465	4_102	159*34	调质-110KSI	48.7	2308235MJL		f
653ae155-db39-4a39-869c-97ed6ca31840	XS2401-025	25	2		1	0	915	3_103	150	调质-80KSI	254		QJ/DT01.24412-2020-B/0	f
c9c501fd-1640-47ad-bf1e-960000ee52c1	FH2401-013	10	2	第3.4项重量	3	72	310	3_102	100	未调	38.3			f
27e12f22-27ea-48e7-9779-7f2ef1e0f5f7	XS202312-69	300	1		1	5	1230	3_109	25	固溶时效120KSI	5		0	t
34dc7955-c6d8-415b-b09b-8b73e1bfa4c3	FH2401-015	33	10		1	0	98	4_103	219*28	调质-80KSI	129.2	3072881M		f
2d679041-4ca7-4720-a04a-a1f445e546af	FH2401-015	33	10	第1.2项重量	2	258	98	4_103	219*28	调质-80KSI	129.2	2055208M		f
12d96819-1bd8-4721-821f-cb17442b1b8e	FH2401-015	25	15		3	0	275	3_103	220	调质-80KSI	1231.8	22210023579		f
279903ef-98d6-4516-a7e8-b7eb59e24fd3	FH2401-015	25	5	第3.4项重量	4	1642	275	3_103	220	调质-80KSI	410.6	22210010854		f
c1bffc47-1630-4f2a-ac25-2c5bb5557b1f	XS202312-65	25	6		1	14.8	110	3_103	60	调质-80KSI	14.7		0	t
00f13a4e-ed4b-40fb-9f2a-9d37b81cc349	XS2401-016	330	1		1	5.7	200	3_109	65	固溶时效	5.5		0	t
d71c7cf7-f777-46e5-ac6e-56e0b514a797	CG202312-07	17.5	0		1	6228	7348	4_107	159*35	调质	0		YTG 001-2021	f
e6cda25e-3f6a-4c4a-8323-b3c23c180f77	CG202312-07	17.5	0		2	10566	11203	4_107	135*21	调质	0		YTG 001-2021	t
59195264-0fb6-4538-837e-a50bbeb62291	CG202312-07	17.5	0		3	10772	12688	4_107	162*25	调质	0		YTG 001-2021	t
0027db77-f158-46d0-ad82-db61acefe820	CG202312-07	17.5	0		4	10888	12865	4_107	146*30	调质	0		YTG 001-2021	t
367c91cf-460c-4ed1-91f0-bd74d0d8cd82	CG202312-07	17.5	0		5	8818	22523	4_107	219*20	调质	0		YTG 001-2021	t
e0933730-772d-43ed-90d4-e15f8d749d3c	CG202312-07	17.5	0		6	9340	12305	4_107	178*20	调质	0		YTG 001-2021	t
40d04a82-c5a4-42a7-9ff4-4069d01b8c14	CG202312-07	17.5	0		7	10392	8860	4_107	203*28	调质	0		YTG 001-2021	t
8177fa1d-32ef-4eb7-925e-b8b5e82c51d5	XS2401-021	30	1		1	0	5050	4_103	108*24	调质-80KSI	251.1		0	t
fa4ba6fd-8bf6-4058-85c8-2a30e9731715	FH202401-01	26.5	1		1	638.3	7800	3_108	115	调质-80KSI	636.5	22210023890		f
20914971-dbe4-4f03-9483-08afb41f22b5	FH202401-01	28	2		2	0	534	3_108	170	调质-80KSI	190.4	23210023626		f
d090f178-3724-43bf-a3ef-dcaf770406e6	FH202401-01	28	2		3	0	434	3_108	170	调质-80KSI	154.8	23210023626		f
2eaaae2d-b7c8-4d85-b0a7-7785141f5dbb	FH202401-01	28	2	第1.2.3项重量	4	624.3	768	3_108	170	调质-80KSI	273.9	23210023626		f
c61d1a91-0f44-4f3b-976f-62666fe47fb8	FH202401-01	28	2		5	425.3	1886	3_108	135	调质-80KSI	424.2	22210023890		f
29813b56-6baf-460b-8ed8-ed20746db82b	XS2401-021	30	1		2	511.2	5000	4_103	108*24	调质-80KSI	248.6		0	t
da052598-a407-46b4-bd42-d14bb18e11a3	XS2401-025	25	2		2	0	915	3_103	150	调质-80KSI	254		QJ/DT01.24412-2020-A/0	f
cdf5fdd6-c8ce-4ecc-9e5c-f0bc6a9713c6	XS2401-025	33	4		3	0	197	4_103	110*20	调质80KSI	35		XYGN4972-2022-01	f
fb153f32-76ea-4755-b3db-bf4582249a23	XS2401-025	33	4		4	0	275	4_103	110*20	调质80KSI	48.8		XYGN4972-2022-01	f
7e3fb485-3cac-4568-b0d3-175edbd13386	FH202401-02	26.5	1		1	638.3	7800	3_108	115	调质-80KSI	636.5	22210023890		f
fabc8799-e330-4dda-98a9-0b30b6cc64ad	FH202401-03	13	2		1	567	950	3_105	220	调质110KSI	567.4	2018630Z		f
18844aba-46a5-46ce-a08d-bd52106d8032	FH202401-03	13	2		2	0	4060	3_105	190	调质110KSI	1808.6	3017454Z		f
17e88c43-a525-4165-ae21-61cfe9d82d7d	FH202401-03	13	2	第2.3项重量	3	3576	4060	3_105	190	调质110KSI	1808.6	3017454Z		f
a89451fa-651f-4048-8e95-8ee611c7aa61	FH202401-03	13	5		4	0	810	3_105	160	调质	639.7	3017454E		f
4d5587b5-9f30-45e6-bb55-b4d5ef015f80	FH202401-03	13	1	第4.5项重量	5	765	810	3_105	160	调质	127.9	3017454E		f
44843433-9b5b-4a9d-b6d3-29a4a48ebd3c	FH202401-04	31.5	4		1	0	1530	4_103	108*30	调质-80KSI	353.2	3050615M		f
180c9ac0-19af-47c8-9edb-fb382180006f	FH202401-04	31.5	4		2	0	1530	4_103	108*30	调质-80KSI	353.2	3050615M		f
dde3a79c-17a7-4381-8c47-8bb4e006e89f	FH202401-04	31.5	4		3	0	1530	4_103	108*30	调质-80KSI	353.2	3050615M		f
485b01d2-f278-4e68-abd4-4d4ba06dc8a2	FH202401-04	31.5	4		4	0	1530	4_103	108*30	调质-80KSI	353.2	3050615M		f
a4149bd2-42c0-42f7-a3b2-d1ea37a507ee	FH202401-04	31.5	4		5	0	1530	4_103	108*30	调质-80KSI	353.2	3050615M		f
94f782a3-3046-4567-b0ad-dd52e71cbfac	FH202401-04	31.5	4		6	0	1530	4_103	108*30	调质-80KSI	353.2	3050615M		f
7f3e0173-9fbe-4b01-b201-8a738092edf2	FH202401-04	31.5	4		7	0	1530	4_103	108*30	调质-80KSI	353.2	3050615M		f
c3ae6a8c-c279-448f-9644-a09d175545c8	FH202401-04	31.5	2	第1.2.3.4.5.6.7.8项重量	8	2610	1530	4_103	108*30	调质-80KSI	176.6	3050615M		f
cbe27344-ed25-4409-b270-b43b98d516ad	XS202401-08	30.5	1		2	554	7835	4_103	219*13	调质-80KSI	517.4		0	t
12217999-dceb-4cef-8d4d-8c47c0018ad7	XS202401-04	25	1		1	220.4	1400	3_103	160	调质-80KSI	221.1		0	t
98eec790-81f8-460d-876b-4ae807c8e0af	XS202401-03	46	1		1	32	125	3_101	200	固溶时效	31		0	t
e0c1c738-8b3e-4f3a-a377-e38cf48c08d5	XS202401-02	28	1		1	104.7	578	3_108	170	调质-80KSI	103.1		0	t
4de72aa0-581d-4b81-b8a7-4f849e803d05	XS202401-08	45	1		1	1023.6	3445	3_104	220	调质-110KSI	1035.4		0	t
162b5bda-a62e-46a5-b1f5-75251c3cf345	FH202401-04	31.5	2		9	0	920	4_103	108*30	调质-80KSI	106.2	3050615M		f
37f45d7c-2f95-4991-a801-d1f48145a853	FH202401-04	31.5	2		10	0	920	4_103	108*30	调质-80KSI	106.2	3050615M		f
2729f5d1-9b27-4b3b-8890-c8b848a10614	FH202401-04	31.5	2		11	0	920	4_103	108*30	调质-80KSI	106.2	3050615M		f
64fdd3c0-7626-4369-a1bc-3eca9750eb07	FH202401-04	31.5	2		12	0	920	4_103	108*30	调质-80KSI	106.2	3050615M		f
6f7d1682-d2aa-4c48-82fa-63216cda246d	FH202401-04	31.5	2		13	0	920	4_103	108*30	调质-80KSI	106.2	3050615M		f
74dda709-21e0-4373-a3eb-d6ef3710ac97	FH202401-04	31.5	2		14	0	920	4_103	108*30	调质-80KSI	106.2	3050615M		f
c2473178-def6-4ff5-9385-8baffe15700b	FH202401-04	31.5	2		15	0	920	4_103	108*30	调质-80KSI	106.2	3050615M		f
8d676d17-49fa-43f4-abe2-814ee30b5d96	FH202401-04	31.5	5		16	0	920	4_103	108*30	调质-80KSI	265.4	3050615M		f
c7bfcc98-b619-449c-ace6-267901af076f	FH202401-04	31.5	1	第9.10.11.12.13.14.15.16.17项重量	17	1054	920	4_103	108*30	调质-80KSI	53.1	3050615M		f
dc326573-e022-4c86-b512-a5364b235cf4	FH202401-05	11.5	1	3040+余料	1	835.2	6380	4_102	203*28	调质110KSI	770.9	TX2206530LG		f
c7883137-6378-494c-ae70-394ab8a1096c	FH202401-05	12	1		2	200.6	1520	4_102	203*28	调质110KSI	183.7	TX22-06530LG		f
9e371b34-6db6-4c46-a9eb-6d1535e94985	FH202401-05	12	1		3	145.4	1430	4_102	219*20	调质110KSI	140.3	22704942XG		f
4d183874-79d3-4487-85af-b23e94d7f0e3	XS2401-002	12	11		1	0	1520	4_102	203*28	调质110KSI	2020.3		0	t
993f6b62-14fe-4ab2-b093-43a206cd107a	XS2401-002	12	11		2	0	278	4_102	219*20	调质110KSI	300.1		0	t
fcd2c4b3-457b-4b56-a3bc-0d9f2394e853	XS2401-002	20	22		3	0	0	4_111	-	-	0			t
67b98721-4ee9-4b7e-babd-2140b826be35	XS2401-005	21.5	1		17	0	6810	3_103	120	调质-80KSI	605.1		0	t
0a888e1b-1828-412b-b5ec-9ad24249ed88	XS202312-49	26.5	1		1	1746.5	5835	3_108	220	调质-80KSI	1742.5		0	t
1c62e2ab-f226-4a2f-929e-148f5ad0bfe4	XS202312-49	23	1		2	2054	6880	3_103	220	调质-80KSI	2054.6		0	t
f0da4bbb-5d84-48e5-8641-f1b1f524d76a	XS202312-49	23	1		4	1999	6720	3_103	220	调质-80KSI	2006.8		0	t
ff9e439c-3f33-46dc-8536-e42c4e6da9f0	XS202312-49	23	1		3	1952.5	6580	3_103	220	调质-80KSI	1965		0	t
4a1f6206-2290-41ba-aa6d-bff6c226dc7a	XS2401-005	21.5	1		18	0	6820	3_103	120	调质-80KSI	605.9		0	t
1ab5c9d0-6d0e-46bc-b0cb-880da7976c73	XS2401-005	21.5	1		19	0	7170	3_103	120	调质-80KSI	637		0	t
817f91f3-d10c-4573-b4da-21559248d8e2	XS2401-005	21.5	1		20	0	6645	3_103	120	调质-80KSI	590.4		0	t
25e15d00-95af-4174-b190-81f84c200834	XS2401-005	21.5	1		21	0	4440	3_103	110	调质-80KSI	331.5		0	t
952712ea-36f1-4696-8955-b29f7aa19465	CG2401-003	33	0		3	1.816	24800	4_103	174*18	调质-80KSI	0		XYGN4972-2022-01	t
a5fdcb71-3ab7-4c85-adbd-5c5e0a3f2778	CG2401-003	33	0		4	2.058	31200	4_103	174*18	调质-80KSI	0		XYGN4972-2022-01	t
6df35dbd-61b6-4e44-819d-f428da467ec8	CG2401-003	33	0		5	1.78	25800	4_103	174*18	调质-80KSI	0		XYGN4972-2022-01	t
f15922f5-118d-40b4-beb3-89164a5e6fd3	CG2401-003	33	0		6	9.914	55201	4_103	222.25*41.275	调质-80KSI	0		XYGN4972-2022-01	t
3049561f-f775-481e-97a3-cb3704ad1cb4	XS2401-005	21.5	1		22	0	4240	3_103	110	调质-80KSI	316.5		0	t
95327609-5405-4a37-a5cc-dc223fdc7211	FH2401-025	50	1		1	83	280	3_104	220	调质-110KSI	84.2	23209120492		f
565a60ec-a81b-4eb9-917f-793151a6e4f8	FH2401-027	25	1	第1.2项重量	1	14.8	110	3_103	60	调质-80KSI	2.4	22210021787		f
2135c41f-ea69-4b16-9295-c1d977e7f7b7	XS2401-005	21.5	1		23	0	5155	3_103	110	调质-80KSI	384.9		0	t
cbb9079f-8406-421d-aaac-74164f5dbb27	XS2401-005	21.5	1		24	0	920	3_103	100	调质-80KSI	56.8		0	t
570a6554-9e4f-494e-915c-3fa3b6b41d42	XS2401-005	21.5	1		25	0	3900	3_103	80	调质-80KSI	154		0	t
39f2c6b4-bda4-4cf4-83e1-8fb0273d99ee	XS2401-006	25	1		1	0	2030	3_103	110	调质-80KSI	151.6		0	t
abe72062-3ed6-4fbb-9bcb-17dbe6a139b2	XS2401-006	25	1		2	0	2490	3_103	110	调质-80KSI	185.9		0	t
1bd9b838-39fb-4155-816e-983490e36070	XS2401-006	25	1		3	0	640	3_103	140	调质-80KSI	39.5		0	t
7ed647b5-06c3-40c3-aa63-1ce03e2d714f	XS2401-006	25	2		4	0	2590	3_103	88	调质-80KSI	247.5		0	t
67c912ec-22e9-47a4-8ca5-20b161ddb46f	XS2401-006	33	1		5	0	1265	4_103	140*28	调质-80KSI	97.8		0	t
60d1580c-618d-4b8c-8edf-e7ee34141f81	XS202401-07	50	1		1	160	1000	3_104	160	调质-110KSI	159		0	f
7993b776-fd0d-4afb-8a57-a21515850304	FH2401-033	54	6		1	0	510	3_104	120	调质-110KSI	273.6	23209121037		f
3bc89dc1-8c0b-4611-bd85-0db29e4d4262	FH2401-033	54	5	第1.2项重量	2	501.6	510	3_104	120	调质-110KSI	228	23209121037		f
c039e880-6e4a-4a68-8df8-5febde042fb3	FH2401-033	54	2		3	0	510	3_104	130	调质-110KSI	107	21209120311		f
6fd5adfb-f98c-469e-869d-1c380bbba846	FH2401-033	54	2	第3.4项重量	4	216	510	3_104	130	调质-110KSI	107	21209120311		f
ea887e80-61dd-4165-8174-9ca762ded8f5	FH2401-034	13	2		1	0	620	3_105	110	调质110KSI	92.6	2031049Z		f
631b1665-1825-467b-9a01-3551df000a19	FH2401-034	13	2		2	0	310	3_105	110	调质110KSI	46.3	2031049Z		f
e11d9d56-f6f6-41f6-bd90-eda4eadbcb5a	FH2401-034	13	2	第1.2.3项重量	3	227	610	3_105	110	调质110KSI	91.1	2031049Z		f
f07aaa47-96d6-4728-b253-3a0eef2fa0ea	FH2401-035	13	1		1	99	1600	3_105	100	调质110KSI	98.7	3030153Z		f
d612eb40-e0b7-42b9-aaac-bbd25b375b52	FH2401-036	11.5	1		1	38	1090	4_102	89*20	调质-110KSI	37.1	TX22-06236LG		f
d7e828b1-f65a-48af-b3b6-b0bd057cde96	FH2401-036	11.5	1		2	12.3	208	4_102	116*25	调质-110KSI	11.7	623050389ZT		f
025058ad-bd59-4df1-9b28-efa5581cfddc	FH202401-06	25	1		1	73	1180	3_103	100	调质-80KSI	72.8	23210023179		f
817e236e-cb0e-41ca-b4f5-252ab62a14fe	FH202401-06	25	1		2	63	1600	3_103	80	调质-80KSI	63.2	22209122737		f
aabba7e0-2e43-46e1-87a1-4ce9cb92ec62	FH202401-06	25	5		3	233	1180	3_103	80	调质-80KSI	233	22209122737		f
500e5d3a-5988-4981-a803-f17919355b51	FH202401-06	25	1		4	157	1740	3_103	120	调质-80KSI	154.6	23210023136		f
927bed8a-fa34-43d7-8c49-fedbb60e362a	FH202401-06	25	1		5	109.7	1220	3_103	120	调质-80KSI	108.4	23210023136		f
97b629fc-0b1f-43d4-8914-191ddeacc053	FH202401-06	25	1		6	193.8	2150	3_103	120	调质-80KSI	191	23210023136		f
fc287075-cad9-4512-9748-3daac892cbd6	FH202401-06	25	1		7	83	3730	3_103	60	调质-80KSI	82.9	22210021787		f
85810501-32e1-43ec-b5e6-cb144c189208	XS202312-66	50	1	2023-12-29收款1835元	1	36.7	440	3_104	115	调质-110KSI	36.1		0	t
189f1f00-58ca-4737-939a-b94506c9b7fa	CG2401-003	33	0		1	2.642	22200	4_103	222.25*25.4	调质-80KSI	0		XYGN4972-2022-01	t
4707f9af-b5ba-453f-a777-8be89d866479	CG2401-003	33	0		2	9.988	79200	4_103	222.25*25.4	调质-80KSI	0		XYGN4972-2022-01	t
ba9b46b9-793c-4bdd-a5b2-28690ea149a7	XS2401-013	25	12		1	0	603	3_103	220	调质-80KSI	2160.9		QJ/DT01.24412-2020-A/0	f
8b28d028-eff6-4d9b-ae63-d846d838c428	XS2401-013	12	7		2	0	1467	4_102	180*25	调质110KSI	1777.7		API SPEC 5CT 10th PSL2 & FS-T-M-011B	f
9c3e007f-bf4b-496e-a5d9-72a97f211217	XS2401-013	50	20		3	0	560	3_104	170	调质-110KSI	2009.9		QJ/DT01.24548-2021-B/0	f
cee10a5f-1d5b-402d-a90f-aa0ea33fd5cd	XS2401-013	33	20		4	0	990	3_103	80	调质-80KSI	781.9		QJ/DT01.24412-2020-B/0	f
8c2517e0-0fed-4a01-b8f4-94cf772827eb	XS2401-013	25	20		5	0	820	3_103	170	调质-80KSI	2924.3		QJ/DT01.24412-2020-B/0	f
3b62065f-c411-4bc1-ab7a-c1b1a2942c5f	XS2401-013	25	20		6	0	35	3_103	120	调质-80KSI	62.2		QJ/DT01.24412-2020-B/0	f
694002bf-61bb-4b43-b0e1-bc8edabe1e44	XS2401-013	25	20		7	0	25	3_103	140	调质-80KSI	60.5		QJ/DT01.24412-2020-B/0	f
2207ea53-1446-42a2-ac31-e910fc448b7f	XS2401-013	25	20		8	0	425	3_103	170	调质-80KSI	1515.7		QJ/DT01.24412-2020-B/0	f
41eaa7ab-246f-4c2f-8761-f593da8c2856	FH2401-041	46	1		1	32	125	3_101	200	固溶时效	31			f
bd610497-64f5-4a04-9bf3-9426de978371	FH2401-024	25	3		1	0	2112	3_103	80	调质-80KSI	250.2	22209122737		f
6d63f27f-fbdf-4a80-949a-c05b0eb1741a	FH2401-024	25	3		2	0	2112	3_103	80	调质-80KSI	250.2	22209122737		f
8b9b3a09-99c4-4ae7-aeb4-17bafcd8e19e	FH2401-024	25	3		3	0	2112	3_103	80	调质-80KSI	250.2	22209122737		f
7dab332c-d69b-43a9-8cac-4e15c5eda7ae	FH2401-024	25	3		4	0	2112	3_103	80	调质-80KSI	250.2	22209122737		f
e762da2d-1cfe-4fd5-9b7a-985cf34c1119	FH2401-024	25	3		5	0	2112	3_103	80	调质-80KSI	250.2	22209122737		f
242148e3-a819-4af3-84e4-3adb4d590846	FH2401-024	25	3		6	0	2112	3_103	80	调质-80KSI	250.2	22209122737		f
45a6dc39-f3ee-4ac9-8eb4-28674d11935d	FH2401-024	25	1		7	0	2112	3_103	80	调质-80KSI	83.4	22209122737		f
3507fc18-6424-4761-8a73-3763721a0375	FH2401-024	25	1		8	1669	2125	3_103	80	调质-80KSI	83.9	22209122737		f
bb96f6f1-8b93-405b-9d1e-a826ee36584d	FH2401-026	50	1		1	36.7	440	3_104	115	调质-110KSI	36.1	2021135317		f
61d8ace5-b6e2-4467-b9cf-4ec31fef32ed	FH2401-029	26.5	1		1	1746.5	5835	3_108	220	调质-80KSI	1742.5	23210023626		f
82928955-649e-4799-9334-a7bf5cd6da10	FH2401-029	23	1		2	2054	6880	3_103	220	调质-80KSI	2054.6	23210020032		f
b44ab0c6-fada-434a-9e54-5b77d08548cd	FH2401-029	23	1		3	1952.5	6580	3_103	220	调质-80KSI	1965	22210010854		f
508e3f96-bfc6-456d-9301-e8f100cc8333	FH2401-029	23	1		4	1999	6720	3_103	220	调质-80KSI	2006.8	22210010854		f
9e77cc2f-53dc-4093-a35b-a1f15a029066	FH2401-030	50	1		1	72	1160	3_104	100	调质110KSI	72	23209121257		f
1fded21a-f1c3-4aa8-9230-9ea3d82d60e2	FH2401-060	21.5	1		13	1863.6	6860	3_103	210	调质-80KSI	1866.6	22210023855		f
ba0c3274-347b-4b24-b58b-f9a29dbe578b	FH2401-060	21.5	1		14	1365.6	8640	3_103	160	调质80KSI	1364.7	23210024195		f
6a9ebcbb-7b50-4160-a433-cafc827fd5bc	FH2401-060	21.5	1		15	0	7290	3_103	120	调质-80KSI	647.7	23210023136		f
1bcca590-9131-4144-b43d-384989588690	FH2401-030	11	1		2	141	1000	3_110	150	热轧	138.8	179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000		f
d29f9739-976b-4530-bfc4-ebecd80f3b4c	CG2401-004	33	0		1	1554	3000	3_101	210	固溶时效	0		ZHSD/JT-20-0136/0+GB/T1220-2007	t
f8cdf8a3-22d9-49cd-b946-1f85ffb1a441	FH2401-042	25	6		1	220.8	305	3_103	140	调质-80KSI	221.3	23210010659		f
f0d22b57-1d68-4f41-9b61-74066291fa85	FH2401-042	25	13		2	666.9	370	3_103	150	调质-80KSI	667.7	23210023328		f
324928a1-4240-45e1-9085-136bb70c833e	FH2401-042	25	5		3	188.5	313	3_103	140	调质-80KSI	189.3	23210010659		f
304dda58-3b5a-4938-9b01-e84f2492e61a	FH2401-042	25	9		4	460.8	325	3_103	160	调质-80KSI	462	23210010659		f
787f25f4-f2c1-4b70-8fa5-949f9d6b64ca	FH2401-042	25	11		5	927.3	535	3_103	160	调质-80KSI	929.5	23210010659		f
1bfe041b-c4c5-4054-aa90-d8adc11524fd	FH2401-042	25	1		6	0	357	3_103	140	调质-80KSI	43.2	23210010659		f
59a77188-a1e7-4a78-adc4-e08cbe8898a4	FH2401-042	25	7	第6.7项重量	7	344	357	3_103	140	调质-80KSI	302.2	23210010659		f
2b207dfb-85b6-400a-8ab4-e0bada2d5395	FH2401-042	25	7		8	301	357	3_103	140	调质-80KSI	302.2	23210010659		f
96cc25ee-1378-4dc8-b86c-ea698183b18c	FH2401-042	25	5		9	161.5	268	3_103	140	调质-80KSI	162	23210010659		f
2aee8b8c-7116-4419-9e2c-d6c6547956bf	XS2401-020	10	5		2	0	0	4_111	-	-	0			f
c0ebbf0e-d7c1-4a1f-8f7a-18295e23e0e3	XS2401-008	13	2		1	0	510	3_105	140	调质110KSI	123.4		0	t
7e76b878-cba2-494c-a62c-4b374a3aef0e	XS2401-008	13	1		2	0	440	3_105	180	调质110KSI	88		0	t
aa5c35e0-cf37-4a41-8865-c73623d39c31	XS2401-020	50	5		1	555.5	920	3_104	140	调质-110KSI	559.8		0	t
4799e9e3-97d5-4b0b-b5ba-6f4bf24b2a6d	XS2401-025	25	2		5	0	915	3_103	150	调质-80KSI	254		QJ/DT01.24412-2020-B/0	f
c5216865-3e21-4deb-9f1d-523f8a86db49	XS2401-025	13	2		6	0	520	3_111	125	热轧	100.3			f
2a9bec91-08a0-4238-a923-4136565e2533	XS2401-025	33	2		7	0	108	4_103	195.5*28	调质80KSI	25		XYGN4972-2022-01	f
c1bd10de-da46-4a75-a63a-220ae3576069	XS2401-025	12	3		8	0	200	3_105	160	调质110KSI	94.8		XYGN5189.3-2023-01	f
00c64f77-cf11-409b-9330-f48458bc2a17	XS2401-025	10	3		9	0	310	3_102	80	退火态	36.7		GB/T 3077-2015	f
6fd69617-3894-47bd-88b7-e969199061b1	XS2401-025	33	3		10	0	850	3_103	60	调质-80KSI	56.6		QJ/DT01.24412-2020-B/0	f
7c46ec45-2740-4fc6-8259-6762ee5228c9	XS2401-001	11.5	1		2	12.3	208	4_102	116*25	调质-110KSI	11.7		0	t
e4df9e13-7d90-4ccf-a4f3-ea99f82fbd26	XS2401-001	11.5	1		1	38	1090	4_102	89*20	调质-110KSI	37.1		0	t
dc59594c-b207-413d-b3ae-4ad6de14df95	FH2401-047	12	2		1	112	460	4_102	203*28	调质110KSI	111.2	TX22-06530LG		f
8d83bf48-1c54-4662-85d4-7155f05f78b2	FH2401-051	25	11	第15.16项重量	16	1892.5	425	3_103	170	调质-80KSI	833.6	23210020566		f
aced2794-d514-490b-8a01-5968e93b2e6b	FH2401-051	25	25		17	80	36	3_103	120	调质-80KSI	80	23210023136		f
5170d28e-6ef1-415b-af43-fdc74e31da20	XS2401-026	330	1		1	0	233	3_109	100	固溶时效	15.1		API STANDARD 6ACRA-2015(2019)	t
676e4747-6b47-4bd0-bd5f-3d371278bd62	FH202401-07	13	1		1	211	955	3_105	190	调质110KSI	212.7	3017454Z		f
91966627-7d37-4363-933c-ea3ccb07e1ec	FH202401-07	13	1		2	686	2315	3_105	220	调质110KSI	691.3	2018630Z		f
3fd759ed-2307-4e12-a90f-ba374526b6b2	FH202401-07	13	1		3	62.3	210	3_105	220	调质110KSI	62.7	2018630Z		f
beddf019-c409-4e4a-b496-42a79f769c71	FH202401-07	13	1		4	115	730	3_105	160	调质	115.3	3017454E		f
7edc2bcd-902f-46d7-bfa0-a186539631c4	FH202401-07	13	1		5	7.2	45	3_105	160	调质	7.1	3017454E		f
fd48c632-4227-4828-82f7-4cddf7ef5963	FH202401-07	13	1		6	67.8	645	3_105	130	调质	67.3	3017454Z		f
63dba859-78c6-4a5a-9222-d0061dc09307	XS2401-005	28.5	1		1	0	870	4_103	150*25	调质-80KSI	67		0	t
2f348510-8827-4f12-a2bc-ae8cf606778c	XS2401-005	28.5	1		2	0	6920	4_103	128*25	调质-80KSI	439.4		0	t
1fbdec22-3997-432d-bb50-cc256e2bdf98	XS2401-005	28.5	1		3	0	5555	4_103	102*22	调质-80KSI	241.1		0	t
db50a2da-7bba-4810-80d2-931bcd8261e1	XS2401-005	28.5	1		4	0	8320	4_103	121*18	调质-80KSI	380.4		0	t
a2a18952-d227-4999-aa8b-646d2fcd9e08	XS202312-44	31.5	20	钢带打捆	1	1054	920	4_103	108*30	调质-80KSI	1061.8		0	f
ec9c92df-b33b-4b97-bae1-9504d484526d	XS202312-44	31.5	30	钢带打捆	2	2610	1530	4_103	108*30	调质-80KSI	2648.6		0	f
ce8272e9-7812-42c8-b194-bfb25d7050c5	XS202401-11	12	2		1	112	460	4_102	203*28	调质110KSI	111.2		API SPEC 5CT & FS-T-M-011C	t
f6f0544a-b741-46a2-800d-d38423dee2d3	CG202401-02	13	0		1	8246	9600	3_105	90	调质110KSI	0		XYGN5189.2-2022-01	t
b6b97514-47c7-4a41-a6d1-48c80b4e13dd	XS202401-10	11	3	卡瓦	1	19.5	87	3_110	110	热轧	19.5		GB/T3077-2015	t
ed7698e8-7eb2-4a0b-bb49-667d4cad323b	XS202312-48	13	1		1	21.4	240	3_105	120	调质110KSI	21.3		0	f
fb378f32-e7b8-4715-bbfa-a56e3d3f8095	XS202312-48	13	1		2	29	210	3_105	150	调质-110KSI	29.2		0	f
531434c6-a0f0-4e8c-b174-05fe00ac4fc3	XS202312-48	20	2		3	0	0	4_111	-	-	0			f
ed284118-d120-4d42-8b85-eb1aeda50b7e	XS202312-12	13	1		1	0	955	3_105	190	调质-110KSI	212.7			f
f51d3b6d-01f7-405b-9771-55d8ec079a2e	XS202312-12	13	1		2	0	2315	3_105	220	调质-110KSI	691.3			f
ecc1cccf-5470-49d8-8cf8-a2ed5e759f7c	XS202312-12	13	1		3	0	210	3_105	220	调质110KSI	62.7			f
a1ca5ac3-e2e3-435d-8ead-fdf9fddd98ea	XS202312-12	13	1		4	0	730	3_105	160	调质110KSI	115.3			f
95eb8f4c-679c-41e6-841c-84ac64a6185f	XS202312-12	13	1		5	0	45	3_105	160	调质110KSI	7.1			f
1a6651d2-69a5-4369-af69-a19b1e04d5fc	XS202312-12	13	1		6	0	645	3_105	130	调质110KSI	67.3			f
8833cc22-f0ff-437d-ac1a-12016c588376	XS202312-12	20	6		7	0	0	4_111	-	-	0			f
9e42a93e-f77f-454c-96ce-0a7c7c4daab8	XS2401-005	28.5	1		5	0	8330	4_103	121*18	调质-80KSI	380.8		0	t
f5ac87d8-22e2-4081-9937-07404911da42	XS202401-09	13	2	中心管	1	409.4	1694	3_105	140	调质-110KSI	409.7		XYGN5189.2-2022-01	t
5eef0fa1-a253-4890-ad29-a19d83c7dea4	FH2401-017	50	1		1	160	1000	3_104	160	调质-110KSI	159	23209121074		f
e2dd661d-e942-4b3f-a065-0fced3e7c044	FH2401-021	17.5	1		1	89.6	300	3_113	220	退火态	89.6	3075357M		f
d20378c3-9cc8-4610-b053-88ab51f9b783	FH2401-021	11	1		2	1139	9200	4_105	219*25	热轧	1100.3	2016314F		f
a8320015-b29e-415d-aa20-93a8d5a5e6a5	XS2401-005	28.5	1		6	0	6200	4_103	106*18	调质-80KSI	242.2		0	t
495901f7-c6fd-4c3d-9be0-2fe0893cf30c	XS2401-005	28.5	1		7	0	6200	4_103	106*18	调质-80KSI	242.2		0	t
2005ae70-085d-456b-9cea-bd6070c9ec41	XS2401-005	28.5	1		8	0	4390	4_103	110*20	调质-80KSI	194.9		0	t
3ed7aa42-280a-40e9-bd76-0c61bf4bf3d6	XS202312-15	50	1	切	1	0	3000	3_104	120	调质-110KSI	268.2			f
4e395512-5208-4f51-bfe8-e7ed5625ee0e	XS202312-15	45	1	整支	2	0	2940	3_104	140	调质-110KSI	357.8			f
590f1443-fd07-4d54-9ffd-add5e7cf7ecb	XS202312-15	50	1	切	3	0	5000	3_104	155	调质-110KSI	745.9			f
a1999516-214f-4e7e-bb82-8648168700af	XS202312-15	50	1	切	4	0	4200	3_104	170	调质-110KSI	753.7			f
89d15479-89f8-439b-9584-aeddbaeaff0d	XS202312-15	50	1	切	5	0	1000	3_104	190	调质-110KSI	224.2			f
905a08e8-370d-488a-8528-ed869fbee4ec	XS202312-15	50	1	切	6	0	3500	3_104	200	调质-110KSI	869.3			f
830b8c99-e7e8-40f3-9b39-e2882d97dc4a	XS202312-15	45	1	整支	7	0	6150	3_104	220	调质-110KSI	1848.3			f
e4c35e10-487d-449f-8c81-1ed8353bad96	XS202312-15	50	1	切	8	0	1400	3_104	210	调质-110KSI	383.4			f
03b691ab-90ef-47a7-81e0-89bb043b067a	XS202312-35	25	1		1	73	1180	3_103	100	调质-80KSI	72.8		0	f
e9601d31-19f0-432c-8586-cab5e7d9511c	XS202312-35	25	1		2	63	1600	3_103	80	调质-80KSI	63.2		0	f
0a815819-6d79-4322-bde7-259354e78399	XS202312-35	25	5		3	233	1180	3_103	80	调质-80KSI	233		0	f
ff92edb8-8437-425e-940e-8f9109648e4b	XS202312-35	25	1		4	157	1740	3_103	120	调质-80KSI	154.6		0	f
e5a408e5-47d1-4f69-872a-c35ce2dc5312	XS202312-35	25	1		5	109.7	1220	3_103	120	调质-80KSI	108.4		0	f
93fea376-38fe-40c1-9071-9f8e5c15cb3a	XS202312-35	25	1		6	193.8	2150	3_103	120	调质-80KSI	191		0	f
09d00804-65f7-49ac-90d6-1e826cf7e0ca	XS202312-35	25	1		7	83	3730	3_103	60	调质-80KSI	82.9		0	f
f80c80a7-93e8-4f4f-a86b-90ef2e60beea	XS2401-005	28.5	1		9	0	4650	4_103	110*20	调质-80KSI	206.4		0	t
6aae06bc-cb3c-4aa8-9ac9-39a8d1d621ba	FH2401-022	15	2		1	87	500	4_104	158.75*25.4	调质-80KSI	83.5	2200694		f
567857b3-bcde-4a77-a717-a950be7864aa	FH2401-031	49.47	1		3	151	2426	3_104	100	调质110KSI	150.6	23209121257		f
2681d31d-ee72-42e6-8c09-e256aa8d469a	XS202312-70	15	2		1	87	500	4_104	158.75*25.4	调质-80KSI	83.5		0	t
80471e86-b448-4e55-80b9-ccfbb355a79d	XS202401-12	33	1		1	20.1	296	4_103	135*25	调质-80KSI	20.1		XYGN4972-2022-01	t
0b348ebf-2450-4f70-bc3a-8006b4f7b2ce	FH2401-038	13	1		1	99	1600	3_105	100	调质110KSI	98.7	3030153Z		f
9b6c0dba-275f-4684-b396-9f8230d391cd	FH2401-044	25	6		1	220.8	305	3_103	140	调质-80KSI	221.3	23210010659		f
43292fbf-8919-4fee-a007-a4bf9e9d05d5	FH2401-044	25	13		2	666.9	370	3_103	150	调质-80KSI	667.7	23210023328		f
b59597b0-87d3-4700-a3ea-5d2894332c68	XS2401-017	48	2		1	213.6	2030	3_104	92	调质-110KSI	213.4		0	t
59ffddfc-ea06-4b03-9c4d-b7f8f3ab5ea5	FH2401-044	25	5		3	188.5	313	3_103	140	调质-80KSI	189.3	23210010659		f
6d5d8a79-fc58-452f-a65d-6582dc76067f	FH2401-044	25	9		4	460.8	325	3_103	160	调质-80KSI	462	23210010659		f
5aa1ceee-ef0d-4c83-a79c-364b6ddf7ca1	FH2401-044	25	11		5	927.3	535	3_103	160	调质-80KSI	929.5	23210010659		f
8bd1771b-bdc8-4ec2-86ee-2647521e6e4b	FH2401-044	25	1		6	0	357	3_103	140	调质-80KSI	43.2	23210010659		f
5ed4fae5-8736-466a-9393-951b17dcf0e3	FH2401-044	25	7	第6.7项重量	7	344	357	3_103	140	调质-80KSI	302.2	23210010659		f
1f6ac510-3e26-4d05-9cf5-c0e007f66296	FH2401-044	25	7		8	301	357	3_103	140	调质-80KSI	302.2	23210010659		f
9e728f95-7bcf-4466-ad9b-57cc1e3f3b84	XS2401-024	12	3		1	600.6	2457	4_102	146*28	调质-110KSI	600.6		0	t
6b9ca389-ad37-4dbc-947a-400dbda13b72	XS202401-06	12	1		1	0	1200	4_102	108*30	调质-110KSI	69.2		0	f
0e4fd4c3-bf93-4c54-8518-bc9fbb60a885	XS202401-06	12	1		2	0	465	4_102	159*34	调质110KSI	48.7		0	f
635d35c5-e67c-4deb-a787-bb6c0778b74c	XS2401-006	33	1		6	0	560	4_103	116*22	调质-80KSI	28.6		0	t
7425f75b-197d-4e0e-84ea-9ccb23539c3e	XS2401-006	25	1		7	0	2200	3_103	110	调质-80KSI	490		0	t
79cc59a1-6d80-4bdc-ba47-b403127f0848	XS2401-006	25	1		8	0	1305	3_103	110	调质-80KSI	136.1		0	t
c1c135a6-2b2d-4c4a-a215-f03429d96212	XS2401-006	33	1		9	0	650	4_103	95*22.5	调质-80KSI	26.1		0	t
3f3ab9ed-2a26-4c5f-a656-9482ff1b655c	XS2401-006	33	1		10	0	1580	4_103	90*13	调质-80KSI	39		0	t
c41b134e-f259-475f-8b7a-ef46fa176250	XS2401-006	33	1		11	0	934	4_103	80*15	调质-80KSI	22.5		0	t
43b7f34e-2f6a-44a4-87d9-571acd552bb9	XS2401-006	20	10		12	0	0	4_111	-	-	0			t
bb975dfd-3545-4c3f-8122-c3b01517b3f9	XS2401-022	45	1		1	567.1	3810	3_104	155	调质-110KSI	568.4		0	t
8ee9c558-02e6-400e-a10b-f841c1b75f8b	FH2401-043	17.5	1		1	77	3350	4_107	127*7.52	调质-80KSI	74.2	22211303		f
94f93135-0b69-481c-bded-8c414436364b	FH2401-043	17.5	1		2	49	2150	4_107	127*7.52	调质-80KSI	47.6	22211303		f
4a433a34-125d-43af-a43c-40a09b5c58ed	FH2401-045	10	80		1	744	350	4_102	139.7*7.72	调质-110KSI	703.5	000000		f
0e72371b-308e-4f88-a721-ba862d9f9a8a	FH2401-045	12	16		2	0	512	4_102	121*25	调质-110KSI	484.8	622120689ZT		f
2b1f6a36-b9d9-4155-846e-918e42b54f0c	FH2401-045	12	16		3	0	512	4_102	121*25	调质-110KSI	484.8	622120689ZT		f
3fce941e-8c03-4abe-a63f-f94b44766a71	FH2401-045	12	16		4	0	512	4_102	121*25	调质-110KSI	484.8	622120689ZT		f
acfd75a1-49f7-46f6-b7ca-b0a3971c7940	FH2401-045	12	16		5	0	512	4_102	121*25	调质-110KSI	484.8	622120689ZT		f
051173ed-6c13-4dbb-9411-bb0249fa74ed	FH2401-045	12	16	第2.3.4.5.6项重量	6	2560	512	4_102	121*25	调质-110KSI	484.8	622120689ZT		f
ba74f39f-1966-43b8-bf10-fb10951e0534	FH2401-045	12	160		7	348.8	30	4_102	143*25	调质110KSI	349.2	TZ23-03584LG		f
c3518440-1168-4033-bc98-e4733439bab3	FH2401-045	12	2		8	231.6	3010	4_102	98*20	调质110KSI	231.6	623040105ZT		f
78ec52a3-80f8-4dc8-89c4-d64aa0ed784f	FH2401-045	12	2		9	343	2700	4_102	128*25	调质110KSI	342.9	TZ23-03584LG		f
6a4d2109-72b7-4d1c-a7f2-6e146e444d65	FH2401-045	12	4		10	41.2	122	4_102	159*24	调质-110KSI	39	TX22-06533LG		f
a0ae6d93-fd05-4922-8f60-ec27172b8e89	FH2401-045	33	12		11	223.2	267	4_103	219*13	调质-80KSI	211.6	2MALV21099		f
7c975624-5fbc-4688-9dd8-455b0542f561	FH2401-045	25	2		12	380.6	603	3_103	220	调质-80KSI	360.1	22210023579		f
cc81b6b6-fcba-456b-95a7-3435152a3afc	FH2401-045	12	2		13	101.4	810	4_102	121*25	调质-110KSI	95.9	622120689ZT		f
0dd0674c-ea52-4c03-871d-1402f3bdecf4	FH2401-046	33	1	键套	1	20.1	296	4_103	135*25	调质-80KSI	20.1	3070668M		f
b5c6a771-6dda-4a91-b914-f3a28f2f8083	FH2401-048	11	3	卡瓦	1	19.5	87	3_110	110	热轧	19.5	179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000		f
db30801a-bbac-4379-bde8-947e7456068c	FH2401-050	330	9		1	8.9	125	3_109	35	固溶时效120KSI	8.9	1D70645		f
dc8b0ecf-de6b-4b79-83f2-dfb67e1d0ec9	FH2401-051	50	1		1	0	560	3_104	170	调质-110KSI	100.5	22209121261		f
b27141a6-4f67-4f6e-9c71-f43c3e10193f	FH2401-051	50	2		2	0	560	3_104	170	调质-110KSI	201	22209121261		f
15e4fd96-4931-4083-9bf1-244bf4fa87de	FH2401-051	50	10		3	0	560	3_104	170	调质-110KSI	1004.9	22209121261		f
5b75b000-9b84-43b4-ab2d-e5570fb5e4df	FH2401-051	50	10	第1.2.3.4项重量	4	2295.4	560	3_104	170	调质-110KSI	1004.9	22209121261		f
598c2280-9e21-4b0d-90c9-38acd30d1a7c	FH2401-051	25	1		5	0	990	3_103	80	调质-80KSI	39.1	22209122737		f
76c7f49f-996c-4e6e-947d-a34c9a6077cf	FH2401-051	25	5		6	0	990	3_103	80	调质-80KSI	195.5	22209122737		f
5c0f2f9c-e37b-4a42-ad6f-c9c1b8bc388a	FH2401-051	25	6		7	0	990	3_103	80	调质-80KSI	234.6	22209122737		f
65fc2824-23c2-46a7-9005-f300c7a4532a	FH2401-051	25	6		8	0	990	3_103	80	调质-80KSI	234.6	22209122737		f
cbb71caf-428c-455e-a157-10cd8a58c6a3	FH2401-051	25	6	第5.6.7.8.9项重量	9	936	990	3_103	80	调质-80KSI	234.6	22209122737		f
450621ad-11cc-4567-be97-860773fb2c88	FH2401-051	25	8		10	0	820	3_103	170	调质-80KSI	1169.7	22210025474		f
dffb97de-b8a3-458c-b40e-431f9913460d	FH2401-051	25	8		11	0	820	3_103	170	调质-80KSI	1169.7	23210020566		f
0f27178d-cecc-4737-af7d-04cada42297d	FH2401-051	25	8		12	0	820	3_103	170	调质-80KSI	1169.7	22210025474		f
0c7bf817-1787-411f-93c2-123b84f8e302	XS2401-023	330	1		1	0	450	3_109	138	固溶时效120KSI	55.5		0	f
34f5b456-abee-4585-815e-eb7dd70cf15b	XS2401-023	150	1		2	0	0	4_111	-	-	0			f
73ed53af-979a-423b-a03d-00ad44ef8889	XS2401-010	150	2		3	0	0	4_111	-	-	0			f
37e84b41-f0c3-474d-950b-18f4b0b2daea	XS2401-011	16	1		1	0	8000	4_107	135*21	调质80KSI	472.3		0	f
1610d134-eaf3-412d-8e73-198d72df3671	XS2401-011	16	1		2	0	7920	4_107	135*21	调质80KSI	467.6		0	f
bb41e9fd-3b9c-4e62-ae3c-f4b8a7dedf0d	XS2401-011	16	1		3	0	8020	4_107	135*21	调质80KSI	1273.7		0	f
dee60246-5851-4a3c-afe1-6d8a4d403daa	XS2401-010	330	1		1	0	450	3_109	158	固溶时效120KSI	63.9		0	t
2ecb5e96-828e-4b28-89a5-dab238eb60f2	XS2401-010	330	1		2	0	210	3_109	110	固溶时效120KSI	16.5		0	t
3fcf5c5d-cfca-45cb-b3da-ea5a19c4a881	XS2401-034	30.5	1	中间切断	1	682.2	8720	4_103	150*25	调质-80KSI	672		XYGN4972-2022-01	t
8c1422ca-954e-4ca6-8272-4f2b4e162f90	XS202312-47	30	1		1	960	6610	4_103	184.5*38.5	调质-80KSI	916.2		0	f
149081a0-ce43-4df0-a6b0-a6e48529a574	FH202312-18	30	1		1	960	6610	4_103	184.5*38.5	调质-80KSI	916.2	3074011M		f
63d85125-2c8d-4f91-81ff-de9b44628155	FH2401-052	330	1		1	56.4	450	3_109	138	固溶时效	55.5	3KD70758		f
bb4dea67-8702-46aa-9585-6d2d9922c37b	FH2401-052	150	1		2	0	0	4_111			0			f
f65e7f05-9105-4ac2-b1ae-1d2b51368934	FH2401-053	45	1		1	567.1	3810	3_104	155	调质-110KSI	568.4	23209120311		f
bde42acd-8fae-4d9f-a88b-e70f1b6073b7	FH2401-054	50	5		1	555.5	920	3_104	140	调质-110KSI	559.8	23209121054		f
2fa78e4e-3aee-4312-ab45-9dd148df1e77	FH2401-054	10	5		2	0	0	4_111			0			f
e1a8b27b-ab1c-4ac5-99a4-caecf9d0170a	FH2401-055	11.5	1		1	539.1	8470	4_102	128*25	调质110KSI	537.8	TZ23-03584LG		f
56680dd2-5f54-447a-a550-7aeb67db0d0b	FH2401-055	11.5	1		2	0	3100	4_102	128*25	调质110KSI	196.8	TZ23-03584LG		f
209c868d-11d7-43a9-be77-2df07cf9b57a	FH2401-055	11.5	1	第2.3项重量	3	356	2490	4_102	128*25	调质110KSI	158.1	TZ23-03584LG		f
20863f1d-ed70-4f1d-89fb-4059363bef81	FH2401-055	11.5	1		4	0	7100	4_102	127*35	调质110KSI	563.8	823040121ZT		f
6f965888-c78d-41ff-977b-47fa8077c4f2	FH2401-055	11.5	1	第4.5项重量	5	1138.2	7100	4_102	127*35	调质110KSI	563.8	823040121ZT		f
6c45c408-66ea-4fd2-9ecb-8a713d553056	FH2401-055	11.5	1		6	0	6570	4_102	146*28	调质-110KSI	535.3	TZ23-03583LG		f
74543ba3-1271-4838-9f06-636b375b442e	FH2401-055	11.5	1		7	0	6625	4_102	146*28	调质-110KSI	539.8	TZ23-03583LG		f
b606bb27-067c-4f26-ba57-06a06bb2c628	FH2401-055	11.5	1	第6.7.8项重量	8	1646.3	6660	4_102	146*28	调质-110KSI	542.6	TZ23-03583LG		f
4b34f938-3df6-4316-bf00-932df9521541	FH2401-056	16	1		1	0	8000	4_107	135*21	调质-80KSI	472.3	23215087		f
b8b981aa-a565-479f-8e77-4998efa9d3db	FH2401-056	16	1		2	0	7920	4_107	135*21	调质-80KSI	467.6	23215087		f
8a421bd4-24ff-473e-85a0-d0ee2e4bb798	FH2401-056	16	1	第1.2.3项重量	3	1445.5	8020	4_107	135*21	调质-80KSI	473.5	23215087		f
78ecb76b-9aca-4809-b076-883b1d41f194	FH2401-057	330	1		1	74.1	450	3_109	158	固溶时效	72.8	3KD30256		f
f067bc31-6748-48ee-9691-c49f68871578	FH2401-057	330	1		2	16.6	210	3_109	110	固溶时效	16.5	3KD70740		f
58b40352-d194-4a19-9057-569501cd72c2	FH2401-057	150	2		3	0	0	4_111			0			f
9c6a3f08-a92b-41cc-8a68-f1224499d8a1	FH2401-058	13	2		1	122.7	510	3_105	140	调质-110KSI	123.4	3018947Z		f
a3ffe9bc-fd92-4064-9f5f-8029b1c2f10c	FH2401-058	13	1		2	86.8	440	3_105	180	调质110KSI	88	2018630Z		f
9d92d2f5-8e8c-431e-a40b-42b9e7f9d085	FH2401-059	25	1		1	151.3	2030	3_103	110	调质-80KSI	151.6	23210010659		f
f4776b16-d639-49fb-ad44-7bd97ed083c7	FH2401-059	25	1		2	185.5	2490	3_103	110	调质-80KSI	185.9	23210010659		f
1c804a87-639e-4072-999f-c76f46f56f6f	FH2401-059	25	1		3	77.4	640	3_103	140	调质-80KSI	77.4	23210010659		f
d3d54fcf-b899-451b-af25-f8b5fd04c975	FH2401-059	25	2		4	245	2590	3_103	88	调质-80KSI	247.5	22210025713		f
f2392ab7-c11d-4f66-b8b9-ad4774593151	FH2401-059	33	1		5	100.6	1265	4_103	140*28	调质-80KSI	97.8	3050996M		f
145cae23-b058-498d-9f3a-3ad80c960b50	FH2401-059	33	1		6	29.4	560	4_103	116*22	调质-80KSI	28.6	3072161M		f
5030edd0-82a3-4a88-8ba5-bd9ff1e9934d	FH2401-059	25	1		7	164	2200	3_103	110	调质-80KSI	164.2	23210010659		f
9dfce7c3-0a9e-4585-87b4-49c8d439637f	FH2401-059	25	1		8	97.4	1305	3_103	110	调质-80KSI	97.4	23210010659		f
25504352-1f85-4dde-82c4-2b22fa068bf2	FH2401-059	33	1		9	25.8	650	4_103	95*22.5	调质-80KSI	26.1	3052308M		f
162d38e0-212f-43c8-a2b4-e2b1f902295b	FH2401-059	33	1		10	42	1580	4_103	90*13	调质-80KSI	39	2042973V		f
0f566c23-401d-4675-ba5f-892cb06ed837	FH2401-059	33	1		11	22	934	4_103	80*15	调质-80KSI	22.5	2050705M		f
434890be-c926-40d7-ab31-30105cab82ea	FH2401-059	20	10		12	0	0	4_111			0			f
28533b23-eb6a-4147-a766-fc4ab9c43afe	XS2401-024	12	4		2	676	2074	4_102	146*28	调质-110KSI	675.9		0	t
dfe3c4d3-9e27-4871-9251-c7b38d2545cf	XS2401-014	12	10		1	151	680	3_102	60	调质-110KSI	151		GB/T 3077-2015	t
ceaeef9b-6a9d-43b1-995a-4aa3bddbb59a	XS2401-032	13.5	3		1	687	3200	4_102	121*32	调质-110KSI	674.2		API SPEC 5CT&FS-T-M-011B-3	t
54aee006-095b-4e3e-8e49-17a259b2bb99	XS2401-033	25	1		1	24.9	1120	3_103	60	调质-80KSI	24.9		QJ/DT01.24412-2020-A/0	t
d6735329-d598-46a7-a28e-bdd293b5cb0e	XS2401-033	25	1		2	46.6	2100	3_103	60	调质-80KSI	46.6		QJ/DT01.24412-2020-A/0	t
d590ce69-1add-4234-a103-46685bd86efd	FH2401-060	28.5	1		1	64	870	4_103	150*25	调质-80KSI	67	2055653M		f
bf887d63-e97f-4691-9c82-9be2ae38d4bf	FH2401-060	28.5	1		2	458.9	6920	4_103	128*25	调质-80KSI	439.4	3072161M		f
55b86725-9007-4c5e-9bc8-00809c7e43c3	FH2401-060	28.5	1		3	242.2	5555	4_103	102*22	调质-80KSI	241.1	3052130M		f
f3ae30ef-78eb-4717-8ebf-c8d5a7e81e0d	FH2401-060	28.5	1		4	0	8320	4_103	121*18	调质-80KSI	380.4	2055048M		f
c5442fc0-fdb0-4b47-8db3-5dd268c50f53	FH2401-060	28.5	1	第4.5项重量	5	775.2	8330	4_103	121*18	调质-80KSI	380.8	2055048M		f
13fc8072-9d03-46df-aa01-d8785f44e8c2	FH2401-060	28.5	1		6	0	6200	4_103	106*18	调质-80KSI	242.2	3060076A		f
c8f6d099-acbc-4b86-84ad-932c49a4f367	FH2401-060	28.5	1	第6.7项重量	7	510.4	6200	4_103	106*18	调质-80KSI	242.2	3060076A		f
65e37c36-5fe4-4bbc-920d-2677303c8da8	FH2401-060	28.5	1		8	0	4650	4_103	110*20	调质-80KSI	206.4	3074934M		f
7cd2b00f-424b-4ce5-b082-82e334bc2967	FH2401-060	28.5	1	第8.9项重量	9	401.5	4390	4_103	110*20	调质-80KSI	194.9	3074934M		f
836bf6c0-32c4-4854-9eaa-803e47749990	FH2401-060	28.5	1		10	105.2	1900	4_103	108*30	调质-80KSI	109.6	3050615M		f
5af865c0-df9f-4ba4-8a09-29486dbcd4ba	FH2401-060	28.5	1		11	15	345	4_103	108*30	调质-80KSI	19.9	3050615M		f
878852e1-d76e-4be1-9a4a-00fe4e7e503b	FH2401-060	28.5	1		12	460.4	8300	4_103	108*30	调质-80KSI	478.9	3050615M		f
10488705-f608-4694-bb8e-871efcb46a37	FH2401-060	21.5	1		16	0	5895	3_103	120	调质-80KSI	523.8	23210023136		f
a6d6f9d5-4ec2-42cd-ae4e-e4f5189e202a	FH2401-060	21.5	1		17	0	6810	3_103	120	调质-80KSI	605.1	23210023136		f
45d99942-bbe2-4b14-b098-d41b83329b1a	FH2401-060	21.5	1		18	0	6820	3_103	120	调质-80KSI	605.9	22210020445		f
bcf03563-79bf-43fe-a6c4-11a1f2e6d8c8	FH2401-060	21.5	1		19	0	7170	3_103	120	调质-80KSI	637	23210023136		f
8c2aa52a-4bdc-48ba-b9a4-1d9a89cde209	FH2401-060	21.5	1	第15.16.1718.19.20项重量	20	3632.2	6645	3_103	120	调质-80KSI	590.4	23210021903		f
2cab7b71-321c-4094-90f8-e6cd00f8a0b9	FH2401-060	21.5	1		21	0	4440	3_103	110	调质-80KSI	331.5	23210010659		f
1ea30c57-3602-432e-8cd6-dc307f1942c8	FH2401-060	21.5	1		22	0	4240	3_103	110	调质-80KSI	316.5	23210010659		f
ecd60859-53ef-4787-9a59-011799d82b71	FH2401-060	21.5	1	第21.22.23项重量	23	1031.3	5155	3_103	110	调质-80KSI	384.9	23210023205		f
eb60c3e5-53e3-4b47-9cae-2ea98abffeb3	FH2401-060	21.5	1		24	57	920	3_103	100	调质-80KSI	56.8	22209120311		f
7b4f5057-08f6-44a5-84d3-4bb4bcd49a4b	FH2401-060	21.5	1		25	154.5	3900	3_103	80	调质-80KSI	154	22209122737		f
5e9d6650-5100-4645-89f1-09c42e8fb699	FH2401-061	12	2		1	0	1520	4_102	203*28	调质110KSI	367.3	TX22-06530LG		f
afe3c5a9-787a-4b2c-b3f3-41b8b21803e2	FH2401-061	12	4		2	0	1520	4_102	203*28	调质110KSI	734.7	TX2206530LG		f
27a86ca6-1473-46d7-bf33-3dd808addf7a	FH2401-061	12	4		3	0	1520	4_102	203*28	调质110KSI	734.7	TX2206530LG		f
a35be475-c065-42e7-98c4-6a1320e18f3e	FH2401-061	12	1	第1.2.3.4项重量	4	2189	1520	4_102	203*28	调质110KSI	183.7	TX22-06530LG		f
7ee90cd2-eac2-49cc-b4f4-f047dd67d726	FH2401-061	12	11		5	310.2	278	4_102	219*20	调质110KSI	300.1	22704942XG		f
9b7cb3a6-59d7-4b0a-a8b0-ad4d072b2bbd	FH2401-061	20	22		6	0	0	4_111			0			f
1785aecf-e7c9-4a51-bdaa-c3644e15aaed	CG2401-002	13	0		1	4650	27350	3_105	90	调质110KSI	0		XYGN5189.2-2022-01	t
46298a02-a73b-4596-9acc-2af324ec0e26	FH2401-062	30.5	1		1	682.2	8720	4_103	150*25	调质-80KSI	672	3050996M		f
add9d1f9-07c3-4751-ba83-4ae5c314ab71	FH2401-063	330	1		1	14.4	233	3_109	100	固溶时效120KSI	15.1	1D70643		f
146623e7-3767-4279-bd9a-24c1a7db6288	FH2401-064	12	1		1	0	2457	4_102	146*28	调质-110KSI	200.2	TZ23-03583LG		f
c3931d92-1586-469f-93e3-c3fc122d8717	FH2401-064	12	1		2	0	2457	4_102	146*28	调质-110KSI	200.2	TZ23-03583LG		f
a3337e42-21ec-4a75-b8a7-b92212c95b90	FH2401-064	12	1	第1.2.3项重量	3	600.6	2457	4_102	146*28	调质-110KSI	200.2	TZ23-03583LG		f
7a20ee8e-6192-4287-8038-a0b0d5946895	FH2401-064	12	2		4	0	2074	4_102	146*28	调质-110KSI	338	TZ23-03583LG		f
cd283ae2-b61a-40cd-ae9c-f1bc5b18dc52	FH2401-064	12	2	第4.5项重量	5	676	2074	4_102	146*28	调质-110KSI	338	TZ23-03583LG		f
d9c9b7ae-d40f-4057-b07d-7434b21eb9a1	FH2401-065	33	5		1	0	267	4_103	219*13	调质-80KSI	88.2	2MALV21099		f
e83f4faa-7907-456a-b473-cd4827ed5123	FH2401-065	33	3	第1.2项重量	2	140.8	267	4_103	219*13	调质-80KSI	52.9	2MALV21099		f
a69b8a65-8048-49ef-9383-6e8138174d3c	FH2401-066	12	4	上接头	1	0	680	3_102	60	调质-110KSI	60.4	20A1392		f
59f505aa-6fc7-4208-b91c-0e378736e6b5	FH2401-066	12	6	第1.2项重量	2	151	680	3_102	60	调质-110KSI	90.6	20A1392		f
bfe35777-630a-4957-a880-b1fd21d018e9	FH2401-067	25	1	主体	1	180	603	3_103	220	调质-80KSI	180.1	22210010854		f
7724bee5-ed16-4dff-9480-f19b850f07dc	FH2401-067	25	1	主体	2	180	603	3_103	220	调质-80KSI	180.1	22210010854		f
9175a22d-58bd-4c35-84f4-f8abe1786638	XS2401-038	33	5	转换接头	1	0	2010	4_103	140*28	调质80KSI	777.2		XYGN4972-2022-01	t
ddde75f6-41e3-40c4-820b-f73446e20b6e	XS2401-038	12	2	回插工具连接杆	2	0	460	4_102	121*25	调质110KSI	54.4		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
dffe86ee-9907-46b1-82ef-bd7c40ea7e2c	XS2401-037	330	1	短活塞杆	1	0	145	3_109	100	固溶时效	9.4		API STANDARD 6ACRA-2015(2019)	t
eeaadbef-e3fc-46bb-827d-13dc28e038b9	XS2401-035	33	6	流量调节套	1	58.2	327	4_103	95*15	调质80KSI	58.1		XYGN4972-2022-01	t
3bbdb2f5-ead1-4998-adf9-a4b521fbd25a	XS2401-036	25	1		1	82	275	3_103	220	调质-80KSI	82.1		QJ/DT01.24412-2020-B/0	t
9b8c87af-d84c-4835-9bbb-37f365fa3539	XS2401-041	33	4		1	392	1874	4_103	116*22	调质-80KSI	382.3		XYGN4972-2022-01	t
3ab2f087-f615-4a94-8f18-f150e0a942c6	XS2401-041	33	4		2	246.9	800	4_103	143*25	调质-80KSI	232.8		XYGN4972-2022-01	t
a1e800dd-3a44-4ec8-93a3-cfb422f41fe7	XS2401-049	20	1		1	0	6010	3_103	180	调质-80KSI	1201.4		QJ/DT01.24412-2020-A/0	f
3df092f0-a03f-48e1-b974-ba7f99fbbcdc	XS2401-049	20	1		2	0	5785	3_103	180	调质-80KSI	1156.5		QJ/DT01.24412-2020-A/0	f
8775395e-c458-4389-9e01-7dc82e0f2a67	XS2401-049	20	1		3	0	6740	3_103	180	调质-80KSI	1347.4		QJ/DT01.24412-2020-A/0	f
b701d383-6fbe-45d7-8559-11b7c9719c79	XS2401-049	20	1		4	0	6875	3_103	180	调质-80KSI	1374.4		QJ/DT01.24412-2020-A/0	f
c1ce53d8-eb7b-4a38-a88a-f66ef5065add	XS2401-049	20	1		5	0	6870	3_103	180	调质-80KSI	1373.4		QJ/DT01.24412-2020-A/0	f
d24abcdc-78fc-446c-8791-614d65800eb1	XS2401-049	20	1		6	0	6285	3_103	180	调质-80KSI	1256.4		QJ/DT01.24412-2020-A/0	f
35fc4474-6b4f-4b9e-b172-6841a50845a3	XS2401-049	20	1		7	0	6715	3_103	170	调质-80KSI	1197.4		QJ/DT01.24412-2020-A/0	f
944dcca4-e755-4953-9437-a65fae9b01ee	XS2401-049	20	1		8	0	6730	3_103	170	调质-80KSI	1200		QJ/DT01.24412-2020-A/0	f
8ae421b4-f566-485f-b2e9-985013509564	XS2401-049	20	1		9	0	9100	3_103	160	调质-80KSI	1437.4		QJ/DT01.24412-2020-A/0	f
77d3664d-b519-4e7d-b4a3-8502d5f31db5	XS2401-049	20	1		10	0	8680	3_103	160	调质-80KSI	1371		QJ/DT01.24412-2020-A/0	f
df40b169-da58-43af-9d08-0bd0315831b9	XS2401-049	20	1		11	0	8740	3_103	160	调质-80KSI	1380.5		QJ/DT01.24412-2020-A/0	f
3761e022-a99a-4038-9b04-5abcbc2275f1	XS2401-049	20	1		12	0	8070	3_103	160	调质-80KSI	1274.7		QJ/DT01.24412-2020-A/0	f
448fda3e-833c-4b32-9668-ab354707dae9	XS2401-049	20	1		13	0	8065	3_103	160	调质-80KSI	1273.9		QJ-DT01.24412-2020-B/0	f
302c8b56-e10e-4913-81b4-d5f8712febe9	XS2401-049	20	1		14	0	7740	3_103	160	调质-80KSI	1222.5		QJ-DT01.24412-2020-B/0	f
f9544754-9947-427c-bee0-09fe8351d7db	XS2401-049	20	1		15	0	8700	3_103	160	调质-80KSI	1374.2		QJ-DT01.24412-2020-B/0	f
6ce031e8-5ce6-4251-a6d7-58d22bd69c6c	XS2401-049	20	1		16	0	7500	3_103	160	调质-80KSI	1184.6		QJ-DT01.24412-2020-B/0	f
24627f8a-3fe9-4c1c-b62d-fee770d8f08c	XS2401-049	20	1		17	0	7850	3_103	160	调质-80KSI	1239.9		QJ-DT01.24412-2020-B/0	f
0ffe6057-939e-4469-9e77-1b0c8dd53e2f	XS2401-049	20	1		18	0	8830	3_103	160	调质-80KSI	1394.7		QJ-DT01.24412-2020-B/0	f
7b705700-5a20-4a50-b3c0-da6c6fdd7d38	XS2401-049	20	1		19	0	8885	3_103	160	调质-80KSI	1403.4		QJ-DT01.24412-2020-B/0	f
11b3fdf8-d0da-41f9-ab69-12319a658704	XS2401-049	20	1		20	0	9365	3_103	160	调质-80KSI	1479.2		QJ-DT01.24412-2020-B/0	f
06ea9c35-74d7-4ef7-ab0d-f41d3f7adc5e	XS2401-049	20	1		21	0	5710	3_103	150	调质-80KSI	792.7		QJ-DT01.24412-2020-B/0	f
65990a18-5e56-45b5-b26d-6c24c756aff2	XS2401-049	20	1		22	0	6185	3_103	150	调质-80KSI	858.6		QJ/DT01.24412-2020-B/0	f
85eba861-cd7d-48f1-9f56-dee378327368	XS2401-049	20	1		23	0	6065	3_103	150	调质-80KSI	842		QJ/DT01.24412-2020-B/0	f
f560fa4a-f0e7-4cf3-bd6a-0aaaa1454456	XS2401-049	20	1		24	0	5980	3_103	150	调质-80KSI	830.2		QJ/DT01.24412-2020-B/0	f
a71d12e9-6ad0-41c0-8c10-5d4d939506f3	XS2401-049	20	1		25	0	6070	3_103	150	调质-80KSI	842.7		QJ/DT01.24412-2020-B/0	f
c93d7f37-ff04-4aa0-a7be-f29a2a0f84a9	XS2401-049	20	1		26	0	6075	3_103	150	调质-80KSI	843.4		QJ/DT01.24412-2020-B/0	f
133eb4da-71b6-4089-bd5f-3334522d5c3b	XS2401-049	20	1		27	0	5780	3_103	150	调质-80KSI	802.4		QJ/DT01.24412-2020-B/0	f
61e9542b-349a-471e-ab2c-92a91fb91665	XS2401-049	20	1		28	0	6045	3_103	150	调质-80KSI	839.2		QJ/DT01.24412-2020-B/0	f
d4a9d217-2a67-4238-ad32-421c38f3ae4e	XS2401-049	20	1		29	0	6115	3_103	150	调质-80KSI	848.9		QJ/DT01.24412-2020-B/0	f
0fbc9448-8525-4afe-ba66-2e26c239d32d	XS2401-049	20	1		30	0	6070	3_103	150	调质-80KSI	842.7		QJ/DT01.24412-2020-B/0	f
405c3595-2024-4b6f-8a4b-21ec598a45ef	XS2401-049	20	1		31	0	6180	3_103	150	调质-80KSI	857.9		QJ/DT01.24412-2020-B/0	f
d202f286-a0ce-4a01-a922-569b710be03d	XS2401-049	20	1		32	0	6190	3_103	150	调质-80KSI	859.3		QJ/DT01.24412-2020-B/0	f
8c5e584a-b9da-4e50-a57a-15a36872d24e	XS2401-049	20	1		33	0	6260	3_103	150	调质-80KSI	869		QJ/DT01.24412-2020-B/0	f
0d8c1f03-717b-488f-90f9-ef409e10f67e	XS2401-049	20	1		34	0	6200	3_103	150	调质-80KSI	860.7		QJ/DT01.24412-2020-B/0	f
6605f19b-2931-450a-a6de-d3347bd8b3f2	XS2401-049	20	1		35	0	6270	3_103	150	调质-80KSI	870.4		QJ/DT01.24412-2020-B/0	f
f6c52a3d-27a8-449a-8f89-5be987260c2a	XS2401-049	20	1		36	0	5930	3_103	150	调质-80KSI	823.2		QJ/DT01.24412-2020-B/0	f
fb64149e-7865-4be4-b7b5-e22a77a50940	XS2401-049	20	1		37	0	6050	3_103	150	调质-80KSI	839.9		QJ/DT01.24412-2020-B/0	f
9a4b4a68-ad02-4f3b-a13f-5d244c0afb39	XS2401-049	20	1		38	0	6270	3_103	150	调质-80KSI	870.4		QJ/DT01.24412-2020-B/0	f
16ca34ef-77f3-4d9e-af53-36871f695035	XS2401-049	20	1		39	0	6200	3_103	150	调质-80KSI	860.7		QJ/DT01.24412-2020-B/0	f
37c73a50-8bfc-4274-a29a-e67063477659	XS2401-049	20	1		40	0	6070	3_103	150	调质-80KSI	842.7		QJ/DT01.24412-2020-B/0	f
0c23e5b8-9ce2-4e75-97a0-a4402a351e8c	XS2401-049	20	1		41	0	6200	3_103	150	调质-80KSI	860.7		QJ/DT01.24412-2020-B/0	f
cbc24e11-69da-4124-b144-80229f15498c	XS2401-049	20	1		42	0	6270	3_103	150	调质-80KSI	870.4		QJ/DT01.24412-2020-B/0	f
d6f0a343-9298-4047-ba2f-db610e38c169	XS2401-049	20	1		43	0	6270	3_103	150	调质-80KSI	870.4		QJ/DT01.24412-2020-B/0	f
a3cce576-184f-4faa-bee6-f73e3da35027	XS2401-049	20	1		44	0	6200	3_103	150	调质-80KSI	860.7		QJ/DT01.24412-2020-B/0	f
9d44f0c4-f2f9-450a-a9bf-bba85e38fcff	XS2401-049	20	1		45	0	6100	3_103	150	调质-80KSI	846.8		QJ/DT01.24412-2020-B/0	f
acf47ed2-70c3-4b6f-b9e6-66437e314653	XS2401-049	20	1		46	0	5860	3_103	150	调质-80KSI	813.5		QJ/DT01.24412-2020-B/0	f
dcded177-b202-445a-a904-74f9ba4aa7e1	XS2401-049	20	1		47	0	5970	3_103	150	调质-80KSI	828.8		QJ/DT01.24412-2020-B/0	f
d64a4ac9-a3bb-4891-970c-0b6505a365ec	XS2401-049	20	1		48	0	5750	3_103	150	调质-80KSI	798.2		QJ/DT01.24412-2020-B/0	f
4858a65a-8711-4ca2-a0bb-ed206cab11e5	XS2401-049	20	1		49	0	5880	3_103	150	调质-80KSI	816.3		QJ/DT01.24412-2020-B/0	f
c2a7be30-4223-4d64-a3c1-edca94806491	XS2401-049	20	1		50	0	6000	3_103	150	调质-80KSI	833		QJ/DT01.24412-2020-B/0	f
8ed97629-9bc2-4165-b657-a6dd6ea31411	XS2401-049	20	1		51	0	5910	3_103	150	调质-80KSI	820.5		QJ/DT01.24412-2020-B/0	f
5648b1af-4113-4bce-9011-4aa6aeda2cb4	XS2401-049	20	1		52	0	5940	3_103	150	调质-80KSI	824.6		QJ/DT01.24412-2020-B/0	f
d476387e-4dd9-45ba-9b2a-1044d53b7e53	XS2401-049	20	1		53	0	5840	3_103	150	调质-80KSI	810.7		QJ/DT01.24412-2020-B/0	f
21ce3bac-ff40-4c2b-8882-c8337df39c66	XS2401-049	20	1		54	0	6130	3_103	150	调质-80KSI	851		QJ/DT01.24412-2020-B/0	f
c0755ff9-88c7-45d9-91ef-9c545baf7d77	XS2401-049	20	1		55	0	5370	3_103	150	调质-80KSI	745.5		QJ/DT01.24412-2020-B/0	f
be48bca3-2f2e-4cd7-be0d-03e007c3304c	FH2401-068	25	1		1	24.9	1120	3_103	60	调质-80KSI	24.9	22210021787		f
dbc0eeae-a89a-4fb8-a0df-b8879c490e83	FH2401-068	25	1		2	46.6	2100	3_103	60	调质-80KSI	46.6	22210021787		f
2cd8e9a5-cca5-43d9-8ee1-df97b8c013c2	XS2401-044	25	1		1	116.5	740	3_103	160	调质-80KSI	116.9		QJ/DT01.24412-2020-A/0	t
7b51aecb-21ba-4438-a1b6-5ee5d3887df4	XS2401-045	44	1	3225切开	1	611	5810	3_104	130	调质-110KSI	609.7		QJ/DT01.24548-2021-A/0	t
95de6c05-2a61-4056-9c1f-268e08a94b3e	XS2401-045	44	1		2	318.7	2134	3_104	155	调质-110KSI	318.4		QJ/DT01.24548-2021-A/0	t
0db49745-a2d5-4c67-a7ad-8727ff26e723	XS2401-046	25	1		5	74.2	270	3_103	210	调质-80KSI	73.5		QJ/DT01.24412-2020-A/0	t
61f8b5b7-3123-4253-a6c2-eaedc7244b34	XS2401-046	25	1		2	36.3	300	3_103	140	调质-80KSI	36.3		QJ/DT01.24412-2020-A/0	t
651e2c01-c3c1-4d20-8f2c-84c14d223f5c	XS2401-046	25	1		3	44.5	280	3_103	160	调质-80KSI	44.2		QJ/DT01.24412-2020-A/0	t
8d64dd3b-1d07-4c2a-a0ab-21b4f771b52a	XS2401-046	25	1		4	62.2	280	3_103	190	调质-80KSI	62.4		QJ/DT01.24412-2020-A/0	t
8ff4a04e-7824-4cba-bc8d-442d1b17cc40	XS2401-046	25	1		1	31.5	300	3_103	130	调质-80KSI	31.3		QJ/DT01.24412-2020-A/0	t
fd518559-acbc-4022-856f-aad53e5d174d	XS2401-046	25	1		6	155	270	3_103	305	调质-80KSI	155		QJ/DT01.24412-2020-A/0	t
e0056baf-2bfb-4ebb-94c5-f90b453b2c32	XS2401-047	20	4		5	0	0	4_111	-	-	0			f
42d9a7f2-192d-44b1-953e-4fbadd2f56d2	XS2401-047	13	1		2	190.5	640	3_105	220	调质110KSI	191.1		XYGN1992.6-2022-01	t
7efdb8f2-3d2c-4937-af5c-fdfb2496158f	XS2401-047	13	1		1	196	660	3_105	220	调质110KSI	197.1		XYGN1992.6-2022-01	t
c70bac9f-4b95-443e-b677-4d0af64f75f3	XS2401-047	13	1		3	249.8	840	3_105	220	调质110KSI	250.8		XYGN1992.6-2022-01	t
dac59df2-2e44-44e6-8ef0-d54946a4e9e2	XS2401-047	13	1		4	397.7	1340	3_105	220	调质110KSI	400.2		XYGN1992.6-2022-01	t
96ce6f18-cb0c-4876-b91c-a7b8ae303e7e	FH2401-068	17.65	1		3	1125	1835	3_105	310	调质110KSI	1088	3060346A		f
22423da6-a248-4cc5-8005-2e15727ebafe	FH2401-069	30	1		1	0	5050	4_103	108*24	调质-80KSI	251.1	3052130M		f
97a6be75-029a-4db3-8d20-a93bc5a091cd	FH2401-069	30	1	第1.2项重量	2	511.2	5000	4_103	108*24	调质-80KSI	248.6	3052130M		f
bc44b0de-0ae2-4c9e-85e6-ec7ef37a63f1	FH2401-070	48	2		1	213.6	2030	3_104	92	调质-110KSI	213.4	21209111899		f
63f7e03e-628b-4b1f-8a44-45cd6bb4595d	FH2401-071	330	1		1	5.7	200	3_109	65	固溶时效	5.5	3KHD70033		f
ad3eaa94-2760-4e45-ac92-5c8d2d957e44	FH2401-072	31.7	1		1	511.4	7585	4_103	156*18	调质-80KSI	464.6	3071650M		f
5ef68b82-5913-4d1e-819c-bf06cb896b31	FH2401-072	31.7	1		2	248	4040	4_103	156*18	调质-80KSI	247.5	2055585A		f
6d39e928-7fe9-45e6-936b-54de07542777	FH2401-073	11.3	1		1	892	7700	4_102	178*32	调质-110KSI	887.1	TZ23-03328LG		f
2c855b6c-74f3-4bc7-896c-a7e8eba06fb7	FH2401-074	35	1		1	67	410	4_103	219*36	调质80KSI	66.6	3074014M		f
32dc8ad0-df20-4dd8-9456-e2a15517458d	FH2401-075	25	1		1	24.9	1120	3_103	60	调质-80KSI	24.9	22210021787		f
ee85c75a-3d96-45ba-a9ca-b7ad31e19e09	FH2401-075	25	1		2	46.6	2100	3_103	60	调质-80KSI	46.6	22210021787		f
1716021f-a700-426d-b6f4-6e525719e200	FH2401-076	22.5	1		1	446	2830	3_103	160	调质-80KSI	447	23210010659		f
ae2b56d5-a11c-41fd-9a6a-11e097844c2a	FH2401-076	22.5	1		2	0	8910	3_103	160	调质80KSI	1407.4	23210024195		f
0c9d976b-e606-4a1a-826c-7eaf86d6ca63	FH2401-076	22.5	1		3	0	8360	3_103	160	调质80KSI	1320.5	23210024195		f
db837580-d4b2-415e-a7b1-66d7b13c0002	FH2401-076	22.5	1		4	0	8070	3_103	160	调质80KSI	1274.7	23210024195		f
4cc6a1f1-c8f3-4e11-95d5-95f63bc22a88	FH2401-076	22.5	1	第2.3.4.5项重量	5	5418.8	8940	3_103	160	调质80KSI	1412.1	23210024195		f
7c3c3268-18d0-4773-9afa-9c8b9af8821a	FH2401-077	33	1		1	0	2010	4_103	140*28	调质-80KSI	155.4	3050996M		f
8a9edf66-008f-4d53-bf62-5c337d2de282	FH2401-077	33	4	第1.2项重量	2	777.5	2010	4_103	140*28	调质-80KSI	621.8	3050996M		f
cc5aeafd-5a58-425a-8d5e-63ea527c0077	FH2401-077	12	2		3	54.4	460	4_102	121*25	调质-110KSI	54.4	622120689ZT		f
3fd26ddf-1fcc-45ca-8c24-547f05048a7b	FH2401-078	330	1	短活塞杆	1	8.9	145	3_109	100	固溶时效120KSI	9.4	1D70643		f
a4877265-2089-411c-8985-0c9df0a73b4c	FH2401-079	25	1	下连接体	1	82	275	3_103	220	调质-80KSI	82.1	23210020032		f
cd65edd6-34ed-4a65-ad70-7b80d652ffc6	FH2401-080	33	6	流量调节套	1	58.2	327	4_103	95*15	调质-80KSI	58.1	119V-1547		f
da0dc777-126a-47d2-8ef1-f5c019bff00d	XS2401-031	17.65	1		1	1125	1835	3_105	310	调质110KSI	1088		XYGN5189.3-2023-01	f
f0554043-2bd1-4d3d-bcb9-71d2b85885b4	XS2401-030	33	6		1	0	3018	4_103	219*20	调质-80KSI	1777.2		XYGN4972-2022-01	f
aa110aaa-48f4-40a8-913a-b42c6b7f34ce	XS2401-030	20	6		2	0	0	4_111	-	-	0			f
68f95a75-d635-41d0-af2d-0f0486d7c314	XS2401-029	22.5	1		1	446	2830	3_103	160	调质-80KSI	447		QJ/DT01.24412-2020-A/0	f
5f74cf11-a3b5-4ac8-b39f-84189802114f	XS2401-029	22.5	1		2	0	8910	3_103	160	调质-80KSI	1407.4		QJ/DT01.24412-2020-A/0	f
9b44062e-cec8-4d61-9718-1e9044d4dc8e	XS2401-043	12	2		1	204	2200	4_102	114*20	调质-110KSI	204		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
8ca4fec1-3e30-4983-8dce-805b38c477b6	XS2401-040	33	1		1	180.6	4000	3_101	85	固溶时效	179.5		GB/T 1220-2007	f
17c89db5-5f64-4130-86d3-a4317d98e983	FH2401-081	33	1		1	14.7	205	4_103	168*20	调质-80KSI	15	21D0347V		f
fe2bf9cc-58d7-4670-84c2-0150ef2b9ecc	FH2401-082	13	1		1	196	660	3_105	220	调质110KSI	197.1	2018630Z		f
6fcc6e49-87d3-47af-a2be-11f0f41adc8e	FH2401-082	13	1		2	190.5	640	3_105	220	调质110KSI	191.1	2018630Z		f
ed1c49a0-8253-4717-9b00-3164b6b6688a	FH2401-082	13	1		3	249.8	840	3_105	220	调质110KSI	250.8	2018630Z		f
e94bc7c1-469c-4305-b5b2-8a74fa7be2a4	FH2401-082	13	1		4	397.7	1340	3_105	220	调质110KSI	400.2	2018630Z		f
6cf74480-84bc-4c42-8fa6-fab9cff0d54c	FH2401-082	20	4		5	0	0	4_111			0			f
b021b917-0e72-48d0-a3c5-d7d32603ca43	FH2401-083	44	1		1	611	5810	3_104	130	调质-110KSI	609.7	21209120311		f
dd3fa845-bf21-44e6-aff5-c82cf4b3c7a6	FH2401-083	44	1		2	318.7	2134	3_104	155	调质-110KSI	318.4	23209120311		f
a09e1b9c-6eb4-42b8-8f38-e24f067f18af	FH2401-084	12	2		1	204	2200	4_102	114*20	调质-110KSI	204	23E104515YG		f
376689a4-1591-40f5-953c-636e8068f241	FH2401-085	33	2		1	256	1950	4_103	128*25	调质-80KSI	247.6	3072161M		f
b7ebcf51-9bad-41e5-9299-84fd973393c7	FH2401-085	33	1		2	18.5	245	4_103	143*25	调质-80KSI	17.8	2053515M		f
3f8d7b36-8bd8-4a17-ba44-defd8a26eb64	FH2401-085	25	2		3	37	605	3_103	70	调质-80KSI	36.6	22209122737		f
9cf09e90-daea-48df-9600-460a257fbd2c	FH2401-085	25	1		4	56	1840	3_103	70	调质-80KSI	55.6	22209122737		f
8ce6a23f-729f-43ab-82fa-1db08754f24d	FH2401-085	25	1		5	0	1060	3_103	70	调质-80KSI	32	22209122737		f
7b6a34f8-766a-40f6-9f06-2005c4e5a7bb	FH2401-085	25	1	第5.6项重量	6	65	1060	3_103	70	调质-80KSI	32	21209123087		f
b85c792b-a670-4601-86fb-ba3c9283b34f	FH2401-085	20	7		7	0	0	4_111			0			f
cb8aca63-35d8-4d27-812b-364e0d4d74ae	FH2401-086	33	4		1	392	1874	4_103	116*22	调质-80KSI	382.3	3072161M		f
04aa7760-4cc9-4124-95ad-7cf36848156d	FH2401-086	33	4		2	246.9	800	4_103	143*25	调质-80KSI	232.8	3074205A		f
5dd2d514-74d3-4940-95a8-cd1a258fe700	FH2401-087	33	1		1	180.6	4000	3_101	85	固溶时效	179.5	YX2302-2136		f
b952ab9f-c499-4a5d-bf75-5216b77dc2aa	XS2401-048	33	1		1	14.7	205	4_103	168*20	调质-80KSI	15		XTG-JY-C-010-2020	f
2bc5c173-0285-4847-b5a9-4c65f0fcc899	XS2401-042	33	2		1	256	1950	4_103	128*25	调质-80KSI	247.6		XYGN4972-2022-01	f
12e8df6b-5c5a-4e2d-9c62-1fc00f91624c	XS2401-042	33	1		2	18.5	245	4_103	143*25	调质-80KSI	17.8		XYGN4972-2022-01	f
b98e0f54-b703-4f9b-9522-8d3fd5fc0599	XS2401-042	25	2		3	37	605	3_103	70	调质-80KSI	36.6		QJ/DT01.24412-2020-A/0	f
52b3abda-6a35-4e2a-b418-0ead1f16a609	XS2401-042	25	1		4	56	1840	3_103	70	调质-80KSI	55.6		QJ/DT01.24412-2020-A/0	f
185dbf69-61a4-484b-b531-36ce26f3ca60	XS2401-042	25	2		5	65	1060	3_103	70	调质-80KSI	64.1		QJ/DT01.24412-2020-A/0	f
049ab85d-f959-4598-923f-72a760ebb124	XS2401-042	20	7		6	0	0	4_111	-	-	0			f
ca48ad85-d30e-49a7-b52f-fdefde571ffe	XS2401-039	12	1		1	446.2	4200	4_102	168*32		450.7		API SPEC 5CT&FS-T-M-011B-3	f
c23521c7-56ae-4b97-872c-62be1de40bc5	XS2401-039	25	1		2	121.2	4000	3_103	70	调质-80KSI	120.9		QJ/DT01.24412-2020-A/0	f
ca256da4-61f0-4f04-8c1f-104b6189d9e7	XS2401-029	22.5	1		3	0	8360	3_103	160	调质-80KSI	1320.5		QJ/DT01.24412-2020-A/0	f
79ada487-f7e9-4b0e-b1b9-397c27d79433	XS2401-029	22.5	1		4	0	8070	3_103	160	调质-80KSI	1274.7		QJ/DT01.24412-2020-A/0	f
5a253eb0-11a2-42ba-aa00-5db494f24caf	XS2401-029	22.5	1		5	5418.8	8940	3_103	160	调质-80KSI	1412.1		QJ/DT01.24412-2020-A/0	f
7e1039e7-e23d-4227-b776-75e96cceba8b	XS2401-028	35	1		1	0	410	4_103	219*36	调质-80KSI	66.6		XTG-JT-028-2019	f
793c4bcb-065f-46ed-9aa8-d66e4337c7c9	XS2401-009	31.7	1	中间切开	1	511.4	7585	4_103	156*18	调质-80KSI	464.6		0	f
42c1b5b8-182e-4ff9-98d1-d95e838d3386	XS2401-009	31.7	1		2	248	4040	4_103	156*18	调质-80KSI	247.5		0	f
2cea4e46-8a52-48f7-9ee6-537203226485	XS2401-003	13	1		1	0	1600	3_105	100	调质	98.7		0	f
4c0f37c8-4936-42e6-887c-691588697a7c	XS202312-64	25	6	按支销售，单价950元	1	220.8	305	3_103	140	调质-80KSI	221.3		0	f
f5316efd-a712-4afd-a212-490d884eda6e	XS202312-64	25	13	按支销售，单价1305元	2	666.9	370	3_103	150	调质-80KSI	667.7		0	f
42d970e0-fd31-4a47-b5ad-6f0e452d1971	XS202312-64	25	5	按支销售，单价965元	3	188.5	313	3_103	140	调质-80KSI	189.3		0	f
ff743744-2c7b-4a1a-8d59-c5fade12cf19	XS202312-64	25	9	按支销售，单价1305元	4	460.8	325	3_103	160	调质-80KSI	462		0	f
ca946f58-96fe-4b29-b844-14e0e0d91756	XS202312-64	25	11	按支销售，单价2135元	5	927.3	535	3_103	160	调质-80KSI	929.5		0	f
f28a52ad-2f90-413f-acc5-e0f0095cf3ae	XS202312-64	25	8	按支销售，单价1100元	6	0	357	3_103	140	调质-80KSI	345.4		0	f
7af6d2a5-fe6d-4605-81af-e1071097a12c	XS202312-64	25	5	按支销售，单价830元	7	161.5	268	3_103	140	调质-80KSI	162		0	f
b0009142-fec4-4b0e-a5f8-ccd34fbd81e2	XS202312-64	25	7	按支销售，单价1100元	8	645	357	3_103	140	调质-80KSI	302.2		0	f
9f251c96-6894-4f5d-b0e1-ec10c402f6a5	XS202312-09	11.3	1	中间切开	1	0	7700	4_102	178*32	调质-110KSI	887.1			f
1c3ba89a-9967-4511-b8e1-4a94c01c6750	XS202312-63	54	6	按支销售，单价2880元/支。含加工内孔，运费	1	0	510	3_104	120	调质-110KSI	273.6		0	f
759ffd22-6834-41c9-a349-ae39bc169a5f	XS202312-63	54	5	按支销售，单价2880元/支。含加工内孔，运费	2	501.6	510	3_104	120	调质-110KSI	228		0	f
df8f49fa-d398-474b-900f-28b368e17944	XS202312-63	54	2	按支销售，单价3520元/支含加工内孔，运费	3	0	510	3_104	130	调质-110KSI	107		0	f
07cf5fe3-30e3-40f3-a4c0-816bf722ca8b	XS202312-63	54	2	按支销售，单价3360元/支.含加工内孔，运费	4	216	510	3_104	130	调质-110KSI	107		0	f
f90c3cc2-e8c3-4d53-801f-1ef56734a646	CG202312-01	16.429	0	不超过30%短尺可接受	1	5000	0	3_108	80	调质-80KSI	0		QJ/DT01.24669-2021-C/0	t
1f12b635-3780-400b-a4cc-5e181bd631b1	XS2401-053	15	8		1	155	256	4_101	160*22	固溶时效H1100	154.3		XTG-JY-036-2020	t
d3da22dd-d0af-49f0-9f8f-5b412cce8cde	XS2401-050	11.5	1	中间切开	1	0	6540	4_102	108*30	调质-110KSI	377.4		API SPEC 5CT 10th PSL2 & FS-T-M-011B	t
72903a40-886d-49b2-9836-dfa2a3190516	XS2401-052	12	2		1	0	620	4_101	160*22	固溶时效H1100	93.4		XTG-JY-036-2020	f
8bcd7428-efdf-4a3f-852b-f166dda8bc9c	FH2401-090	25	1		1	116.5	740	3_103	160	调质-80KSI	116.9	23210010659		f
9c052bef-9cea-43a0-8444-0cbb9c255fc4	CT2401-001	0	0		0	225.1	5700	3_108	80	调质-80KSI	0			f
c3b4a7a9-0fa9-4049-b0c3-dda204abaa82	FH2401-089	15	8	测试	1	155	256	4_101	160*22	固溶时效H1100	154.3	19D2971V		f
d3d76e26-cbf5-4060-a3fd-0ebf1855dd94	XS2401-054	12	1		1	0	485	4_101	150*10	固溶时效H1100	16.9		ASTM S564/A564M-13	f
7b45dfc5-d7e6-44dc-8f4b-ed74d6baa4e0	XS2401-054	13	2		2	0	222	4_101	160*22	固溶时效H1100	33.5		XTG-JY-036-2020	f
1f6747cb-3ec3-4d47-b22e-ae201e8b4c33	CT2401-002	0	0		1	130.8	2120	3_108	100	调质-80KSI	0			f
76e1d1a3-81bf-4fba-a4a1-66bd03101f2f	CG2401-005	12	0		1	2345	2222	4_101	160*22	固溶时效H1100	0		XTG-JY-036-2020	f
3cfba6a8-2d22-4ecc-96f0-d63c11e1872c	XS2401-051	20	2		1	0	2000	4_101	160*22	固溶时效H1100	301.4		XTG-JY-036-2020	f
c4093040-37a7-4af7-b5c3-bc57962578ef	XS2401-055	12	1		1	0	133	4_101	219*14	固溶时效，28-32HRC	9.5		XTG-JY-C-036-2020	f
c6c4d754-fddd-445d-9de1-115cc83ee5ff	XS2401-056	12	12		1	0	222	4_101	160*22	固溶时效H1100	200.7		XTG-JY-036-2020	f
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents ("单号", "客商id", "日期", "应结金额", "已结金额", "是否含税", "是否欠款", "其他费用", "已记账", "经办人", "备注", "开单时间", "文本字段1", "文本字段2", "文本字段3", "文本字段4", "文本字段5", "文本字段6", "文本字段7", "文本字段8", "文本字段9", "文本字段10", "整数字段1", "整数字段2", "整数字段3", "整数字段4", "整数字段5", "实数字段1", "实数字段2", "实数字段3", "实数字段4", "实数字段5", "布尔字段1", "布尔字段2", "布尔字段3", "类别", "整数字段6", "实数字段6", "文本字段11", "文本字段12") FROM stdin;
FH2401-062	0	2024-01-13	0	0	f	t	0	f	张金宝		2024-01-13 08:03:31.546691	荆州市沙市区318国道银湖工业区B5栋荆州市赛瑞能源技术有限公司		21-WXM-240035		荆州市赛瑞能源技术有限公司	XS2401-034	天津	田学虎	13972331343		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-044	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-10 08:36:54.874545		自提	21-WXM-230751		天津盛杰斯国际贸易有限公司	XS202312-64	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
CK2401-008	25	2024-01-05	0	0	f	t	0	f	唐文静	 	2024-01-05 06:58:16.482067		/upload/pics/pic_CK2401-008.jpg		天津彩虹石油机械有限公司	CHSC-231230	XS202312-16	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-027	25	2024-01-10	5974.5	0	f	f	0	f	唐文静		2024-01-10 09:02:30.731053						CHSC-240109	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
FH2401-049	0	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 09:06:33.086397	 		231254		天津彩虹石油机械有限公司	XS202401-09	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CG2401-003	37	2024-01-17	1241.13	0	f	t	0	f	唐文静		2024-01-17 10:41:16.521743	0200389						天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
FH2401-058	0	2024-01-08	0	0	f	t	0	f	张金宝		2024-01-11 14:25:32.860485	津南区八里台工业园南区春经路	自提	21-WXM-240017		天津鑫威斯特石油机械有限公司	XS2401-008	天津	徐超	15522118082 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-060	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-11 14:26:42.712316	天津市北辰区北仓镇	自提	21-WXM-240014		欧亚汇通（天津）商贸有限公司	XS2401-005	天津	丁总	13512283998		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-061	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-11 14:28:25.112442		自提	21-WXM-240011		山东宏继源石油装备有限公司	XS2401-002	天津	黄蜂			0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-024	25	2024-01-10	15318	0	f	f	0	f	唐文静		2024-01-10 08:18:42.726341						CHSC-230106	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
KT202312-01	0	2023-12-11	0	0	f	t	0	f		专用于库存数据导入, 与后台程序中的 单号id 保持一致	2023-12-11 11:32:04.870424										已审核	0	0	0	0	0	0	0	0	0	0	f	f	t	库存导入	0	0		
CK202401-23	25	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:31:54.486995		/upload/pics/pic_CK202401-23.jpg		天津彩虹石油机械有限公司	CHSC-231225	XS202401-11	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-050	0	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 09:06:52.484645	 		CHSC-231246		天津彩虹石油机械有限公司	XS202312-53	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-046	0	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 09:05:09.119854	 		CHSC-231227		天津彩虹石油机械有限公司	XS202401-12	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-043	0	2024-01-10	0	0	f	t	0	f	张金宝		2024-01-10 08:28:13.115202			21-WXM-240025		天津市克赛斯工贸有限公司	XS2401-018	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-044	25	2024-01-15	0	0	f	t	0	f	唐文静	 	2024-01-15 09:32:01.428124		/upload/pics/pic_CK2401-044.jpg		天津彩虹石油机械有限公司	CHSC-240112	XS2401-037	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-048	66	2024-01-16	495	0	f	f	0	f	张金宝	 	2024-01-16 09:59:06.548143		 		 	 	21-WXM-240046	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-037	78	2024-01-12	0	0	f	t	0	f	唐文静	 	2024-01-12 10:12:44.843942		/upload/pics/pic_CK2401-037.jpg		济南华菱劲通钢管有限公司	21-WXM-240031	XS2401-030	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
CK2401-042	25	2024-01-13	0	0	f	t	0	f	唐文静	 	2024-01-13 13:59:32.893846		/upload/pics/pic_CK2401-042.jpg		天津彩虹石油机械有限公司	CHSC-240108	XS2401-026	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-064	0	2024-01-15	0	0	f	t	0	f	唐文静		2024-01-15 09:22:54.060961	 		CHSC-230106		天津彩虹石油机械有限公司	XS2401-024	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-065	0	2024-01-15	0	0	f	t	0	f	唐文静		2024-01-15 09:23:35.336082	 		CHSC-240104		天津彩虹石油机械有限公司	XS2401-015	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
RK2401-003	0	2024-01-17	0	0	f	t	0	f	唐文静	 	2024-01-17 11:29:50.466686					2024-01-17	CG2401-003	天津			朱玉树	0	0	0	0	0	37610	37611	37770.5	0	0	f	f	t	采购入库	0	0		
XS2401-038	25	2024-01-13	26300.4	0	f	f	0	f	唐文静	 	2024-01-13 14:17:41.318034		 		 	 	CHSC-240113	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
FH202312-01	0	2023-12-18	0	0	f	t	0	f	唐文静		2023-12-17 17:35:07.585773			CHSC-YCLCG-231229	XS202312-01	天津彩虹石油机械有限公司	CK202312-01	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
RK2401-002	0	2024-01-12	0	0	f	t	0	f	唐文静	 	2024-01-12 16:19:19.682161					2024-01-11	CG2401-002	天津			朱玉树	0	0	0	0	0	4650	4653	4682.5	0	0	f	f	t	采购入库	0	0		
CK202401-22	25	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:29:34.464348		/upload/pics/pic_CK202401-22.jpg		天津彩虹石油机械有限公司	240101	XS202401-10	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-025	25	2024-01-10	27316.7	0	f	f	0	f	唐文静		2024-01-10 08:42:20.356328						CHSC-240107	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
FH2401-047	0	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 09:06:04.341705	 		CHSC-231225		天津彩虹石油机械有限公司	XS202401-11	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-040	43	2024-01-16	5923.5	0	f	t	0	t	张金宝	 	2024-01-16 09:37:35.80753		2024-01-15		 	 	21-WXM-240037	天津			张金宝	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-026	25	2024-01-10	4983	0	f	f	0	f	唐文静		2024-01-10 08:43:31.771385						CHSC-240108	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-042	81	2024-01-16	12805.7	0	f	f	0	f	张金宝	 	2024-01-16 09:48:31.180141		 		 	 	21-WXM-240040	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
FH2401-066	0	2024-01-15	0	0	f	t	0	f	唐文静		2024-01-15 09:23:54.348464	 		CHSC-240103		天津彩虹石油机械有限公司	XS2401-014	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-067	0	2024-01-15	0	0	f	t	0	f	唐文静		2024-01-15 09:24:05.687622	 		CHSC-240105		天津彩虹石油机械有限公司	XS2401-012	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-035	25	2024-01-13	1917.3	0	f	f	0	f	唐文静		2024-01-13 14:04:56.375234						CHSC-240110	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-036	25	2024-01-13	2052.5	0	f	f	0	f	唐文静		2024-01-13 14:06:09.24563						CHSC-240111	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CG2401-004	58	2024-01-18	51282	0	f	t	0	f	唐文静		2024-01-18 14:06:25.531418	2024.1-18						天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
XS2401-047	33	2024-01-16	13589.6	0	f	t	0	f	张金宝		2024-01-16 09:58:30.876813						21-WXM-240045	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS202312-13	25	2023-12-19	2558.4	0	f	f	0	f	唐文静	 	2023-12-18 17:44:53.141042		 		 	 	CHSC-YCLCG-231232	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK2401-038	48	2024-01-12	0	0	f	t	0	f	唐文静		2024-01-12 16:21:11.009779		/upload/pics/pic_CK2401-038.jpg		荆州市赛瑞能源技术有限公司	21-WXM-240035	XS2401-034	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-24	25	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:33:29.709447		/upload/pics/pic_CK202401-24.jpg		天津彩虹石油机械有限公司	CHSC-231227	XS202401-12	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-051	0	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 09:08:19.648458	 		CHSC-231230		天津彩虹石油机械有限公司	XS202312-16	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-048	0	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 09:06:17.262389	 		240101		天津彩虹石油机械有限公司	XS202401-10	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-045	0	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 09:04:28.211289	 		CHSC-231231		天津彩虹石油机械有限公司	XS2401-007	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-037	25	2024-01-13	3102	0	f	f	0	f	唐文静		2024-01-13 14:14:49.682945						CHSC-240112	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-041	52	2024-01-12	0	0	f	t	0	f	唐文静		2024-01-12 16:25:47.909734		/upload/pics/pic_CK2401-041.jpg		湖南苏普锐油气装备科技有限公司	21-WXM-240033	XS2401-032	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
CK2401-043	25	2024-01-15	0	0	f	t	0	f	唐文静	 	2024-01-15 09:27:40.650494		/upload/pics/pic_CK2401-043.jpg		天津彩虹石油机械有限公司	CHSC-240113	XS2401-038	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-039	79	2024-01-12	0	0	f	t	0	f	唐文静		2024-01-12 16:23:02.726546		/upload/pics/pic_CK2401-039.jpg		三河市华夏恒泰电子科技有限公司	21-WXM-240032	XS2401-031	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
XS202312-64	60	2023-12-30	81985	0	f	f	0	f	张金宝	 	2023-12-30 05:48:38.11187		 		 	 	21-WXM-230751	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
RK2401-004	0	2024-01-19	0	0	f	t	0	f	唐文静		2024-01-19 11:11:38.143151					2024-01-18	CG2401-004	天津			朱玉树	0	0	0	0	0	1554	1553	1536.2	0	0	f	f	t	采购入库	0	0		
XS202312-14	28	2023-12-19	0	0	f	t	0	f	张金宝	 	2023-12-18 19:34:55.958312		 		 	 	21-WXM-230727	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	商品销售	0	0		
XS2401-023	76	2024-01-09	18465	0	f	f	0	f	张金宝	 	2024-01-09 06:22:16.668291		2024-01-10		 	 	21-WXM-240022	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
FH2401-063	0	2024-01-15	0	0	f	t	0	f	唐文静		2024-01-15 09:21:43.197387	 		CHSC-240108		天津彩虹石油机械有限公司	XS2401-026	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-040	61	2024-01-12	0	0	f	t	0	f	唐文静		2024-01-12 16:24:40.46556		/upload/pics/pic_CK2401-040.jpg		荆州市瑞驰石油机械有限公司	21-WXM-240034	XS2401-033	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-045	25	2024-01-15	0	0	f	t	0	f	唐文静		2024-01-15 09:34:04.444799		/upload/pics/pic_CK2401-045.jpg		天津彩虹石油机械有限公司	CHSC-240111	XS2401-036	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-046	25	2024-01-15	0	0	f	t	0	f	唐文静		2024-01-15 09:35:16.926789		/upload/pics/pic_CK2401-046.jpg		天津彩虹石油机械有限公司	CHSC-240110	XS2401-035	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-043	74	2024-01-16	2448	0	f	t	0	f	张金宝		2024-01-16 09:49:23.507481						21-WXM-240041	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-028	77	2024-01-10	2331	0	f	f	0	f	张金宝	 	2024-01-10 14:27:40.527072		 		 	 	21-WXM-240029	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS202312-42	25	2023-12-23	4620.2	0	f	f	0	f	唐文静		2023-12-22 18:17:20.043989						CHSC-231245	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS2401-041	35	2024-01-16	20298.3	0	f	t	0	f	张金宝		2024-01-16 09:43:28.597307						21-WXM-240039	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-044	82	2024-01-16	2922.5	0	f	t	0	f	张金宝		2024-01-16 09:51:35.883476						21-WXM-240042	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-045	48	2024-01-16	40836.4	0	f	t	0	f	张金宝		2024-01-16 09:52:45.680556						21-WXM-240043	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-046	83	2024-01-16	10067.5	0	f	t	0	f	张金宝		2024-01-16 09:57:21.339332						21-WXM-240044	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-029	28	2024-01-10	131888.25	0	f	t	0	f	张金宝	 收预付款45000元	2024-01-10 14:29:19.974847		 		 	 	21-WXM-240030	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-034	25	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 16:08:17.225442		/upload/pics/pic_CK2401-034.jpg		天津彩虹石油机械有限公司	CHSC-240103	XS2401-014	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-033	25	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 16:04:18.282774		/upload/pics/pic_CK2401-033.jpg		天津彩虹石油机械有限公司	CHSC-240105	XS2401-012	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-053	81	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:21:18.384624		/upload/pics/pic_CK2401-053.jpg		长葛市金博机械化工有限公司 	21-WXM-240040	XS2401-042	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
CK2401-055	80	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:27:40.220638		/upload/pics/pic_CK2401-055.jpg		井星（天津）能源技术有限公司	21-WXM-240036	XS2401-039	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
FH2401-068	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 11:38:13.297313	河北省廊坊市三河市燕郊开发区燕昌路西侧，欧森工业园院内A2厂房		21-WXM-240032		三河市华夏恒泰电子科技有限公司	XS2401-031	天津	田敬辉	15226661859		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-071	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 11:39:10.438039			21-WXM-240021		天津市克赛斯工贸有限公司	XS2401-016	天津				0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-075	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 11:39:53.925087			21-WXM-240034		荆州市瑞驰石油机械有限公司	XS2401-033	天津				0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-030	78	2024-01-11	58767.6	0	f	f	0	f	张金宝	 	2024-01-11 09:33:52.12881		2024-01-11		 	 	21-WXM-240031	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-030	72	2024-01-10	0	0	f	t	0	f	唐文静	 	2024-01-10 15:10:08.528523		/upload/pics/pic_CK2401-030.jpg		陕西众诚汇智油气工程技术有限公司	21-WXM-240019	XS2401-010	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-049	84	2024-01-16	1.10982e+06	0	f	t	0	f	张金宝		2024-01-16 10:44:34.629741						21-WXM-240038	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
CK202312-04	30	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-18 16:18:20.625265		/upload/pics/pic_CK202312-04.jpg		天津顺得来机械工程有限公司 	21-WXM-230722	XS202312-08	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-035	25	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 16:13:10.163561		/upload/pics/pic_CK2401-035.jpg		天津彩虹石油机械有限公司	CHSC-230106	XS2401-024	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-052	0	2024-01-10	0	0	f	t	0	f	张金宝		2024-01-11 14:17:38.222614	河北省廊坊市大厂县潮白河工业区正景自动化有限公司6号厂房南端	安能到付	21-WXM-240022		北京乐富特科技有限公司	XS2401-023	天津	彭通	13311300432		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-050	45	2024-01-16	4340.1	0	f	t	0	f	张金宝		2024-01-16 11:37:41.150951						21-WXM-240047	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
CK2401-054	35	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:24:22.346483		/upload/pics/pic_CK2401-054.jpg		荆州诚达石油工具有限公司	21-WXM-240039	XS2401-041	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-031	28	2024-01-10	0	0	f	t	0	f	唐文静		2024-01-10 15:50:26.912037		/upload/pics/pic_CK2401-031.jpg		成都若克石油技术开发有限公司	21-WXM-240030	XS2401-029	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
XS202312-23	44	2023-12-19	10701.2	0	f	f	0	f	张金宝	 	2023-12-19 01:16:37.141993		 		 	 	21-WXM-230731	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-17	25	2023-12-20	0	0	f	t	0	f	唐文静		2023-12-19 18:05:12.302632		/upload/pics/pic_CK202312-17.jpg		天津彩虹石油机械有限公司	CHSC-YCLCG-231224	XS202312-05	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-069	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 11:38:46.362056	天津市武清区京滨工业园民丰道6号		21-WXM-240027		天津德瑞克石油工具有限公司	XS2401-021	天津	张泽	18920480870		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-032	52	2024-01-11	9101.7	0	f	t	0	f	张金宝		2024-01-11 14:13:43.406131						21-WXM-240033	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
FH2401-077	0	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:35:34.723271	 		CHSC-240113		天津彩虹石油机械有限公司	XS2401-038	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-033	61	2024-01-11	1787.5	0	f	t	0	f	张金宝		2024-01-11 14:14:34.081002						21-WXM-240034	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-024	43	2024-01-09	0	0	f	t	0	f	唐文静	 	2024-01-09 10:33:20.24441		/upload/pics/pic_CK2401-024.jpg		天津市克赛斯工贸有限公司	21-WXM-240025	XS2401-018	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-014	56	2024-01-06	0	0	f	t	0	f	唐文静	 	2024-01-06 09:33:59.345616		/upload/pics/pic_CK2401-014.jpg		天津天屹能源科技有限公司	21-WXM-240012	XS2401-003	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-025	33	2024-01-09	0	0	f	t	0	f	唐文静		2024-01-09 10:37:49.340838		/upload/pics/pic_CK2401-025.jpg		天津鑫威斯特石油机械有限公司	21-WXM-240026	XS2401-020	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-054	0	2024-01-10	0	0	f	t	0	f	张金宝		2024-01-11 14:18:40.962151	津南区八里台工业园南区春经路	自提	21-WXM-240026		天津鑫威斯特石油机械有限公司	XS2401-020	天津	徐超	15522118082 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-029	27	2024-01-09	0	0	f	t	0	f	唐文静	 	2024-01-09 10:51:23.257475		/upload/pics/pic_CK2401-029.jpg		鞍山申阔机械制造有限公司	21-WXM-240024	XS2401-019	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-055	0	2024-01-10	0	0	f	t	0	f	张金宝		2024-01-11 14:19:10.655752	辽宁省鞍山市铁西区双德街45号 鞍山申阔 	自提	21-WXM-240024		鞍山申阔机械制造有限公司	XS2401-019	天津	崔立健	18641270600		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH202312-14	0	2023-12-23	0	0	f	t	0	f	张金宝		2023-12-22 18:37:07.4283	荆州市沙市区318国道银湖工业区B5栋荆州市赛瑞能源技术有限公司		21-WXM-230736		荆州市赛瑞能源技术有限公司	XS202312-32	天津	田学虎	13972331343	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202312-03	27	2023-12-18	0	0	f	t	0	f	唐文静		2023-12-17 19:59:16.464832		/upload/pics/pic_CK202312-03.jpg		鞍山申阔机械制造有限公司	21-WXM-230718	XS202312-03	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-001	54	2024-01-05	561.2	0	f	t	0	f	张金宝		2024-01-05 05:54:36.908691		2024-01-05				21-WXM-240010	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK2401-051	82	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:12:00.959391		/upload/pics/pic_CK2401-051.jpg		天津远海采油科技有限公司	21-WXM-240042	XS2401-044	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-016	69	2024-01-06	0	0	f	t	0	f	唐文静	 	2024-01-06 09:46:06.51812		/upload/pics/pic_CK2401-016.jpg		欧亚汇通（天津）商贸有限公司	21-WXM-240014	XS2401-005	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-056	43	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:31:00.959552		/upload/pics/pic_CK2401-056.jpg		天津市克赛斯工贸有限公司	21-WXM-240037	XS2401-040	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-032	77	2024-01-10	0	0	f	t	0	f	唐文静	 	2024-01-10 15:58:34.537		/upload/pics/pic_CK2401-032.jpg		江苏赛维斯石油科技有限公司	21-WXM-240029	XS2401-028	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
FH2401-074	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 11:39:42.933712	江苏省常州市武进区板上蒲工业园96号		21-WXM-240029		江苏赛维斯石油科技有限公司	XS2401-028	天津	莫工	18912319650		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-019	52	2024-01-09	0	0	f	t	0	f	唐文静		2024-01-09 10:25:14.992176		/upload/pics/pic_CK2401-019.jpg		湖南苏普锐油气装备科技有限公司	21-WXM-240018	XS2401-009	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
FH2401-072	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 11:39:25.002947			21-WXM-240018		湖南苏普锐油气装备科技有限公司	XS2401-009	天津				0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-036	25	2024-01-10	0	0	f	t	0	f	唐文静	 	2024-01-10 16:15:57.295361		/upload/pics/pic_CK2401-036.jpg		天津彩虹石油机械有限公司	CHSC-240104	XS2401-015	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-015	33	2024-01-06	0	0	f	t	0	f	唐文静	 	2024-01-06 09:36:02.125994		/upload/pics/pic_CK2401-015.jpg		天津鑫威斯特石油机械有限公司	21-WXM-240013	XS2401-004	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-026	75	2024-01-09	0	0	f	t	0	f	唐文静		2024-01-09 10:39:56.041125		/upload/pics/pic_CK2401-026.jpg		天津德瑞克石油工具有限公司	21-WXM-240027	XS2401-021	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-052	74	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:13:06.629842		/upload/pics/pic_CK2401-052.jpg		天津市达利普石油管材有限公司	21-WXM-240041	XS2401-043	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-020	33	2024-01-09	0	0	f	t	0	f	唐文静	 	2024-01-09 10:27:15.041817		/upload/pics/pic_CK2401-020.jpg		天津鑫威斯特石油机械有限公司	21-WXM-240017	XS2401-008	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-013	51	2024-01-06	0	0	f	t	0	f	唐文静	 	2024-01-06 09:32:44.778385		/upload/pics/pic_CK2401-013.jpg		山东宏继源石油装备有限公司	21-WXM-240011	XS2401-002	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-070	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 11:38:57.156857	天津市静海经济凯大区广海道17号		21-WXM-240023		天津市达利普石油管材有限公司	XS2401-017	天津	袁总	18722411544		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-053	0	2024-01-10	0	0	f	t	0	f	张金宝		2024-01-11 14:18:10.473451	 	安能含运	21-WXM-240028		东营市瑞丰石油技术发展有限責任公司	XS2401-022	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH202312-08	0	2023-12-20	0	0	f	t	0	f	唐文静		2023-12-19 19:14:13.124492	 		CHSC-YCLCG-231229	XS202312-01	天津彩虹石油机械有限公司	CK202312-02	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	f	运输发货	0	0		
FH202312-16	0	2023-12-26	0	0	f	t	0	f	张金宝		2023-12-26 01:46:58.626032			21-WXM-230731		东营市博鸿石油机械有限公司	XS202312-23	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
XS202312-07	29	2023-12-18	19180.7	0	f	f	0	f	张金宝	 	2023-12-17 17:26:50.172552		2023-12-20		 	 	21-WXM-230720	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-45	55	2023-12-25	223082.73	0	f	t	0	f	张金宝	 	2023-12-25 03:04:58.702813		2023-12-26		 	 	21-WXM-230741	天津				0	0	0	0	0	0	0	0	0	0	f	t	f	商品销售	0	0		
CK202312-29	53	2023-12-23	0	0	f	t	0	f	张金宝	 	2023-12-22 21:51:28.046691		/upload/pics/pic_CK202312-29.jpg		杭州途晟物资有限公司	21-WXM-230740	XS202312-38	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-50	33	2023-12-26	64378.6	0	f	t	0	f	张金宝		2023-12-26 06:46:46.122107		2023-12-27				21-WXM-230747	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-35	25	2023-12-26	0	0	f	t	0	f	唐文静		2023-12-26 07:22:43.168275				天津彩虹石油机械有限公司	CHSC-231235	XS202312-34	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	销售出库	0	0		
XS202312-52	45	2023-12-27	16867.25	0	f	t	0	f	张金宝		2023-12-27 00:22:13.037259						21-WXM-230749	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-18	25	2023-12-19	2949.6	0	f	f	0	f	唐文静	 	2023-12-18 22:44:47.173412		 		 	 	CHSC-231232	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
XS202312-05	25	2023-12-18	1510	0	f	f	0	f	唐文静	 	2023-12-17 16:59:23.531081		 		 	 	CHSC-YCLCG-231224	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CG202312-01	36	2023-12-19	739305	0	f	t	0	f	朱玉树	9CR圆钢采购	2023-12-18 21:01:14.806997	 		2024-03-19				天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	材料采购	0	0		
XS202312-21	43	2023-12-19	5126.8	0	f	t	0	f	张金宝		2023-12-19 00:53:28.438946		2023-12-20				21-WXM-230730	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH2401-017	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:44:19.55291			21-WXM-240007		山东九玺金属制造有限公司	XS202401-07	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
XS202312-10	50	2023-12-18	49232.58	0	f	t	0	f	张金宝	 	2023-12-17 22:27:58.036462		2023-12-19		 	 	21-WXM-230724	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-06	28	2023-12-19	0	0	f	t	0	f	唐文静	 	2023-12-18 16:24:32.434077		/upload/pics/pic_CK202312-06.jpg		成都若克石油技术开发有限公司	21-WXM-230721	XS202312-06	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-25	46	2023-12-19	210000	0	f	t	0	f	张金宝	 期货合同/黄石提货	2023-12-19 03:42:36.625595		2024-03-20		 	 	22-WXM-230036	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
FH2401-078	0	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:35:49.729831	 		CHSC-240112		天津彩虹石油机械有限公司	XS2401-037	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-048	33	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:05:00.465141		/upload/pics/pic_CK2401-048.jpg		天津鑫威斯特石油机械有限公司	21-WXM-240045	XS2401-047	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-033	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 09:57:56.737805	海南省澄迈县老城镇（龙盘油田内）		21-WXM-230750		深圳威晟海南分公司	XS202312-63	天津	周丽娇	13857994068	朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
FH2401-079	0	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:35:57.826447	 		CHSC-240111		天津彩虹石油机械有限公司	XS2401-036	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-031	79	2024-01-11	19203.2	0	f	f	0	f	张金宝	 	2024-01-11 14:12:47.078789		 		 	 	21-WXM-240032	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-034	48	2024-01-11	20496	0	f	t	0	f	张金宝		2024-01-11 14:15:47.675693						21-WXM-240035	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK202312-31	57	2023-12-26	0	0	f	t	0	t	唐文静	 	2023-12-26 07:09:45.002797		/upload/pics/pic_CK202312-31.jpg		辽宁富美石油机械制造有限公司	21-WXM-230745	XS202312-47	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-011	73	2024-01-08	35417.6	0	f	f	0	f	张金宝	 	2024-01-08 05:44:19.375895		2024-01-08		 	 	21-WXM-240020	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS202312-16	25	2023-12-19	281740	0	f	f	0	f	唐文静	 	2023-12-18 22:17:44.525771		 		 	 	CHSC-231230	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH202312-06	0	2023-12-20	0	0	f	t	0	f	唐文静		2023-12-19 17:09:53.981505	 		CHSC-231233	XS202312-19	天津彩虹石油机械有限公司	CK202312-13	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH202312-09	0	2023-12-20	0	0	f	t	0	f	张金宝		2023-12-19 19:45:38.821577	 		21-WXM-230729	XS202312-20	天津市鑫东航通钢铁贸易有限公司	CK202312-15	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-021	73	2024-01-09	0	0	f	t	0	f	唐文静		2024-01-09 10:29:53.63497		/upload/pics/pic_CK2401-021.jpg		无锡贝来石油专用管有限公司	21-WXM-240020	XS2401-011	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-050	48	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:10:09.943614		/upload/pics/pic_CK2401-050.jpg		荆州市赛瑞能源技术有限公司	21-WXM-240043	XS2401-045	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-39	25	2023-12-23	1418.2	0	f	f	0	f	唐文静		2023-12-22 18:11:15.14448						CHSC-231238	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH202312-02	0	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-18 16:06:03.204199	 		CHSC-YCLCG-231229	XS202312-01	天津彩虹石油机械有限公司	CK202312-02	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-008	33	2024-01-08	2748.2	0	f	t	0	f	张金宝		2024-01-08 05:35:33.20022		2024-01-08				21-WXM-240017	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-047	66	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:02:57.122553		/upload/pics/pic_CK2401-047.jpg		天津瑞莱富德石油机械制造有限公司	21-WXM-240046	XS2401-048	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
CK202312-09	33	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-18 17:59:54.75525		/upload/pics/pic_CK202312-09.jpg		天津鑫威斯特石油机械有限公司	21-WXM-230725	XS202312-11	天津				0	0	0	0	0	0	0	0	0	0	t	f	f	销售出库	0	0		
XS202312-24	45	2023-12-19	18044.65	0	f	t	0	f	张金宝	 	2023-12-19 01:19:36.073369		 		 	 	21-WXM-230732	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-05	31	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-18 16:20:46.957957		/upload/pics/pic_CK202312-05.jpg		天津市三一兴石油机械有限公司 	21-WXM-230723	XS202312-09	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
CK2401-049	83	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:08:10.188428		/upload/pics/pic_CK2401-049.jpg		江苏宏扬镍基金属制品有限公司	21-WXM-240044	XS2401-046	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
XS202312-28	47	2023-12-20	33982.75	0	f	f	0	f	张金宝	 	2023-12-19 18:29:08.108458		 		 	 	21-WXM-230733	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH202312-11	0	2023-12-22	0	0	f	t	0	f	张金宝		2023-12-21 19:52:04.832166	 		21-WXM-230720		河南逸唐石油机械有限公司	XS202312-07	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
XS202312-19	25	2023-12-19	78	0	f	f	0	f	唐文静	 	2023-12-18 22:48:36.390861		 		 	 	CHSC-231233	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-32	48	2023-12-20	757666.5	0	f	t	0	f	张金宝	 	2023-12-20 00:28:40.807204		 		 	 	21-WXM-230736	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH2401-073	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 11:39:33.853778	 		21-WXM-230723		天津市三一兴石油机械有限公司 	XS202312-09	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH202312-03	0	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-18 23:16:15.457125	 		CHSC-YCLCG-231228	XS202312-04	天津彩虹石油机械有限公司	CK202312-10	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202312-16	45	2023-12-20	0	0	f	t	0	f	唐文静		2023-12-19 17:37:59.788855		/upload/pics/pic_CK202312-16.jpg		天津市通盈石油技术开发有限公司	21-WXM-230732	XS202312-24	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH202312-10	0	2023-12-20	0	0	f	t	0	f	张金宝		2023-12-19 19:46:26.498074			21-WXM-230732	XS202312-24	天津市通盈石油技术开发有限公司	CK202312-16	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS202312-40	25	2023-12-23	4790	0	f	f	0	f	唐文静		2023-12-22 18:13:23.397138						CHSC-231240	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-19	25	2023-12-21	0	0	f	t	0	f	唐文静		2023-12-20 18:58:24.692177		/upload/pics/pic_CK202312-19.jpg		天津彩虹石油机械有限公司	CHSC-231237	XS202312-31	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-041	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-09 00:07:37.929286			21-WXM-240003		天津滨海雷克斯激光科技发展有限公司	XS202401-03	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-028	76	2024-01-09	0	0	f	t	0	f	唐文静	 	2024-01-09 10:42:24.5766		/upload/pics/pic_CK2401-028.jpg		北京乐富特科技有限公司	21-WXM-240022	XS2401-023	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-040	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-09 00:07:27.355205			21-WXM-240006		天津朝彭盛世科技发展有限公司	XS202401-06	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-039	80	2024-01-16	8430.9	0	f	f	0	f	张金宝	 	2024-01-16 09:36:43.960366		2024-01-15		 	 	21-WXM-240036	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK2401-012	54	2024-01-06	0	0	f	t	0	f	唐文静		2024-01-06 09:28:12.214124		/upload/pics/pic_CK2401-012.jpg		天津隆凯来石油设备有限公司	21-WXM-240010	XS2401-001	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-080	0	2024-01-16	0	0	f	t	0	f	唐文静		2024-01-16 15:36:05.454913	 		CHSC-240110		天津彩虹石油机械有限公司	XS2401-035	天津	 	 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-082	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 18:59:49.776243	津南区八里台工业园南区春经路		21-WXM-240045		天津鑫威斯特石油机械有限公司	XS2401-047	天津	徐超	15522118082 		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-056	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-11 14:20:38.995613	无锡市惠山区钱桥街道钱洛路3号	自提	21-WXM-240020		无锡贝来石油专用管有限公司	XS2401-011	天津	薛骑	15161518190		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-015	25	2024-01-08	4656.3	0	f	f	0	f	唐文静		2024-01-08 09:34:38.410071						CHSC-240104	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-014	25	2024-01-08	1812	0	f	f	0	f	唐文静		2024-01-08 09:32:08.166181						CHSC-240103	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
FH2401-084	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 19:00:36.963254	天津市静海经济凯大区广海道17号		21-WXM-240041		天津市达利普石油管材有限公司	XS2401-043	天津	袁总	18722411544		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-087	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 19:01:13.164954			21-WXM-240037		天津市克赛斯工贸有限公司	XS2401-040	天津				0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-081	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 18:59:29.30014			21-WXM-240046		天津瑞莱富德石油机械制造有限公司	XS2401-048	天津				0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-085	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 19:00:51.241472	长葛市石固镇东关		21-WXM-240040		长葛市金博机械化工有限公司 	XS2401-042	天津	陈世杰	13523289303		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-038	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-09 00:06:58.363968			21-WXM-240012		天津天屹能源科技有限公司	XS2401-003	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
CK2401-011	60	2024-01-06	0	0	f	t	0	f	唐文静		2024-01-06 07:36:15.85836		/upload/pics/pic_CK2401-011.jpg		天津盛杰斯国际贸易有限公司	21-WXM-230751	XS202312-64	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-039	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-09 00:07:17.381547			21-WXM-240010		天津隆凯来石油设备有限公司	XS2401-001	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-042	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-09 00:08:00.722822			21-WXM-230751		天津盛杰斯国际贸易有限公司	XS202312-64	天津				0	0	0	0	0	0	0	0	0	0	t	f	f	运输发货	0	0		
FH2401-037	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-09 00:06:41.99844	津南区八里台工业园南区春经路		21-WXM-240013		天津鑫威斯特石油机械有限公司	XS2401-004	天津	徐超	15522118082 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202312-15	42	2023-12-20	0	0	f	t	0	f	唐文静		2023-12-19 17:30:35.320417		/upload/pics/pic_CK202312-15.jpg		天津市鑫东航通钢铁贸易有限公司	21-WXM-230729	XS202312-20	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-49	27	2023-12-25	184783.45	0	f	t	0	f	张金宝	 	2023-12-25 09:37:06.984011		2023-12-27		 	 	21-WXM-230746	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-01	25	2023-12-17	0	0	f	f	0	f	唐文静	 	2023-12-17 03:17:08.522404		 		 	 	CHSC-YCLCG-231229	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-02	26	2023-12-17	14440	0	f	f	0	f	张金宝	 	2023-12-17 03:55:02.184995		 		 09566671	 12120	21-WXM-230719	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-08	30	2023-12-18	19747.8	0	f	f	0	f	张金宝	 	2023-12-17 19:20:41.840539		2023-12-19		 09566672	 19550	21-WXM-230722	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH202312-04	0	2023-12-20	0	0	f	t	0	f	唐文静		2023-12-19 17:08:18.963919	 		CHSC-YCLCG-231232	XS202312-13	天津彩虹石油机械有限公司	CK202312-14	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS202312-22	25	2023-12-19	2485	0	f	t	0	f	唐文静	 	2023-12-19 00:55:28.464438		 		 	 	CHSC-231229	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	商品销售	0	0		
CK202312-34	55	2023-12-26	0	0	f	t	0	f	唐文静		2023-12-26 07:18:10.365713		/upload/pics/pic_CK202312-34.jpg		宝鸡聚能石油机械有限公司	21-WXM-230743	XS202312-46	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
CK202312-20	33	2023-12-21	0	0	f	t	0	f	唐文静		2023-12-20 22:56:29.577904		/upload/pics/pic_CK202312-20.jpg		天津鑫威斯特石油机械有限公司	21-WXM-230734	XS202312-27	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-03	27	2023-12-17	34452.85	0	f	t	0	f	张金宝	 2023-12-28客户自提	2023-12-17 04:17:50.443542		2023-12-19		 	 	21-WXM-230718	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-13	25	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-19 01:05:54.910045		/upload/pics/pic_CK202312-13.jpg		天津彩虹石油机械有限公司	CHSC-231233	XS202312-19	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
XS202312-06	28	2023-12-18	182083.5	0	f	t	0	f	张金宝	 已收款172800元	2023-12-17 17:01:39.160691		2023-12-19		 	 	21-WXM-230721	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-30	53	2023-12-23	0	0	f	t	0	f	唐文静		2023-12-23 00:45:43.997125		/upload/pics/pic_CK202312-30.jpg		杭州途晟物资有限公司	21-WXM-230740	XS202312-38	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202312-33	55	2023-12-26	0	0	f	t	0	f	唐文静	 	2023-12-26 07:17:40.983265		/upload/pics/pic_CK202312-33.jpg		宝鸡聚能石油机械有限公司	21-WXM-230741	XS202312-45	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
FH202312-17	0	2023-12-26	0	0	f	t	0	f	张金宝		2023-12-26 06:47:04.704601			21-WXM-230739		湖南苏普锐油气装备科技有限公司	XS202312-37	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS202312-46	55	2023-12-25	15519	0	f	t	0	f	张金宝		2023-12-25 03:05:56.217075		2023-12-26				21-WXM-230743	天津				0	0	0	0	0	0	0	0	0	0	f	t	f	商品销售	0	0		
CK202312-32	56	2023-12-26	0	0	f	t	0	f	唐文静		2023-12-26 07:14:44.859195		/upload/pics/pic_CK202312-32.jpg		天津天屹能源科技有限公司	21-WXM-230744	XS202312-48	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-41	25	2023-12-23	1798.8	0	f	f	0	f	唐文静		2023-12-22 18:15:03.305857						CHSC-231242	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-04	25	2023-12-18	406.9	0	f	f	0	f	唐文静	 	2023-12-17 16:44:37.524026		 		 	 	CHSC-YCLCG-231228	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-25	44	2023-12-22	0	0	f	t	0	f	唐文静		2023-12-21 19:54:52.453347		/upload/pics/pic_CK202312-25.jpg		东营市博鸿石油机械有限公司	21-WXM-230731	XS202312-23	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-36	51	2023-12-22	12853.35	0	f	f	0	f	张金宝	 	2023-12-21 16:33:19.092988		2023-12-22		 	 	21-WXM-230738	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-22	47	2023-12-21	0	0	f	t	0	f	唐文静		2023-12-21 00:29:09.585139		/upload/pics/pic_CK202312-22.jpg		天津跃峰科技股份有限公司	21-WXM-230733	XS202312-28	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-11	33	2023-12-18	990.6	0	f	t	0	f	张金宝	 	2023-12-18 00:37:14.740261		2023-12-19		 	 	21-WXM-230725	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-27	33	2023-12-20	832	0	f	t	0	f	张金宝	 	2023-12-19 17:54:32.247747		2023-12-20		 	 	21-WXM-230734	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-20	42	2023-12-19	27162	0	f	f	0	f	张金宝	 	2023-12-19 00:49:00.616231		2023-12-19		 09566676	 27018	21-WXM-230729	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-08	33	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-18 17:31:40.78122		/upload/pics/pic_CK202312-08.jpg		天津鑫威斯特石油机械有限公司	21-WXM-230725	XS202312-11	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202312-11	33	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-18 20:04:04.845882		/upload/pics/pic_CK202312-11.jpg		天津鑫威斯特石油机械有限公司	21-WXM-230725	XS202312-11	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202312-10	25	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-18 20:01:15.024783		/upload/pics/pic_CK202312-10.jpg		天津彩虹石油机械有限公司	CHSC-YCLCG-231228	XS202312-04	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-26	49	2023-12-19	290000	0	f	t	0	f	张金宝	期货合同/含到天津港运费	2023-12-19 03:46:39.408157		2024-01-25		 	 	22-WXM-230037	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
CK202312-12	25	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-19 01:05:15.118631				天津彩虹石油机械有限公司	CHSC-231233	XS202312-19	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	销售出库	0	0		
CK202312-14	25	2023-12-19	0	0	f	t	0	f	唐文静		2023-12-19 01:09:24.804529		/upload/pics/pic_CK202312-14.jpg		天津彩虹石油机械有限公司	CHSC-YCLCG-231232	XS202312-13	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
FH202312-05	0	2023-12-20	0	0	f	t	0	f	唐文静		2023-12-19 17:09:07.910182	 		CHSC-YCLCG-231228	XS202312-04	天津彩虹石油机械有限公司	CK202312-10	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS202312-30	25	2023-12-20	4695	0	f	f	0	f	唐文静	 	2023-12-20 00:00:13.163043		 		 	 	CHSC-231236	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-31	25	2023-12-20	5000	0	f	f	0	f	唐文静	 	2023-12-20 00:02:47.809048		 		 	 	CHSC-231237	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-02	25	2023-12-17	0	0	f	t	0	f	唐文静		2023-12-17 06:01:48.660803		/upload/pics/pic_CK202312-02.jpg		天津彩虹石油机械有限公司	CHSC-YCLCG-231229	XS202312-01	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
XS202312-47	57	2023-12-25	27486	0	f	t	0	t	张金宝	 	2023-12-25 07:11:24.885798		2023-12-26		 	 	21-WXM-230745	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-09	31	2023-12-18	10024.23	0	f	f	0	f	张金宝	 	2023-12-17 19:39:56.785106		2023-12-18		 	 	21-WXM-230723	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK202312-01	25	2023-12-17	0	0	f	t	0	f	唐文静		2023-12-17 03:50:03.649888		/upload/pics/pic_CK202312-01.jpg		天津彩虹石油机械有限公司	CHSC-YCLCG-231229	XS202312-01	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	销售出库	0	0		
XS202312-34	25	2023-12-21	4566.1	0	f	f	0	f	唐文静		2023-12-21 02:02:13.625626						CHSC-231235	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH202312-07	0	2023-12-20	0	0	f	t	0	f	唐文静		2023-12-19 19:05:38.564837	 		CHSC-YCLCG-231224	XS202312-05	天津彩虹石油机械有限公司	CK202312-17	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS202312-35	35	2023-12-22	22647.5	0	f	f	0	f	张金宝	 	2023-12-21 16:29:18.486395		2023-12-22		 09566711	 22812.5	21-WXM-230737	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-33	25	2023-12-21	49593	0	f	f	0	f	唐文静		2023-12-21 01:57:08.047174						CHSC-231234	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-18	25	2023-12-21	0	0	f	t	0	f	唐文静		2023-12-20 17:39:38.944029		/upload/pics/pic_CK202312-18.jpg		天津彩虹石油机械有限公司	CHSC-231236	XS202312-30	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202312-24	43	2023-12-22	0	0	f	t	0	f	唐文静		2023-12-21 19:39:16.42597		/upload/pics/pic_CK202312-24.jpg		天津市克赛斯工贸有限公司	21-WXM-230735	XS202312-29	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	销售出库	0	0		
CK202312-23	29	2023-12-21	0	0	f	t	0	f	唐文静		2023-12-21 00:34:06.483058		/upload/pics/pic_CK202312-23.jpg		河南逸唐石油机械有限公司	21-WXM-230720	XS202312-07	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-43	25	2023-12-23	1363.2	0	f	f	0	f	唐文静		2023-12-22 18:21:23.082769						CHSC-231243	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-12	34	2023-12-19	15153.2	0	f	f	0	f	张金宝	 	2023-12-18 16:35:45.613465		2023-12-20		 09566714	 15060.9	21-WXM-230726	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-17	25	2023-12-19	56576.5	0	f	f	0	f	唐文静	 	2023-12-18 22:43:04.746462		 		 	 	SHSC-231231	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	商品销售	0	0		
XS202312-29	43	2023-12-20	28819.4	0	f	t	0	f	张金宝	 	2023-12-19 22:54:42.889017		2023-12-21		 	 	21-WXM-230735	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH202312-15	0	2023-12-25	0	0	f	t	0	f	张金宝		2023-12-25 00:51:52.023566			21-WXM-230740		杭州途晟物资有限公司	XS202312-38	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
CK202312-27	48	2023-12-22	0	0	f	t	0	f	唐文静		2023-12-22 01:28:21.477292		/upload/pics/pic_CK202312-27.jpg		荆州市赛瑞能源技术有限公司	21-WXM-230736	XS202312-32	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202312-44	54	2023-12-27	0	0	f	t	0	f	唐文静		2023-12-27 10:59:37.728885		/upload/pics/pic_CK202312-44.jpg		天津隆凯来石油设备有限公司	21-WXM-230742	XS202312-44	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202312-26	43	2023-12-22	0	0	f	t	0	f	唐文静		2023-12-21 19:56:26.468506		/upload/pics/pic_CK202312-26.jpg		天津市克赛斯工贸有限公司	21-WXM-230735	XS202312-29	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH202312-12	0	2023-12-22	0	0	f	t	0	f	张金宝		2023-12-22 01:02:59.027607			21-WXM-230735		天津市克赛斯工贸有限公司	XS202312-29	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH202312-13	0	2023-12-23	0	0	f	t	0	f	张金宝		2023-12-22 18:36:36.212318			21-WXM-230733		天津跃峰科技股份有限公司	XS202312-28	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
CK202312-40	45	2023-12-27	0	0	f	t	0	f	唐文静		2023-12-27 05:45:29.650806		/upload/pics/pic_CK202312-40.jpg		天津市通盈石油技术开发有限公司	21-WXM-230749	XS202312-52	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-54	25	2023-12-28	24423.3	0	f	f	0	f	唐文静		2023-12-28 08:38:51.498215						CHSC-231244	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-43	33	2023-12-27	0	0	f	t	0	f	唐文静	 	2023-12-27 10:36:38.938077		/upload/pics/pic_CK202312-43.jpg		天津鑫威斯特石油机械有限公司	21-WXM-230747	XS202312-50	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH202312-19	0	2023-12-26	0	0	f	t	0	f	张金宝		2023-12-26 10:36:51.82267			21-WXM-230744		天津天屹能源科技有限公司	XS202312-48	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
CK202312-42	34	2023-12-27	0	0	f	t	0	f	唐文静	 	2023-12-27 06:01:51.906476		/upload/pics/pic_CK202312-42.jpg		北京航天兴达精密机械有限公司	21-WXM-230726	XS202312-12	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202312-28	52	2023-12-23	0	0	f	t	0	f	唐文静		2023-12-22 18:01:10.53433		/upload/pics/pic_CK202312-28.jpg		湖南苏普锐油气装备科技有限公司	21-WXM-230739	XS202312-37	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
XS202312-38	53	2023-12-22	775	0	f	f	0	f	张金宝	 	2023-12-22 01:02:24.039216		2023-12-23		 	 	21-WXM-230740	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-41	25	2023-12-27	0	0	f	t	0	f	唐文静		2023-12-27 05:56:40.717127		/upload/pics/pic_CK202312-41.jpg		天津彩虹石油机械有限公司	CHSC-231245	XS202312-42	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202312-38	51	2023-12-27	0	0	f	t	0	f	唐文静	 	2023-12-27 05:35:01.988371		/upload/pics/pic_CK202312-38.jpg		山东宏继源石油装备有限公司	21-WXM-230738	XS202312-36	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-44	54	2023-12-25	116877.6	0	f	f	0	f	张金宝	 	2023-12-25 03:02:18.360742		2023-12-26		 09566701/09566702	 115416	21-WXM-230742	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-37	52	2023-12-22	9440.42	0	f	f	0	f	张金宝	 	2023-12-22 00:59:10.14024		2023-12-23		 	 	21-WXM-230739	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-55	25	2023-12-28	48677.7	0	f	f	0	f	唐文静	 	2023-12-28 08:47:54.518049		 		 	 	 CHSC-231241	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-53	25	2023-12-28	8184	0	f	f	0	f	唐文静	 	2023-12-28 08:35:06.944272		 		 	 	CHSC-231246	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH202312-18	0	2023-12-26	0	0	f	t	0	t	张金宝	 	2023-12-26 10:36:34.176889		 	21-WXM-230745		辽宁富美石油机械制造有限公司	XS202312-47	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
XS202312-48	56	2023-12-25	696.5	0	f	f	0	f	张金宝	 2024-1-3收款695.2元	2023-12-25 07:12:39.938765		2023-12-25		 09566705	 695.2	21-WXM-230744	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-36	25	2023-12-26	0	0	f	t	0	f	唐文静		2023-12-26 07:27:37.932393		/upload/pics/pic_CK202312-36.jpg		天津彩虹石油机械有限公司	CHSC-231235	XS202312-34	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-58	25	2023-12-28	2255	0	f	f	0	f	唐文静	 	2023-12-28 09:00:40.768711		 		 	 	 CHSC-231249	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-57	25	2023-12-28	8555.9	0	f	f	0	f	唐文静		2023-12-28 08:58:20.360787						CHSC-231248	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202401-02	45	2024-01-02	2886.8	0	f	t	0	f	张金宝		2024-01-02 07:54:57.39647		2024-01-02				21-WXM-240002	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-59	25	2023-12-28	4175	0	f	f	0	f	唐文静	 	2023-12-28 09:01:51.581022		 		 	 	 CHSC-231250	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-62	25	2023-12-28	158.4	0	f	f	0	f	唐文静		2023-12-28 09:10:49.536806						CHSC-231253	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-60	25	2023-12-28	2043.8	0	f	f	0	f	唐文静		2023-12-28 09:07:43.397756						CHSC-231251	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-61	25	2023-12-28	13230	0	f	f	0	f	唐文静		2023-12-28 09:09:30.039466						CHSC-231252	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-37	25	2023-12-26	0	0	f	t	0	f	唐文静	 	2023-12-26 07:30:13.326155		/upload/pics/pic_CK202312-37.jpg		天津彩虹石油机械有限公司	CHSC-231243	XS202312-43	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-56	25	2023-12-28	91916	0	f	f	0	f	唐文静		2023-12-28 08:52:55.790065						CHSC-231247	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
XS2401-019	27	2024-01-09	41837	0	f	t	0	f	张金宝		2024-01-09 06:10:35.774537						21-WXM-240024	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS2401-021	75	2024-01-09	14991	0	f	t	0	f	张金宝		2024-01-09 06:15:59.990518						21-WXM-240027	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS202312-51	45	2023-12-26	29372.4	0	f	t	0	f	张金宝		2023-12-26 09:00:50.073468		2023-12-27				21-WXM-230748	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH202401-01	0	2024-01-02	0	0	f	t	0	f	张金宝		2024-01-02 07:09:34.535512			21-WXM-230748		天津市通盈石油技术开发有限公司	XS202312-51	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
RK202312-02	0	2023-12-28	0	0	f	t	0	f	唐文静		2023-12-28 11:47:02.714982					2023-12-11	CG202312-03	天津			朱玉树	0	0	0	0	0	11860	11866	11361.8	0	0	f	f	t	采购入库	0	0		
XS202401-01	64	2024-01-02	1449.6	0	f	t	0	f	张金宝		2024-01-02 07:54:01.953242		2024-01-02				21-WXM-240001	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
CK202401-07	25	2024-01-04	0	0	f	t	0	f	唐文静	 	2024-01-04 10:45:48.838063		/upload/pics/pic_CK202401-07.jpg		天津彩虹石油机械有限公司	 CHSC-231241	XS202312-55	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-019	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:45:04.243166			21-WXM-240004		天津市克赛斯工贸有限公司	XS202401-04	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH202401-05	0	2024-01-04	0	0	f	t	0	f	张金宝		2024-01-04 07:13:46.007304			21-WXM-230738		山东宏继源石油装备有限公司	XS202312-36	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH202401-02	0	2024-01-04	0	0	f	t	0	f	张金宝		2024-01-04 07:13:07.75549			21-WXM-230749		天津市通盈石油技术开发有限公司	XS202312-52	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202401-08	25	2024-01-04	0	0	f	t	0	f	唐文静	 	2024-01-04 10:49:41.837055		/upload/pics/pic_CK202401-08.jpg		天津彩虹石油机械有限公司	CHSC-231244	XS202312-54	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-002	51	2024-01-05	28284.8	0	f	f	0	f	张金宝	 	2024-01-05 05:55:45.451401		2024-01-06		 	 	21-WXM-240011	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK202401-16	43	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 12:00:54.053671		/upload/pics/pic_CK202401-16.jpg		天津市克赛斯工贸有限公司	21-WXM-240004	XS202401-04	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-14	64	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 11:55:06.673428				天津康坦石油设备科技有限公司	21-WXM-240001	XS202401-01	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	销售出库	0	0		
CK202401-17	66	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 12:04:36.397753		/upload/pics/pic_CK202401-17.jpg		天津瑞莱富德石油机械制造有限公司	21-WXM-240005	XS202401-05	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202401-03	65	2024-01-04	1426	0	f	t	0	f	张金宝		2024-01-04 07:03:36.444981		2024-01-04				21-WXM-240003	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-15	28	2023-12-19	261509.5	0	f	t	0	f	张金宝	 待提货	2023-12-18 19:43:16.187668		 		 	 	21-WXM-230727	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-45	35	2023-12-29	0	0	f	t	0	f	唐文静		2023-12-29 10:01:05.041983		/upload/pics/pic_CK202312-45.jpg		荆州诚达石油工具有限公司	21-WXM-230737	XS202312-35	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202401-06	67	2024-01-04	1414.8	0	f	f	0	f	张金宝	 	2024-01-04 07:10:59.580266		2024-01-05		 	 	21-WXM-240006	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202401-07	68	2024-01-04	7950	0	f	f	0	f	张金宝	 收款8000元	2024-01-04 07:11:38.589173		2024-01-04		 	 	21-WXM-240007	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK2401-002	43	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:57:37.375984		/upload/pics/pic_CK2401-002.jpg		天津市克赛斯工贸有限公司	21-WXM-230756	XS202312-69	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-21	25	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:27:36.611739		/upload/pics/pic_CK202401-21.jpg		天津彩虹石油机械有限公司	231254	XS202401-09	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-003	61	2024-01-05	0	0	f	t	0	f	唐文静	 	2024-01-05 02:00:45.073479		/upload/pics/pic_CK2401-003.jpg		荆州市瑞驰石油机械有限公司	21-WXM-230752	XS202312-65	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-024	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:46:08.295304	荆州市荆州区西环路 135号 荆州诚达石油工具有限公司		21-WXM-230755		荆州诚达石油工具有限公司	XS202312-68	天津	胡蕾	177 2038 9392	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS202401-04	43	2024-01-04	5527.5	0	f	t	0	f	张金宝		2024-01-04 07:04:52.840729		2024-01-03				21-WXM-240004	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202401-13	45	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 11:42:44.8505		/upload/pics/pic_CK202401-13.jpg		天津市通盈石油技术开发有限公司	21-WXM-240002	XS202401-02	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-020	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:45:16.351081			21-WXM-240002		天津市通盈石油技术开发有限公司	XS202401-02	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-018	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:44:47.073393	荆州市沙市区318国道银湖工业区B5栋荆州市赛瑞能源技术有限公司		21-WXM-240008		荆州市赛瑞能源技术有限公司	XS202401-08	天津	田学虎	13972331343	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-030	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:47:41.801934			21-WXM-230730		天津市克赛斯工贸有限公司	XS202312-21	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-020	33	2024-01-09	28040	0	f	t	0	f	张金宝		2024-01-09 06:11:43.718026						21-WXM-240026	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS202312-66	62	2023-12-30	1805	0	f	f	0	f	张金宝	 	2023-12-30 05:52:07.248779		 		 	 	21-WXM-230753	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202312-07	26	2023-12-19	0	0	f	t	0	f	唐文静	 	2023-12-18 16:27:39.894739		/upload/pics/pic_CK202312-07.jpg		德阳鼎宏科技有限责任公司	21-WXM-230719	XS202312-02	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-022	50	2024-01-09	25578	0	f	t	0	f	张金宝		2024-01-09 06:16:39.293206						21-WXM-240028	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
FH2401-007	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:37:45.011436	 		 CHSC-231241		天津彩虹石油机械有限公司	XS202312-55	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
RK202312-05	0	2023-12-30	0	0	f	t	0	f	唐文静	 	2023-12-30 06:05:28.30524					2023-12-11	CG202312-06	天津			朱玉树	0	0	0	0	0	3532	3536	3527.8	0	0	f	f	t	采购入库	0	0		
FH202401-03	0	2024-01-04	0	0	f	t	0	f	张金宝		2024-01-04 07:13:24.425035	津南区八里台工业园南区春经路		21-WXM-230747		天津鑫威斯特石油机械有限公司	XS202312-50	天津	徐超	15522118082 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
RK202312-06	0	2023-12-30	0	0	f	t	0	f	唐文静	 	2023-12-30 06:07:34.797346					2023-12-02	CG202312-07	天津			朱玉树	0	0	0	0	0	10392	10402	69821.6	0	0	f	f	t	采购入库	0	0		
CK202312-39	45	2023-12-27	0	0	f	t	0	f	唐文静		2023-12-27 05:41:50.919454		/upload/pics/pic_CK202312-39.jpg		天津市通盈石油技术开发有限公司	21-WXM-230748	XS202312-51	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CG202401-01	37	2023-11-13	46500	0	f	t	0	f	朱玉琢		2024-01-04 02:02:47.550055	2302-64		2024-01-25				天津				0	0	0	0	0	0	0	0	0	0	f	f	f	材料采购	0	0		
CK202312-21	28	2023-12-21	0	0	f	t	0	f	唐文静		2023-12-20 23:49:40.258445		/upload/pics/pic_CK202312-21.jpg		成都若克石油技术开发有限公司	21-WXM-230727	XS202312-15	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH202401-06	0	2024-01-04	0	0	f	t	0	f	张金宝		2024-01-04 07:13:55.528311	荆州市荆州区西环路 135号 荆州诚达石油工具有限公司		21-WXM-230737		荆州诚达石油工具有限公司	XS202312-35	天津	胡蕾	177 2038 9392	朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
CK202401-01	25	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 10:26:11.061847		/upload/pics/pic_CK202401-01.jpg		天津彩虹石油机械有限公司	CHSC-231252	XS202312-61	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-001	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:36:18.164235	 		CHSC-231253		天津彩虹石油机械有限公司	XS202312-62	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-004	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:37:06.703158	 		 CHSC-231250		天津彩虹石油机械有限公司	XS202312-59	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-005	69	2024-01-05	259405.16	0	f	f	0	f	张金宝	 2024-1-6收款262825.1元	2024-01-05 09:37:17.102936		2024-01-06		 	 	21-WXM-240014	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK202401-25	48	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:37:01.776275		/upload/pics/pic_CK202401-25.jpg		荆州市赛瑞能源技术有限公司	21-WXM-230759	XS202312-71	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-05	25	2024-01-04	0	0	f	t	0	f	唐文静	 	2024-01-04 10:34:40.276186		/upload/pics/pic_CK202401-05.jpg		天津彩虹石油机械有限公司	CHSC-231248	XS202312-57	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-18	67	2024-01-04	0	0	f	t	0	f	唐文静	 	2024-01-04 12:05:56.590321		/upload/pics/pic_CK202401-18.jpg		天津朝彭盛世科技发展有限公司	21-WXM-240006	XS202401-06	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-002	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:36:32.828167	 		CHSC-231252		天津彩虹石油机械有限公司	XS202312-61	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-015	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:39:53.09675	 		CHSC-231234		天津彩虹石油机械有限公司	XS202312-33	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202401-09	25	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 11:08:12.930723		/upload/pics/pic_CK202401-09.jpg		天津彩虹石油机械有限公司	CHSC-231242	XS202312-41	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-10	25	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 11:10:40.498292		/upload/pics/pic_CK202401-10.jpg		天津彩虹石油机械有限公司	CHSC-231240	XS202312-40	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-009	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:38:26.30117	 		CHSC-231243		天津彩虹石油机械有限公司	XS202312-43	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CG202401-02	38	2024-01-04	107198	0	f	t	0	f	唐文静	 	2024-01-04 12:17:00.143664	G239P32001		 				天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
FH2401-014	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:39:36.74442	 		CHSC-231235		天津彩虹石油机械有限公司	XS202312-34	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-009	43	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 07:35:05.51746		/upload/pics/pic_CK2401-009.jpg		天津市克赛斯工贸有限公司	21-WXM-230730	XS202312-21	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-003	56	2024-01-05	1283.1	0	f	f	0	f	张金宝	 	2024-01-05 07:21:23.805262		2024-01-05		 	 	21-WXM-240012	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK202401-15	65	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 11:56:02.520134		/upload/pics/pic_CK202401-15.jpg		天津滨海雷克斯激光科技发展有限公司	21-WXM-240003	XS202401-03	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-20	48	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 12:08:42.81379		/upload/pics/pic_CK202401-20.jpg		荆州市赛瑞能源技术有限公司	21-WXM-240008	XS202401-08	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-65	61	2023-12-30	367.5	0	f	t	0	f	张金宝		2023-12-30 05:50:18.846421						21-WXM-230752	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH2401-025	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:46:19.384833	 		 21-WXM-230754		天津德瑞克石油工具有限公司	XS202312-67	天津	张泽	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202401-02	25	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 10:27:53.31386		/upload/pics/pic_CK202401-02.jpg		天津彩虹石油机械有限公司	CHSC-231251	XS202312-60	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH202401-04	0	2024-01-04	0	0	f	t	0	f	张金宝		2024-01-04 07:13:36.731917			21-WXM-230742		天津隆凯来石油设备有限公司	XS202312-44	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
CG202312-06	37	2023-12-28	116556	0	f	t	0	f	唐文静	 	2023-12-28 11:53:46.718278	G236K08006		 				天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
CG2401-001	71	2024-01-06	7440	0	f	t	0	f	唐文静	 	2024-01-06 05:35:12.841275	WX20240106		 				天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
RK202312-01	0	2023-12-28	0	0	f	t	0	f	唐文静		2023-12-28 11:02:00.864509					2023-12-11	CG202312-02	天津			朱玉树	0	0	0	0	0	9475	9333	9284.1	0	0	f	f	t	采购入库	0	0		
FH2401-010	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:38:35.334537	 		CHSC-231245		天津彩虹石油机械有限公司	XS202312-42	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-021	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:45:27.387968	荆州市沙市区318国道银湖工业区B5栋荆州市赛瑞能源技术有限公司		21-WXM-230759		荆州市赛瑞能源技术有限公司	XS202312-71	天津	田学虎	13972331343	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-006	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:37:31.393593	 		CHSC-231248		天津彩虹石油机械有限公司	XS202312-57	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CG202312-03	37	2023-12-28	391.38	0	f	t	0	f	唐文静	 	2023-12-28 11:27:41.09349	G238T44001		 				天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
FH2401-003	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:36:45.4881	 		CHSC-231251		天津彩虹石油机械有限公司	XS202312-60	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202401-11	25	2024-01-04	0	0	f	t	0	f	唐文静	 	2024-01-04 11:20:04.714655		/upload/pics/pic_CK202401-11.jpg		天津彩虹石油机械有限公司	CHSC-231238	XS202312-39	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-016	0	2024-01-05	0	0	f	t	0	f	张金宝		2024-01-05 07:22:18.927204			21-WXM-240005		天津瑞莱富德石油机械制造有限公司	XS202401-05	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-013	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:39:22.641056	 		CHSC-231238		天津彩虹石油机械有限公司	XS202312-39	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202401-06	25	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 10:37:29.634178		/upload/pics/pic_CK202401-06.jpg		天津彩虹石油机械有限公司	CHSC-231253	XS202312-62	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-004	63	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 03:11:13.315139		/upload/pics/pic_CK2401-004.jpg		天津德瑞克石油工具有限公司	 21-WXM-230754	XS202312-67	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-27	62	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:46:06.580878		/upload/pics/pic_CK202401-27.jpg		俱准（天津）机械设备有限公司	21-WXM-230753	XS202312-66	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK202401-26	64	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:40:34.174188		/upload/pics/pic_CK202401-26.jpg		天津康坦石油设备科技有限公司	 21-WXM-230758	XS202312-70	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-006	70	2024-01-06	38527	0	f	f	0	f	张金宝	 	2024-01-06 02:21:11.699307		2024-01-06		 	 	21-WXM-240015	天津			张金宝	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK202401-19	68	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 12:07:18.8813		/upload/pics/pic_CK202401-19.jpg		山东九玺金属制造有限公司	21-WXM-240007	XS202401-07	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202401-09	25	2024-01-04	5326.1	0	f	f	0	f	唐文静		2024-01-04 12:20:42.386757						231254	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202401-10	25	2024-01-04	214.5	0	f	f	0	f	唐文静		2024-01-04 12:22:25.508268						240101	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202401-11	25	2024-01-05	1334.4	0	f	f	0	f	唐文静		2024-01-05 00:48:25.258131						CHSC-231225	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202401-12	25	2024-01-05	663.3	0	f	f	0	f	唐文静		2024-01-05 00:51:42.772413						CHSC-231227	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH2401-031	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:48:29.774116	 		21-WXM-230724		东营市瑞丰石油技术发展有限責任公司	XS202312-10	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-029	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:47:30.831411	辽宁省鞍山市铁西区双德街45号 鞍山申阔 		21-WXM-230746		鞍山申阔机械制造有限公司	XS202312-49	天津	崔立健	18641270600	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS202312-67	63	2023-12-30	4210	0	f	t	0	f	张金宝	 	2023-12-30 05:57:41.440188		 		 	 	 21-WXM-230754	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS2401-017	74	2024-01-09	10243.2	0	f	t	0	f	张金宝		2024-01-09 06:06:53.568622						21-WXM-240023	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
XS202401-05	66	2024-01-04	100914.8	0	f	f	0	f	张金宝	 	2024-01-04 07:10:00.803989		2024-01-05		 	 	21-WXM-240005	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
RK202401-01	0	2024-01-05	0	0	f	t	0	f	唐文静	 	2024-01-05 01:24:56.384156					2024-01-04	CG202401-02	天津			朱玉树	0	0	0	0	0	8246	8246	8212.6	0	0	f	f	t	采购入库	0	0		
FH2401-005	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:37:15.240156	 		 CHSC-231249		天津彩虹石油机械有限公司	XS202312-58	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-022	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:45:37.391718			 21-WXM-230758		天津康坦石油设备科技有限公司	XS202312-70	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CG202312-02	39	2023-12-28	90000	0	f	t	0	f	朱玉树	 	2023-12-28 10:51:01.265921	XC23120196		2023-12-11				天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
CK202401-03	25	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 10:29:18.673907		/upload/pics/pic_CK202401-03.jpg		天津彩虹石油机械有限公司	 CHSC-231250	XS202312-59	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH202401-07	0	2024-01-04	0	0	f	t	0	f	张金宝		2024-01-04 07:14:05.976367	河北省张家口市万全区东红庙小区西侧万全京仪院内		21-WXM-230726		北京航天兴达精密机械有限公司	XS202312-12	天津	霍守成	13552758482	朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
XS202312-68	35	2023-12-30	41712.5	0	f	t	0	f	张金宝		2023-12-30 05:58:39.379795						21-WXM-230755	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CG202312-07	41	2023-12-29	1.17257e+06	0	f	t	0	f	唐文静	 	2023-12-29 00:52:39.990863	S3823B29003		 				天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
RK202312-04	0	2023-12-28	0	0	f	t	0	f	唐文静		2023-12-28 11:51:38.660738					2023-12-11	CG202312-05	天津			朱玉树	0	0	0	0	0	7070	7093	7146.7	0	0	f	f	t	采购入库	0	0		
CG202312-05	37	2023-12-28	233.31	0	f	t	0	f	唐文静		2023-12-28 11:35:00.903243	G237T37001						天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
RK202312-03	0	2023-12-28	0	0	f	t	0	f	唐文静		2023-12-28 11:49:15.945602					2023-12-11	CG202312-04	天津			朱玉树	0	0	0	0	0	13206	13231	12989.9	0	0	f	f	t	采购入库	0	0		
CG202312-04	37	2023-12-28	435.8	0	f	t	0	f	唐文静		2023-12-28 11:32:46.937008	G238T11003						天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
CK202401-04	25	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 10:30:44.442492		/upload/pics/pic_CK202401-04.jpg		天津彩虹石油机械有限公司	 CHSC-231249	XS202312-58	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS202312-69	43	2023-12-30	1500	0	f	t	0	f	张金宝		2023-12-30 05:59:22.165292						21-WXM-230756	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-71	48	2023-12-30	13671.3	0	f	t	0	f	张金宝		2023-12-30 06:01:58.468633						21-WXM-230759	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK2401-001	35	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 01:56:00.31672		/upload/pics/pic_CK2401-001.jpg		荆州诚达石油工具有限公司	21-WXM-230755	XS202312-68	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-027	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:46:40.357822			21-WXM-230752		荆州市瑞驰石油机械有限公司	XS202312-65	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK202401-12	25	2024-01-04	0	0	f	t	0	f	唐文静		2024-01-04 11:34:44.432438		/upload/pics/pic_CK202401-12.jpg		天津彩虹石油机械有限公司	CHSC-231234	XS202312-33	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-012	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:39:07.753243	 		CHSC-231240		天津彩虹石油机械有限公司	XS202312-40	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-011	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:38:48.064653	 		CHSC-231242		天津彩虹石油机械有限公司	XS202312-41	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-008	0	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 02:37:57.562595	 		CHSC-231244		天津彩虹石油机械有限公司	XS202312-54	天津	 	 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS202312-70	64	2023-12-30	1252.5	0	f	t	0	f	张金宝	 	2023-12-30 06:01:04.167511		 		 	 	 21-WXM-230758	天津			张金宝	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
FH2401-023	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:45:57.411637			21-WXM-230756		天津市克赛斯工贸有限公司	XS202312-69	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-010	25	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 07:37:59.247384		/upload/pics/pic_CK2401-010.jpg		天津彩虹石油机械有限公司	CHSC-231246	XS202312-53	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-007	25	2024-01-06	64813.9	0	f	f	0	f	唐文静		2024-01-06 03:24:32.833802						CHSC-231231	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS202312-63	59	2023-12-30	38642.4	0	f	f	0	f	张金宝	 	2023-12-30 05:43:32.029337		2024-01-05		 	 	21-WXM-230750	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
CK2401-005	59	2024-01-05	0	0	f	t	0	f	唐文静	 	2024-01-05 03:31:06.698693		/upload/pics/pic_CK2401-005.jpg		深圳威晟海南分公司	21-WXM-230750	XS202312-63	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CK2401-007	27	2024-01-05	0	0	f	t	0	f	唐文静		2024-01-05 03:41:22.805008		/upload/pics/pic_CK2401-007.jpg		鞍山申阔机械制造有限公司	21-WXM-230746	XS202312-49	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-032	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:48:43.050159	德阳市旌阳区工农街道千佛村九组（德阳鼎宏）		21-WXM-230719		德阳鼎宏科技有限责任公司	XS202312-02	天津	王晓明	13678388523	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-006	50	2024-01-05	0	0	f	t	0	f	唐文静	 	2024-01-05 03:38:19.66637		/upload/pics/pic_CK2401-006.jpg		东营市瑞丰石油技术发展有限責任公司	21-WXM-230724	XS202312-10	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-026	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-06 03:46:30.132827			21-WXM-230753		俱准（天津）机械设备有限公司	XS202312-66	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
RK2401-001	0	2024-01-08	0	0	f	t	0	f	唐文静		2024-01-08 03:05:06.074197					2024-01-06	CG2401-001	天津			朱玉树	0	0	0	0	0	744	744	703.5	0	0	f	f	t	采购入库	0	0		
FH2401-034	0	2024-01-08	0	0	f	t	0	f	张金宝		2024-01-07 23:52:11.233907	津南区八里台工业园南区春经路		21-WXM-240013		天津鑫威斯特石油机械有限公司	XS2401-004	天津	徐超	15522118082 	朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-036	0	2024-01-08	0	0	f	t	0	f	张金宝		2024-01-07 23:52:37.541006			21-WXM-240010		天津隆凯来石油设备有限公司	XS2401-001	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-013	25	2024-01-08	315720.1	0	f	f	0	f	唐文静	 	2024-01-08 09:29:06.984917		 		 	 	CHSC-240102	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	f	t	商品销售	0	0		
XS2401-016	43	2024-01-09	1815	0	f	t	0	f	张金宝		2024-01-09 00:06:16.087793		2024-01-09				21-WXM-240021	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-018	25	2024-01-08	0	0	f	t	0	f	唐文静	 	2024-01-08 03:11:47.559459		/upload/pics/pic_CK2401-018.jpg		天津彩虹石油机械有限公司	CHSC-231231	XS2401-007	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
CG2401-002	38	2024-01-11	60450	0	f	t	0	f	唐文静	 	2024-01-11 14:33:08.638576	G239P32001		 				天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	材料采购	0	0		
CK2401-023	74	2024-01-09	0	0	f	t	0	f	唐文静		2024-01-09 10:32:18.61936		/upload/pics/pic_CK2401-023.jpg		天津市达利普石油管材有限公司	21-WXM-240023	XS2401-017	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
XS2401-010	72	2024-01-08	26832	0	f	f	0	f	张金宝	 	2024-01-08 05:40:16.527458		2024-01-09		 	 	21-WXM-240019	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-027	50	2024-01-09	0	0	f	t	0	f	唐文静		2024-01-09 10:41:19.80803		/upload/pics/pic_CK2401-027.jpg		东营市瑞丰石油技术发展有限責任公司	21-WXM-240028	XS2401-022	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-057	0	2024-01-09	0	0	f	t	0	f	张金宝		2024-01-11 14:23:27.323132	陕西咸阳市乾县城关街道乾县城关街道工业区玖犁汇智中心D-1 	安能到付	21-WXM-240019		陕西众诚汇智油气工程技术有限公司	XS2401-010	天津	焦云风	15829446000		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-012	25	2024-01-08	9005	0	f	f	0	f	唐文静		2024-01-08 09:19:58.282667						CHSC-240105	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
CK2401-017	70	2024-01-06	0	0	f	t	0	f	唐文静		2024-01-06 10:04:14.680805		/upload/pics/pic_CK2401-017.jpg		山东宸丰瑞晟精密机械加工有限公司	21-WXM-240015	XS2401-006	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-059	0	2024-01-06	0	0	f	t	0	f	张金宝		2024-01-11 14:26:01.355336	山东省德州市德城区广驰工业园29#车间	自提	21-WXM-240015		山东宸丰瑞晟精密机械加工有限公司	XS2401-006	天津	司立民	15621250872		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
CK2401-022	43	2024-01-09	0	0	f	t	0	f	唐文静		2024-01-09 10:31:21.935128		/upload/pics/pic_CK2401-022.jpg		天津市克赛斯工贸有限公司	21-WXM-240021	XS2401-016	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-083	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 19:00:22.843449	荆州市沙市区318国道银湖工业区B5栋荆州市赛瑞能源技术有限公司		21-WXM-240043		荆州市赛瑞能源技术有限公司	XS2401-045	天津	田学虎	13972331343		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
FH2401-086	0	2024-01-16	0	0	f	t	0	f	张金宝		2024-01-16 19:01:00.098595	荆州市荆州区西环路 135号 荆州诚达石油工具有限公司		21-WXM-240039		荆州诚达石油工具有限公司	XS2401-041	天津	胡蕾	177 2038 9392		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
XS2401-009	52	2024-01-08	22573.57	0	f	f	0	f	张金宝	 	2024-01-08 05:37:18.693966		2024-01-09		 	 	21-WXM-240018	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	f	t	t	商品销售	0	0		
FH2401-035	0	2024-01-08	0	0	f	t	0	f	张金宝		2024-01-07 23:52:25.529871			21-WXM-240012		天津天屹能源科技有限公司	XS2401-003	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	f	t	运输发货	0	0		
RK2401-005	0	2024-01-23	0	0	f	t	0	f	admin		2024-01-23 20:05:16.265293						CG202312-01	天津			admin	0	0	0	0	0	0	0	225.1	0	0	f	f	t	采购入库	0	0		
CT2401-001	36	2024-01-23	0	0	f	t	0	t	admin	不合格品退货	2024-01-23 20:05:54.281167							天津			admin	0	0	0	0	0	0	0	0	0	0	f	f	t	采购退货	0	0		
XS2401-053	30	2024-01-24	2314.5	0	f	f	0	f	admin		2024-01-24 19:03:26.761048						HT222333	天津	PO123		admin	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
RK2401-006	0	2024-01-23	0	0	f	t	0	f	admin		2024-01-23 20:16:33.145198						CG202312-01	天津			admin	0	0	0	0	0	0	0	130.8	0	0	f	f	t	采购入库	0	0		
CK2401-057	30	2024-01-24	0	0	f	t	0	f	admin		2024-01-24 19:04:32.0528				天津顺得来机械工程有限公司 	HT222333	XS2401-053	天津			admin	0	0	0	0	0	0	0	0	0	0	t	f	t	销售出库	0	0		
FH2401-089	0	2024-01-24	0	0	f	t	0	f	admin		2024-01-24 19:05:00.378952	天津市滨海新区开发区天龙路9号尼罗石油院内		HT222333		天津顺得来机械工程有限公司 	XS2401-053	天津	程相征	13602187847	admin	0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
KP2401-005	48	2024-01-25	62373.7	0	f	f	0	t	admin	已完成	2024-01-25 08:36:38.593065		荆州市赛瑞能源技术有限公司	/upload/pics/pic_KP2401-005.jpg	 	9842.00	XS202401-08	天津	21-WXM-240008		admin	0	0	0	0	0	0	0	0	0	0	f	f	t	销售开票	0	0		
KP2401-001	30	2024-01-24	2314.5	0	f	f	0	f	admin	 	2024-01-24 22:22:13.79269		天津顺得来机械工程有限公司 		 123	2460.00	XS2401-053	天津	HT222333 / PO123		admin	0	0	0	0	0	0	0	0	0	0	f	f	t	销售开票	0	0		
CK2401-058	45	2024-01-25	0	0	f	t	0	f	admin		2024-01-25 07:11:30.064171		/upload/pics/pic_CK2401-058.jpg		天津市通盈石油技术开发有限公司	21-WXM-240047	XS2401-050	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	销售出库	0	0		
XS2401-055	30	2024-01-28	114	0	f	t	0	f	admin	 	2024-01-28 06:20:04.637195		 				w333	天津	 			0	0	0	0	0	0	0	0	0	0	f	f	f	商品销售	0	0		
CK2401-059	45	2024-01-25	0	0	f	t	0	f	admin		2024-01-25 14:05:23.896701		/upload/pics/pic_CK2401-059.jpg		天津市通盈石油技术开发有限公司	21-WXM-240047	XS2401-050	天津				0	0	0	0	0	0	0	0	0	0	f	f	t	销售出库	0	0		
KP2401-008	54	2024-01-27	561.2	0	f	t	0	f	admin		2024-01-27 18:32:17.808453		天津隆凯来石油设备有限公司			264.00	XS2401-001	天津	21-WXM-240010			0	0	0	0	0	0	0	0	0	0	f	f	f	销售开票	0	0		
FH2401-090	0	2024-01-27	0	0	f	t	0	f	admin		2024-01-27 21:09:16.231685	天津滨海高新区塘沽海洋科技园新北路4668号创新创业园17-A号厂房东侧	自提	21-WXM-240042		天津远海采油科技有限公司	XS2401-044	天津	阮经理	15222616080		0	0	0	0	0	0	0	0	0	0	f	f	f	运输发货	0	0	苏A56896	13566889976
CT2401-002	36	2024-01-23	0	0	f	t	0	f	admin	不合格品退货	2024-01-23 20:17:08.007618	 		 				天津				0	0	0	0	0	0	0	0	0	0	f	f	f	采购退货	0	0		
XS2401-056	25	2024-01-28	2408.4	0	f	t	0	f	admin	 wweeee	2024-01-28 07:07:58.893721		 				ddddd	天津	 			0	0	0	0	0	0	0	0	0	0	f	f	f	商品销售	0	0		
FH2401-076	0	2024-01-16	0	0	f	t	0	f	张金宝	收预付45000元	2024-01-16 11:40:28.960628	成都市新都区工业东区虎桥路199号B3-2		21-WXM-240030		成都若克石油技术开发有限公司	XS2401-029	天津	林静	18180975876		0	0	0	0	0	0	0	0	0	0	f	f	t	运输发货	0	0		
KP2401-002	43	2024-01-25	2131.5	0	f	t	0	f	admin		2024-01-25 07:25:16.465853		天津市克赛斯工贸有限公司			702.00	XS2401-018	天津	21-WXM-240025			0	0	0	0	0	0	0	0	0	0	f	f	f	销售开票	0	0		
CG2401-005	37	2024-01-28	28140	0	f	t	0	f	admin	 	2024-01-28 07:07:06.647146	we333		 				天津				0	0	0	0	0	0	0	0	0	0	f	f	f	材料采购	0	0		
XS202401-08	48	2024-01-04	62373.7	0	f	f	0	f	张金宝		2024-01-04 07:12:30.134169		2024-01-05				21-WXM-240008	天津			admin	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
KP2401-007	33	2024-01-25	2990	0	f	f	0	t	admin	 	2024-01-25 14:07:36.35078		天津鑫威斯特石油机械有限公司	/upload/pics/pic_KP2401-007.jpg	 	12876.00	XS2401-004	天津	21-WXM-240013		admin	0	0	0	0	0	0	0	0	0	0	f	f	t	销售开票	0	0		
XS2401-004	33	2024-01-05	2990	0	f	f	0	f	张金宝		2024-01-05 09:30:01.550187		2024-01-06				21-WXM-240013	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS2401-054	33	2024-01-27	638.3	0	f	t	0	f	admin		2024-01-27 22:39:49.983289						2222233333	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	商品销售	0	0		
XS2401-051	28	2024-01-23	6028	0	f	t	0	f	admin	 	2024-01-23 20:47:20.944923		 	 www			2wesdsd	天津				0	0	0	0	0	0	0	0	0	0	f	f	f	商品销售	0	0		
KP2401-003	33	2024-01-25	2990	0	f	t	0	f	admin		2024-01-25 07:29:04.976276		/upload/pics/pic_KP2401-003.jpg			2706.00	XS2401-004	天津	21-WXM-240013			0	0	0	0	0	0	0	0	0	0	f	f	f	销售开票	0	0		
KP2401-006	43	2024-01-25	2131.5	0	f	f	0	f	admin	 	2024-01-25 10:25:25.836234		天津市克赛斯工贸有限公司	/upload/pics/pic_KP2401-006.jpg	 	936.00	XS2401-018	天津	21-WXM-240025		admin	0	0	0	0	0	0	0	0	0	0	f	f	t	销售开票	0	0		
KP2401-004	54	2024-01-25	561.2	0	f	t	0	f	admin	 	2024-01-25 07:39:11.378775		天津隆凯来石油设备有限公司	/upload/pics/pic_KP2401-004.jpg	 	246.00	XS2401-001	天津	21-WXM-240010			0	0	0	0	0	0	0	0	0	0	f	f	f	销售开票	0	0		
XS2401-018	43	2024-01-09	2131.5	0	f	f	0	f	张金宝		2024-01-09 06:08:09.935316						21-WXM-240025	天津			朱玉树	0	0	0	0	0	0	0	0	0	0	t	t	t	商品销售	0	0		
XS2401-052	31	2024-01-23	1120.8	0	f	t	0	f	admin	 	2024-01-23 20:53:49.613806		 				swdddd	天津	wewdsd			0	0	0	0	0	0	0	0	0	0	f	f	f	商品销售	0	0		
\.


--
-- Data for Name: help; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.help (id, page_name, tips, show_order) FROM stdin;
\.


--
-- Data for Name: kp_items; Type: TABLE DATA; Schema: public; Owner: sam
--

COPY public.kp_items (id, "单号id", "名称", "规格", "单位", "单价", "数量", "税率", "顺序") FROM stdin;
6306f86b-59d9-4e46-a98e-f144344242a8	KP2401-002	无缝钢管	17-4	kg	3	234	13%	1
005690ce-4f15-4498-9689-9e17ac32ee11	KP2401-003	无缝钢管	17-4	kg	22	123	13%	1
6877a1dd-d651-4a30-9a89-b67f98ff90b4	KP2401-004	无缝钢管	17-4	kg	2	123	13%	1
5a77bdab-8b98-4e42-b222-8cca9142d8d3	KP2401-005	无缝钢管	17-4	kg	22	123	13%	1
8b3034dd-700e-4856-a796-5f8a08f177c9	KP2401-005	圆钢	17-4	kg	32	223	13%	2
c5e09dc0-a31d-4972-a5f4-d0e9696178c3	KP2401-001	无缝钢管	17-4	kg	20	123	13%	1
8d066e63-c434-4144-b8b7-79e15d65e965	KP2401-001	无缝钢管	17-4	kg	0	0	13%	2
a0307725-c34f-45d8-9494-ea72a30b3f2d	KP2401-001	无缝钢管	17-4	kg	0	0	13%	3
ad43dea2-7aad-40d0-a255-2cfe06b085b3	KP2401-006	无缝钢管	17-4	kg	4	234	13%	1
18f709ff-b3c2-4edc-ab91-5728d8ae31b1	KP2401-007	圆钢	17-4	kg	22	234	13%	1
15d24632-fd1c-4282-b757-c7c3e5e0e3da	KP2401-007	圆钢	L80-13Cr	kg	24	322	13%	2
a8b54e64-46d1-4e1e-8fd0-bf967030ff76	KP2401-008	无缝钢管	17-4	kg	22	12	13%	1
\.


--
-- Data for Name: lu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lu ("炉号", "质保书") FROM stdin;
\.


--
-- Data for Name: pout_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pout_items (id, "单号id", "物料号", "长度", "数量", "重量", "备注", "顺序", "理重", "单价", xsid) FROM stdin;
451de63f-f806-48ec-ae1b-4449ef54fcdd	CK202312-01	L395	115	1	34.6		1	34.6	50	
5d1f1414-a169-4f4d-980a-d8d2279882c6	CK202312-02	L395	115	1	34.6		1	34.6	50	
682f60b3-1578-4fe6-acfd-5e7108f4629c	CK202312-03	M003639	7175	1	0		1	569.7	11.5	
fb21b61e-0fe1-4231-a146-0bb37ddce6ae	CK202312-03	M003635	7130	1	1147.8	1.2项重量合计	2	566.2	11.5	
e88709a9-b23f-449d-bbff-eaae07509bb9	CK202312-03	M002203	7670	1	0		3	612.8	11.5	
5cc9fa11-ac4a-47aa-b483-86afd3959272	CK202312-03	M002202	7840	1	0		4	626.4	11.5	
7945eded-1f80-4b9d-bed9-d4146c2264c2	CK202312-03	M002201	7770	1	1869.7	3.4.5项重量合计	5	620.8	11.5	
0f77f38e-cd52-4067-8e6e-52a3841fce19	CK202312-04	M003792	9630	1	1700	1410*6+余料	1	1717.2	11.5	
94c6eb28-f10e-4d98-9564-5280978d5bf9	CK202401-15	Z23010202	125	1	32		1	31	46	98eec790-81f8-460d-876b-4ae807c8e0af
cfc1f6ef-e848-40b5-a537-4ed2e9b0f8e8	CK202312-05	M004499	7700	1	892		1	887.1	11.3	
ed7e0366-e457-4f5e-869f-78eaf27ef707	CK202401-16	M004183	1400	1	220.4		1	221.1	25	12217999-dceb-4cef-8d4d-8c47c0018ad7
0fb9b873-29fb-4bb8-8bd8-46c731a52977	CK202401-19	M004607	1000	1	160		1	159	50	97315efa-c182-4f2c-971a-2c61afd22e61
c1a15195-b4bc-480a-8082-8d97b4287dbc	CK202312-22	M002791	380	1	0		1	32.1	30	
1fb4020f-de9d-4ba2-ad13-8ace5b85b81f	CK202312-22	M003163	190	1	50.3	第1.2项重量	2	16.1	30	
6c824ae6-8eb2-4d64-af44-e401bcf1460d	CK202312-22	M003396	2610	1	214.2		3	208.5	30	
f53a83a9-b0c0-4f99-a242-c2dc8092a8db	CK202312-22	M004263	3900	1	196.5		4	193.9	30	
d28b9a23-173b-4660-8a06-6dbb2c0e1fa6	CK202312-22	M000461	2620	1	130.3		5	131.8	30	
cd345d1e-044e-4c59-87df-c8da81803474	CK202312-22	M004089	3000	1	187.5		6	178.7	32.5	
6638e3ae-079e-4532-9759-080bd75b5c3e	CK202312-07	M004221	1620	1	141.8		1	144.9	50	
f31df039-bbdc-418f-8c28-7bf630615409	CK202312-07	M005569	1620	1	100.6		2	100.6	50	
6f27bbea-5ab1-45ce-92de-4b3eda139505	CK202312-22	M004782	3000	1	247		7	245.6	32.5	
0e3533fa-9250-4c01-8e7a-4bdf65243f6d	CK202312-22	M000083	510	1	0		8	37.9	30	
7a3e3801-dba3-4a82-bbcb-3b052bc4436d	CK202312-22	M000084	710	1	91	第8.9项重量	9	52.8	30	
826e12db-b575-4c95-90dc-bc8160df4cb4	CK202312-06	M003270	3500	1	0		1	214.4	45	
910db28b-5925-4f89-bc4f-f028efe2bf55	CK202312-06	M003271	8535	1	0		2	1273.3	45	
cf0ca319-c121-4ea0-af04-186fb820521f	CK202312-06	M003273	8485	1	3774.5	前3项重量	3	1265.8	45	
ee7bf732-1ccf-441f-94db-cae4f7d1c1de	CK202312-06	M001904	8340	1	261.7		4	1244.2	45	
25b1a3c4-25fd-4ce7-9f2e-2a0cc9583609	CK202312-08	M002134	510	2	75		1	76.2	13	
b6887da8-31a6-45e6-9dcf-05ef081e7807	CK202401-20	M002658	3450	1	1023.6		1	1036.9	45	4de72aa0-581d-4b81-b8a7-4f849e803d05
a7002656-65ab-4b83-9b56-d97f7f607996	CK202312-09	M002134	510	2	75		1	76.2	13	
71c715c3-59e1-4f9a-8cca-ea7d6b96325f	CK202401-20	M001640	7835	1	554		2	517.4	30.5	cbe27344-ed25-4409-b270-b43b98d516ad
b7526706-a284-4e52-81b2-f71e16d9c4ff	CK202312-23	M001467	6780	1	0		1	181	26.5	
c0e1b11f-ec36-4837-a99f-884c1ff99d22	CK202312-10	M003834	298	1	31.3	备注140*50.8	1	36	13	
93016d5c-ab0f-4035-bed5-039aee43b16d	CK202312-23	M001472	6770	1	0		2	180.8	26.5	
513864fd-67e2-41ea-ad66-ac198c524b98	CK202312-11	M002134	510	2	75		1	76.2	13	
fa94ef7e-1246-42d4-a6e8-5e5fc567b0fa	CK202312-12	M000844A	87	1	6.5	卡瓦	1	6.5	12	
e8cd501c-3e47-4523-9e50-5ac4dd86e2b4	CK202312-23	M001487	6770	1	0		3	180.8	26.5	
796948eb-c025-4059-8e34-43f16c9cb30a	CK202312-23	M001475	6790	1	729.5	第1.2.3.4项重量	4	181.3	26.5	
75f1b853-8d22-4674-8780-f523c6d47445	CK202312-13	M000844-A	87	1	6.5	卡瓦	1	6.5	12	
70e996d4-9bb3-4b4e-850e-7bab0aa069d8	CK202401-21	M005192	1694	2	409.4	中心管	1	409.7	13	f5ac87d8-22e2-4081-9937-07404911da42
934c25a7-2b32-4637-861f-02d2d30f02f2	CK202312-24	M001655	6400	1	485.8		1	388.3	68	
d3fbc785-bb42-4bda-a427-e25ed3230c67	CK202312-24	M001926	980	1	75		2	80.5	30	
cb9c754a-6b94-479d-91ce-371d030d1385	CK202401-23	M001973	460	2	112		1	111.2	12	ce8272e9-7812-42c8-b194-bfb25d7050c5
429aa158-4a69-4673-a22a-cbf0d1808175	CK202312-25	M003194	6770	1	355	3030+余料	1	345.2	31	
81e41bef-93cd-4684-928d-723a552d451a	CK202401-24	M003169	296	1	20.1	键套	1	20.1	33	80471e86-b448-4e55-80b9-ccfbb355a79d
7ac09df3-324c-486c-9e6a-c5f32ce16c56	CK202312-14	M003843	508	2	106.6	140*50.8	1	122.9	12	
2fdf4fc8-9612-4886-844a-01626ad4f902	CK202312-14	M003843	508	2	106.6	140*50.8	2	122.9	12	
05a66445-664c-4cc4-8dbe-2f6a7841ccdd	CK202312-15	M004211	6750	1	600.4		1	603.6	45	
2632ed6f-dcbf-420d-9aae-7a2ea0dad0b6	CK202312-26	M001655	6400	1	485.8	3300+3100	1	455.9	68	
58dd4406-8155-4577-ba45-87ecf7c43224	CK202312-26	M001926	980	1	75		2	80.5	30	
d2078b52-acf3-4b3b-bc61-3835dc2e3ee6	CK202312-44	M003151	1530	4	0		1	353.2	31.5	0b73e91f-8859-4e32-bbd9-eb477d4a98b8
33320aa0-3c06-41a9-85b5-185ac6082adf	CK202312-44	M003141	1530	4	0		2	353.2	31.5	0b73e91f-8859-4e32-bbd9-eb477d4a98b8
55d7da43-2013-483c-9433-7c55d43df196	CK202312-44	M003145	1530	4	0		3	353.2	31.5	0b73e91f-8859-4e32-bbd9-eb477d4a98b8
d56ee0c0-d060-4984-b956-a64e7372dd47	CK202312-44	M003150	1530	4	0		4	353.2	31.5	0b73e91f-8859-4e32-bbd9-eb477d4a98b8
003e41d5-2958-437d-b733-2ccdb742c40f	CK202312-16	M003653	2190	1	123		1	122.9	11.5	
fc58a4b3-3c5b-4d25-959d-e6cfc62c6832	CK202312-16	M005048	9940	1	0		2	723.1	11.5	
249e33ea-c223-487e-913f-eb721e2f1a60	CK202312-16	M005049	9940	1	1462	第2.3项重量	3	723.1	11.5	
e263c204-a7b2-4318-98d5-6f864ed804a4	CK202312-44	M003146	1530	4	0		5	353.2	31.5	0b73e91f-8859-4e32-bbd9-eb477d4a98b8
fe7a680d-f267-4a1c-9c94-818e49c213cd	CK202312-17	L366	150	1	30	C型环	1	30.2	50	
e5fc9867-068a-4874-99f8-7af2a23cd12e	CK202312-18	M001904	250	5	93.5	加厚2-7/8接箍	1	93.9	50	
59c55c46-23df-4218-9795-1f36e48a55b5	CK202312-19	M005362	450	1	54.4		1	54.8	50	
d23ec473-7e88-40f5-8279-e7e41043f59e	CK202312-19	M004216	505	1	44.8		2	45.2	50	
e18fe489-0683-4bdf-9c32-744ff9adfdf5	CK202312-20	M002119	720	1	64		1	64	13	
f7ec9257-d41c-4c25-b330-e58d09edea1d	CK202312-27	M002024	8260	1	1101.8		1	1089.3	30.5	
92ea2800-c754-4c65-b978-852ef5047a35	CK202312-27	M004121	6270	1	0		2	252.2	30.5	
44da39d2-c28a-4cfb-9c4d-dcd3f76191a4	CK202312-27	M004118	6180	1	493.7	第2.3项重量	3	248.6	30.5	
4f6650f6-17b8-4788-8e5e-44e32932b68f	CK202312-21	M004221	3000	1	262		1	268.2	50	
b8cf7c27-23db-408a-b511-efdf0dcca80d	CK202312-21	M005344	2940	1	356.3		2	357.8	45	
00c03cb6-8f9a-4be5-95d9-db0ad5292536	CK202312-21	M003272	5000	1	744.6		3	745.9	50	
31569b1a-b16b-4312-b633-00de89c383c6	CK202312-21	M001593	4200	1	746.7		4	753.7	50	
6d8abecc-b572-4b73-8418-4055142c5cc8	CK202312-21	L374	1000	1	224.5		5	224.2	50	
5380d389-e05c-4c91-8eb6-6134872b70e9	CK202312-21	M001594	3500	1	867		6	869.3	50	
8d95a4fc-e3da-42d5-81c5-b5c6575263d9	CK202312-21	M003096	6150	1	1834		7	1848.3	45	
8fde081d-923f-46a5-81fa-75bc6ef57c46	CK202312-21	M000812	1400	1	384.2		8	383.4	50	
94e812b9-8b5d-48a0-a953-ddfc770ed5e7	CK202312-27	M003139	7900	1	451		4	455.9	30.5	
f9ddda26-8e72-4a71-92fa-13cd4889364c	CK202312-27	M001669	5940	1	0		5	360.4	68	
35ae7e7f-d1a5-4666-b9b7-d487a442c577	CK202312-27	M001663	5935	1	783	第5.6项重量	6	360.1	68	
ef540ffe-0e1a-48c7-a871-40d7dae8fc84	CK202312-27	M001235	5185	1	1697		7	1703.2	43.8	
a97539d6-66c8-41f3-aab0-fbdbbae6cfb4	CK202312-27	M001557	5190	1	0		8	1704.8	43.8	
0f35ee5d-213d-4c8e-bfb2-41c38e8511b9	CK202312-27	M001239	3465	1	1123		9	1138.2	43.8	
475c7890-214a-41e7-8f68-34c01b0e1a09	CK202312-27	M001559	5190	1	0		10	1704.8	43.8	
149e933b-6556-4233-ae98-f3ad1bae94a3	CK202312-27	M001236	5190	1	3388.7	第10.11项重量	11	1704.8	43.8	
37471741-cd23-43ef-a5fe-0a1e2da62386	CK202312-27	M001561	5190	1	3406.5	第8.12项重量	12	1704.8	43.8	
43151e53-708a-48fc-8278-27f4ca025c97	CK202312-27	M003108	5680	1	1857		13	1865.8	43.8	
5f3e15ba-2810-4ba2-8e17-39a1a8c3dcef	CK202312-27	M002660	3440	1	1036.2		14	1033.9	43.8	
91801aba-fc7f-4175-a6c5-40cb5ffe3989	CK202312-27	M001897	7030	1	527		15	528.2	43.8	
21fd34df-2e69-4da3-b3fa-fff94435170d	CK202312-27	M004210	6575	1	577		16	587.9	43.8	
22e3d669-878d-4a94-a6bf-ac35ce2144de	CK202312-27	M001858	3450	1	0		17	283.3	33.5	
988903ec-b80f-4f71-95d1-8ae7983cd0c5	CK202312-27	M001806	3450	2	0		18	566.6	33.5	
4853e69b-0244-4d1b-a6d4-32577c6f1b28	CK202312-27	M001804	3450	2	1422.4	第17.18.19项重量	19	566.6	33.5	
a9d89ae0-b6f4-4569-a68e-29898abed96b	CK202312-42	M004093	955	1	211		1	212.7	13	
ac3de39e-ef0b-452e-8b7e-e0039a682a69	CK202312-28	M005362	1500	1	181.2		1	182.6	51.7	b0d4a164-098c-4ba0-95a1-ad182010d9b5
3bbf250f-b731-4253-9bf9-d3d331d8fb70	CK202312-42	M002137	2315	1	686		2	691.3	13	
dd83c410-0f1d-4492-aa5f-1f04db95c066	CK202312-30	M000821	390	1	15.4		1	15.5	50	8c9382ae-24dd-4abd-940e-654cabf951ce
688c4114-1562-4793-961d-eb0d082eb252	CK202312-29	M000721	390	1	15.4		1	15.5	50	8c9382ae-24dd-4abd-940e-654cabf951ce
90425657-71c8-49dc-a7d7-2db6a1f7b4da	CK202312-42	M002137	210	1	62.3		3	62.7	13	
ce5ae0df-1115-4d8c-9c59-5cd41f2c75de	CK202312-42	M004097	730	1	115		4	115.3	13	
9d6c1138-cf41-42a9-bc2d-dbd4c989fe3d	CK202312-42	M004097	45	1	7.2		5	7.1	13	
cebf09eb-74a3-47ac-bdd4-97d14de33ded	CK202312-42	M004108	645	1	67.8		6	67.3	13	
b77ee262-053c-4820-a8a0-acf3c44fccd3	CK202401-13	M001959	578	1	104.7		1	103.1	28	e0c1c738-8b3e-4f3a-a377-e38cf48c08d5
5723afcf-267b-4eac-afc0-4aabc94a56ca	CK202312-32	M002119	240	1	21.4		1	21.3	13	7a8f1144-4530-4ab2-aa3f-12e93c593ccf
0a070cf9-b481-4e61-9ea4-83c4d70283ef	CK202312-32	M005207	210	1	29		2	29.2	13	90043473-7e0f-4a10-b9fe-b3ee5c1a49e1
d6939d89-3ca9-4efa-8dd0-af198fb97638	CK202401-25	M003790	300	1	89.6		1	89.6	17.5	24ee5d4a-e5d8-4d89-8216-1d6743e0d282
1f253344-b994-47a6-99fb-f8f3bec00c1e	CK202312-34	M001922	6300	1	522.6		1	517.3	30	691e6faf-ce16-4556-89bf-5541c57814f3
af7b1b6c-f706-4a25-a186-45394c707e7a	CK202312-35	M002960	1430	2	175.2	回接筒	1	175.2	12	7d34755f-4e3e-4155-8134-334356f95935
3737a632-28fb-4d55-a3d5-0b1600bda18f	CK202312-35	M003503	764	2	160.2	坐挂套	2	160.1	12	10b67473-dd9a-41e9-b4db-34c8458df10a
ebe793a3-ed7c-40ac-8365-034aeee63cfc	CK202312-35	M002880	275	2	0	密封限制套	3	21.7	25	504e52c2-8b68-446b-ac33-409d0b6b11c1
2305d2fd-afe3-4333-8054-b60945891ffe	CK202312-35	M002895	275	2	21.6	第3.4项重量	4	21.7	25	504e52c2-8b68-446b-ac33-409d0b6b11c1
b5061b54-550b-4f10-af49-3729cfd26794	CK202401-25	M001949	9200	1	1139		2	1100.3	11	fb000743-349c-4d60-83dc-12a10a984f6b
e3a7c956-034c-441a-a626-2615511ed488	CK202401-26	M000277	500	2	87		1	83.5	15	2681d31d-ee72-42e6-8c09-e256aa8d469a
5bcca5cc-4b18-4619-8f09-cdd917b92d51	CK2401-036	M001641	267	5	0		1	88.2	33	
c853452e-bab1-415f-83b3-635424df70c3	CK2401-036	M001646	267	3	140.8	第1.2项重量	2	52.9	33	
39a2f570-6881-46ec-b05d-2d2ff45b12b6	CK202312-36	M002960	1430	2	175.2	回接筒	1	175.2	12	7d34755f-4e3e-4155-8134-334356f95935
c3485790-5e38-4808-8315-fc891a049a68	CK202312-36	M003503	764	2	160.2	坐挂套	2	160.1	12	10b67473-dd9a-41e9-b4db-34c8458df10a
4e5a0aa9-efc1-466b-9bec-2836bb8a9e12	CK202312-36	M002880	275	1	0	密封限制套	3	10.9	25	504e52c2-8b68-446b-ac33-409d0b6b11c1
d8c384be-9fd6-4e7b-a69e-bab4567b50fc	CK202312-36	M002895	275	1	21.6	第3.4项重量	4	10.9	25	504e52c2-8b68-446b-ac33-409d0b6b11c1
03473d1b-effe-4cbf-aaac-03aca2084a85	CK2401-037	M005477	3018	2	0		1	592.4	33	
d9625f43-542c-4e55-a481-61f799e39524	CK202312-33	M002651	5010	1	0		1	1505.7	45	
76df2606-157e-439b-998a-0c169d0faeb2	CK202312-33	M002652	5160	1	3048.5	第1.2项重量	2	1550.8	45	e1d5d3a0-6065-4a8f-8916-d78a80a265a1
ff1c208f-4cc2-4a51-adf4-43505457b10d	CK202312-33	M002337	6770	1	1851.6		3	1853.9	45	c097d8b6-c1df-4432-aa8c-81ea872cdf00
d1247737-0717-44be-a58b-8a2c2a3a8015	CK202312-43	M002050	950	2	567		1	567.4	13	
3a16073f-bab8-41cd-a057-6aa944f98d93	CK202312-43	M004096	4060	2	0		2	1808.6	13	
8241198f-038a-455a-9dce-d2567d6898b6	CK202312-37	Z23010527	95	10	114		1	113.6	12	87627862-b34f-4227-b480-662f9743ccca
79b1c29e-4c5c-4743-8984-065a7598fd8f	CK202312-43	M004094	4060	2	3576	第2.3项重量	3	1808.6	13	
e6af2b9d-aa1a-47e8-a414-8e0feec0c4fa	CK202312-43	M004097	810	5	0		4	639.7	13	
7ad3921f-b940-487b-b76b-55016843cf3a	CK202312-43	M004098	810	1	765	第4.5项重量	5	127.9	13	
ae64c9e8-411e-47b1-a0c1-3fb8c0940ebb	CK202312-38	M003482	6380	1	835.2	3040+余料	1	770.9	11.5	
340dd637-585b-4056-a02e-4eab71dc616b	CK202312-38	B230110-4	1520	1	200.6		2	183.7	12	
79da7257-88b3-44c8-8b3b-5c9c46d36076	CK202312-38	M002191	1430	1	145.4		3	140.3	12	
71b9b06c-f8ea-408b-b1ee-2620c393c4ff	CK202401-05	M001641	267	3	52.8		1	52.9	33	
1fe1a591-fc42-49e2-b762-59b9bf9e59b9	CK202401-05	M004108	460	4	191.6		2	191.9	13	
90369940-c1a5-490a-a566-2408ec0e4f81	CK202401-05	M003848	80	2	25.8		3	32	13	
41f72027-3c32-4e7a-9315-a639876a3ce3	CK202401-05	M001369	80	1	23.9		4	23.9	10	
50662990-d8f1-4886-8776-f8ef2edc7c53	CK202312-39	M004176	534	2	0		1	190.4	28	6c7eb440-35c0-4500-9274-4805a4b32e4e
2219a285-9f35-49ed-a149-2b3122b828e5	CK202312-39	M004176	434	2	0		2	154.8	28	d207f7c4-030b-48ac-b674-ccfe18043f68
3ca48ce8-a6e8-4bc8-b649-c5bd5738d993	CK202312-39	M004176	768	2	624.3	第1.2.3项重量	3	273.9	28	6751d4a6-c893-4840-81c0-e8eaeb5913bd
a78c5f8d-f4a2-462f-85eb-a392a823fb2d	CK202312-39	M002355	1886	2	425.3		4	424.2	28	b6204b7d-522c-4ca7-b3b7-02d83a30e90e
6bc25be2-d964-4e83-82c5-42dbdec0365c	CK202401-05	M005163	1425	2	318.8		5	318.8	12	
cc5fedaa-8699-4dce-8c76-bd09c75abff8	CK202312-40	M002343	7800	1	638.3		1	636.5	26.5	c2296f26-b53c-42b3-932e-67b29ddba974
0133c79c-8f0b-44a2-b42e-8ac1c864c38d	CK2401-001	M002885	2112	3	0		1	250.2	25	89a88983-ca55-41ec-a737-58e0c4f4856f
0af2fb9c-26a5-46c7-bf41-73f9aaff171e	CK202312-41	M002116	1000	4	355.2		1	355.4	13	6b08584f-1b9b-4f01-9600-6c4113abb445
3d6a3ab3-35b1-4110-b60c-a52b17a9905c	CK2401-001	M002884	2112	3	0		2	250.2	25	89a88983-ca55-41ec-a737-58e0c4f4856f
f0055501-4ad0-40cf-b08d-cae511f3fd96	CK2401-001	M002883	2112	3	0		3	250.2	25	89a88983-ca55-41ec-a737-58e0c4f4856f
3f5ae58c-48be-4aa8-af71-fd0aece59540	CK2401-001	M002889	2112	3	0		4	250.2	25	89a88983-ca55-41ec-a737-58e0c4f4856f
31f9f52e-3532-45da-9c8f-ea50a864f169	CK2401-001	M002890	2112	3	0		5	250.2	25	89a88983-ca55-41ec-a737-58e0c4f4856f
52c48fe2-7cb5-4f01-9923-0dadc5a1026f	CK2401-037	M005469	3018	2	0		2	592.4	33	
7a2cb002-fff6-4336-9bdc-c91aef752323	CK2401-037	M005472	3018	2	1790	第1.2.3项重量	3	592.4	33	
5bf24f18-7011-4513-a168-1f2c89c3646c	CK202312-44	M003144	1530	4	0		6	353.2	31.5	0b73e91f-8859-4e32-bbd9-eb477d4a98b8
c7144d7c-3c30-457c-9a74-ac05266d7b73	CK202312-44	M003149	1530	4	0		7	353.2	31.5	0b73e91f-8859-4e32-bbd9-eb477d4a98b8
584f1e4d-b041-4778-9daf-66d163aa012c	CK202312-44	M003147	1530	2	2610	第1.2.3.4.5.6.7.8项重量	8	176.6	31.5	0b73e91f-8859-4e32-bbd9-eb477d4a98b8
4888ced8-8715-4656-a7fe-ad11d99cb7da	CK202312-44	M003151	920	2	0		9	106.2	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
e1b92d84-21fa-47c5-8e75-2780c0bc893f	CK202312-44	M003141	920	2	0		10	106.2	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
47478a94-cf0d-4493-872a-bf16ea42e6b2	CK202312-44	M003145	920	2	0		11	106.2	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
4a56e9e2-f99b-40fb-8099-219e4ac9c6b6	CK202312-44	M003150	920	2	0		12	106.2	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
332d114f-62dc-4c5e-9dcd-16bdc8e7f2f5	CK202312-44	M003146	920	2	0		13	106.2	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
047bfd2d-3e0b-475c-9349-83d8a961e457	CK202312-44	M003144	920	2	0		14	106.2	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
d0cae557-95ce-4f27-aa39-b7355e053216	CK202312-44	M003149	920	2	0		15	106.2	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
c5bc3ed3-6158-4d30-9d4f-a9ac12c02f06	CK202312-44	M003147	920	5	0		16	265.4	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
8b5d4817-7e86-4572-8cc9-0870e41af319	CK202312-44	M003140	920	1	1054	第9.10.11.12.13.14.15.16.17项重量	17	53.1	31.5	ee364109-8dd6-4738-b7af-9e730a5b5ee6
9551ab6d-28df-4d35-aeb4-31b8f2ab4095	CK202401-14	Z23010527	1010	1	120		1	120.8	12	cc6bf00f-6273-4753-9a04-cd10b9120ae9
b3e7bbb3-c412-436f-8b70-e87256632896	CK202401-17	M004681	6600	1	0		1	586.4	23	df3b61c8-6cfb-45b9-acd1-7c8508655826
4776e829-a7c7-40e7-94c7-a55954d89f0d	CK202401-17	M004682	6045	1	0		2	537.1	23	fc95b256-7fee-439a-b15f-d2de3238577d
7ee021b2-174c-4c1a-82bd-a7b245c11ffb	CK202401-17	M004680	6010	1	1672	第1.2.3项重量	3	534	23	10aca881-6637-4fd1-8a84-99f7ab0cc0b2
96320a3c-7b7d-4c39-8df0-df908b375cc0	CK202401-17	M005190	9650	1	1155		4	1167	11.5	ef432e91-57ff-4473-8f8e-1e8bb47a48e6
0b373721-4fe0-4239-820a-472d95812fcf	CK202401-17	M004100	9650	1	1516		5	1524.2	11.5	e704a83d-75a4-4a7b-9753-f7e7d9b3e735
0537d119-e7ec-43ad-9ecf-ccde7fa11de5	CK202401-18	M003525	1200	1	71		1	69.2	12	
d037deef-0b4e-4dd9-bf58-da59ac157a99	CK202401-18	M003505	465	1	50.6		2	48.7	12	
767213a9-428f-4591-9769-50c1d5f42bae	CK202312-45	M004654	1180	1	73		1	72.8	25	16c69ca4-9280-490c-91e9-0d05651109d1
705a0eed-6eae-4917-adfa-1d56431aeb30	CK202312-45	M002896	1600	1	63		2	63.2	25	1c5c7abe-cdd5-4576-8995-24f8a78fac1c
8278592a-0920-41eb-b813-ba129b8dd0f5	CK202312-45	M002911	1180	5	233		3	233	25	94fc88be-5389-4866-a945-afe335d954be
6edcff05-2c6d-4908-bb67-5c7e8ad574b1	CK202312-45	M004676	1740	1	157		4	154.6	25	e7ec9dd3-aa32-4c7e-af26-90c5413fd93b
c8de8d27-ce78-40fd-bc72-0bab48d7854d	CK202312-45	M004672	1220	1	109.7		5	108.4	25	bfbb1852-47e2-4668-aed9-cbcea99bb3f2
0167ed6b-7d06-4c14-8cdf-339d6d4ee396	CK202312-45	M004676	2150	1	193.8		6	191	25	c5eed373-8d1d-4fb8-855c-6a503c82ea4e
2a7dd4b3-621a-48bb-a2a1-f2dae946da8d	CK202312-45	M000931	3730	1	83		7	82.9	25	5e4f9e9d-8cb7-4ac0-96c2-b7092ff8d708
0ae3b4bf-8db8-4a2a-be1c-e95806c181cf	CK202401-01	M002163	95	37	0		1	463.6	12	c1a917d5-f14c-4614-b307-b1f3d35a92d8
15f651a4-7ee7-4c88-9e74-569919c9c704	CK202401-01	M002143	95	37	0		2	463.6	12	c1a917d5-f14c-4614-b307-b1f3d35a92d8
87d8a5ac-2ea5-40c1-a1e4-63517a4ddfb0	CK202401-01	M002153	95	14	1100	第1.2.3项重量	3	175.4	12	c1a917d5-f14c-4614-b307-b1f3d35a92d8
1bc398e6-40b1-47b6-8b7e-86738014d4d1	CK202401-22	M000844-A	87	3	19.5	卡瓦	1	19.5	11	b6b97514-47c7-4a41-a6d1-48c80b4e13dd
cd087928-bbed-4c2e-92ce-66e8957cb873	CK202401-02	M004044	310	1	7.1		1	7.4	12	ce733b5a-52fb-417b-83e5-1b3348efab33
de71f38b-7919-494e-8651-4cb545cc56d8	CK202401-02	M002904	990	2	70.8		2	78.2	25	3f00ede0-6caf-46da-bec8-a4cb1aa5c578
32cea52c-4144-4072-9384-97edbe82d9af	CK2401-012	M002919	1090	1	38		1	37.1	11.5	e4df9e13-7d90-4ccf-a4f3-ea99f82fbd26
b11e14cc-1e94-49eb-8ca7-1c94e55d0c22	CK202401-03	M004628	278	1	83		1	83.5	50	53af7b77-939d-4e67-8c45-ddaba0f2042a
5d36ef9a-dad4-4161-a3c5-4138b55f2e19	CK2401-012	M003655	208	1	12.3		2	11.7	11.5	7c46ec45-2740-4fc6-8259-6762ee5228c9
f159267c-92b7-43ee-bf6b-6f7022dc0587	CK202401-04	M004628	15	10	45		1	45.1	50	6759a12a-73ca-47e5-9f6e-2ada804987df
04f1f006-a265-4ecd-b5ea-bda3b3e65094	CK202401-27	L271	440	1	36.7		1	36.1	50	85810501-32e1-43ec-b5e6-cb144c189208
e8310f67-5bd7-4adf-8fca-3e9787e07142	CK2401-014	M005814	1600	1	99		1	98.7	13	
6c22db1b-cb68-4811-91b6-a8fb623e9b1c	CK2401-015	M002134	620	2	0		1	92.6	13	
b83791bc-a640-4f6d-895f-15e79486fd99	CK2401-015	M002134	310	2	0		2	46.3	13	
880b683b-1c00-425d-a56c-be0afd661a83	CK2401-015	M002134	610	2	227	第1.2.3项重量	3	91.1	13	
8a18eaac-8bd4-463e-829b-67325852162e	CK202401-06	M002921	194	2	13.2		1	13.2	12	f8301a80-c7d5-476b-aac8-e0c571ef22a4
2c0ce8dd-f916-4ae8-a6c4-1a2bfd6dd2e5	CK202401-08	M004238	237	27	739.8		1	740.1	33	
09adb52c-689a-45e4-8fc4-80cb147ed919	CK2401-003	M000925	110	5	0		1	12.2	25	
f13fea41-81ae-49c1-81af-34cba10b74a2	CK202401-09	Z23010565	1080	1	149.8		1	149.9	12	3f3c0ca1-1f87-4826-86b2-09fc01e62093
40b05574-df77-4802-958e-db332f794275	CK202401-10	Z23010215	350	1	95.8		1	95.8	50	c1d066b6-14b1-451b-872d-698c6b39ffdb
0437e7b5-7e84-4197-a62f-b1606fb93c96	CK2401-003	M000930	110	1	14.8	第1.2项重量	2	2.4	25	
cc5d1cd9-a4c1-4a13-9237-7ea3afd203ee	CK202401-11	M004249	185	2	17.4		1	17.4	33	
e00b7c54-c627-4156-9f4e-6b6831a247cc	CK202401-11	Z230510-11	310	2	0		2	42.2	10	
c72c785d-4eb1-4050-b7a9-12695e5a4dae	CK202401-11	Z230510-7	310	2	72	第3.4项重量	3	38.3	10	
6109a397-5a4d-4639-90d5-65c9b22cd6cf	CK202401-12	M003433	98	10	0		1	129.2	33	a92a0f39-4308-444d-a51e-1e58af04c9a3
04dbb66b-844d-4712-8f27-da7547db647c	CK202401-12	M002031	98	10	258	第1.2项重量	2	129.2	33	a92a0f39-4308-444d-a51e-1e58af04c9a3
bed25465-ba38-4d20-89b6-ff88997f5846	CK202401-12	M001549	275	15	0		3	1231.8	25	c28051f6-16cc-41b4-a181-76d4b8e5d0bc
f43f17b4-5f71-45d8-8d2b-d42a9257c9f8	CK202401-12	M001545	275	5	1642	第3.4项重量	4	410.6	25	c28051f6-16cc-41b4-a181-76d4b8e5d0bc
1ac4e3f4-363b-46fc-986c-db789d4c7259	CK202401-07	M003056	25	138	204.24		1	204.2	12	
36e0b2a3-7287-45df-9acf-dcea44ade7a1	CK202401-07	M001656	267	20	378		2	380.4	75	
16079b28-9d5b-4616-afe1-641dff07a9cf	CK202401-07	Z23010202	680	1	167.7		3	168.9	33	
7cbfad96-693c-4f3c-8a8b-df02c3ec20e9	CK202401-07	M003167	160	1	9.6		4	9.7	75	
c6e17916-0bf3-4bdb-998d-430ec0ba80e8	CK202401-07	M003928	470	3	229.2		5	229.1	33	
8426e895-d719-4e84-9043-ac72024c8e0b	CK202401-07	M004782	360	1	29.5		6	29.5	33	
44dc32ce-696e-430a-b7de-63ffe4b3ea85	CK202401-07	M002955	210	16	206.4		7	205.8	12	
60e52eae-981d-42f0-9c0b-1d07176f177f	CK202401-07	M002031	15	6	12		8	11.9	33	7907766c-a08c-4d22-90af-b0bf8639c0a4
5567835d-baea-4132-9a09-fdf241a27d74	CK2401-001	M002886	2112	3	0		6	250.2	25	89a88983-ca55-41ec-a737-58e0c4f4856f
7ce3bbb6-368a-4dc8-a42b-9367566e8e01	CK2401-001	M002902	2112	1	0		7	83.4	25	89a88983-ca55-41ec-a737-58e0c4f4856f
27e3972e-1bec-4360-804f-a215c1ba9bce	CK2401-001	M002904	2125	1	1669		8	83.9	25	e2786837-4a37-41d7-b813-735af8921ebd
8aa83d88-5d5e-46da-b050-a7360cdbadfe	CK2401-009	M005569	1160	1	72		1	72	50	445f7b3e-9a63-4aba-9859-e638c7814eeb
f474ba20-98de-45fc-9bf8-23948a701d05	CK2401-009	M001787	1000	1	141		2	138.8	11	86065067-8f48-48ba-80e4-55eadb3b3064
d4d97d12-5bf4-4193-98f7-873ff21b324e	CK2401-002	M000903	1238	1	5		1	5	300	27e12f22-27ea-48e7-9779-7f2ef1e0f5f7
6a8a27dd-332d-4458-a761-d871e2c82f2f	CK2401-033	M001545	603	1	180	主体	1	180.1	25	62cee1a5-3726-4d18-be98-7a08541fabe9
6d131468-fcb9-45da-bb2c-fc7d93e4e0c8	CK2401-033	M001545	603	1	180	主体	2	180.1	25	90c1a914-f8a5-4fca-a7b9-ff70241367cf
affbc0cd-69f1-47a4-ac9d-e2e507c12449	CK2401-011	M004645	305	6	220.8		1	221.3	25	0eeb71fd-bf06-4205-a8c3-3c93fc035a5f
f322ab22-da18-4bd0-b229-5edd7a827b03	CK2401-011	M004354	370	13	666.9		2	667.7	25	1bb18078-ddb2-44ce-8151-d2c3fda22877
1bf6f758-a7f8-4a4f-84b0-d9aac005a06b	CK2401-011	M004645	313	5	188.5		3	189.3	25	e909618d-596c-472d-aac2-c5f9ce3e00aa
7296601c-70c3-4d23-8f96-be348e9b96a1	CK2401-011	M004183	325	9	460.8		4	462	25	4b5747d9-3b05-4b65-ad37-e9529e784295
4b5ce2d7-4424-4d47-8618-11644d598ff0	CK2401-011	M004180	535	11	927.3		5	929.5	25	041fe017-a339-4a31-8845-00b6944d03dd
e8b520fa-de60-42dd-958e-841ca29182d9	CK2401-011	M004645	357	1	0		6	43.2	25	87443149-2e4a-4061-876c-0dd62a84660c
ea18749a-699c-4c66-80d5-3fd5d4530e2f	CK2401-004	M003098	280	1	83		1	84.2	50	5e72c40f-898a-4f3e-8006-d371f2022933
315a830e-a4df-4665-9753-355cc71af8e7	CK2401-011	M004646	357	7	344	第6.7项重量	7	302.2	25	3e6886e3-786d-4c6a-8512-2dd1c429150d
e3b3b31c-a495-4d8e-a801-d1de5e26fc63	CK2401-011	M004646	357	7	301		8	302.2	25	3e6886e3-786d-4c6a-8512-2dd1c429150d
5a3e1cc1-f259-424f-b16a-b62613b755db	CK2401-011	M004644	268	5	161.5		9	162	25	e551a565-6c7d-48a8-b17c-679d9c9b9152
fa982642-18c3-4d1b-a11d-f3f94469b2f9	CK2401-034	M002102	680	4	0	上接头	1	60.4	12	dfe3c4d3-9e27-4871-9251-c7b38d2545cf
24e6de3e-4179-414c-b472-569b86f372d6	CK2401-034	M002108	680	6	151	第1.2项重量	2	90.6	12	dfe3c4d3-9e27-4871-9251-c7b38d2545cf
a5ccc26b-4d3a-4b62-9bb7-3fefafe3d861	CK2401-035	M003492	2457	1	0		1	200.2	12	9e728f95-7bcf-4466-ad9b-57cc1e3f3b84
da0678f5-d32e-472f-a2ed-1a086cfd2eda	CK2401-035	M003311	2457	1	0		2	200.2	12	9e728f95-7bcf-4466-ad9b-57cc1e3f3b84
6ca6d4cd-05ee-4ea6-b0e2-1787bdf2b4a6	CK2401-035	M003310	2457	1	600.6	第1.2.3项重量	3	200.2	12	9e728f95-7bcf-4466-ad9b-57cc1e3f3b84
ca5eb411-53ae-42ea-97ce-8726c814b0a5	CK2401-035	M003492	2074	2	0		4	338	12	28533b23-eb6a-4147-a766-fc4ab9c43afe
ae6d3c5a-bf57-41f2-a4a8-3763a1b793d5	CK2401-035	M003311	2074	2	676	第4.5项重量	5	338	12	28533b23-eb6a-4147-a766-fc4ab9c43afe
2a5b7080-dead-41b5-af0e-f8231ee83656	CK2401-041	M003706	3200	3	687		1	674.2	13.5	ceaeef9b-6a9d-43b1-995a-4aa3bddbb59a
2d62c671-3112-4747-9976-63197bc6febd	CK2401-042	M000882	233	1	14.4		1	15.1	330	
c16fb5c5-4b9b-4f87-9f55-03664f62e229	CK2401-006	M004219	6100	1	552		1	545.4	44	
d58f5534-d984-47a0-8d1a-d7495d1e928f	CK2401-006	M005574	6510	1	403		2	404.2	44	
5c40a816-f28a-467e-85f5-a73de972d5b7	CK2401-006	M005569	2426	1	151		3	150.6	49.47	
bd6c89dd-f18b-463d-adb7-70fe3b739be6	CK2401-007	M004164	5835	1	1746.5		1	1742.5	26.5	0a888e1b-1828-412b-b5ec-9ad24249ed88
19a1d179-c56a-41dc-be95-2cf4ad3e8f71	CK2401-007	M002304	6880	1	2054		2	2054.6	23	1c62e2ab-f226-4a2f-929e-148f5ad0bfe4
fee60d01-24e2-40a9-a2be-22edb8770e87	CK2401-007	M001547	6580	1	1952.5		3	1965	23	ff9e439c-3f33-46dc-8536-e42c4e6da9f0
4b927ed6-9c52-46da-8960-ba7dc2fbc04e	CK2401-007	M001542	6720	1	1999		4	2006.8	23	f0da4bbb-5d84-48e5-8641-f1b1f524d76a
1555c415-2df7-4324-a53f-cdcf72a043c0	CK2401-045	M002309	275	1	82	下连接体	1	82.1	25	3bbdb2f5-ead1-4998-adf9-a4b521fbd25a
2746a1df-77fe-4b60-9349-5d8228f4cd69	CK2401-051	M004183	740	1	116.5		1	116.9	25	2cd8e9a5-cca5-43d9-8ee1-df97b8c013c2
a685e183-2324-4713-88ce-b08f3af1eda5	CK2401-053	M003222	1950	2	256		1	247.6	33	8a3e8d81-c5cc-4083-b92a-8b9aab7cbaaf
beb56aee-29d3-4719-8cf3-2652dc6cb960	CK2401-020	M005192	510	2	122.7		1	123.4	13	
3db16be9-b808-4ae6-98e5-4cdced7318d9	CK2401-020	M003857	440	1	86.8		2	88	13	
79e7eab1-b0c2-4495-9823-3e8315755243	CK2401-053	M001761	245	1	18.5		2	17.8	33	6852e4b9-ed8d-4ff1-a1ca-b993a24b3887
94709c44-76af-466f-82d4-411f0e6a3916	CK2401-053	M002661	605	2	37		3	36.6	25	188b8822-bef5-4b47-bcc8-0df61e8fb167
b2d74f4c-e408-47ee-9b4f-422dc85564f6	CK2401-053	M002663	1840	1	56		4	55.6	25	1a38d622-551e-440e-98cd-448ccc7d5b9c
88655c0f-b513-422d-b9a4-5a33c50bea3b	CK2401-021	M005489	8000	1	0		1	472.3	16	285d9517-b382-4598-9a01-55bf8f0c52af
d3609498-c049-4a91-b110-7a20c539728c	CK2401-021	M005490	7920	1	0		2	467.6	16	c578b90b-dca7-422e-9827-1e736a2a5ddd
cd03461f-bcee-4902-a9d6-22b9566080c0	CK2401-022	M004027	200	1	5.7		1	5.5	330	00f13a4e-ed4b-40fb-9f2a-9d37b81cc349
cd7752a7-2b7f-4502-80c2-94e855af3e31	CK2401-053	M002661	1060	1	0		5	32	25	db7093e6-d654-4b4a-a6e1-08c6b7c2a75f
99d9a850-18c1-4e52-80b2-e02746dda01d	CK2401-053	M000762	1060	1	65	第5.6项重量	6	32	25	db7093e6-d654-4b4a-a6e1-08c6b7c2a75f
3a790384-7ed4-421d-8bb8-d07c8346e778	CK2401-028	M003933	450	1	56.4		1	55.5	330	
e81f8234-dea8-4b1f-8b49-7e08f056f8af	CK2401-016	M004683	6645	1	3632.2	第15.16.1718.19.20项重量	20	590.4	21.5	
30c1998a-413a-48e7-8350-7be9ac728b39	CK2401-016	M004692	4440	1	0		21	331.5	21.5	
70e95520-129b-4c9d-8296-6fe33c19de8b	CK2401-016	M004698	4240	1	0		22	316.5	21.5	
4b82361a-b807-4d49-bd9e-1cae93b9f499	CK2401-016	M004700	5155	1	1031.3	第21.22.23项重量	23	384.9	21.5	
0a9fbe0f-dcc2-4907-9803-a4f4591a562c	CK2401-016	M001011	920	1	57		24	56.8	21.5	
39e5d152-4a76-4ee2-b527-8b66b38cad4c	CK2401-016	M002902	3900	1	154.5		25	154	21.5	
acea40b9-cd40-4b41-ab0a-f382d17130a0	CK2401-021	M005491	8020	1	1445.5	第1.2.3项重量	3	473.5	16	5df2e6d5-efa4-4a69-896b-e1f16a6b2dd0
2c8a0cdc-0c0b-4ff2-817a-93a7a8436721	CK2401-055	M003588	4200	1	446.2		1	450.7	12	5c4dfd1d-f81b-497b-9a3e-67ba1204e232
90ed5c37-8fec-4d11-8143-b7c15bf8494b	CK2401-055	M002663	4000	1	121.2		2	120.9	25	a12d6aa6-b72d-4af7-9a4b-83eea234179d
3abe772c-1e30-4518-bb46-c7ba13b3ba2a	CK2401-013	B230110-4	1520	2	0		1	367.3	12	
f7767b60-c2f7-4943-b7da-62b0ae861f81	CK2401-010	M000899	125	9	8.9		1	8.9	330	c329b2d8-2cf4-4d41-8dbc-06b13ec5e58c
5a0d25d0-aae0-4141-8c01-b59bb5f5ef43	CK2401-013	M003483	1520	4	0		2	734.7	12	
f7139599-b84e-46e0-8a19-e4165c6d7e4a	CK2401-013	M003484	1520	4	0		3	734.7	12	
8bc2c738-d216-4519-90f4-87384c1a0167	CK2401-013	B230110-9	1520	1	2189	第1.2.3.4项重量	4	183.7	12	
027e53ab-f983-4d77-8c9a-2d69e5b65ad4	CK2401-013	M002301	278	11	310.2		5	300.1	12	
84f58159-de13-4cd4-ba70-3554331e9eb9	CK2401-008	M001581	560	1	0		1	100.5	50	
8527dfbe-bfdd-4003-b9a7-13f30ccd8b1c	CK2401-008	M001593	560	2	0		2	201	50	
ee21a9c5-ce78-4ef0-b151-4f210a6e0db6	CK2401-008	M001591	560	10	0		3	1004.9	50	
16d64466-4edf-40ae-ad14-9bdaf7a3bac0	CK2401-008	M001576	560	10	2295.4	第1.2.3.4项重量	4	1004.9	50	
94e5284b-fe4a-4504-8ba4-6b8a30707dfe	CK2401-008	M002896	990	1	0		5	39.1	25	
443410ec-f56d-489b-80f2-de75fdf58747	CK2401-008	M002876	990	5	0		6	195.5	25	
84115f16-7ad3-41eb-a3d0-abbc9bed3de2	CK2401-008	M002878	990	6	0		7	234.6	25	
faa0c660-4104-44ed-9fbd-46bf0e66810d	CK2401-008	M002909	990	6	0		8	234.6	25	
b484f548-c0c3-4c95-b4b3-e2c7e707cc75	CK2401-008	M002868	990	6	936	第5.6.7.8.9项重量	9	234.6	25	
e6558189-b80a-4c30-b26a-25cb7d801a1b	CK2401-008	M002331	820	8	0		10	1169.7	25	
6cd12c13-4c92-49e4-bf2d-293cf09b1f29	CK2401-008	M002642	820	8	0		11	1169.7	25	
abcf960f-c54e-4ef6-a70f-e62e01090d07	CK2401-008	M002333	820	8	0		12	1169.7	25	
663b5956-29c3-4532-8a37-96d7aa07e260	CK2401-008	M002641	820	1	3652.5	第10.11.12.13项重量	13	146.2	25	
a1403fee-ec98-4781-9fb4-92fff7c1f4c9	CK2401-008	M004441	26	25	77.5		14	78.6	25	
27880051-feb8-4e9a-8f0d-9dfb8e5bb031	CK2401-008	M002643	425	14	0		15	1061	25	
ea1d0442-95b2-4a32-89ff-c9fbcba97abb	CK2401-008	M002641	425	11	1892.5	第15.16项重量	16	833.6	25	
17289e7b-8e93-4e9b-a5c9-706c6ea06770	CK2401-008	M004676	36	25	80		17	80	25	e6d178ab-19d2-4536-85f8-3eca20b834e0
6983eb56-6b4b-4078-8f9f-9eff476ddf16	CK2401-025	M005360	920	5	555.5		1	559.8	50	aa5c35e0-cf37-4a41-8865-c73623d39c31
a99c517b-2712-44cd-9691-e07429fb117e	CK202312-31	M004083	6610	1	960		1	916.2	30	
22cde415-063d-4e7d-b3fa-328476a683f5	CK2401-038	M003118	8720	1	682.2		1	672	30.5	3fcf5c5d-cfca-45cb-b3da-ea5a19c4a881
a4da8955-ed89-4be5-914f-8a0c691ff5ab	CK2401-026	M004153	5050	1	0		1	251.1	30	8177fa1d-32ef-4eb7-925e-b8b5e82c51d5
3b9e5f4e-c8d5-4321-a64e-b1fd9d7827a1	CK2401-026	M004158	5000	1	511.2	第1.2项重量	2	248.6	30	29813b56-6baf-460b-8ed8-ed20746db82b
b3b3033d-baab-4812-bc65-af3b9e189b75	CK2401-044	M000883	145	1	8.9	短活塞杆	1	9.4	330	
4befcca3-22b6-4c5e-af72-e23a72987580	CK2401-048	M002050	660	1	196		1	197.1	13	7efdb8f2-3d2c-4937-af5c-fdfb2496158f
b13cf3d5-1fb1-440c-8193-f7c1b104a3ff	CK2401-048	M002050	640	1	190.5		2	191.1	13	42d9a7f2-192d-44b1-953e-4fbadd2f56d2
b0e9f4d6-859e-4414-8f9f-a5e762e00102	CK2401-048	M002050	840	1	249.8		3	250.8	13	c70bac9f-4b95-443e-b677-4d0af64f75f3
7335a103-2a34-4723-90e6-5b83e4b55f5a	CK2401-048	M002050	1340	1	397.7		4	400.2	13	dac59df2-2e44-44e6-8ef0-d54946a4e9e2
45362b7d-800d-42ff-b04a-551ce9d9d953	CK2401-049	M002728	300	1	31.5		1	31.3	25	8ff4a04e-7824-4cba-bc8d-442d1b17cc40
b56bc268-153c-448f-957b-fa71ef953f80	CK2401-017	M004694	2030	1	151.3		1	151.6	25	a21e8d2b-9095-4a58-b7ad-570207647e25
981beb24-d941-4592-9c41-44e357c5d387	CK2401-017	M004699	2490	1	185.5		2	185.9	25	2bbe2bc9-47d8-41f7-ae73-51369e9f3c78
0caf9553-6340-4e73-bcdb-c0311132bc22	CK2401-017	M004644	640	1	77.4		3	77.4	25	3f33dd67-4fd3-4938-9341-545d78f39f1f
c5f497ff-e792-4b62-8735-201b8d34cab9	CK2401-017	M002848	2590	2	245		4	247.5	25	4ac7e273-076c-4915-9bcb-d363187bdd2c
d9f15137-03b1-4476-8187-c9b5ebf6d4a4	CK2401-017	M003215	1265	1	100.6		5	97.8	33	b632d777-e221-425e-b430-b22df7e007e5
09ced571-c084-433f-9572-fa72ed806d02	CK2401-017	M003183	560	1	29.4		6	28.6	33	d6c53a06-a324-44e7-b12b-3dc7b2d510e0
a0171377-541a-4d67-9a50-07da9f728513	CK2401-017	M004694	2200	1	164		7	164.2	25	a5d7ec3f-7ffa-42d7-a8a9-841c903b2f86
2ebf216e-5122-431f-8bb3-fe3218243888	CK2401-017	M004699	1305	1	97.4		8	97.4	25	0ae80634-a169-4d4b-876b-add1b358825b
23fac2eb-b28b-412f-ae9a-1c7b93101483	CK2401-017	M004136	650	1	25.8		9	26.1	33	cb951dbc-fa22-4d24-9154-728014d7864e
e9661826-f33b-46cb-b3dc-599a64a208b5	CK2401-017	Z23010217	1580	1	42		10	39	33	fe10290c-200f-43f2-8d9c-efab2c95a2a1
021bd71f-714f-4053-82c3-5f09146842a5	CK2401-049	M004644	300	1	36.3		2	36.3	25	61f8b5b7-3123-4253-a6c2-eaedc7244b34
357ea39c-27f9-4572-b568-cd69ed7ebf3c	CK2401-049	M004182	280	1	44.5		3	44.2	25	651e2c01-c3c1-4d20-8f2c-84c14d223f5c
cb0481e7-d2da-4bd1-8cd1-377ee1244306	CK2401-049	M000679	280	1	62.2		4	62.4	25	8d64dd3b-1d07-4c2a-a0ab-21b4f771b52a
94ab8db7-6c5c-42e1-bdb3-122bd5bfe685	CK2401-030	M004324	450	1	74.1		1	72.8	330	
9076d9cb-0114-4fdf-a4bc-43a4e46ab663	CK2401-030	M004312	210	1	16.6		2	16.5	330	
7df3d7ba-b3e2-4402-92cd-ae10d4b6a0ae	CK2401-049	M002313	270	1	74.2		5	73.5	25	0db49745-a2d5-4c67-a7ad-8727ff26e723
e169801a-58a2-49d7-8d12-044ce67cab9b	CK2401-049	M001872	270	1	155		6	155	25	fd518559-acbc-4022-856f-aad53e5d174d
2c2ac344-ef44-41fa-9171-2a6e97850b54	CK2401-050	M003281	5810	1	611		1	609.7	44	7b51aecb-21ba-4438-a1b6-5ee5d3887df4
b8026820-6197-4c3d-bf1c-3b3641702523	CK2401-050	M003268	2134	1	318.7		2	318.4	44	95de6c05-2a61-4056-9c1f-268e08a94b3e
37b33dde-b89c-40ac-8c21-4736600484a9	CK2401-052	M005433	2200	2	204		1	204	12	9b44062e-cec8-4d61-9718-1e9044d4dc8e
5a1f63b5-5648-49ae-9cbc-cac5b1568f85	CK2401-031	M004181	2830	1	446		1	447	22.5	0690d986-317a-4f5f-a1a1-adcd9f9082fe
922c9d57-423f-4521-8ffa-252ac36f984a	CK2401-031	M005628	8910	1	0		2	1407.4	22.5	ef324636-aa73-410a-8e72-34c3a38cfcf4
51ffbf58-6330-4060-b316-deb953059390	CK2401-031	M005631	8360	1	0		3	1320.5	22.5	de50d75e-4686-40a0-8ed2-fb98b9acec20
4344f473-030a-41d0-a03c-5d6a7870bbb1	CK2401-031	M005630	8070	1	0		4	1274.7	22.5	9b75713f-bdbb-40de-9980-8d810acdc749
1a147945-0b27-48ef-bd0a-a6a3d1a7fdd1	CK2401-031	M005629	8940	1	5418.8	第2.3.4.5项重量	5	1412.1	22.5	32c20687-6de0-4f5c-a68d-2a564eef89fd
06b4217a-45a1-4a3e-8a7f-e65df069199d	CK2401-032	M003928	410	1	67		1	66.6	35	
129ecb3e-24be-4f02-8b20-ab08c4093250	CK2401-019	M003206	7585	1	511.4		1	464.6	31.7	17e8df88-891a-4c42-aad7-1b39291eee3d
e67afb9c-82fd-43b2-b8e6-2bb7982cb59b	CK2401-019	M002774	4040	1	248		2	247.5	31.7	2e06c7dc-08bc-4e2c-9666-4a10efea0ad0
fdb7bcb8-8ae0-40d6-a1e9-4994dd86e9d2	CK2401-023	L259	2030	2	213.6		1	213.4	48	b59597b0-87d3-4700-a3ea-5d2894332c68
2ed959ba-f50b-4409-9a80-0314fe327b24	CK2401-024	M000612	3350	1	77		1	74.2	17.5	
cce517bc-839c-4fd3-ad4c-6c36d8b1ac38	CK2401-024	M000612	2150	1	49		2	47.6	17.5	
2ac30683-8983-49f7-b649-673bf2ba322a	CK2401-039	M004335	1835	1	1125		1	1088	17.65	9b440076-3547-422f-961a-7257603676c7
314ef0b6-662b-4236-849a-5aa813d1cdbe	CK2401-040	M000934	1120	1	24.9		1	24.9	25	54aee006-095b-4e3e-8e49-17a259b2bb99
f894466d-a872-4a37-9213-2108ca9ae9e2	CK2401-040	M000934	2100	1	46.6		2	46.6	25	d6735329-d598-46a7-a28e-bdd293b5cb0e
965ab297-c981-4e47-b836-5ff0945f863a	CK2401-043	M003215	2010	1	0		1	155.4	33	
6ba120f2-52fa-4512-b77c-c48fab5a3220	CK2401-005	M004216	510	6	0		1	273.6	54	755afce9-1c79-4ec1-ae9c-71f6e19b54d3
7fb7adab-dae5-4f92-ae35-a21b41a3224a	CK2401-005	M004216	510	5	501.6	第1.2项重量	2	228	54	3416db98-48b4-48d9-aac6-c0fe710a56f8
4ee164d7-e097-45e4-b390-6fae6499d737	CK2401-005	M003280	510	2	0		3	107	54	af399c5d-9a07-46bf-aefe-8e921147a27f
47d6d995-4354-4d77-bfb1-0e93e13341f8	CK2401-005	M003280	510	2	216	第3.4项重量	4	107	54	bda4d19b-f128-4ce4-8efc-e78fd2a68575
e42baf48-1923-4b9a-99a6-4d104a7eedf7	CK2401-017	M000432	934	1	22		11	22.5	33	6e3242a5-4dea-4fe9-82a1-8520850c0834
54ccafed-dc36-4f51-9a3c-d862ca82103d	CK2401-027	M003272	3810	1	567.1		1	568.4	45	bb975dfd-3545-4c3f-8122-c3b01517b3f9
ef96b348-e770-4251-8ff4-eecb069f385e	CK2401-043	M003217	2010	4	777.5	第1.2项重量	2	621.8	33	
36d136f9-860f-442f-9e91-97745d749f7f	CK2401-043	M003056	460	2	54.4		3	54.4	12	
aab8b754-eacc-4ba3-a572-50a2ec9a7cdb	CK2401-029	M003669	8470	1	539.1		1	537.8	11.5	
4f47ec71-8bca-4af6-b985-72b355ca4a7f	CK2401-029	M003661	3100	1	0		2	196.8	11.5	
0497ecc8-c12c-4e1f-ae10-97a7c6d2d74b	CK2401-029	M003660	2490	1	356	第2.3项重量	3	158.1	11.5	
a80b3e4c-e067-41e7-af9f-a4a6f302d324	CK2401-029	M003636	7100	1	0		4	563.8	11.5	
98e3ad0c-6ad3-4abf-a78b-045658c6d645	CK2401-029	M003638	7100	1	1138.2	第4.5项重量	5	563.8	11.5	
ee6b92f7-b48e-4666-a65f-394fc6293773	CK2401-029	M003307	6570	1	0		6	535.3	11.5	
ace222d4-e838-4c3b-96d5-7e67d1b6aed0	CK2401-029	M003308	6625	1	0		7	539.8	11.5	
8a6c00ef-84fc-44e0-b3d9-a5fd5d463738	CK2401-029	M003309	6660	1	1646.3	第6.7.8项重量	8	542.6	11.5	
2e7df567-e69e-432d-be3d-6a52750fee55	CK2401-046	Z23010216	327	6	58.2	流量调节套	1	58.1	33	eeaadbef-e3fc-46bb-827d-13dc28e038b9
7206305a-6ab6-402c-9438-d5e3048642be	CK2401-047	L609	205	1	14.7		1	15	33	1d30a475-f016-43d0-91cf-4868a437cdd3
66dc4865-18cf-48f5-9cc1-fb4fc55f9c33	CK2401-054	M003185	1874	4	392		1	382.3	33	9b8c87af-d84c-4835-9bbb-37f365fa3539
60af06c7-e03c-4b43-8462-bb2d0f59e7e0	CK2401-054	M004769	800	4	246.9		2	232.8	33	3ab2f087-f615-4a94-8f18-f150e0a942c6
04af1a08-c090-4097-aa19-efa7f8edb012	CK2401-056	M002615	4000	1	180.6		1	179.5	33	a3fac278-a11b-437f-bafe-7e3d1bceef6d
e6ef4a41-e423-4c7c-9d1a-259f693e71ae	CK2401-016	M003123	870	1	64		1	67	28.5	
bed1412b-bfb2-420a-99a7-7784ca9756ef	CK2401-016	M003230	6920	1	458.9		2	439.4	28.5	
f6f81ab5-acc4-4105-bc53-bbdd50f7a726	CK2401-016	M004138	5555	1	242.2		3	241.1	28.5	
e4a57acb-7bbc-401e-b6d6-dad6cf5560dd	CK2401-016	M002395	8320	1	0		4	380.4	28.5	
beaf1538-305d-4781-a464-caf2f64d5c67	CK2401-018	M005843	350	80	744		1	703.5	10	
40aab540-325c-40b7-ba4f-1a9375a35569	CK2401-018	M003054	512	16	0		2	484.8	12	
1484dd9f-80c2-46ed-a375-5a3247ac2def	CK2401-018	M002980	512	16	0		3	484.8	12	
704691f9-1ebf-4a1f-8aa4-61d7b8e8eeb6	CK2401-018	M003059	512	16	0		4	484.8	12	
aa0621e7-767e-4601-8b1e-6a213d64761e	CK2401-018	M003058	512	16	0		5	484.8	12	
0f66f029-4342-4c3a-a91f-1549d14b36b9	CK2401-018	M003053	512	16	2560	第2.3.4.5.6项重量	6	484.8	12	
26ce04d4-3e2a-4bc3-beb1-60c7e95a5f0d	CK2401-018	M005050	30	160	348.8		7	349.2	12	
a4b541c1-dcb9-494c-bc08-b9ef976a49d3	CK2401-018	M005253	3010	2	231.6		8	231.6	12	
8b487def-6ea2-4198-a4d1-835a7a72aaf5	CK2401-018	M003661	2700	2	343		9	342.9	12	
a80cdcce-143e-462a-9311-53943a2fa44d	CK2401-018	M002200	122	4	41.2		10	39	12	
47c0a030-fe29-4d2d-889f-be766c43c612	CK2401-018	M001641	267	12	223.2		11	211.6	33	
0ef7b22b-eb80-4edb-a649-23fb2ccd11c4	CK2401-018	M001549	603	2	380.6		12	360.1	25	
12b99a04-90cc-449e-bd00-d1b5646c48bd	CK2401-018	M003055	810	2	101.4		13	95.9	12	
4622cc55-59d4-4101-93dd-baf60f068791	CK2401-016	M002397	8330	1	775.2	第4.5项重量	5	380.8	28.5	
14f4bf6e-17f9-40eb-89d1-ea8e290b7984	CK2401-016	M004823	6200	1	0		6	242.2	28.5	
d93e2b72-096b-4200-950e-156a340d9fdf	CK2401-016	M004828	6200	1	510.4	第6.7项重量	7	242.2	28.5	
1b968258-8903-43b6-b743-cabcb6f4d8e8	CK2401-016	M004874	4650	1	0		8	206.4	28.5	
0e3e76a5-770c-4146-98fc-3a3659cc9221	CK2401-016	M004873	4390	1	401.5	第8.9项重量	9	194.9	28.5	
b00ca1cd-f27e-4370-b7ec-4d121ae818c3	CK2401-016	M003137	1900	1	105.2		10	109.6	28.5	
0d1499ae-a167-44eb-a206-0697c333423a	CK2401-016	M003147	345	1	15		11	19.9	28.5	
5a81312b-5551-465a-a3db-ee3c71e8bd96	CK2401-016	M003142	8300	1	460.4		12	478.9	28.5	
edc5d550-2f4c-4db0-9967-3f6d347364d7	CK2401-016	M001970	6860	1	1863.6		13	1866.6	21.5	
70bba993-5cb2-41c0-aa23-4d53ad657ebb	CK2401-016	M005626	8640	1	1365.6		14	1364.7	21.5	
dd35fee4-146d-4f95-bfa0-38cd9bdd0ee3	CK2401-016	M004678	7290	1	0		15	647.7	21.5	
56b79a30-89b6-4a95-8cd8-8fbc9f515b45	CK2401-016	M004679	5895	1	0		16	523.8	21.5	
0bbfed50-0730-4b93-857f-73777a0c03b7	CK2401-016	M004675	6810	1	0		17	605.1	21.5	
a4c3db9d-4a89-48f9-b662-2e09d714ddbf	CK2401-016	M002826	6820	1	0		18	605.9	21.5	
cf2ac7a3-84b8-4183-b971-b99ddd40522c	CK2401-016	M004560	7170	1	0		19	637	21.5	
f67a3331-5fc5-4379-aa4d-05b5f27740c2	CK2401-057	L687	256	8	155	测试	1	154.3	15	1f12b635-3780-400b-a4cc-5e181bd631b1
81cbee7c-f589-402c-8e08-60b3ae3bebee	CK2401-058	L456	6540	1	378		1	377.4	11.5	d3da22dd-d0af-49f0-9f8f-5b412cce8cde
591d821c-941c-44d6-b596-a2f420c9914a	CK2401-059	M003326	6540	1	378		1	377.4	11.5	d3da22dd-d0af-49f0-9f8f-5b412cce8cde
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products ("商品id", "规格型号", "出售价格", "库存下限", "停用", "备注", "单位", "文本字段1", "文本字段2", "文本字段3", "文本字段4", "整数字段1", "整数字段2", "整数字段3", "实数字段1", "实数字段2", "实数字段3", "文本字段5", "文本字段6", "文本字段7", "文本字段8", "文本字段9", "文本字段10", "整数字段4", "整数字段5", "整数字段6", "实数字段4", "实数字段5", "实数字段6", "布尔字段1", "布尔字段2", "布尔字段3", "库位", "单号id") FROM stdin;
4_101	150*10	0	72.5	f			L659	固溶时效H1100	ASTM S564/A564M-13	0D40224	2100	0	2100	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	174*12	0	37.15	f			L663	固溶时效H1100			775	0	775	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	160*22	0	109.68	f			L680	固溶时效H1100	XTG-JY-036-2020	19D2971V	1465	0	1465	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	160*22	0	67.38	f			L687	固溶时效H1100	XTG-JY-036-2020	19D2971V	900	0	900	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	160*22	0	315.94	f			L688	固溶时效H1100	XTG-JY-036-2020	19D2971V	4220	0	4220	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	160*22	0	296.1	f			L689	固溶时效H1100	XTG-JY-036-2020	19D2971V	3955	0	3955	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	160*22	0	316.69	f			L690	固溶时效H1100	XTG-JY-036-2020	19D2971V	4230	0	4230	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	150*10	0	72.5	f	150圆钢打孔		L778	固溶时效H1100	ASTM S564/A564M-13	0D40224	2100	0	2100	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	219*14	0	17.69	f			M001651	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	250	0	250	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	219*14	0	10.97	f			M001652	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	155	0	155	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	219*14	0	3.54	f			M001654	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	50	0	50	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	219*14	0	452.95	f			M001655	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	6400	0	6400	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	219*14	0	360.24	f			M001656	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	5090	0	5090	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	178*15	0	357.84	f			M001663	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	5935	0	5935	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	178*15	0	358.14	f			M001665	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	5940	0	5940	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	178*15	0	358.14	f			M001669	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	5940	0	5940	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	178*15	0	66.32	f			M001670	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	1100	0	1100	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	178*15	0	43.41	f			Z23010205	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	720	0	720	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_101	178*15	0	56.37	f			M003167	固溶时效，28-32HRC	XTG-JY-C-036-2020	2MALV21118	935	0	935	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	859.89	f			M000618	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	4260	0	4260	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1046.6	f			M000619	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	5185	0	5185	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	394.62	f			M000620	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	1955	0	1955	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1059.72	f			M000621	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	5250	0	5250	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1043.57	f			M000622	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	5170	0	5170	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1029.45	f			M000623	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	5100	0	5100	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1029.45	f			M000624	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	5100	0	5100	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	86.8	f			M000625	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	430	0	430	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	58.54	f	带φ10偏心孔		M000626	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	290	0	290	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1031.46	f			M000627	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	5110	0	5110	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1473.52	f			M000628	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	7300	0	7300	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1338.28	f			M000629	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	6630	0	6630	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	1026.42	f			M000630	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20525/1MAL20504	5085	0	5085	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	220	0	48.25	f			M000846	固溶+时效1100	ZHSD/JT-20-0136/0	1MAL20914	160	0	160	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	20	0	1.61	f			M000852	固溶	ZHSD/JT-20-0136/0	1MAL20914	645	0	645	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	170	0	414.11	f			L658	固溶+时效1100			2300	0	2300	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	160	0	318.98	f			L660	固溶+时效1100			2000	0	2000	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	160	0	278.31	f			L661	固溶+时效1100			1745	0	1745	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	150	0	583.13	f			L681	固溶+时效1100			4160	0	4160	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	150	0	53.27	f			L779	固溶+时效1100			380	0	380	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	150	0	189.24	f			L780	固溶+时效1100			1350	0	1350	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*28	0	17.44	f			Z230510-30				308	0	308	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	150	0	4.91	f			M004229	固溶时效	ZHSD/JT-20-0136/0	22306120350	35	0	35	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	150	0	645.51	f			M004230	固溶时效	ZHSD/JT-20-0136/0	22306120350	4605	0	4605	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	150	0	7.01	f			M004231	固溶时效	ZHSD/JT-20-0136/0	22306120350	50	0	50	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	150	0	15.42	f			M004166	固溶时效	ZHSD/JT-20-0136/0	22306120350	110	0	110	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002609	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002610	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.34	f			M002611	固溶时效	GB/T 1220-2007	YX2302-2136	5895	0	5895	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002612	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002613	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002614	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.34	f			M002615	固溶时效	GB/T 1220-2007	YX2302-2136	5895	0	5895	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002616	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002617	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002618	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	102.85	f			M002619	固溶时效	GB/T 1220-2007	YX2302-2136	2285	0	2285	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002620	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002621	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002622	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	85	0	265.57	f			M002623	固溶时效	GB/T 1220-2007	YX2302-2136	5900	0	5900	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	180	0	96.89	f			Z23010201	固溶时效	ZHSD/JT-20-0136/0+GB/T1220-2007		480	0	480	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	200	0	1192.42	f			Z23010202	固溶时效	ZHSD/JT-20-0136/0+GB/T1220-2007		4785	0	4785	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	90	0	57.78	f			Z23010203	固溶时效	ZHSD/JT-20-0136/0+GB/T1220-2007		1145	0	1145	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2179.98	f			M003767	退火态	XYGN4086.4-2022-01	3075357M	7300	0	7300	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2212.83	f			M003768	退火态	XYGN4086.4-2022-01	3075357M	7410	0	7410	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2188.94	f			M003769	退火态	XYGN4086.4-2022-01	3075357M	7330	0	7330	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2197.9	f			M003770	退火态	XYGN4086.4-2022-01	3075357M	7360	0	7360	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2194.92	f			M003771	退火态	XYGN4086.4-2022-01	3075357M	7350	0	7350	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2151.61	f			M003772	退火态	XYGN4086.4-2022-01	3075357M	7205	0	7205	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2202.38	f			M003773	退火态	XYGN4086.4-2022-01	3075357M	7375	0	7375	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2200.89	f			M003774	退火态	XYGN4086.4-2022-01	3075357M	7370	0	7370	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2148.63	f			M003775	退火态	XYGN4086.4-2022-01	3075357M	7195	0	7195	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2138.18	f			M003776	退火态	XYGN4086.4-2022-01	3075357M	7160	0	7160	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2203.87	f			M003777	退火态	XYGN4086.4-2022-01	3075357M	7380	0	7380	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2203.87	f			M003778	退火态	XYGN4086.4-2022-01	3075357M	7380	0	7380	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2202.38	f			M003779	退火态	XYGN4086.4-2022-01	3075357M	7375	0	7375	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2147.14	f			M003780	退火态	XYGN4086.4-2022-01	3075357M	7190	0	7190	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2191.93	f			M003781	退火态	XYGN4086.4-2022-01	3075357M	7340	0	7340	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2250.16	f			M003782	退火态	XYGN4086.4-2022-01	3075357M	7535	0	7535	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2145.64	f			M003784	退火态	XYGN4086.4-2022-01	3075357M	7185	0	7185	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2141.16	f			M003785	退火态	XYGN4086.4-2022-01	3075357M	7170	0	7170	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2099.35	f			M003786	退火态	XYGN4086.4-2022-01	3075357M	7030	0	7030	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2190.44	f			M003787	退火态	XYGN4086.4-2022-01	3075357M	7335	0	7335	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	2088.9	f			M003788	退火态	XYGN4086.4-2022-01	3075357M	6995	0	6995	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_113	220	0	1781.32	f			M003790	退火态	XYGN4086.4-2022-01	3075357M	5965	0	5965	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	220	0	1015.34	f			M001369	热轧	GB/T3077-2015	2018358Z	3400	0	3400	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	210	0	2010.8	f			L582	退火态	GB/T 3077-2015	21EB07161	7390	0	7390	0	0	0	西宁特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	210	0	2009.44	f			L583	退火态	GB/T 3077-2015	21EB07161	7385	0	7385	0	0	0	西宁特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	210	0	340.12	f			L586	退火态	GB/T 3077-2015	21EB07161	1250	0	1250	0	0	0	西宁特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	200	0	1182.17	f	硬度不够		L517	调质-110KSI	GB/T 3077-2015	2020687	4790	0	4790	0	0	0	本钢/中兴热处理	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	200	0	1522.76	f	硬度不够		L518	调质-110KSI	GB/T 3077-2015	2020687	6170	0	6170	0	0	0	本钢/中兴热处理	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	200	0	54.3	f	硬度不够		L652	调质-110KSI	GB/T 3077-2015	2020687	220	0	220	0	0	0	本钢/中兴热处理	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	200	0	1920.1	f			L580	退火态	GB/T 3077-2015	21EB07158	7780	0	7780	0	0	0	西宁特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	200	0	1920.1	f			L581	退火态	GB/T 3077-2015	21EB07158	7780	0	7780	0	0	0	西宁特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	200	0	419.56	f			L585	退火态	GB/T 3077-2015	21EB07158	1700	0	1700	0	0	0	西宁特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	200	0	241.86	f			Z23010221	退火态	GB/T 3077-2015	21EB07158	980	0	980	0	0	0	西宁特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	200	0	103.66	f	已调硬度不够		Z23010503	退火态	GB/T 3077-2015	21EB07158	420	0	420	0	0	0	西宁特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	180	0	73.97	f	已调硬度不够		Z23010501	热轧	GB/T3077-2015	2018559Z	370	0	370	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	180	0	208.9	f	已调硬度不够		Z23010502	热轧	GB/T3077-2015	2018559Z	1045	0	1045	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	165	0	53.75	f			M003156	调质125KSI	XYGN5233-2022-01	2018878Z	320	0	320	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	165	0	369.55	f			M003157	调质125KSI	XYGN5233-2022-01	2018878Z	2200	0	2200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	165	0	19.32	f			M003158	调质125KSI	XYGN5233-2022-01	2018878Z	115	0	115	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	150	0	8.33	f			L542	退火态	西宁特钢	21EB05115	60	0	60	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	756.79	f			L574	退火态	西宁特钢	21EB07158	7850	0	7850	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	771.25	f			L575	退火态	西宁特钢	21EB07158	8000	0	8000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	771.25	f			L576	退火态	西宁特钢	21EB07158	8000	0	8000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	771.25	f			Z23010222	退火态	西宁特钢	21EB07158	8000	0	8000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	771.25	f			L561	退火态	西宁特钢	21EB07158	8000	0	8000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	771.25	f			L562	退火态	西宁特钢	21EB07158	8000	0	8000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	771.25	f			L566	退火态	西宁特钢	21EB07158	8000	0	8000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	263.57	f			L572	退火态	东北特钢	21EB07158	2734	0	2734	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	125	0	771.25	f			Z230330-1	退火态	东北特钢	21EB07158	8000	0	8000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	120	0	787.19	f			L567	退火态	东北特钢	21EB06970	8860	0	8860	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	120	0	787.19	f			L568	退火态	东北特钢	21EB06970	8860	0	8860	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	120	0	787.19	f			L569	退火态	东北特钢	21EB06970	8860	0	8860	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	120	0	787.19	f			L570	退火态	东北特钢	21EB06970	8860	0	8860	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	120	0	63.53	f			L571	退火态	东北特钢	21EB06970	715	0	715	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	120	0	396.26	f			L537	退火态	东北特钢	21EB06970	4460	0	4460	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	110	0	447.94	f			L505	热轧	本钢	18C3566	6000	0	6000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	110	0	447.94	f			L502	热轧	本钢	18C3566	6000	0	6000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	110	0	6.72	f			L645	热轧	本钢	18C3566	90	0	90	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	80	0	63.18	f			L498	热轧	本钢	2036055	1600	0	1600	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	80	0	8.49	f			L535	热轧	本钢	2036055	215	0	215	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	75	0	9.89	f			L540	退火态	西宁特钢	21EB07316	285	0	285	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	191.02	f			L546	退火态	西宁特钢	21EB06513	8600	0	8600	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	44.42	f			L553	退火态	西宁特钢	21EB06513	2000	0	2000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	40	0	59.23	f			L549	热轧	本钢	20A1762	6000	0	6000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	40	0	37.27	f			L555	热轧	本钢	20A1762	3775	0	3775	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	40	0	59.23	f			L556	热轧	本钢	20A1762	6000	0	6000	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	100	0	0.62	f			Z23010540	热轧			10	0	10	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	110	0	50.02	f			Z23010541	热轧			670	0	670	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	85	0	0.89	f			Z23010543	热轧			20	0	20	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	175	0	245.64	f	打孔		Z23010547	热轧			1300	0	1300	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	180	0	23.99	f	已调质硬度不够		Z23010552				120	0	120	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	180	0	167.92	f			L653	热轧			840	0	840	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	95	0	6.68	f			Z23010553	退火 态			120	0	120	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	170	0	12.48	f			Z23010554	热轧			70	0	70	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	170	0	57.95	f			Z23010555	热轧			325	0	325	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	1	f			M002099	调质-110KSI	本钢钢铁	20A1392	45	0	45	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	38.43	f			M002100	调质-110KSI	本钢钢铁	20A1392	1730	0	1730	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	1	f			M002101	调质-110KSI	本钢钢铁	20A1392	45	0	45	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	87.96	f			M002102	调质-110KSI	本钢钢铁	20A1392	3960	0	3960	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	2.22	f			M002106	调质-110KSI	本钢钢铁	20A1392	100	0	100	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	134.6	f			M002108	调质-110KSI	本钢钢铁	20A1392	6060	0	6060	0	0	0	GB/T 3077-2015	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	100	0	61.7	f			Z230510-7	未调			1000	0	1000	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	12.22	f			Z230510-8	未调			550	0	550	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	60	0	6.33	f			Z230510-10	未调			285	0	285	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	105	0	49.66	f	打孔40		Z230510-11	未调			730	0	730	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	100	0	0.74	f			Z230510-12	未调			12	0	12	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	110	0	38.82	f			Z230510-14	未调			520	0	520	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_102	110	0	62.71	f			Z230510-16	未调			840	0	840	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	215.9*38.1	0	1303	f			M002141	调质110KSI	ASTM A519	TX22-01664LG	7800	0	7800	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	215.9*38.1	0	1314.69	f			M002142	调质110KSI	ASTM A519	TX22-01664LG	5860	0	5860	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	203.2*28.575	0	276.25	f			L717	调质-110KSI	GA-102Rev.1	8023216A	2245	0	2245	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	120.65*31.75	0	2.37	f			L721	调质-80KSI	CA&S 0028 Rev.13/ASTM A519	8023247C	34	0	34	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	222.25*38.1	0	1176.52	f			L724	调质-110KSI	CA&A 0011 Rev.12/ASTM A519	8021764C	6800	0	6800	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	196.85*25.4	0	335.59	f			L727	调质-110KSI	CA&A 0011 Rev.12/ASTM A519	8020701C	3125	0	3125	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	146.05*25.4	0	56.3	f			L728	调质-110KSI	ARA/TS-14	1624154C	745	0	745	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	146.05*25.4	0	7.93	f			L729	调质-110KSI	ARA/TS-14	1624154C	105	0	105	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	171.5*31.75	0	876.44	f			B230110-185	调质-80KSI	API SPEC 5CT& FS-T-M-011C	TX22-06595LG	8010	0	8010	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	171.5*31.75	0	874.25	f			B230110-186	调质-80KSI	API SPEC 5CT& FS-T-M-011C	TX22-06595LG	7990	0	7990	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	171.5*31.75	0	879.72	f			B230110-188	调质-80KSI	API SPEC 5CT& FS-T-M-011C	TX22-06595LG	8040	0	8040	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	171.5*31.75	0	833.76	f			B230110-190	调质-80KSI	API SPEC 5CT& FS-T-M-011C	TX22-06595LG	7620	0	7620	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	158.75*25.4	0	690.76	f			M000277	调质-80KSI	XTG-RZ026-C-037-2013	2200694	8270	0	8270	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	158.75*25.4	0	53.87	f			M000278	调质-80KSI	XTG-RZ026-C-037-2013	2200694	645	0	645	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	158.75*25.4	0	709.13	f			M000279	调质-80KSI	XTG-RZ026-C-037-2013	2200694	8490	0	8490	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	171.5*31.75	0	876.44	f	 		B230110-187	调质-80KSI	API SPEC 5CT& FS-T-M-011C	TX22-06595LG	8010	0	8010	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_104	158.75*25.4	0	715.81	f			M000280	调质-80KSI	XTG-RZ026-C-037-2013	2200694	8570	0	8570	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	158.75*25.4	0	666.53	f			M000322	调质-80KSI	XTG-RZ026-C-037-2013	2200694	7980	0	7980	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	158.75*25.4	0	730.85	f			L716	调质-110KSI	CA&A 0011 Rev.12/ASTM A519	2023251B	8750	0	8750	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	158.75*25.4	0	143.66	f			M000282	调质-110KSI	XTG-RZ026-C-037-2013	2200694	1720	0	1720	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	158.75*25.4	0	597.21	f			M000283	调质-110KSI	XTG-RZ026-C-037-2013	2200694	7150	0	7150	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	215.9*22.225	0	956.39	f			M000293	调质-110KSI	XTG-RZ026-C-037-2013	8023250A	9010	0	9010	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	215.9*22.225	0	857.67	f			M000294	调质-110KSI	XTG-RZ026-C-037-2013	8024417C	8080	0	8080	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	158.75*19.05	0	525.02	f			M000319	调质-110KSI	XTG-RZ026-C-037-2013	8020700B	8000	0	8000	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_104	133.4*22.23	0	4.88	f			Z23010225	调质-110KSI	WS-305RevU		80	0	80	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_110	203*28	0	722.59	f			M002758	调质110KSI	XYGN4935-2022-01	2055452A	5980	0	5980	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_110	203*28	0	14.5	f			M002760	调质110KSI	XYGN4935-2022-01	2055452A	120	0	120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_110	203*28	0	733.46	f			M002762	调质110KSI	XYGN4935-2022-01	2055452A	6070	0	6070	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_110	203*28	0	745.55	f			M002763	调质110KSI	XYGN4935-2022-01	2055452A	6170	0	6170	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	273*32	0	1692.58	f			M004241	调质80KSI	XYGN4972-2022-01	2053576A	8900	0	8900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	273*32	0	1719.21	f			M004242	调质80KSI	XYGN4972-2022-01	2053576A	9040	0	9040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	273*32	0	1760.1	f			M004243	调质80KSI	XYGN4972-2022-01	2053576A	9255	0	9255	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	18.68	f			M003378	调质80KSI	XYGN4972-2022-01	3071311M	115	0	115	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1085.23	f			M003903	调质80KSI	XYGN4972-2022-01	3074014M	6680	0	6680	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1088.48	f			M003904	调质80KSI	XYGN4972-2022-01	3074014M	6700	0	6700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1085.23	f			M003905	调质80KSI	XYGN4972-2022-01	3074014M	6680	0	6680	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1080.36	f			M003914	调质80KSI	XYGN4972-2022-01	3074014M	6650	0	6650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1085.23	f			M003915	调质80KSI	XYGN4972-2022-01	3074014M	6680	0	6680	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1080.36	f			M003916	调质80KSI	XYGN4972-2022-01	3074014M	6650	0	6650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1091.73	f			M003917	调质80KSI	XYGN4972-2022-01	3074014M	6720	0	6720	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1070.61	f			M003918	调质80KSI	XYGN4972-2022-01	3074014M	6590	0	6590	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1019.44	f			M003919	调质80KSI	XYGN4972-2022-01	3074014M	6275	0	6275	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1094.17	f			M003920	调质80KSI	XYGN4972-2022-01	3074014M	6735	0	6735	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1060.86	f			M003921	调质80KSI	XYGN4972-2022-01	3074014M	6530	0	6530	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1093.36	f			M003922	调质80KSI	XYGN4972-2022-01	3074014M	6730	0	6730	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1092.54	f			M003923	调质80KSI	XYGN4972-2022-01	3074014M	6725	0	6725	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1087.67	f			M003924	调质80KSI	XYGN4972-2022-01	3074014M	6695	0	6695	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1094.17	f			M003925	调质80KSI	XYGN4972-2022-01	3074014M	6735	0	6735	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	41.43	f			M003926	调质80KSI	XYGN4972-2022-01	3074014M	255	0	255	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	1071.42	f			M003927	调质80KSI	XYGN4972-2022-01	3074014M	6595	0	6595	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*36	0	539.37	f			M003928	调质80KSI	XYGN4972-2022-01	3074014M	3320	0	3320	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	507.74	f			M003431	调质-80KSI	XYGN4972-2022-01	3072881M	3850	0	3850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	130.56	f			M003433	调质-80KSI	XYGN4972-2022-01	3072881M	990	0	990	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	478.73	f			M003434	调质-80KSI	XYGN4972-2022-01	3072881M	3630	0	3630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	4.62	f			M001631	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	70	0	70	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	551.43	f			M001632	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8350	0	8350	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	545.02	f			M001633	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8253	0	8253	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	528.32	f			M001634	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8000	0	8000	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	539.54	f			M001635	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8170	0	8170	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	548.79	f			M001636	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8310	0	8310	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	555.13	f			M001637	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8406	0	8406	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	555.13	f			M001638	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8406	0	8406	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	551.76	f			M001639	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8355	0	8355	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	517.62	f			M001640	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	7838	0	7838	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	352.65	f			M001641	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	5340	0	5340	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	519.07	f			M001643	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	7860	0	7860	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	550.77	f			M001644	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8340	0	8340	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	521.71	f			M001645	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	7900	0	7900	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	536.9	f			M001646	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8130	0	8130	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	529.31	f			M001648	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8015	0	8015	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	544.17	f			M001649	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	8240	0	8240	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*13	0	13.54	f			M001650	调质-80KSI	XTG-JY-C-041-2020/FS-T-M-003	2MALV21099	205	0	205	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1089.34	f			M002024	调质-80KSI	XYGN4972-2022-01	2055208M	8260	0	8260	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1099.23	f			M002025	调质-80KSI	XYGN4972-2022-01	2055208M	8335	0	8335	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1091.98	f			M002026	调质-80KSI	XYGN4972-2022-01	2055208M	8280	0	8280	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1.98	f			M002027	调质-80KSI	XYGN4972-2022-01	2055208M	15	0	15	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	494.56	f			M002029	调质-80KSI	XYGN4972-2022-01	2055208M	3750	0	3750	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	204.42	f			M002031	调质-80KSI	XYGN4972-2022-01	2055208M	1550	0	1550	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1078.13	f	外径217-217.1\n壁厚26.5-27		M004897	调质-80KSI	XYGN4972-2022-01	3073989M	8175	0	8175	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1070.88	f			M004898	调质-80KSI	XYGN4972-2022-01	3073989M	8120	0	8120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1082.09	f			M004899	调质-80KSI	XYGN4972-2022-01	3073989M	8205	0	8205	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1072.2	f			M004900	调质-80KSI	XYGN4972-2022-01	3073989M	8130	0	8130	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1072.2	f			M004901	调质-80KSI	XYGN4972-2022-01	3073989M	8130	0	8130	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*28	0	1072.2	f			M004902	调质-80KSI	XYGN4972-2022-01	3073989M	8130	0	8130	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	4.42	f			M001821	调质-80KSI	XYGN4972-2022-01	2053670M	45	0	45	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	22.08	f			M001822	调质-80KSI	XYGN4972-2022-01	2053670M	225	0	225	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	1.96	f			M001825	调质-80KSI	XYGN4972-2022-01	2053670M	20	0	20	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	8.83	f			M003569	调质-80KSI	XYGN4972-2022-01	3051115M	90	0	90	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	74.59	f			M003571	调质-80KSI	XYGN4972-2022-01	3051115M	760	0	760	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	95.2	f			M003572	调质-80KSI	XYGN4972-2022-01	3051115M	970	0	970	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	242.42	f			M004336	调质-80KSI	XYGN4972-2022-01	3074014M	2470	0	2470	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	202.18	f			M004337	调质-80KSI	XYGN4972-2022-01	3074014M	2060	0	2060	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	205.13	f			M004338	调质-80KSI	XYGN4972-2022-01	3074014M	2090	0	2090	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	38.77	f			M004339	调质-80KSI	XYGN4972-2022-01	3074014M	395	0	395	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	247.82	f			M004340	调质-80KSI	XYGN4972-2022-01	3074014M	2525	0	2525	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	506.21	f			M003906	调质-80KSI	XYGN4972-2022-01	3074205A	8500	0	8500	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1108.2	f			M004801	调质-80KSI	XYGN5203-2022-01	3073989M	7110	0	7110	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1109.76	f			M004802	调质-80KSI	XYGN5203-2022-01	3073989M	7120	0	7120	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1078.58	f			M004803	调质-80KSI	XYGN5203-2022-01	3073989M	6920	0	6920	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1069.23	f			M004804	调质-80KSI	XYGN5203-2022-01	3073989M	6860	0	6860	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1174.44	f			M005394	调质-80KSI	XYGN5203-2022-01	3052448M	7535	0	7535	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1151.84	f			M005395	调质-80KSI	XYGN5203-2022-01	3052448M	7390	0	7390	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1187.69	f			M005396	调质-80KSI	XYGN5203-2022-01	3052448M	7620	0	7620	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1120.67	f			M005397	调质-80KSI	XYGN5203-2022-01	3076208A	7190	0	7190	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1120.67	f			M005398	调质-80KSI	XYGN5203-2022-01	3076208A	7190	0	7190	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1123.79	f			M005399	调质-80KSI	XYGN5203-2022-01	3076208A	7210	0	7210	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1122.23	f			M005400	调质-80KSI	XYGN5203-2022-01	3076208A	7200	0	7200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1103.52	f			M005401	调质-80KSI	XYGN5203-2022-01	3076208A	7080	0	7080	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1114.43	f			M005402	调质-80KSI	XYGN5203-2022-01	3076208A	7150	0	7150	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1106.64	f			M005403	调质-80KSI	XYGN5203-2022-01	3074014M	7100	0	7100	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1112.87	f			M005404	调质-80KSI	XYGN5203-2022-01	3074014M	7140	0	7140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1112.87	f			M005405	调质-80KSI	XYGN5203-2022-01	3074014M	7140	0	7140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1109.76	f			M005406	调质-80KSI	XYGN5203-2022-01	3074014M	7120	0	7120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1078.58	f			M005407	调质-80KSI	XYGN5203-2022-01	3074014M	6920	0	6920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1109.76	f			M005408	调质-80KSI	XYGN5203-2022-01	3074014M	7120	0	7120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1175.22	f			M005409	调质-80KSI	XYGN5203-2022-01	3052448M	7540	0	7540	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1187.69	f			M005410	调质-80KSI	XYGN5203-2022-01	3052448M	7620	0	7620	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	215.9*34.925	0	1159.63	f			M005411	调质-80KSI	XYGN5203-2022-01	3052448M	7440	0	7440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	970.87	f			M004531	调质-80KSI	XYGN5203-2022-01	3074511M	7890	0	7890	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	969.03	f			M004532	调质-80KSI	XYGN5203-2022-01	3074511M	7875	0	7875	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	984.41	f			M004533	调质-80KSI	XYGN5203-2022-01	3074511M	8000	0	8000	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	979.49	f			M004534	调质-80KSI	XYGN5203-2022-01	3074511M	7960	0	7960	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	984.41	f			M004535	调质-80KSI	XYGN5203-2022-01	3074511M	8000	0	8000	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	959.18	f			M004536	调质-80KSI	XYGN5203-2022-01	3074511M	7795	0	7795	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	981.33	f			M004537	调质-80KSI	XYGN5203-2022-01	3074511M	7975	0	7975	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	972.1	f			M004538	调质-80KSI	XYGN5203-2022-01	3074511M	7900	0	7900	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	992.41	f			M004539	调质-80KSI	XYGN5203-2022-01	3074511M	8065	0	8065	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	994.25	f			M004540	调质-80KSI	XYGN5203-2022-01	3074511M	8080	0	8080	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	985.64	f			M004541	调质-80KSI	XYGN5203-2022-01	3074511M	8010	0	8010	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	987.49	f			M004542	调质-80KSI	XYGN5203-2022-01	3074511M	8025	0	8025	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	980.1	f			M004543	调质-80KSI	XYGN5203-2022-01	3074511M	7965	0	7965	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	986.87	f			M004544	调质-80KSI	XYGN5203-2022-01	3074511M	8020	0	8020	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203.2*28.575	0	980.72	f			M004545	调质-80KSI	XYGN5203-2022-01	3074511M	7970	0	7970	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	793.88	f			M002003	调质-80KSI	XYGN4972-2022-01	2055044M	6570	0	6570	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	803.55	f			M002005	调质-80KSI	XYGN4972-2022-01	2055044M	6650	0	6650	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	39.88	f			M002006	调质-80KSI	XYGN4972-2022-01	2055044M	330	0	330	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	779.38	f			M002007	调质-80KSI	XYGN4972-2022-01	2055045M	6450	0	6450	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	799.32	f			M002009	调质-80KSI	XYGN4972-2022-01	2055045M	6615	0	6615	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	768.5	f			M002010	调质-80KSI	XYGN4972-2022-01	2055045M	6360	0	6360	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	787.23	f			M002602	调质-80KSI	XYGN4972-2022-01	2055045M	6515	0	6515	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	766.69	f			M002013	调质-80KSI	XYGN4972-2022-01	2055044M	6345	0	6345	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	773.34	f			M002014	调质-80KSI	XYGN4972-2022-01	2055044M	6400	0	6400	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	766.69	f			M002015	调质-80KSI	XYGN4972-2022-01	2055044M	6345	0	6345	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	773.34	f			M002016	调质-80KSI	XYGN4972-2022-01	2055044M	6400	0	6400	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	31.42	f			M002087	调质-80KSI	XYGN4972-2022-01	2055045M	260	0	260	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	42.29	f			M002089	调质-80KSI	XYGN4972-2022-01	2055045M	350	0	350	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	35.65	f			M002091	调质-80KSI	XYGN4972-2022-01	2055045M	295	0	295	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	756.42	f			M002092	调质-80KSI	XYGN4972-2022-01	2055045M	6260	0	6260	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	153.46	f			M002093	调质-80KSI	XYGN4972-2022-01	2055045M	1270	0	1270	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	2.42	f			M002094	调质-80KSI	XYGN4972-2022-01	2055045M	20	0	20	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	88.21	f			M002781	调质-80KSI	XYGN4972-2022-01	2054693A	730	0	730	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*28	0	141.98	f			M002782	调质-80KSI	XYGN4972-2022-01	2054693A	1175	0	1175	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	779.3	f			M001802	调质-80KSI	XYGN4972-2022-01	2053669M	9490	0	9490	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	767.8	f			M001803	调质-80KSI	XYGN4972-2022-01	2053669M	9350	0	9350	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	754.25	f			M001804	调质-80KSI	XYGN4972-2022-01	2053669M	9185	0	9185	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	776.01	f			M001805	调质-80KSI	XYGN4972-2022-01	2053669M	9450	0	9450	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	769.03	f			M001806	调质-80KSI	XYGN4972-2022-01	2053669M	9365	0	9365	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	5.75	f			M001812	调质-80KSI	XYGN4972-2022-01	2053669M	70	0	70	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	1.64	f			M001813	调质-80KSI	XYGN4972-2022-01	2053669M	20	0	20	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	9.85	f			M001817	调质-80KSI	XYGN4972-2022-01	2053669M	120	0	120	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	6.16	f			M001857	调质-80KSI	XYGN4972-2022-01	2074733T	75	0	75	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	514.47	f			M001858	调质-80KSI	XYGN4972-2022-01	2074733T	6265	0	6265	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	514.88	f			M001909	调质-80KSI	XYGN4972-2022-01	2074733T	6270	0	6270	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	515.7	f			M001910	调质-80KSI	XYGN4972-2022-01	2074733T	6280	0	6280	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	515.29	f			M001911	调质-80KSI	XYGN4972-2022-01	2074733T	6275	0	6275	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	500.92	f			M001912	调质-80KSI	XYGN4972-2022-01	2074733T	6100	0	6100	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	513.24	f			M001913	调质-80KSI	XYGN4972-2022-01	2074733T	6250	0	6250	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	516.52	f			M001914	调质-80KSI	XYGN4972-2022-01	2074733T	6290	0	6290	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	515.29	f			M001915	调质-80KSI	XYGN4972-2022-01	2074733T	6275	0	6275	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	500.1	f			M001916	调质-80KSI	XYGN4972-2022-01	2074733T	6090	0	6090	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	500.92	f			M001917	调质-80KSI	XYGN4972-2022-01	2074733T	6100	0	6100	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	508.31	f			M001918	调质-80KSI	XYGN4972-2022-01	2074733T	6190	0	6190	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	505.02	f			M001919	调质-80KSI	XYGN4972-2022-01	2074733T	6150	0	6150	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	428.65	f			M001920	调质-80KSI	XYGN4972-2022-01	2074733T	5220	0	5220	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	514.88	f			M001921	调质-80KSI	XYGN4972-2022-01	2074733T	6270	0	6270	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	517.34	f			M001922	调质-80KSI	XYGN4972-2022-01	2074733T	6300	0	6300	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	518.98	f			M001923	调质-80KSI	XYGN4972-2022-01	2074733T	6320	0	6320	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	516.52	f			M001925	调质-80KSI	XYGN4972-2022-01	2074733T	6290	0	6290	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	203*18	0	80.48	f			M001926	调质-80KSI	XYGN4972-2022-01	2074733T	980	0	980	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	195.5*28	0	817.68	f			M004238	调质-80KSI	XYGN4972.3-2023-01	3074011M	7070	0	7070	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	195.5*28	0	961.1	f			M004239	调质-80KSI	XYGN4972.3-2023-01	3074011M	8310	0	8310	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	195.5*28	0	962.25	f			M004240	调质-80KSI	XYGN4972.3-2023-01	3074011M	8320	0	8320	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	712	f			M004794	调质-80KSI	XYGN5203-2022-01	3074511M	6630	0	6630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	709.85	f			M004795	调质-80KSI	XYGN5203-2022-01	3074511M	6610	0	6610	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	722.74	f			M004796	调质-80KSI	XYGN5203-2022-01	3074511M	6730	0	6730	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	709.85	f			M004797	调质-80KSI	XYGN5203-2022-01	3074511M	6610	0	6610	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	712	f			M004798	调质-80KSI	XYGN5203-2022-01	3074511M	6630	0	6630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	738.84	f			M004799	调质-80KSI	XYGN5203-2022-01	3074511M	6880	0	6880	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	721.66	f			M004800	调质-80KSI	XYGN5203-2022-01	3074511M	6720	0	6720	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	786.1	f	预留\n外销		M005372	调质-80KSI	XYGN5203-2022-01	3074511M	7320	0	7320	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	781.8	f			M005373	调质-80KSI	XYGN5203-2022-01	3074511M	7280	0	7280	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	766.77	f			M005374	调质-80KSI	XYGN5203-2022-01	3074511M	7140	0	7140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	762.47	f			M005375	调质-80KSI	XYGN5203-2022-01	3074511M	7100	0	7100	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	785.02	f			M005376	调质-80KSI	XYGN5203-2022-01	3074511M	7310	0	7310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	778.58	f			M005377	调质-80KSI	XYGN5203-2022-01	3074511M	7250	0	7250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	769.45	f			M005378	调质-80KSI	XYGN5203-2022-01	3074511M	7165	0	7165	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	196.85*25.4	0	764.62	f			M005379	调质-80KSI	XYGN5203-2022-01	3074511M	7120	0	7120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190*35	0	1034.12	f			M003393	调质-80KSI	XYGN4972-2022-01	3071311M	7730	0	7730	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190*35	0	936.46	f			M003394	调质-80KSI	XYGN4972-2022-01	3071311M	7000	0	7000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	755.95	f	预留\n外销		M005380	调质-80KSI	XYGN5203-2022-01	3074511M	7310	0	7310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	722.34	f			M005381	调质-80KSI	XYGN5203-2022-01	3074511M	6985	0	6985	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	745.61	f			M005382	调质-80KSI	XYGN5203-2022-01	3074511M	7210	0	7210	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	754.91	f			M005383	调质-80KSI	XYGN5203-2022-01	3074511M	7300	0	7300	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	750.78	f			M005384	调质-80KSI	XYGN5203-2022-01	3074511M	7260	0	7260	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	744.57	f			M005385	调质-80KSI	XYGN5203-2022-01	3074511M	7200	0	7200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	734.23	f			M005386	调质-80KSI	XYGN5203-2022-01	3074511M	7100	0	7100	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	741.47	f			M005387	调质-80KSI	XYGN5203-2022-01	3074511M	7170	0	7170	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	746.12	f			M005388	调质-80KSI	XYGN5203-2022-01	3074511M	7215	0	7215	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	708.38	f			M005389	调质-80KSI	XYGN5203-2022-01	3074511M	6850	0	6850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	711.48	f			M005390	调质-80KSI	XYGN5203-2022-01	3074511M	6880	0	6880	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	708.38	f			M005391	调质-80KSI	XYGN5203-2022-01	3074511M	6850	0	6850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	730.09	f			M005392	调质-80KSI	XYGN5203-2022-01	3074511M	7060	0	7060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	190.5*25.4	0	728.03	f			M005393	调质-80KSI	XYGN5203-2022-01	3074511M	7040	0	7040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	686.9	f			M004773	调质-80KSI	XYGN4972-2022-01	3073626A	8390	0	8390	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	670.12	f			M004774	调质-80KSI	XYGN4972-2022-01	3073626A	8185	0	8185	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	664.38	f			M004775	调质-80KSI	XYGN4972-2022-01	3073626A	8115	0	8115	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	662.34	f			M004776	调质-80KSI	XYGN4972-2022-01	3073626A	8090	0	8090	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	650.06	f			M004777	调质-80KSI	XYGN4972-2022-01	3073626A	7940	0	7940	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	685.26	f			M004778	调质-80KSI	XYGN4972-2022-01	3073626A	8370	0	8370	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	686.08	f			M004779	调质-80KSI	XYGN4972-2022-01	3073626A	8380	0	8380	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	653.33	f			M004780	调质-80KSI	XYGN4972-2022-01	3073626A	7980	0	7980	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	650.06	f			M004782	调质-80KSI	XYGN4972-2022-01	3073626A	7940	0	7940	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	672.98	f			M004783	调质-80KSI	XYGN4972-2022-01	3073626A	8220	0	8220	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	650.88	f			M004784	调质-80KSI	XYGN4972-2022-01	3073626A	7950	0	7950	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	668.07	f			M004785	调质-80KSI	XYGN4972-2022-01	3073626A	8160	0	8160	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	665.61	f			M004786	调质-80KSI	XYGN4972-2022-01	3073626A	8130	0	8130	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	690.17	f			M004787	调质-80KSI	XYGN4972-2022-01	3073626A	8430	0	8430	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	651.69	f			M004788	调质-80KSI	XYGN4972-2022-01	3073626A	7960	0	7960	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	186*20	0	650.06	f			M004789	调质-80KSI	XYGN4972-2022-01	3073626A	7940	0	7940	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	184.5*38.5	0	916.24	f			M004083	调质-80KSI	XYGN4972.3-2023-01	3074011M	6610	0	6610	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	184.5*38.5	0	961.29	f			M004084	调质-80KSI	XYGN4972.3-2023-01	3074011M	6935	0	6935	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	184.5*38.5	0	527.43	f			M004085	调质-80KSI	XYGN4972.3-2023-01	3074011M	3805	0	3805	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	639.14	f			M004739	调质-80KSI	XYGN4972-2022-01	3073671M	6340	0	6340	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	704.66	f			M004740	调质-80KSI	XYGN4972-2022-01	3073671M	6990	0	6990	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	695.09	f			M004741	调质-80KSI	XYGN4972-2022-01	3073671M	6895	0	6895	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	702.65	f			M004742	调质-80KSI	XYGN4972-2022-01	3073671M	6970	0	6970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	670.89	f			M004743	调质-80KSI	XYGN4972-2022-01	3073671M	6655	0	6655	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	717.77	f			M004744	调质-80KSI	XYGN4972-2022-01	3073671M	7120	0	7120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	688.53	f			M004745	调质-80KSI	XYGN4972-2022-01	3073671M	6830	0	6830	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	700.63	f			M004746	调质-80KSI	XYGN4972-2022-01	3073671M	6950	0	6950	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	697.61	f			M004747	调质-80KSI	XYGN4972-2022-01	3073671M	6920	0	6920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	694.08	f			M004748	调质-80KSI	XYGN4972-2022-01	3073671M	6885	0	6885	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	668.37	f			M004749	调质-80KSI	XYGN4972-2022-01	3073671M	6630	0	6630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	706.68	f			M004750	调质-80KSI	XYGN4972-2022-01	3073671M	7010	0	7010	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	732.89	f			M004751	调质-80KSI	XYGN4972-2022-01	3073671M	7270	0	7270	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	698.61	f			M004752	调质-80KSI	XYGN4972-2022-01	3073671M	6930	0	6930	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	723.82	f			M004753	调质-80KSI	XYGN4972-2022-01	3073671M	7180	0	7180	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	673.41	f			M004754	调质-80KSI	XYGN4972-2022-01	3073671M	6680	0	6680	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	515.88	f			M005365	调质-80KSI	XYGN4972-2022-01	3073671A	7450	0	7450	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	562.96	f			M005366	调质-80KSI	XYGN4972-2022-01	3073671A	8130	0	8130	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	533.88	f			M005367	调质-80KSI	XYGN4972-2022-01	3073671A	7710	0	7710	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	573.35	f			M005368	调质-80KSI	XYGN4972-2022-01	3073671A	8280	0	8280	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	42.59	f			M005369	调质-80KSI	XYGN4972-2022-01	3073671A	615	0	615	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	553.96	f			M005370	调质-80KSI	XYGN4972-2022-01	3073671A	8000	0	8000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	558.12	f			M005371	调质-80KSI	XYGN4972-2022-01	3073671A	8060	0	8060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	514.6	f			M004072	调质-80KSI	XYGN4972-2022-01	3073671M	7400	0	7400	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	538.25	f			M004073	调质-80KSI	XYGN4972-2022-01	3073671M	7740	0	7740	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	509.74	f			M004074	调质-80KSI	XYGN4972-2022-01	3073671M	7330	0	7330	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	536.86	f			M004075	调质-80KSI	XYGN4972-2022-01	3073671M	7720	0	7720	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	537.9	f			M004076	调质-80KSI	XYGN4972-2022-01	3073671M	7735	0	7735	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	514.6	f			M004077	调质-80KSI	XYGN4972-2022-01	3073671M	7400	0	7400	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	555.63	f			M004078	调质-80KSI	XYGN4972-2022-01	3073671M	7990	0	7990	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	537.21	f			M004079	调质-80KSI	XYGN4972-2022-01	3073671M	7725	0	7725	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	520.17	f			M004080	调质-80KSI	XYGN4972-2022-01	3073671M	7480	0	7480	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	537.55	f			M004081	调质-80KSI	XYGN4972-2022-01	3073671M	7730	0	7730	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	161*20	0	556.33	f			M004082	调质-80KSI	XYGN4972-2022-01	3073671M	8000	0	8000	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	675.07	f			M003117	调质-80KSI	XYGN4972-2022-01	3050996M	8760	0	8760	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	671.99	f			M003118	调质-80KSI	XYGN4972-2022-01	3050996M	8720	0	8720	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	698.96	f			M003119	调质-80KSI	XYGN4972-2022-01	3050996M	9070	0	9070	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	698.96	f			M003120	调质-80KSI	XYGN4972-2022-01	3050996M	9070	0	9070	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	71.67	f			M003121	调质-80KSI	XYGN4972-2022-01	2055653M	930	0	930	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	67.04	f			M003123	调质-80KSI	XYGN4972-2022-01	2055653M	870	0	870	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	228.88	f			M003124	调质-80KSI	XYGN4972-2022-01	2055653M	2970	0	2970	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	757.52	f			M004576	调质-80KSI	XYGN4972-2022-01	3052131M	9830	0	9830	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	757.52	f			M004577	调质-80KSI	XYGN4972-2022-01	3052131M	9830	0	9830	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	766	f			M004578	调质-80KSI	XYGN4972-2022-01	3052131M	9940	0	9940	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	752.9	f			M004579	调质-80KSI	XYGN4972-2022-01	3052131M	9770	0	9770	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	764.07	f			M004580	调质-80KSI	XYGN4972-2022-01	3052131M	9915	0	9915	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	732.48	f			M004581	调质-80KSI	XYGN4972-2022-01	3052131M	9505	0	9505	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	731.32	f	外径148-148.6\n壁厚24.8-26		M004890	调质-80KSI	XYGN4972-2022-01	3073626A	9490	0	9490	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	762.92	f			M004891	调质-80KSI	XYGN4972-2022-01	3073626A	9900	0	9900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	766	f			M004892	调质-80KSI	XYGN4972-2022-01	3073626A	9940	0	9940	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	750.59	f			M004893	调质-80KSI	XYGN4972-2022-01	3073626A	9740	0	9740	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	766	f			M004894	调质-80KSI	XYGN4972-2022-01	3073626A	9940	0	9940	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	747.51	f			M004895	调质-80KSI	XYGN4972-2022-01	3073626A	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	770.63	f			M004896	调质-80KSI	XYGN4972-2022-01	3073626A	10000	0	10000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	457.97	f			M003125	调质-80KSI	XYGN4972-2022-01	3072161M	7690	0	7690	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	454.99	f			M003126	调质-80KSI	XYGN4972-2022-01	3072161M	7640	0	7640	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	455.59	f			M003127	调质-80KSI	XYGN4972-2022-01	3072161M	7650	0	7650	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	457.97	f			M003128	调质-80KSI	XYGN4972-2022-01	3072161M	7690	0	7690	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	457.97	f			M003129	调质-80KSI	XYGN4972-2022-01	3072161M	7690	0	7690	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	457.97	f			M003130	调质-80KSI	XYGN4972-2022-01	3072161M	7690	0	7690	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	451.42	f			M003131	调质-80KSI	XYGN4972-2022-01	3072161M	7580	0	7580	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	453.8	f			M003132	调质-80KSI	XYGN4972-2022-01	3072161M	7620	0	7620	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	453.8	f			M003133	调质-80KSI	XYGN4972-2022-01	3072161M	7620	0	7620	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	453.8	f			M003134	调质-80KSI	XYGN4972-2022-01	3072161M	7620	0	7620	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	454.99	f			M003135	调质-80KSI	XYGN4972-2022-01	3072161M	7640	0	7640	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	457.97	f			M003136	调质-80KSI	XYGN4972-2022-01	3072161M	7690	0	7690	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	506.51	f			M003907	调质-80KSI	XYGN4972-2022-01	3074205A	8505	0	8505	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	510.97	f			M003908	调质-80KSI	XYGN4972-2022-01	3074205A	8580	0	8580	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	510.67	f			M003909	调质-80KSI	XYGN4972-2022-01	3074205A	8575	0	8575	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	383.82	f			M003910	调质-80KSI	XYGN4972-2022-01	3074205A	6445	0	6445	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	379.36	f			M003911	调质-80KSI	XYGN4972-2022-01	3074205A	6370	0	6370	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	385.61	f			M003912	调质-80KSI	XYGN4972-2022-01	3074205A	6475	0	6475	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	385.61	f			M003913	调质-80KSI	XYGN4972-2022-01	3074205A	6475	0	6475	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	379.95	f			M004086	调质-80KSI	XYGN4972-2022-01	3074205A	6380	0	6380	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	385.61	f			M004087	调质-80KSI	XYGN4972-2022-01	3074205A	6475	0	6475	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	373.7	f			M004089	调质-80KSI	XYGN4972-2022-01	3074205A	6275	0	6275	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	136*21	0	371.91	f			M004090	调质-80KSI	XYGN4972-2022-01	3074205A	6245	0	6245	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	426.56	f			M004244	调质-80KSI	XYGN4972-2022-01	2016505Z	9085	0	9085	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	378.91	f			M004245	调质-80KSI	XYGN4972-2022-01	2016505Z	8070	0	8070	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	394.4	f			M004246	调质-80KSI	XYGN4972-2022-01	2016505Z	8400	0	8400	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	414.12	f			M004247	调质-80KSI	XYGN4972-2022-01	2016505Z	8820	0	8820	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	389.24	f			M004248	调质-80KSI	XYGN4972-2022-01	2016505Z	8290	0	8290	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	386.42	f			M004249	调质-80KSI	XYGN4972-2022-01	2016505Z	8230	0	8230	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	339	f			M004250	调质-80KSI	XYGN4972-2022-01	2016505Z	7220	0	7220	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	412.71	f			M004251	调质-80KSI	XYGN4972-2022-01	2016505Z	8790	0	8790	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	408.72	f			M004252	调质-80KSI	XYGN4972-2022-01	2016505Z	8705	0	8705	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	419.29	f			M004253	调质-80KSI	XYGN4972-2022-01	2016505Z	8930	0	8930	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	415.06	f			M004254	调质-80KSI	XYGN4972-2022-01	2016505Z	8840	0	8840	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	389	f			M004255	调质-80KSI	XYGN4972-2022-01	2016505Z	8285	0	8285	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	423.98	f			M004256	调质-80KSI	XYGN4972-2022-01	2016505Z	9030	0	9030	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*16	0	423.98	f			M004257	调质-80KSI	XYGN4972-2022-01	2016505Z	9030	0	9030	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	21.77	f			M003528	调质-80KSI	XYGN4972-2022-01	3073018A	310	0	310	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	514.8	f			M003531	调质-80KSI	XYGN4972-2022-01	3073018A	7330	0	7330	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	517.96	f			M003532	调质-80KSI	XYGN4972-2022-01	3073018A	7375	0	7375	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	34.41	f			M003535	调质-80KSI	XYGN4972-2022-01	3073018A	490	0	490	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	10.89	f			M003536	调质-80KSI	XYGN4972-2022-01	3073018A	155	0	155	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	21.77	f			M003539	调质-80KSI	XYGN4972-2022-01	3073018A	310	0	310	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	233.52	f			M003540	调质-80KSI	XYGN4972-2022-01	3073018A	3325	0	3325	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	44.18	f			M003543	调质-80KSI	XYGN4972-2022-01	3073018A	629	0	629	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	42.84	f			M003544	调质-80KSI	XYGN4972-2022-01	3073018A	610	0	610	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	44.18	f			M003545	调质-80KSI	XYGN4972-2022-01	3073018A	629	0	629	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	14.96	f			M003546	调质-80KSI	XYGN4972-2022-01	3073018A	213	0	213	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	2.81	f			M003547	调质-80KSI	XYGN4972-2022-01	3073018A	40	0	40	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	42.14	f			M003549	调质-80KSI	XYGN4972-2022-01	3073018A	600	0	600	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*32	0	47.13	f			M003550	调质-80KSI	XYGN4972-2022-01	3073018A	671	0	671	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	168*20	0	5.47	f			L619	调质-80KSI	XTG-JY-C-010-2020	0MALV20331	75	0	75	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	168*20	0	80.29	f			L620	调质-80KSI	XTG-JY-C-010-2020	0MALV20331	1100	0	1100	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	168*20	0	48.54	f			L609	调质-80KSI	XTG-JY-C-010-2020	21D0347V	665	0	665	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	168*20	0	394.17	f			L621	调质-80KSI	XTG-JY-C-010-2020	0MALV20331	5400	0	5400	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	168*20	0	104.02	f			L622	调质-80KSI	XTG-JY-C-010-2020	0MALV20331	1425	0	1425	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*35	0	2.54	f			M002790	调质-80KSI	XYGN4972-2022-01	3070668M	30	0	30	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*35	0	32.14	f			M002791	调质-80KSI	XYGN4972-2022-01	3070668M	380	0	380	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*35	0	510.04	f			M002792	调质-80KSI	XYGN4972-2022-01	3070668M	6030	0	6030	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*35	0	225.84	f			M003159	调质-80KSI	XYGN4972-2022-01	3070668M	2670	0	2670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*35	0	16.07	f			M003163	调质-80KSI	XYGN4972-2022-01	3070668M	190	0	190	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*35	0	21.15	f			M003164	调质-80KSI	XYGN4972-2022-01	3070668M	250	0	250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*13	0	186.12	f			L695	调质-80KSI	XTG-JY-C-041-2021/FS-T-M-003	2042973V	7540	0	7540	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*13	0	192.05	f			L697	调质-80KSI	XTG-JY-C-041-2021/FS-T-M-003	2042973V	7780	0	7780	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*13	0	191.06	f			L698	调质-80KSI	XTG-JY-C-041-2021/FS-T-M-003	2042973V	7740	0	7740	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*13	0	190.07	f			L701	调质-80KSI	XTG-JY-C-041-2021/FS-T-M-003	2042973V	7700	0	7700	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	505.97	f			M003200	调质-80KSI	XYGN4972-2022-01	3071650M	8260	0	8260	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	502.91	f			M003201	调质-80KSI	XYGN4972-2022-01	3071650M	8210	0	8210	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	517.61	f			M003202	调质-80KSI	XYGN4972-2022-01	3071650M	8450	0	8450	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	502.91	f			M003203	调质-80KSI	XYGN4972-2022-01	3071650M	8210	0	8210	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	499.84	f			M003204	调质-80KSI	XYGN4972-2022-01	3071650M	8160	0	8160	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	209.49	f			M003205	调质-80KSI	XYGN4972-2022-01	3071650M	3420	0	3420	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	464.62	f			M003206	调质-80KSI	XYGN4972-2022-01	3071650M	7585	0	7585	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	531.08	f			M003207	调质-80KSI	XYGN4972-2022-01	3071650M	8670	0	8670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	505.36	f			M003208	调质-80KSI	XYGN4972-2022-01	3071650M	8250	0	8250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	499.84	f			M003209	调质-80KSI	XYGN4972-2022-01	3071650M	8160	0	8160	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	523.12	f			M003210	调质-80KSI	XYGN4972-2022-01	3071650M	8540	0	8540	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	700.64	f			M003211	调质-80KSI	XYGN4972-2022-01	3050996M	9060	0	9060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	702.96	f			M003212	调质-80KSI	XYGN4972-2022-01	3050996M	9090	0	9090	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	700.64	f			M003213	调质-80KSI	XYGN4972-2022-01	3050996M	9060	0	9060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	692.14	f			M003214	调质-80KSI	XYGN4972-2022-01	3050996M	8950	0	8950	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	556.8	f			M003215	调质-80KSI	XYGN4972-2022-01	3050996M	7200	0	7200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	771.02	f			M003216	调质-80KSI	XYGN4972-2022-01	3050996M	9970	0	9970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	690.59	f			M003217	调质-80KSI	XYGN4972-2022-01	3050996M	8930	0	8930	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	762.51	f			M003218	调质-80KSI	XYGN4972-2022-01	3050996M	9860	0	9860	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	762.9	f			M003219	调质-80KSI	XYGN4972-2022-01	3050996M	9865	0	9865	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	760.19	f			M003714	调质-80KSI	XYGN4972-2022-01	3071650M	9830	0	9830	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	761.74	f			M003715	调质-80KSI	XYGN4972-2022-01	3071650M	9850	0	9850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	761.74	f			M003716	调质-80KSI	XYGN4972-2022-01	3071650M	9850	0	9850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	762.51	f			M003717	调质-80KSI	XYGN4972-2022-01	3071650M	9860	0	9860	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	767.15	f			M003718	调质-80KSI	XYGN4972-2022-01	3071650M	9920	0	9920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	767.92	f			M003719	调质-80KSI	XYGN4972-2022-01	3071650M	9930	0	9930	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	765.6	f			M003720	调质-80KSI	XYGN4972-2022-01	3071650M	9900	0	9900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	764.06	f			M003721	调质-80KSI	XYGN4972-2022-01	3071650M	9880	0	9880	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	756.32	f			M003722	调质-80KSI	XYGN4972-2022-01	3071650M	9780	0	9780	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	756.32	f			M003723	调质-80KSI	XYGN4972-2022-01	3071650M	9780	0	9780	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	773.34	f			M003724	调质-80KSI	XYGN4972-2022-01	3071650M	10000	0	10000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	761.74	f			M003725	调质-80KSI	XYGN4972-2022-01	3071650M	9850	0	9850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	761.74	f			M003726	调质-80KSI	XYGN4972-2022-01	3071650M	9850	0	9850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	768.7	f			M003727	调质-80KSI	XYGN4972-2022-01	3071650M	9940	0	9940	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	42.38	f			M000067	调质-80KSI	XYGN4018.1-2021-02	2050596M	550	0	550	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	38.73	f			M002057	调质-80KSI	XYGN4972-2022-01	2055049M	610	0	610	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	234.95	f			M002062	调质-80KSI	XYGN4972-2022-01	2055049M	3700	0	3700	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	464.82	f			M002064	调质-80KSI	XYGN4972-2022-01	2055049M	7320	0	7320	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	461.96	f			M002066	调质-80KSI	XYGN4972-2022-01	2055049M	7275	0	7275	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	461.96	f			M002068	调质-80KSI	XYGN4972-2022-01	2055049M	7275	0	7275	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	464.82	f			M002069	调质-80KSI	XYGN4972-2022-01	2055049M	7320	0	7320	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	453.39	f			M003221	调质-80KSI	XYGN4972-2022-01	3072161M	7140	0	7140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	442.59	f			M003222	调质-80KSI	XYGN4972-2022-01	3072161M	6970	0	6970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	436.24	f			M003223	调质-80KSI	XYGN4972-2022-01	3072161M	6870	0	6870	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	441.32	f			M003224	调质-80KSI	XYGN4972-2022-01	3072161M	6950	0	6950	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	442.59	f			M003225	调质-80KSI	XYGN4972-2022-01	3072161M	6970	0	6970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	441.32	f			M003226	调质-80KSI	XYGN4972-2022-01	3072161M	6950	0	6950	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	441.32	f			M003227	调质-80KSI	XYGN4972-2022-01	3072161M	6950	0	6950	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	442.59	f			M003228	调质-80KSI	XYGN4972-2022-01	3072161M	6970	0	6970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	439.42	f			M003229	调质-80KSI	XYGN4972-2022-01	3072161M	6920	0	6920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	439.42	f			M003230	调质-80KSI	XYGN4972-2022-01	3072161M	6920	0	6920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	128*25	0	442.59	f			M003231	调质-80KSI	XYGN4972-2022-01	3072161M	6970	0	6970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*35	0	19.26	f			M002374	调质-80KSI	XYGN4972-2022-01	2074709T	180	0	180	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*35	0	27.29	f			M002377	调质-80KSI	XYGN4972-2022-01	2053826M	255	0	255	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*35	0	83.48	f			M002379	调质-80KSI	XYGN4972-2022-01	2054509M	780	0	780	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*26	0	699.25	f			M003729	调质-80KSI	XYGN4972.3-2023-01	3071650M	8200	0	8200	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*24	0	208.53	f			M003396	调质-80KSI	XYGN4972-2022-01	3050376M	2610	0	2610	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*22	0	37.91	f			M000083	调质-80KSI	XYGN4018.1-2021-02	2050595M	510	0	510	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*22	0	52.77	f			M000084	调质-80KSI	XYGN4018.1-2021-02	2050595M	710	0	710	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*24	0	761.43	f			M003153	调质-80KSI	XYGN4972-2022-01	2055585A	9530	0	9530	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*24	0	18.38	f			M003154	调质-80KSI	XYGN4972-2022-01	2055585A	230	0	230	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*24	0	761.43	f			M003155	调质-80KSI	XYGN4972-2022-01	2055585A	9530	0	9530	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	29.1	f			M000096	调质-80KSI	XYGN4018.1-2021-02	1054937M	400	0	400	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	140*28	0	6.96	f			M001866	调质-80KSI	XYGN4972-2022-01	2051591M	90	0	90	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	145	f			M000114	调质-80KSI	XTG-JT-028-2019	119V-1547	4900	0	4900	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	248.57	f			M000116	调质-80KSI	XTG-JT-028-2019	119V-1547	8400	0	8400	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	242.95	f			M000117	调质-80KSI	XTG-JT-028-2019	119V-1547	8210	0	8210	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	253.01	f			M000118	调质-80KSI	XTG-JT-028-2019	119V-1547	8550	0	8550	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	251.53	f			M000119	调质-80KSI	XTG-JT-028-2019	119V-1547	8500	0	8500	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	247.39	f			M000120	调质-80KSI	XTG-JT-028-2019	119V-1547	8360	0	8360	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	248.57	f			M000121	调质-80KSI	XTG-JT-028-2019	119V-1547	8400	0	8400	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	247.69	f			M000122	调质-80KSI	XTG-JT-028-2019	119V-1547	8370	0	8370	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	251.24	f			M000123	调质-80KSI	XTG-JT-028-2019	119V-1547	8490	0	8490	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	247.98	f			M000124	调质-80KSI	XTG-JT-028-2019	119V-1547	8380	0	8380	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	163.94	f			M000126	调质-80KSI	XTG-JT-028-2019	119V-1547	5540	0	5540	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	371.26	f			M003173	调质-80KSI	XYGN4972-2022-01	3072161M	7280	0	7280	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	359.27	f			M003174	调质-80KSI	XYGN4972-2022-01	3072161M	7045	0	7045	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	381.46	f			M003176	调质-80KSI	XYGN4972-2022-01	3072161M	7480	0	7480	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	385.03	f			M003177	调质-80KSI	XYGN4972-2022-01	3072161M	7550	0	7550	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	385.54	f			M003178	调质-80KSI	XYGN4972-2022-01	3072161M	7560	0	7560	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	378.4	f			M003179	调质-80KSI	XYGN4972-2022-01	3072161M	7420	0	7420	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	377.89	f			M003180	调质-80KSI	XYGN4972-2022-01	3072161M	7410	0	7410	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	392.68	f			M003181	调质-80KSI	XYGN4972-2022-01	3072161M	7700	0	7700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	378.4	f			M003182	调质-80KSI	XYGN4972-2022-01	3072161M	7420	0	7420	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	227.96	f			M003183	调质-80KSI	XYGN4972-2022-01	3072161M	4470	0	4470	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	385.54	f			M003184	调质-80KSI	XYGN4972-2022-01	3072161M	7560	0	7560	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	383.75	f			M003185	调质-80KSI	XYGN4972-2022-01	3072161M	7525	0	7525	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	392.93	f			M003186	调质-80KSI	XYGN4972-2022-01	3072161M	7705	0	7705	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	370.75	f			M003187	调质-80KSI	XYGN4972-2022-01	3072161M	7270	0	7270	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	382.48	f			M003188	调质-80KSI	XYGN4972-2022-01	3072161M	7500	0	7500	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	374.83	f			M003189	调质-80KSI	XYGN4972-2022-01	3072161M	7350	0	7350	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	354.94	f			M003190	调质-80KSI	XYGN4972-2022-01	3072161M	6960	0	6960	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	354.43	f			M003191	调质-80KSI	XYGN4972-2022-01	3072161M	6950	0	6950	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	359.02	f			M003192	调质-80KSI	XYGN4972-2022-01	3072161M	7040	0	7040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	360.04	f			M003193	调质-80KSI	XYGN4972-2022-01	3072161M	7060	0	7060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	345.25	f			M003194	调质-80KSI	XYGN4972-2022-01	3072161M	6770	0	6770	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	356.47	f			M003195	调质-80KSI	XYGN4972-2022-01	3072161M	6990	0	6990	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	352.9	f			M003196	调质-80KSI	XYGN4972-2022-01	3072161M	6920	0	6920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	379.42	f			M003197	调质-80KSI	XYGN4972-2022-01	3072161M	7440	0	7440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	383.5	f			M003198	调质-80KSI	XYGN4972-2022-01	3072161M	7520	0	7520	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	385.54	f			M003247	调质-80KSI	XYGN4972-2022-01	3072161M	7560	0	7560	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	6.88	f			M002071	调质-80KSI	XYGN4972-2022-01	2055048M	155	0	155	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	2.22	f			M002072	调质-80KSI	XYGN4972-2022-01	2055048M	50	0	50	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	15.31	f			M002073	调质-80KSI	XYGN4972-2022-01	2055048M	345	0	345	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	2.22	f			M002081	调质-80KSI	XYGN4972-2022-01	2055048M	50	0	50	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	11.32	f			M002082	调质-80KSI	XYGN4972-2022-01	2055048M	255	0	255	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	2.09	f			M000150	调质-80KSI		2050592M	35	0	35	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	7.18	f			M000151	调质-80KSI		2050592M	120	0	120	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	31.1	f			M000152	调质-80KSI		2050592M	520	0	520	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	1.2	f			M000164	调质-80KSI		2050592M	20	0	20	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	20.93	f			M000166	调质-80KSI		2050592M	350	0	350	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	20.33	f			M000167	调质-80KSI		2050592M	340	0	340	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	20.33	f			M000168	调质-80KSI		2050592M	340	0	340	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	15.55	f			M000169	调质-80KSI		2050592M	260	0	260	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	20.33	f			M000170	调质-80KSI		2050592M	340	0	340	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	22.13	f			M000171	调质-80KSI		2050592M	370	0	370	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*25	0	114.82	f			M000172	调质-80KSI		2050592M	1920	0	1920	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	2.91	f			M001753	调质-80KSI	XYGN4972-2022-01	2053515M	40	0	40	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	5.46	f			M001755	调质-80KSI	XYGN4972-2022-01	2053515M	75	0	75	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	7.64	f			M001759	调质-80KSI	XYGN4972-2022-01	2053515M	105	0	105	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	3.27	f			M001760	调质-80KSI	XYGN4972-2022-01	2053515M	45	0	45	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	20.73	f			M001761	调质-80KSI	XYGN4972-2022-01	2053515M	285	0	285	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	3.64	f			M001762	调质-80KSI	XYGN4972-2022-01	2053515M	50	0	50	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	3.27	f			M001764	调质-80KSI	XYGN4972-2022-01	2053515M	45	0	45	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	5.46	f			M001767	调质-80KSI	XYGN4972-2022-01	2053515M	75	0	75	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	2.91	f			M001770	调质-80KSI	XYGN4972-2022-01	2053515M	40	0	40	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	6.18	f			M001773	调质-80KSI	XYGN4972-2022-01	2053515M	85	0	85	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	510.68	f			M004755	调质-80KSI	XYGN4972-2022-01	3074205A	7020	0	7020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	504.14	f			M004756	调质-80KSI	XYGN4972-2022-01	3074205A	6930	0	6930	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	507.05	f			M004757	调质-80KSI	XYGN4972-2022-01	3074205A	6970	0	6970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	512.87	f			M004758	调质-80KSI	XYGN4972-2022-01	3074205A	7050	0	7050	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	512.87	f			M004759	调质-80KSI	XYGN4972-2022-01	3074205A	7050	0	7050	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	507.77	f			M004760	调质-80KSI	XYGN4972-2022-01	3074205A	6980	0	6980	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	523.78	f			M004761	调质-80KSI	XYGN4972-2022-01	3074205A	7200	0	7200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	507.77	f			M004762	调质-80KSI	XYGN4972-2022-01	3074205A	6980	0	6980	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	513.59	f			M004763	调质-80KSI	XYGN4972-2022-01	3074205A	7060	0	7060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	512.87	f			M004764	调质-80KSI	XYGN4972-2022-01	3074205A	7050	0	7050	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	510.68	f			M004765	调质-80KSI	XYGN4972-2022-01	3074205A	7020	0	7020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	501.95	f			M004766	调质-80KSI	XYGN4972-2022-01	3074205A	6900	0	6900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	0.51	f			Z230510-29				13	0	13	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	505.96	f			M004767	调质-80KSI	XYGN4972-2022-01	3074205A	6955	0	6955	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	506.68	f			M004768	调质-80KSI	XYGN4972-2022-01	3074205A	6965	0	6965	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	493.22	f			M004769	调质-80KSI	XYGN4972-2022-01	3074205A	6780	0	6780	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	504.14	f			M004770	调质-80KSI	XYGN4972-2022-01	3074205A	6930	0	6930	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	507.05	f			M004771	调质-80KSI	XYGN4972-2022-01	3074205A	6970	0	6970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	143*25	0	499.77	f			M004772	调质-80KSI	XYGN4972-2022-01	3074205A	6870	0	6870	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*22	0	10.41	f			M000078	调质-80KSI	XYGN4018.1-2021-02	2050595M	140	0	140	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*25	0	3.39	f			M001774	调质-80KSI	XYGN4972-2022-01	2053515M	50	0	50	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*25	0	5.43	f			M001775	调质-80KSI	XYGN4972-2022-01	2053515M	80	0	80	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*25	0	5.43	f			M001776	调质-80KSI	XYGN4972-2022-01	2053515M	80	0	80	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*25	0	6.78	f			M001781	调质-80KSI	XYGN4972-2022-01	2053515M	100	0	100	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*25	0	487.25	f			M003168	调质-80KSI	XYGN4972-2022-01	3070668M	7185	0	7185	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*25	0	414.35	f			M003169	调质-80KSI	XYGN4972-2022-01	3070668M	6110	0	6110	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*25	0	523.53	f			M003170	调质-80KSI	XYGN4972-2022-01	3070668M	7720	0	7720	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	135*25	0	537.09	f			M003171	调质-80KSI	XYGN4972-2022-01	3070668M	7920	0	7920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	505.36	f			M003997	调质-80KSI	XYGN4972-2022-01	3072974M	7590	0	7590	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	499.37	f			M003998	调质-80KSI	XYGN4972-2022-01	3072974M	7500	0	7500	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	513.35	f			M003999	调质-80KSI	XYGN4972-2022-01	3072974M	7710	0	7710	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	512.02	f			M004000	调质-80KSI	XYGN4972-2022-01	3072974M	7690	0	7690	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	512.68	f			M004001	调质-80KSI	XYGN4972-2022-01	3072974M	7700	0	7700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	508.35	f			M004002	调质-80KSI	XYGN4972-2022-01	3072974M	7635	0	7635	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	506.02	f			M004003	调质-80KSI	XYGN4972-2022-01	3072974M	7600	0	7600	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	511.35	f			M004004	调质-80KSI	XYGN4972-2022-01	3072974M	7680	0	7680	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	511.35	f			M004005	调质-80KSI	XYGN4972-2022-01	3072974M	7680	0	7680	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	512.68	f			M004006	调质-80KSI	XYGN4972-2022-01	3072974M	7700	0	7700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	502.03	f			M004007	调质-80KSI	XYGN4972-2022-01	3072974M	7540	0	7540	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	518.67	f			M004008	调质-80KSI	XYGN4972-2022-01	3073018A	7790	0	7790	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	514.68	f			M004009	调质-80KSI	XYGN4972-2022-01	3073018A	7730	0	7730	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	515.01	f			M004010	调质-80KSI	XYGN4972-2022-01	3073018A	7735	0	7735	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	510.68	f			M004011	调质-80KSI	XYGN4972-2022-01	3073018A	7670	0	7670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	511.35	f			M004012	调质-80KSI	XYGN4972-2022-01	3073018A	7680	0	7680	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	501.36	f			M004013	调质-80KSI	XYGN4972-2022-01	3073018A	7530	0	7530	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	504.69	f			M004014	调质-80KSI	XYGN4972-2022-01	3073018A	7580	0	7580	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	498.03	f			M004015	调质-80KSI	XYGN4972-2022-01	3072974M	7480	0	7480	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	508.69	f			M004016	调质-80KSI	XYGN4972-2022-01	3072974M	7640	0	7640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	505.36	f			M004017	调质-80KSI	XYGN4972-2022-01	3072974M	7590	0	7590	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	492.71	f			M004018	调质-80KSI	XYGN4972-2022-01	3072974M	7400	0	7400	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	493.37	f			M004019	调质-80KSI	XYGN4972-2022-01	3072974M	7410	0	7410	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	512.02	f			M004020	调质-80KSI	XYGN4972-2022-01	3072974M	7690	0	7690	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	502.69	f			M004021	调质-80KSI	XYGN4972-2022-01	3072974M	7550	0	7550	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	133*25	0	504.69	f			M004022	调质-80KSI	XYGN4972-2022-01	3072974M	7580	0	7580	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	162*25	0	116.56	f			M000176	调质-80KSI	XYGN4972-2022-01	2050596M	1380	0	1380	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	162*25	0	812.51	f			M002796	调质-80KSI	XYGN4972-2022-01	2055551M	9620	0	9620	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	162*25	0	814.2	f			M002797	调质-80KSI	XYGN4972-2022-01	2055551M	9640	0	9640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	162*25	0	804.91	f			M002798	调质-80KSI	XYGN4972-2022-01	2055551M	9530	0	9530	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	162*25	0	805.75	f			M002799	调质-80KSI	XYGN4972-2022-01	2055551M	9540	0	9540	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	162*25	0	814.2	f			M002800	调质-80KSI	XYGN4972-2022-01	2055551M	9640	0	9640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	162*25	0	87.84	f			M002716	调质-80KSI	XYGN4972-2022-01	2055551M	1040	0	1040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	265	f			M004843	调质-80KSI	XYGN4972-2022-01	3074934M	5970	0	5970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	262.78	f			M004844	调质-80KSI	XYGN4972-2022-01	3074934M	5920	0	5920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	260.56	f			M004845	调质-80KSI	XYGN4972-2022-01	3074934M	5870	0	5870	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	264.33	f			M004846	调质-80KSI	XYGN4972-2022-01	3074934M	5955	0	5955	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261	f			M004847	调质-80KSI	XYGN4972-2022-01	3074934M	5880	0	5880	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	263.66	f			M004848	调质-80KSI	XYGN4972-2022-01	3074934M	5940	0	5940	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261	f			M004849	调质-80KSI	XYGN4972-2022-01	3074934M	5880	0	5880	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	263.22	f			M004850	调质-80KSI	XYGN4972-2022-01	3074934M	5930	0	5930	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	263.66	f			M004851	调质-80KSI	XYGN4972-2022-01	3074934M	5940	0	5940	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261	f			M004852	调质-80KSI	XYGN4972-2022-01	3074934M	5880	0	5880	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	264.33	f			M004853	调质-80KSI	XYGN4972-2022-01	3074934M	5955	0	5955	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261	f			M004854	调质-80KSI	XYGN4972-2022-01	3074934M	5880	0	5880	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	266.77	f			M004855	调质-80KSI	XYGN4972-2022-01	3074934M	6010	0	6010	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.89	f			M004856	调质-80KSI	XYGN4972-2022-01	3074934M	5900	0	5900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	265.22	f			M004857	调质-80KSI	XYGN4972-2022-01	3074934M	5975	0	5975	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.89	f			M004858	调质-80KSI	XYGN4972-2022-01	3074934M	5900	0	5900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	262.33	f			M004859	调质-80KSI	XYGN4972-2022-01	3074934M	5910	0	5910	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	264.11	f			M004860	调质-80KSI	XYGN4972-2022-01	3074934M	5950	0	5950	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	264.55	f			M004861	调质-80KSI	XYGN4972-2022-01	3074934M	5960	0	5960	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.89	f			M004862	调质-80KSI	XYGN4972-2022-01	3074934M	5900	0	5900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	260.56	f			M004863	调质-80KSI	XYGN4972-2022-01	3074934M	5870	0	5870	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	265	f			M004864	调质-80KSI	XYGN4972-2022-01	3074934M	5970	0	5970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	263.89	f			M004865	调质-80KSI	XYGN4972-2022-01	3074934M	5945	0	5945	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	258.78	f			M004866	调质-80KSI	XYGN4972-2022-01	3074934M	5830	0	5830	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.45	f			M004867	调质-80KSI	XYGN4972-2022-01	3074934M	5890	0	5890	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.89	f			M004868	调质-80KSI	XYGN4972-2022-01	3074934M	5900	0	5900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	264.11	f			M004869	调质-80KSI	XYGN4972-2022-01	3074934M	5950	0	5950	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	248.13	f			M004870	调质-80KSI	XYGN4972-2022-01	3074934M	5590	0	5590	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	209.51	f			M004871	调质-80KSI	XYGN4972-2022-01	3074934M	4720	0	4720	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	258.78	f			M004872	调质-80KSI	XYGN4972-2022-01	3074934M	5830	0	5830	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	194.86	f			M004873	调质-80KSI	XYGN4972-2022-01	3074934M	4390	0	4390	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	206.4	f			M004874	调质-80KSI	XYGN4972-2022-01	3074934M	4650	0	4650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	218.83	f			M004875	调质-80KSI	XYGN4972-2022-01	3074934M	4930	0	4930	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	262.33	f			M004876	调质-80KSI	XYGN4972-2022-01	3074934M	5910	0	5910	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.45	f			M004877	调质-80KSI	XYGN4972-2022-01	3074934M	5890	0	5890	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.45	f			M004878	调质-80KSI	XYGN4972-2022-01	3074934M	5890	0	5890	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.89	f			M004879	调质-80KSI	XYGN4972-2022-01	3074934M	5900	0	5900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.45	f			M004880	调质-80KSI	XYGN4972-2022-01	3074934M	5890	0	5890	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.89	f			M004881	调质-80KSI	XYGN4972-2022-01	3074934M	5900	0	5900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	260.34	f			M004882	调质-80KSI	XYGN4972-2022-01	3074934M	5865	0	5865	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	262.33	f			M004883	调质-80KSI	XYGN4972-2022-01	3074934M	5910	0	5910	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.67	f			M004884	调质-80KSI	XYGN4972-2022-01	3074934M	5895	0	5895	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	260.11	f			M004885	调质-80KSI	XYGN4972-2022-01	3074934M	5860	0	5860	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.45	f			M004886	调质-80KSI	XYGN4972-2022-01	3074934M	5890	0	5890	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.89	f			M004887	调质-80KSI	XYGN4972-2022-01	3074934M	5900	0	5900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	260.34	f			M004888	调质-80KSI	XYGN4972-2022-01	3074934M	5865	0	5865	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	110*20	0	261.89	f			M004889	调质-80KSI	XYGN4972-2022-01	3074934M	5900	0	5900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	28.34	f			M004149	调质-80KSI	XYGN4972-2022-01	3052130M	570	0	570	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	52.95	f			M004150	调质-80KSI	XYGN4972-2022-01	3052130M	1065	0	1065	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.04	f			M004151	调质-80KSI	XYGN4972-2022-01	3052130M	5110	0	5110	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	249.07	f			M004152	调质-80KSI	XYGN4972-2022-01	3052130M	5010	0	5010	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	251.06	f			M004153	调质-80KSI	XYGN4972-2022-01	3052130M	5050	0	5050	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	252.8	f			M004154	调质-80KSI	XYGN4972-2022-01	3052130M	5085	0	5085	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	51.7	f			M004155	调质-80KSI	XYGN4972-2022-01	3052130M	1040	0	1040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	253.3	f			M004156	调质-80KSI	XYGN4972-2022-01	3052130M	5095	0	5095	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	252.55	f			M004157	调质-80KSI	XYGN4972-2022-01	3052130M	5080	0	5080	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	248.57	f			M004158	调质-80KSI	XYGN4972-2022-01	3052130M	5000	0	5000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	4.47	f			M004262	调质-80KSI	XYGN4972-2022-01	3074934M	90	0	90	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	193.89	f			M004263	调质-80KSI	XYGN4972-2022-01	3074934M	3900	0	3900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	245.59	f			M004264	调质-80KSI	XYGN4972-2022-01	3074934M	4940	0	4940	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	242.86	f			M004265	调质-80KSI	XYGN4972-2022-01	3074934M	4885	0	4885	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	241.86	f			M004266	调质-80KSI	XYGN4972-2022-01	3074934M	4865	0	4865	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	258.02	f			M004267	调质-80KSI	XYGN4972-2022-01	3074934M	5190	0	5190	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	250.31	f			M004268	调质-80KSI	XYGN4972-2022-01	3074934M	5035	0	5035	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	255.04	f			M004269	调质-80KSI	XYGN4972-2022-01	3074934M	5130	0	5130	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.79	f			M004270	调质-80KSI	XYGN4972-2022-01	3074934M	5125	0	5125	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	252.3	f			M004271	调质-80KSI	XYGN4972-2022-01	3074934M	5075	0	5075	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	250.06	f			M004272	调质-80KSI	XYGN4972-2022-01	3074934M	5030	0	5030	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	250.06	f			M004273	调质-80KSI	XYGN4972-2022-01	3074934M	5030	0	5030	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	255.78	f			M004274	调质-80KSI	XYGN4972-2022-01	3074934M	5145	0	5145	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	255.53	f			M004275	调质-80KSI	XYGN4972-2022-01	3074934M	5140	0	5140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.79	f			M004276	调质-80KSI	XYGN4972-2022-01	3074934M	5125	0	5125	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	251.56	f			M004277	调质-80KSI	XYGN4972-2022-01	3074934M	5060	0	5060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.79	f			M004278	调质-80KSI	XYGN4972-2022-01	3074934M	5125	0	5125	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	256.28	f			M004279	调质-80KSI	XYGN4972-2022-01	3074934M	5155	0	5155	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.04	f			M004280	调质-80KSI	XYGN4972-2022-01	3074934M	5110	0	5110	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.54	f			M004281	调质-80KSI	XYGN4972-2022-01	3074934M	5120	0	5120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.04	f			M004282	调质-80KSI	XYGN4972-2022-01	3074934M	5110	0	5110	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	250.56	f			M004283	调质-80KSI	XYGN4972-2022-01	3074934M	5040	0	5040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	253.79	f			M004284	调质-80KSI	XYGN4972-2022-01	3074934M	5105	0	5105	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	259.01	f			M004285	调质-80KSI	XYGN4972-2022-01	3074934M	5210	0	5210	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	248.57	f			M004286	调质-80KSI	XYGN4972-2022-01	3074934M	5000	0	5000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.04	f			M004287	调质-80KSI	XYGN4972-2022-01	3074934M	5110	0	5110	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	249.82	f			M004288	调质-80KSI	XYGN4972-2022-01	3074934M	5025	0	5025	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	250.06	f			M004289	调质-80KSI	XYGN4972-2022-01	3074934M	5030	0	5030	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	253.79	f			M004290	调质-80KSI	XYGN4972-2022-01	3074934M	5105	0	5105	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	252.05	f			M004291	调质-80KSI	XYGN4972-2022-01	3074934M	5070	0	5070	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	252.05	f			M004292	调质-80KSI	XYGN4972-2022-01	3074934M	5070	0	5070	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	254.54	f			M004293	调质-80KSI	XYGN4972-2022-01	3074934M	5120	0	5120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	251.56	f			M004294	调质-80KSI	XYGN4972-2022-01	3074934M	5060	0	5060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*24	0	253.54	f			M004295	调质-80KSI	XYGN4972-2022-01	3074934M	5100	0	5100	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	244.13	f			M004805	调质-80KSI	XYGN5203-2022-01	3060076A	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.96	f			M004806	调质-80KSI	XYGN5203-2022-01	3060076A	6220	0	6220	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	241.79	f			M004807	调质-80KSI	XYGN5203-2022-01	3060076A	6190	0	6190	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	241.4	f			M004808	调质-80KSI	XYGN5203-2022-01	3060076A	6180	0	6180	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	239.84	f			M004809	调质-80KSI	XYGN5203-2022-01	3060076A	6140	0	6140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	241.79	f			M004810	调质-80KSI	XYGN5203-2022-01	3060076A	6190	0	6190	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	244.13	f			M004811	调质-80KSI	XYGN5203-2022-01	3060076A	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	244.13	f			M004812	调质-80KSI	XYGN5203-2022-01	3060076A	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004813	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004814	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004815	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	241.01	f			M004816	调质-80KSI	XYGN5203-2022-01	3060076A	6170	0	6170	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004817	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004818	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	239.84	f			M004819	调质-80KSI	XYGN5203-2022-01	3060076A	6140	0	6140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004820	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.57	f			M004821	调质-80KSI	XYGN5203-2022-01	3060076A	6210	0	6210	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004822	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.77	f			M004823	调质-80KSI	XYGN5203-2022-01	3060076A	6215	0	6215	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	244.13	f			M004824	调质-80KSI	XYGN5203-2022-01	3060076A	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	244.13	f			M004825	调质-80KSI	XYGN5203-2022-01	3060076A	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	244.13	f			M004826	调质-80KSI	XYGN5203-2022-01	3060076A	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004827	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M004828	调质-80KSI	XYGN5203-2022-01	3060076A	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	238.27	f			M004829	调质-80KSI	XYGN5203-2022-01	3060076A	6100	0	6100	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.57	f			M004830	调质-80KSI	XYGN5203-2022-01	3060076A	6210	0	6210	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	353.73	f			M004831	调质-80KSI	XYGN5203-2022-01	3060076A	8470	0	8470	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	339.53	f			M004832	调质-80KSI	XYGN5203-2022-01	3060076A	8130	0	8130	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	352.06	f			M004833	调质-80KSI	XYGN5203-2022-01	3060076A	8430	0	8430	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	316.14	f			M004834	调质-80KSI	XYGN5203-2022-01	3060076A	7570	0	7570	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	320.32	f			M004835	调质-80KSI	XYGN5203-2022-01	3060076A	7670	0	7670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	349.14	f			M004836	调质-80KSI	XYGN5203-2022-01	3060076A	8360	0	8360	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	351.23	f			M004837	调质-80KSI	XYGN5203-2022-01	3060076A	8410	0	8410	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	353.73	f			M004838	调质-80KSI	XYGN5203-2022-01	3060076A	8470	0	8470	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	327.42	f			M004839	调质-80KSI	XYGN5203-2022-01	3060076A	7840	0	7840	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	317.4	f			M004840	调质-80KSI	XYGN5203-2022-01	3060076A	7600	0	7600	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	349.14	f			M004841	调质-80KSI	XYGN5203-2022-01	3060076A	8360	0	8360	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	107.95*19.05	0	351.23	f			M004842	调质-80KSI	XYGN5203-2022-01	3060076A	8410	0	8410	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	262.36	f			M003954	调质-80KSI	XYGN4972-2022-01	3052130M	6045	0	6045	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	263.23	f			M003955	调质-80KSI	XYGN4972-2022-01	3052130M	6065	0	6065	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	261.28	f			M003956	调质-80KSI	XYGN4972-2022-01	3052130M	6020	0	6020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	261.28	f			M003957	调质-80KSI	XYGN4972-2022-01	3052130M	6020	0	6020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	260.41	f			M003958	调质-80KSI	XYGN4972-2022-01	3051854M	6000	0	6000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	262.15	f			M003959	调质-80KSI	XYGN4972-2022-01	3051854M	6040	0	6040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	262.58	f			M003960	调质-80KSI	XYGN4972-2022-01	3051854M	6050	0	6050	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	260.41	f			M003962	调质-80KSI	XYGN4972-2022-01	3051854M	6000	0	6000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	261.49	f			M003963	调质-80KSI	XYGN4972-2022-01	3051854M	6025	0	6025	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	263.01	f			M003964	调质-80KSI	XYGN4972-2022-01	3051854M	6060	0	6060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	260.84	f			M003965	调质-80KSI	XYGN4972-2022-01	3051854M	6010	0	6010	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	263.01	f			M003966	调质-80KSI	XYGN4972-2022-01	3051854M	6060	0	6060	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	260.41	f			M003967	调质-80KSI	XYGN4972-2022-01	3051854M	6000	0	6000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	260.41	f			M003968	调质-80KSI	XYGN4972-2022-01	3051854M	6000	0	6000	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	249.13	f			M003969	调质-80KSI	XYGN4972-2022-01	3052130M	5740	0	5740	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	253.25	f			M003970	调质-80KSI	XYGN4972-2022-01	3052130M	5835	0	5835	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	254.12	f			M003971	调质-80KSI	XYGN4972-2022-01	3052130M	5855	0	5855	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	253.9	f			M003972	调质-80KSI	XYGN4972-2022-01	3052130M	5850	0	5850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	245.22	f			M003973	调质-80KSI	XYGN4972-2022-01	3052130M	5650	0	5650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	247.82	f			M003974	调质-80KSI	XYGN4972-2022-01	3052130M	5710	0	5710	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	244.35	f			M003975	调质-80KSI	XYGN4972-2022-01	3052130M	5630	0	5630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	242.18	f			M003976	调质-80KSI	XYGN4972-2022-01	3052130M	5580	0	5580	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	244.35	f			M003977	调质-80KSI	XYGN4972-2022-01	3052130M	5630	0	5630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	245.22	f			M003978	调质-80KSI	XYGN4972-2022-01	3052130M	5650	0	5650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	253.9	f			M003979	调质-80KSI	XYGN4972-2022-01	3051854M	5850	0	5850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	253.9	f			M003980	调质-80KSI	XYGN4972-2022-01	3051854M	5850	0	5850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	254.33	f			M003981	调质-80KSI	XYGN4972-2022-01	3051854M	5860	0	5860	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	244.35	f			M003982	调质-80KSI	XYGN4972-2022-01	3051854M	5630	0	5630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	236.1	f			M003983	调质-80KSI	XYGN4972-2022-01	3051854M	5440	0	5440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	253.47	f			M003984	调质-80KSI	XYGN4972-2022-01	3051854M	5840	0	5840	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	22.79	f			M004137	调质-80KSI	XYGN4972-2022-01	3052130M	525	0	525	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	241.1	f			M004138	调质-80KSI	XYGN4972-2022-01	3052130M	5555	0	5555	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	236.97	f			M004139	调质-80KSI	XYGN4972-2022-01	3052130M	5460	0	5460	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	249.99	f			M004140	调质-80KSI	XYGN4972-2022-01	3052130M	5760	0	5760	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	239.79	f			M004141	调质-80KSI	XYGN4972-2022-01	3052130M	5525	0	5525	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	23.44	f			M004142	调质-80KSI	XYGN4972-2022-01	3052130M	540	0	540	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	249.13	f			M004143	调质-80KSI	XYGN4972-2022-01	3052130M	5740	0	5740	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	119.79	f			M004144	调质-80KSI	XYGN4972-2022-01	3052130M	2760	0	2760	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	21.7	f			M004145	调质-80KSI	XYGN4972-2022-01	3052130M	500	0	500	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	246.09	f			M004146	调质-80KSI	XYGN4972-2022-01	3052130M	5670	0	5670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	27.78	f			M004147	调质-80KSI	XYGN4972-2022-01	3052130M	640	0	640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	33.85	f			M004148	调质-80KSI	XYGN4972-2022-01	3052130M	780	0	780	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	109.64	f			M003137	调质-80KSI	XYGN4972-2022-01	3050615M	1900	0	1900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	17.6	f			M003138	调质-80KSI	XYGN4972-2022-01	3050615M	305	0	305	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	455.86	f			M003139	调质-80KSI	XYGN4972-2022-01	3050615M	7900	0	7900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	73.28	f			M003140	调质-80KSI	XYGN4972-2022-01	3050615M	1270	0	1270	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	462.79	f			M003141	调质-80KSI	XYGN4972-2022-01	3050615M	8020	0	8020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	478.95	f			M003142	调质-80KSI	XYGN4972-2022-01	3050615M	8300	0	8300	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	469.71	f			M003144	调质-80KSI	XYGN4972-2022-01	3050615M	8140	0	8140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	462.79	f			M003145	调质-80KSI	XYGN4972-2022-01	3050615M	8020	0	8020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	476.06	f			M003146	调质-80KSI	XYGN4972-2022-01	3050615M	8250	0	8250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	462.79	f			M003147	调质-80KSI	XYGN4972-2022-01	3050615M	8020	0	8020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	469.71	f			M003149	调质-80KSI	XYGN4972-2022-01	3050615M	8140	0	8140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	463.37	f			M003150	调质-80KSI	XYGN4972-2022-01	3050615M	8030	0	8030	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	462.79	f			M003151	调质-80KSI	XYGN4972-2022-01	3050615M	8020	0	8020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	3.32	f			M003297	调质-80KSI	XYGN4972-2022-01	3051620M	85	0	85	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	3.91	f			M003298	调质-80KSI	XYGN4972-2022-01	3051620M	100	0	100	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	1.56	f			M003299	调质-80KSI	XYGN4972-2022-01	3051620M	40	0	40	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	6.45	f			M003300	调质-80KSI	XYGN4972-2022-01	3051620M	165	0	165	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	5.47	f			M003301	调质-80KSI	XYGN4972-2022-01	3051620M	140	0	140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	3.91	f			M003302	调质-80KSI	XYGN4972-2022-01	3051620M	100	0	100	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	6.45	f			M003303	调质-80KSI	XYGN4972-2022-01	3051620M	165	0	165	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	3.32	f			M003304	调质-80KSI	XYGN4972-2022-01	3051620M	85	0	85	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	0.78	f			M003305	调质-80KSI	XYGN4972-2022-01	3051620M	20	0	20	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	239.45	f			M003398	调质-80KSI	XYGN4972-2022-01	3051620M	6130	0	6130	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	253.51	f			M003399	调质-80KSI	XYGN4972-2022-01	3051620M	6490	0	6490	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	96.48	f			M003400	调质-80KSI	XYGN4972-2022-01	3051620M	2470	0	2470	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	1.76	f			M003401	调质-80KSI	XYGN4972-2022-01	3051620M	45	0	45	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	251.56	f			M003402	调质-80KSI	XYGN4972-2022-01	3051620M	6440	0	6440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	259.37	f			M003403	调质-80KSI	XYGN4972-2022-01	3051620M	6640	0	6640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	256.24	f			M003404	调质-80KSI	XYGN4972-2022-01	3051620M	6560	0	6560	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	242.18	f			M003405	调质-80KSI	XYGN4972-2022-01	3051620M	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	4.69	f			M003406	调质-80KSI	XYGN4972-2022-01	3051620M	120	0	120	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	4.88	f			M003408	调质-80KSI	XYGN4972-2022-01	3051620M	125	0	125	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	2.34	f			M003409	调质-80KSI	XYGN4972-2022-01	3051620M	60	0	60	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	7.03	f			M003410	调质-80KSI	XYGN4972-2022-01	3051620M	180	0	180	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	0.59	f			M003411	调质-80KSI	XYGN4972-2022-01	3051620M	15	0	15	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	0.66	f			M003412	调质-80KSI	XYGN4972-2022-01	3051620M	17	0	17	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	106*18	0	6.64	f			M003413	调质-80KSI	XYGN4972-2022-01	3051620M	170	0	170	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	255.04	f			M003985	调质-80KSI	XYGN4972-2022-01	3052127M	6340	0	6340	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	251.42	f			M003986	调质-80KSI	XYGN4972-2022-01	3052127M	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	256.65	f			M003987	调质-80KSI	XYGN4972-2022-01	3052127M	6380	0	6380	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	256.65	f			M003988	调质-80KSI	XYGN4972-2022-01	3052127M	6380	0	6380	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	255.44	f			M003989	调质-80KSI	XYGN4972-2022-01	3052127M	6350	0	6350	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	254.63	f			M003990	调质-80KSI	XYGN4972-2022-01	3052127M	6330	0	6330	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	249.41	f			M003991	调质-80KSI	XYGN4972-2022-01	3052127M	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	251.42	f			M003992	调质-80KSI	XYGN4972-2022-01	3052127M	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	257.05	f			M003993	调质-80KSI	XYGN4972-2022-01	3052127M	6390	0	6390	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	253.03	f			M003994	调质-80KSI	XYGN4972-2022-01	3052127M	6290	0	6290	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	18.1	f			M003995	调质-80KSI	XYGN4972-2022-01	3052127M	450	0	450	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	249.41	f			M003996	调质-80KSI	XYGN4972-2022-01	3052127M	6200	0	6200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	259.86	f			M004111	调质-80KSI	XYGN4972-2022-01	3052308M	6460	0	6460	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	258.25	f			M004112	调质-80KSI	XYGN4972-2022-01	3052308M	6420	0	6420	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	252.22	f			M004113	调质-80KSI	XYGN4972-2022-01	3052308M	6270	0	6270	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	256.44	f			M004114	调质-80KSI	XYGN4972-2022-01	3052308M	6375	0	6375	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	251.42	f			M004115	调质-80KSI	XYGN4972-2022-01	3052308M	6250	0	6250	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	254.43	f			M004116	调质-80KSI	XYGN4972-2022-01	3052308M	6325	0	6325	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	249.81	f			M004117	调质-80KSI	XYGN4972-2022-01	3052308M	6210	0	6210	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	248.6	f			M004118	调质-80KSI	XYGN4972-2022-01	3052308M	6180	0	6180	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	252.82	f			M004119	调质-80KSI	XYGN4972-2022-01	3052308M	6285	0	6285	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	248.8	f			M004120	调质-80KSI	XYGN4972-2022-01	3052308M	6185	0	6185	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	252.22	f			M004121	调质-80KSI	XYGN4972-2022-01	3052308M	6270	0	6270	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	252.62	f			M004122	调质-80KSI	XYGN4972-2022-01	3052308M	6280	0	6280	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	254.23	f			M004123	调质-80KSI	XYGN4972-2022-01	3052308M	6320	0	6320	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	258.25	f			M004124	调质-80KSI	XYGN4972-2022-01	3052308M	6420	0	6420	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	253.83	f			M004125	调质-80KSI	XYGN4972-2022-01	3052308M	6310	0	6310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	251.01	f			M004126	调质-80KSI	XYGN4972-2022-01	3052308M	6240	0	6240	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	253.83	f			M004127	调质-80KSI	XYGN4972-2022-01	3052308M	6310	0	6310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	263.28	f			M004130	调质-80KSI	XYGN4972-2022-01	3052308M	6545	0	6545	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	252.82	f			M004131	调质-80KSI	XYGN4972-2022-01	3052308M	6285	0	6285	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	19.11	f			M004133	调质-80KSI	XYGN4972-2022-01	3052308M	475	0	475	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	8.25	f			M004134	调质-80KSI	XYGN4972-2022-01	3052308M	205	0	205	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	17.38	f			M004135	调质-80KSI	XYGN4972-2022-01	3052308M	432	0	432	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*22.5	0	115.25	f			M004136	调质-80KSI	XYGN4972-2022-01	3052308M	2865	0	2865	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*20	0	20.34	f			M000323	调质-80KSI	XYGN4018.1-2021-02	2050706M	550	0	550	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*20	0	2.22	f			M000334	调质-80KSI	XYGN4018.1-2021-02	2050706M	60	0	60	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*20	0	1.66	f			M000339	调质-80KSI	XYGN4018.1-2021-02	2050706M	45	0	45	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*15	0	188.65	f			M000346	调质-80KSI	XYGN4018.1-2021-02	2050706M	6800	0	6800	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*15	0	57.43	f			M000347	调质-80KSI	XYGN4018.1-2021-02	2050706M	2070	0	2070	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*15	0	195.86	f			M000349	调质-80KSI	XYGN4018.1-2021-02	2050706M	7060	0	7060	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*15	0	21.16	f			M000351	调质-80KSI	XYGN4018.1-2021-02	2050706M	715	0	715	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*15	0	210.84	f			M000354	调质-80KSI	XYGN4018.1-2021-02	2050706M	7600	0	7600	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	107.12	f			Z23010216	调质-80KSI	XTG-JT-028-2019	119V-1547	3620	0	3620	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	95*15	0	125.77	f			M000115	调质-80KSI	XTG-JT-028-2019	119V-1547	4250	0	4250	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*15	0	91.83	f			M000357	调质-80KSI	XYGN4018.1-2021-02	2050706M	3310	0	3310	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	116*22	0	9.69	f			M000367	调质-80KSI	XYGN4018.1-2021-02	2050997M	190	0	190	0	0	0	湖北新冶钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*28	0	43.35	f			M000423	调质-80KSI	XYGN4018.1-2021-02	2051078M	430	0	430	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	80*15	0	1.08	f			M000429	调质-80KSI	XYGN4018.1-2021-02	2050705M	45	0	45	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	80*15	0	29.09	f			M000432	调质-80KSI	XYGN4018.1-2021-02	2050705M	1210	0	1210	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	80*15	0	4.21	f			M000441	调质-80KSI	XYGN4018.1-2021-02	2050705M	175	0	175	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	41.61	f			M002783	调质-80KSI	XYGN4972-2022-01	2055669M	540	0	540	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	604.17	f			M002784	调质-80KSI	XYGN4972-2022-01	2055669M	7840	0	7840	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	16.57	f			M002785	调质-80KSI	XYGN4972-2022-01	2055585A	215	0	215	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	16.18	f			M002786	调质-80KSI	XYGN4972-2022-01	2055585A	210	0	210	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	18.5	f			M002787	调质-80KSI	XYGN4972-2022-01	2055585A	240	0	240	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	20.42	f			M002788	调质-80KSI	XYGN4972-2022-01	2055669M	265	0	265	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	150*25	0	8.09	f			M002789	调质-80KSI	XYGN4972-2022-01	2055669M	105	0	105	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	122*20	0	131.8	f			M000461	调质-80KSI	XYGN4018.1-2021-02	2050997M	2620	0	2620	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	155*35	0	55.93	f			M000481	调质-80KSI	BMS S210 REV AA	418V1-1069	540	0	540	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	155*35	0	19.68	f			M000483	调质-80KSI	BMS S210 REV AA	418V1-1069	190	0	190	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	68.61	f			M000551	调质-80KSI	XYGN4018.1-2021-02	2050688M	1120	0	1120	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	23.28	f			M000566	调质-80KSI	XYGN4018.1-2021-02	2050688M	380	0	380	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	1.84	f			M000567	调质-80KSI	XYGN4018.1-2021-02	2050688M	30	0	30	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	475.95	f			M000569	调质-80KSI	XYGN4018.1-2021-02	2050688M	7770	0	7770	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	479.02	f			M000571	调质-80KSI	XYGN4018.1-2021-02	2050688M	7820	0	7820	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	447.16	f			M002764	调质-80KSI	XYGN4972-2022-01	2055653M	7300	0	7300	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	392.65	f			M002765	调质-80KSI	XYGN4972-2022-01	2055653M	6410	0	6410	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	436.14	f			M002766	调质-80KSI	XYGN4972-2022-01	2055653M	7120	0	7120	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	477.18	f			M002767	调质-80KSI	XYGN4972-2022-01	2055653M	7790	0	7790	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	477.79	f			M002768	调质-80KSI	XYGN4972-2022-01	2055653M	7800	0	7800	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	499.23	f			M002769	调质-80KSI	XYGN4972-2022-01	2055653M	8150	0	8150	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	492.49	f			M002770	调质-80KSI	XYGN4972-2022-01	2055653M	8040	0	8040	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	486.37	f			M002771	调质-80KSI	XYGN4972-2022-01	2055653M	7940	0	7940	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	437.36	f			M002772	调质-80KSI	XYGN4972-2022-01	2055653M	7140	0	7140	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	247.47	f			M002773	调质-80KSI	XYGN4972-2022-01	2055585A	4040	0	4040	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	247.47	f			M002774	调质-80KSI	XYGN4972-2022-01	2055585A	4040	0	4040	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	263.4	f			M002776	调质-80KSI	XYGN4972-2022-01	2055585A	4300	0	4300	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	156*18	0	21.44	f			M002778	调质-80KSI	XYGN4972-2022-01	2055585A	350	0	350	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	7.48	f			M000573	调质-80KSI	XYGN4018.1-2021-02	2051081M	108	0	108	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	8.31	f			M001929	调质-80KSI	XYGN4972-2022-01	2052672M	120	0	120	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	36.01	f			M001934	调质-80KSI	XYGN4972-2022-01	2052672M	520	0	520	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	8.66	f			M001935	调质-80KSI	XYGN4972-2022-01	2052672M	125	0	125	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	174*18	0	1.38	f			M001936	调质-80KSI	XYGN4972-2022-01	2052672M	20	0	20	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	6.63	f			M002384	调质-80KSI	XYGN4972-2022-01	2055048M	145	0	145	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	26.06	f			M002386	调质-80KSI	XYGN4972-2022-01	2055048M	570	0	570	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	13.72	f			M002389	调质-80KSI	XYGN4972-2022-01	2055048M	300	0	300	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	382.67	f			M002391	调质-80KSI	XYGN4972-2022-01	2055048M	8370	0	8370	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	17.37	f			M002392	调质-80KSI	XYGN4972-2022-01	2055048M	380	0	380	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	384.04	f			M002393	调质-80KSI	XYGN4972-2022-01	2055048M	8400	0	8400	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	398.68	f			M002394	调质-80KSI	XYGN4972-2022-01	2055048M	8720	0	8720	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	380.39	f			M002395	调质-80KSI	XYGN4972-2022-01	2055048M	8320	0	8320	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	4.11	f			M002396	调质-80KSI	XYGN4972-2022-01	2055048M	90	0	90	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	380.84	f			M002397	调质-80KSI	XYGN4972-2022-01	2055048M	8330	0	8330	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	338.33	f			M002398	调质-80KSI	XYGN4972-2022-01	2055048M	7400	0	7400	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	12.34	f			M002399	调质-80KSI	XYGN4972-2022-01	2055048M	270	0	270	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	383.13	f			M002400	调质-80KSI	XYGN4972-2022-01	2055048M	8380	0	8380	0	0	0	大冶特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	1.87	f			M001464	调质-80KSI	XTG-JY-C-010-2020	20M1499V	70	0	70	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	176.21	f			M001463	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6600	0	6600	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	178.08	f			M001460	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6670	0	6670	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	167.4	f			M001458	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6270	0	6270	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	1.6	f			M001470	调质-80KSI	XTG-JY-C-010-2020	20M1499V	60	0	60	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	1.74	f			M001468	调质-80KSI	XTG-JY-C-010-2020	20M1499V	65	0	65	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	95.85	f			M001469	调质-80KSI	XTG-JY-C-010-2020	20M1499V	3590	0	3590	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	181.02	f			M001467	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6780	0	6780	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	4.67	f			M001466	调质-80KSI	XTG-JY-C-010-2020	20M1499V	175	0	175	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	169.27	f			M001465	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6340	0	6340	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	172.47	f			M001483	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6460	0	6460	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	179.95	f			M001484	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6740	0	6740	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	180.75	f			M001487	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6770	0	6770	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	3.34	f			M001486	调质-80KSI	XTG-JY-C-010-2020	20M1499V	125	0	125	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	162.06	f			M001485	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6070	0	6070	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	171.41	f			M001474	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6420	0	6420	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	170.6	f			M001471	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6390	0	6390	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	181.28	f			M001475	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6790	0	6790	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	180.75	f			M001472	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6770	0	6770	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	181.02	f			M001473	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6780	0	6780	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	178.61	f			M001476	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6690	0	6690	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	173.01	f			M001478	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6480	0	6480	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	177.55	f			M001477	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6650	0	6650	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	160.19	f			M001479	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6000	0	6000	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	165.53	f			M001481	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6200	0	6200	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	162.86	f			M001482	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6100	0	6100	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	160.19	f			M001480	调质-80KSI	XTG-JY-C-010-2020	20M1499V	6000	0	6000	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	25.36	f			M001452	调质-80KSI	XTG-JY-C-010-2020	20M1499V	950	0	950	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	35.51	f			M001453	调质-80KSI	XTG-JY-C-010-2020	20M1499V	1330	0	1330	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	154.85	f			M001454	调质-80KSI	XTG-JY-C-010-2020	20M1499V	5800	0	5800	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	127*9.19	0	152.98	f			M001456	调质-80KSI	XTG-JY-C-010-2020	20M1499V	5730	0	5730	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.42	f			M003420	调质-80KSI	XYGN4972-2022-01	3072281A	9310	0	9310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.42	f			M003421	调质-80KSI	XYGN4972-2022-01	3072281A	9310	0	9310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	228.92	f			M003422	调质-80KSI	XYGN4972-2022-01	3072281A	4850	0	4850	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.9	f			M003423	调质-80KSI	XYGN4972-2022-01	3072281A	9320	0	9320	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.9	f			M003424	调质-80KSI	XYGN4972-2022-01	3072281A	9320	0	9320	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.42	f			M003425	调质-80KSI	XYGN4972-2022-01	3072281A	9310	0	9310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	441.31	f			M003426	调质-80KSI	XYGN4972-2022-01	3072281A	9350	0	9350	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.42	f			M003427	调质-80KSI	XYGN4972-2022-01	3072281A	9310	0	9310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.42	f			M003428	调质-80KSI	XYGN4972-2022-01	3072281A	9310	0	9310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.42	f			M003429	调质-80KSI	XYGN4972-2022-01	3072281A	9310	0	9310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	177.8*11.51	0	439.42	f			M003430	调质-80KSI	XYGN4972-2022-01	3072281A	9310	0	9310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	90*13	0	60.48	f			Z23010217	调质-80KSI	XTG-JY-C-041-2021/FS-T-M-003	2042973V	2450	0	2450	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	108*30	0	7.5	f			Z23010218	调质-80KSI	XTG-JY-C-041-2021/FS-T-M-003	121V-2083	130	0	130	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	195*13	0	200.42	f			Z23010561				3435	0	3435	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	152*26	0	233.47	f			L672	调质-80KSI		21D3290V	2890	0	2890	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	178*10	0	21.54	f			Z230510-23				520	0	520	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	114*20	0	22.95	f			Z230510-24				495	0	495	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	102*22	0	25.82	f			Z230510-25				595	0	595	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	114*20	0	23.64	f			Z230510-27				510	0	510	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	88*15	0	15.12	f			Z230510-28				560	0	560	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	114*20	0	22.25	f			Z230510-32				480	0	480	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	121*18	0	18.29	f			Z230510-34				400	0	400	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	114*20	0	19.7	f			Z230510-35				425	0	425	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	310	0	3753.29	f			M004332	调质110KSI	XYGN5189.3-2023-01	3060346A	6330	0	6330	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	310	0	3735.5	f			M004333	调质110KSI	XYGN5189.3-2023-01	3060346A	6300	0	6300	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	310	0	3913.38	f			M004334	调质110KSI	XYGN5189.3-2023-01	3060346A	6600	0	6600	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	310	0	3735.5	f			M004335	调质110KSI	XYGN5189.3-2023-01	3060346A	6300	0	6300	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	280	0	2795.95	f			M004328	调质110KSI	XYGN5189.3-2023-01	3060346A	5780	0	5780	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	280	0	3773.08	f			M004329	调质110KSI	XYGN5189.3-2023-01	3060346A	7800	0	7800	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	280	0	3821.45	f			M004330	调质110KSI	XYGN5189.3-2023-01	3060346A	7900	0	7900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	280	0	3758.57	f			M004331	调质110KSI	XYGN5189.3-2023-01	3060346A	7770	0	7770	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	250	0	2907.61	f			M004258	调质110KSI	XYGN5189.3-2023-01	3017455Z	7540	0	7540	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	250	0	2753.36	f			M004259	调质110KSI	XYGN5189.3-2023-01	3017455Z	7140	0	7140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	250	0	1596.49	f			M004260	调质110KSI	XYGN5189.3-2023-01	3017455Z	4140	0	4140	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	250	0	2552.84	f			M004261	调质110KSI	XYGN5189.3-2023-01	3017455Z	6620	0	6620	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	2090.4	f			M002136	调质110KSI	XYGN1992.6-2022-01	2018630Z	7000	0	7000	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	913.8	f			M002137	调质110KSI	XYGN1992.6-2022-01	2018630Z	3060	0	3060	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	2068	f			M002138	调质110KSI	XYGN1992.6-2022-01	2018630Z	6925	0	6925	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	1691.73	f			M002050	调质110KSI	XYGN1992.6-2022-01	2018630Z	5665	0	5665	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	41.81	f			M002051	调质110KSI	XYGN1992.6-2022-01	2018630Z	140	0	140	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	31.36	f			M002052	调质110KSI	XYGN1992.6-2022-01	2018630Z	105	0	105	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	47.78	f			 M001950	调质110KSI	XYGN1992.6-2022-01	2018630Z	160	0	160	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	2886.24	f			M003950	调质110KSI	XYGN5189.2-2022-01	3017454E	9665	0	9665	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	2886.24	f			M003951	调质110KSI	XYGN5189.2-2022-01	3017454E	9665	0	9665	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	2875.79	f			M003952	调质110KSI	XYGN5189.2-2022-01	3017454E	9630	0	9630	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	545	f			M003953	调质110KSI	XYGN5189.2-2022-01	3017454E	1825	0	1825	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	2883.25	f			M004064	调质110KSI	XYGN5189.2-2022-01	3017454E	9655	0	9655	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	220	0	2880.27	f			M004065	调质110KSI	XYGN5189.2-2022-01	3017454E	9645	0	9645	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	190	0	1940.04	f			M004093	调质110KSI	XYGN5189.2-2022-01	3017454Z	8710	0	8710	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	190	0	2142.73	f			M004094	调质110KSI	XYGN5189.2-2022-01	3017454Z	9620	0	9620	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	190	0	2082.59	f			M004096	调质110KSI	XYGN5189.2-2022-01	3017454Z	9350	0	9350	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	70.97	f			M002607	调质	XYGN5189.2-2022-01	2032359Z	355	0	355	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	66.97	f			M003856	调质110KSI	XYGN1992.6-2022-01	2018630Z	335	0	335	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	227.3	f			M003857	调质110KSI	XYGN1992.6-2022-01	2018630Z	1137	0	1137	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	229.89	f			M003858	调质110KSI	XYGN1992.6-2022-01	2018630Z	1150	0	1150	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	229.49	f			M003860	调质110KSI	XYGN1992.6-2022-01	2018630Z	1148	0	1148	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	1891.13	f			M003939	调质110KSI	XYGN5189.2-2022-01	3017454Z	9460	0	9460	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	170	0	1720.72	f			M003791	调质	XYGN5189.2-2022-01	3017454Z	9650	0	9650	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	170	0	1717.15	f			M003792	调质	XYGN5189.2-2022-01	3017454Z	9630	0	9630	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	170	0	1720.72	f			M003793	调质	XYGN5189.2-2022-01	3017454Z	9650	0	9650	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	170	0	25.86	f			M003794	调质	XYGN5189.2-2022-01	3017454Z	145	0	145	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	170	0	1720.72	f			M003795	调质	XYGN5189.2-2022-01	3017454Z	9650	0	9650	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1506.86	f			M004066	调质	XYGN5189.2-2022-01	3017454E	9540	0	9540	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1525.03	f			M004067	调质	XYGN5189.2-2022-01	3017454E	9655	0	9655	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1528.19	f			M004068	调质	XYGN5189.2-2022-01	3017454E	9675	0	9675	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1522.66	f			M004069	调质	XYGN5189.2-2022-01	3017454E	9640	0	9640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1523.45	f			M004070	调质	XYGN5189.2-2022-01	3017454E	9645	0	9645	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1523.45	f			M004071	调质	XYGN5189.2-2022-01	3017454E	9645	0	9645	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	916.12	f			M004097	调质	XYGN5189.2-2022-01	3017454E	5800	0	5800	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1525.82	f			M004098	调质	XYGN5189.2-2022-01	3017454E	9660	0	9660	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_111	-	20	0	f			锯口费	-			0	0	0	0	0	0			否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1524.24	f			M004100	调质	XYGN5189.2-2022-01	3017454E	9650	0	9650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	160	0	1525.03	f			M004101	调质	XYGN5189.2-2022-01	3017454E	9655	0	9655	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1225.82	f			M005202	调质110KSI	XYGN5189.2-2022-01	3018946Z	8830	0	8830	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1366.04	f			M005203	调质110KSI	XYGN5189.2-2022-01	3018946Z	9840	0	9840	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1341.05	f			M005204	调质110KSI	XYGN5189.2-2022-01	3018946Z	9660	0	9660	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1342.44	f			M005205	调质110KSI	XYGN5189.2-2022-01	3018946Z	9670	0	9670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1341.05	f			M005206	调质110KSI	XYGN5189.2-2022-01	3018946Z	9660	0	9660	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1335.5	f			M005207	调质110KSI	XYGN5189.2-2022-01	3018946Z	9620	0	9620	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1341.74	f			M005208	调质110KSI	XYGN5189.2-2022-01	3018946Z	9665	0	9665	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1341.05	f			M005209	调质110KSI	XYGN5189.2-2022-01	3018946Z	9660	0	9660	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1342.44	f			M005210	调质110KSI	XYGN5189.2-2022-01	3018946Z	9670	0	9670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1341.74	f			M005211	调质110KSI	XYGN5189.2-2022-01	3018946Z	9665	0	9665	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1342.44	f			M005212	调质110KSI	XYGN5189.2-2022-01	3018946Z	9670	0	9670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1341.05	f			M005213	调质110KSI	XYGN5189.2-2022-01	3018946Z	9660	0	9660	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1341.74	f			M005214	调质110KSI	XYGN5189.2-2022-01	3018946Z	9665	0	9665	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	1341.74	f			M005215	调质110KSI	XYGN5189.2-2022-01	3018946Z	9665	0	9665	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1141.6	f			M001270	调质	XYGN1992.6-2022-01	2016324Z	9440	0	9440	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	13.3	f			M001619	调质-110KSI	XYGN1992.6-2022-01	2018629Z	110	0	110	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	35.67	f	换料		M003742	调质-110KSI	JX-2021-01	F22306309XA	295	0	295	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1168.81	f			M005188	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9665	0	9665	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1166.99	f			M005189	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9650	0	9650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1166.99	f			M005190	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9650	0	9650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	691.73	f			M005192	调质-110KSI	XYGN5189.2-2022-01	3018947Z	5720	0	5720	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1164.58	f			M005193	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9630	0	9630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1165.78	f			M005194	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9640	0	9640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1165.18	f			M005195	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9635	0	9635	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1164.58	f			M005196	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9630	0	9630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1165.18	f			M005197	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9635	0	9635	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1164.58	f			M005198	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9630	0	9630	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1169.41	f			M005199	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9670	0	9670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	842.9	f			M005200	调质-110KSI	XYGN5189.2-2022-01	3018947Z	6970	0	6970	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1169.41	f			M005201	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9670	0	9670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1165.78	f			M005412	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9640	0	9640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1129.5	f			M005413	调质-110KSI	XYGN5189.2-2022-01	3018947Z	9340	0	9340	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	5.74	f			M000860	调质	XYGN1992.6-2022-01	2016324Z	55	0	55	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	5.21	f			Z23010519	调质	XYGN1992.6-2022-01	2016324Z	50	0	50	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	1005.19	f			M004103	调质	XYGN5189.2-2022-01	3017454Z	9640	0	9640	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	1006.23	f			M004104	调质	XYGN5189.2-2022-01	3017454Z	9650	0	9650	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	968.17	f			M004105	调质	XYGN5189.2-2022-01	3017454Z	9285	0	9285	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	915.52	f			M004106	调质	XYGN5189.2-2022-01	3017454Z	8780	0	8780	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	1007.28	f			M004107	调质	XYGN5189.2-2022-01	3017454Z	9660	0	9660	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	419.7	f			M004108	调质	XYGN5189.2-2022-01	3017454Z	4025	0	4025	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	1007.28	f			M004109	调质	XYGN5189.2-2022-01	3017454Z	9660	0	9660	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	1007.8	f			M004110	调质	XYGN5189.2-2022-01	3017454Z	9665	0	9665	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	861.38	f			M002116	调质110KSI	XYGN5189.2-2022-01	2031049Z	9695	0	9695	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	116.39	f			M002119	调质110KSI	XYGN5189.2-2022-01	2031049Z	1310	0	1310	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	719.69	f			M001303	调质	XYGN1992.6-2022-01	2016897Z	9640	0	9640	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	11.2	f			M001304	调质	XYGN1992.6-2022-01	2016897Z	150	0	150	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	663.33	f			M001305	调质	XYGN1992.6-2022-01	2016897Z	8885	0	8885	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	720.44	f			M001307	调质	XYGN1992.6-2022-01	2016897Z	9650	0	9650	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	719.69	f			M001308	调质	XYGN1992.6-2022-01	2016897Z	9640	0	9640	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	10.45	f			M001309	调质	XYGN1992.6-2022-01	2016897Z	140	0	140	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	3.96	f			M002122	调质110KSI	XYGN5189.2-2022-01	2031049Z	53	0	53	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	1.87	f			M002124	调质110KSI	XYGN5189.2-2022-01	2031049Z	25	0	25	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	4.85	f			M002129	调质110KSI	XYGN5189.2-2022-01	2031049Z	65	0	65	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	456.9	f			M002134	调质110KSI	XYGN5189.2-2022-01	2031049Z	6120	0	6120	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	90	0	2.75	f			M002039	调质110KSI	XYGN1992.6-2022-01	2018629E	55	0	55	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	90	0	1	f			M002043	调质110KSI	XYGN1992.6-2022-01	2018629E	20	0	20	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	90	0	3	f			M003114	调质110KSI	XYGN1992.6-2022-01	2018629E	60	0	60	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	23.99	f			M000536	热轧	JX2534-2010-01	E12200905XA	120	0	120	0	0	0	江阴兴澄	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	1959.1	f			M000537	热轧	JX2534-2010-01	E12200905XA	9800	0	9800	0	0	0	江阴兴澄	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	130	0	187.69	f			M000541	热轧	JX2534-2010-01	E12200905XA	1800	0	1800	0	0	0	江阴兴澄	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	1185.13	f			M000544	热轧	JX2534-2016-01	E12203975XX	9800	0	9800	0	0	0	江阴兴澄	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	981.97	f			M000547	热轧	JX2534-2016-01	E12203975XX	8120	0	8120	0	0	0	江阴兴澄	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	18.74	f			Z23010538	热轧			155	0	155	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	262	0	471.7	f	已卖		M003766	固溶时效		3KH80092	1103	0	1103	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	206	0	265.17	f	已卖		M003765			3KH80092	1003	0	1003	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	168	0	225.95	f			M003264	固溶时效	API STANARD 6ACRA-2015(2019)	3KD10274	1285	0	1285	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	168	0	513.79	f			M003763	固溶时效		3KD70559	2922	0	2922	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	168	0	119.57	f			M003764	固溶时效		3KD70560	680	0	680	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	158	0	681.98	f			M004323	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD30255	4385	0	4385	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	158	0	365.49	f			M004324	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD30256	2350	0	2350	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	148	0	70.96	f			M003262	固溶时效	API STANARD 6ACRA-2015(2019)	3KD30176	520	0	520	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	148	0	556.49	f			M003263	固溶时效	API STANARD 6ACRA-2015(2019)	3KD30181	4078	0	4078	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	146.5	0	141.73	f			M004325	固溶时效	API STANARD 6ACRA-2015(2019)	3KD10349	1060	0	1060	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	146.5	0	501.41	f			M004326	固溶时效	API STANARD 6ACRA-2015(2019)	3KD10347	3750	0	3750	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	146.5	0	171.15	f			M004327	固溶时效	API STANARD 6ACRA-2015(2019)	3KD30254	1280	0	1280	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	19.34	f			M003254	固溶时效	API STANARD 6ACRA-2015(2019)	3KD30163	163	0	163	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	37.97	f			M003258	固溶时效	API STANARD 6ACRA-2015(2019)	3KD30164	320	0	320	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	186.86	f			M003931	固溶时效	API STANARD 6ACRA-2015(2019)	3KD70758	1575	0	1575	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
	130	0	1277.34	f	 		M000543	热轧	JX2534-2010-01	E12200905XA	12250	0	12250	0	0	0	江阴兴澄	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
	130	0	1277.34	f	 		M000542	热轧	JX2534-2010-01	E12200905XA	12250	0	12250	0	0	0	江阴兴澄	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_109	138	0	191.02	f			M003932	固溶时效	API STANARD 6ACRA-2015(2019)	3KD70758	1610	0	1610	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	184.85	f			M003933	固溶时效	API STANARD 6ACRA-2015(2019)	3KD70758	1558	0	1558	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	169.31	f	1010+414		M003935	固溶时效	API STANARD 6ACRA-2015(2019)	3KD70758	1427	0	1427	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	396.86	f			M005414	固溶时效	API STANARD 6ACRA-2015(2019)	3KD71035	3345	0	3345	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	396.86	f			M005415	固溶时效	API STANARD 6ACRA-2015(2019)	3KD71052	3345	0	3345	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	135.25	f			M005416	固溶时效	API STANARD 6ACRA-2015(2019)	3KD71053	1140	0	1140	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	130	0	71.6	f			M004063	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD10344	680	0	680	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	152	0	277.8	f			M003756	固溶时效	API STANARD 6ACRA-2015(2019)	3KD70551	1930	0	1930	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	152	0	269.88	f			M004161	固溶时效	API STANARD 6ACRA-2015(2019)	3KD10336	1875	0	1875	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	152	0	380.72	f			M004322	固溶时效	API STANARD 6ACRA-2015(2019)	3KD10340	2645	0	2645	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	152	0	467.8	f			M004162	固溶时效	API STANARD 6ACRA-2015(2019)	 3KD10338	3250	0	3250	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	17.81	f			M003089	固溶时效	API STANARD 6ACRA-2015(2019)	3KD80335	353	0	353	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	5.8	f			M003090	固溶时效	API STANARD 6ACRA-2015(2019)	3KD80335	115	0	115	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	2.17	f			M003255	固溶时效	API STANARD 6ACRA-2015(2019)	3KD30172	43	0	43	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	6.01	f			M003294	固溶时效	API STANARD 6ACRA-2015(2019)	3KD30175	119	0	119	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	6.56	f			M003296	固溶时效	API STANARD 6ACRA-2015(2019)	3KD30175	130	0	130	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	150	0	32.52	f	1110处有切口		M000881	固溶时效120KSI	ASTM-B637-2016	1D70645	232	0	232	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	145	0	120.51	f	有缺陷		M001729	固溶时效120KSI	XYGN5226-2022-01-006	2420188R	920	0	920	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	138	0	18.86	f			M001724	固溶时效120KSI	XYGN5226-2022-01-006	2420218R	159	0	159	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	130	0	558.55	f			M004302	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD10345	5305	0	5305	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	122	0	123.51	f			M003580	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70550	1332	0	1332	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	122	0	14.37	f			M003585	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70547	155	0	155	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	2.19	f	中间打了68孔		L801	固溶时效120KSI	YQ-JS-M-006B	L210045	29	0	29	0	0	0	重庆重材	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	100	0	18.25	f			M000882	固溶时效120KSI	ASTM-B637-2016	1D70643	293	0	293	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	100	0	9.03	f			M000883	固溶时效120KSI	ASTM-B637-2016	1D70643	145	0	145	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	231.43	f			M004312	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70740	3070	0	3070	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	338.09	f			M004313	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70744	4485	0	4485	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	300.78	f			M004314	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70744	3990	0	3990	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	310.58	f			M004315	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70740	4120	0	4120	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	296.63	f			M004316	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70747	3935	0	3935	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	318.87	f			M004317	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70747	4230	0	4230	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	283.44	f			M004318	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70748	3760	0	3760	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	271	f			M004319	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70748	3595	0	3595	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	323.39	f			M004320	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70745	4290	0	4290	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	110	0	284.19	f			M004321	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70745	3770	0	3770	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	100	0	260.41	f			M004296	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70746	4180	0	4180	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	100	0	297.79	f			M004297	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70746	4780	0	4780	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	100	0	300.91	f			M004298	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70742	4830	0	4830	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	100	0	280.35	f			M004299	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70742	4500	0	4500	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	100	0	286.58	f			M004300	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70741	4600	0	4600	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	100	0	167.59	f			M004301	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70741	2690	0	2690	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	163.25	f			M004303	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70558	3235	0	3235	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	163.25	f			M004304	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70558	3235	0	3235	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	204.12	f			M004305	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70558	4045	0	4045	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	285.62	f			M004306	固溶时效	API STANDARD 6ACRA-2015(2019)	3KH80094	5660	0	5660	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	244.75	f			M004307	固溶时效	API STANDARD 6ACRA-2015(2019)	3KH80094	4850	0	4850	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	202.86	f			M004308	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70557	4020	0	4020	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	203.97	f			M004309	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70557	4042	0	4042	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	163.25	f			M004310	固溶时效	API STANDARD 6ACRA-2015(2019)	3KD70557	3235	0	3235	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_114	65	0	12.43	f			Z230413-1	固溶	ASEM SB446-2015	272-0079	477	0	477	0	0	0	宝钢特种	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	80	0	39.87	f			M000885	固溶时效120KSI	ASTM-B637-2016	0D20001	1000	0	1000	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	65	0	103.71	f			M004023	固溶时效	ASTM B637-2016	3KHD70033	3940	0	3940	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	65	0	90.02	f			M004025	固溶时效	ASTM B637-2016	3KHD70033	3420	0	3420	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	65	0	76.33	f			M004026	固溶时效	ASTM B637-2016	3KHD70033	2900	0	2900	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	65	0	63.7	f			M004027	固溶时效	ASTM B637-2016	3KHD70033	2420	0	2420	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	65	0	102.26	f			M004028	固溶时效	ASTM B637-2016	3KHD70033	3885	0	3885	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	110.79	f			M004720	固溶时效	ASTM  B637-2016	3KD70234	4940	0	4940	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	105.86	f			M004721	固溶时效	ASTM  B637-2016	3KD70234	4720	0	4720	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	105.41	f			M004722	固溶时效	ASTM  B637-2016	3KD70234	4700	0	4700	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	109.67	f			M004723	固溶时效	ASTM  B637-2016	3KD70234	4890	0	4890	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	102.38	f			M004724	固溶时效	ASTM  B637-2016	3KD70234	4565	0	4565	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	102.72	f			M004725	固溶时效	ASTM  B637-2016	3KD70234	4580	0	4580	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	119.88	f			M004726	固溶时效	ASTM  B637-2016	3KD70311	5345	0	5345	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	111.36	f			M004727	固溶时效	ASTM  B637-2016	3KD70311	4965	0	4965	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	89.71	f			M004728	固溶时效	ASTM  B637-2016	3KD70311	4000	0	4000	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	60	0	101.94	f			M004729	固溶时效	ASTM  B637-2016	3KD70311	4545	0	4545	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	55	0	29.68	f			M000886	固溶时效120KSI	ASTM-B637-2016	0D70338	1575	0	1575	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	45	0	15.2	f			M000887	固溶时效120KSI	ASTM-B637-2016	0D70727	1205	0	1205	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	45	0	30.63	f			M000888	固溶时效120KSI	ASTM-B637-2016	0D70727	2428	0	2428	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	45	0	28.57	f			M000889	固溶时效120KSI	ASTM-B637-2016	0D70727	2265	0	2265	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	45	0	27.73	f			M000891	固溶时效120KSI	ASTM-B637-2016	0D70727	2198	0	2198	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	45	0	1.14	f			M000240	固溶时效120KSI	ASTM-B637-2016	0D70727	90	0	90	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	30	0	13.43	f			M000892	固溶时效120KSI	ASTM-B637-2016	1D70645	2396	0	2396	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	30	0	14.75	f			M000895	固溶时效120KSI	ASTM-B637-2016	1D70645	2630	0	2630	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	35	0	9.16	f			M000899	固溶时效120KSI	ASTM-B637-2016	1D70645	1200	0	1200	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	30	0	15.46	f			M000902	固溶时效120KSI	ASTM-B637-2016	1D70645	2758	0	2758	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	25	0	4.82	f			M000903	固溶时效120KSI	ASTM-B637-2016	7D70138	1238	0	1238	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	25	0	0.69	f			M000893	固溶时效120KSI	ASTM-B637-2016	7D70138	178	0	178	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	25	0	7.13	f			M000901	固溶时效120KSI	ASTM-B637-2016	7D70138	1830	0	1830	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	25	0	8.64	f			M000898	固溶时效120KSI	ASTM-B637-2016	7D70138	2220	0	2220	0	0	0	中航上大	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	90	0	7.92	f			Z23010207				157	0	157	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	73	0	6.64	f			Z23010208				200	0	200	0	0	0	取芯材	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_109	73	0	6.64	f			Z23010209				200	0	200	0	0	0	取芯材	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.47	f			M005046	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9945	0	9945	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.47	f			M005047	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9945	0	9945	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.11	f			M005050	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	0	9940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.11	f			M005051	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	0	9940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.11	f			M005052	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	0	9940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	697.82	f			M004979	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7700	0	7700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1076.76	f			M005226	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6220	0	6220	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1080.23	f			M005227	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6240	0	6240	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1090.61	f			M005228	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6300	0	6300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1101	f			M005229	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6360	0	6360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1068.11	f			M005230	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6170	0	6170	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1094.08	f			M005231	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6320	0	6320	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1061.18	f			M005232	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6130	0	6130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	0.01	f	 		M005048	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	1	0	0	0	0	江苏常宝	天津	是				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_102	219*39	0	1054.26	f			M005233	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6090	0	6090	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1047.33	f			M005234	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6050	0	6050	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*39	0	1059.45	f			M005235	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	6120	0	6120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	586.84	f			M002238	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	3405	0	3405	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	1163.33	f			M002240	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	6750	0	6750	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	1185.73	f			M002241	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	6880	0	6880	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	1099.56	f			M002242	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	6380	0	6380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	1101.29	f			M002243	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	6390	0	6390	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	1123.69	f			M002244	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	6520	0	6520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	1175.39	f			M002245	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	6820	0	6820	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	1177.98	f			M002246	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	6835	0	6835	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*35	0	1149.54	f			M002247	调质110KSI	API SPEC 5CT&FS-T-M-011	TX22-06530LG	6670	0	6670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1113.2	f			M002143	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7540	0	7540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1113.2	f			M002144	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7540	0	7540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1110.24	f			M002145	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7520	0	7520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1098.43	f			M002148	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7440	0	7440	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1096.95	f			M002149	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7430	0	7430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1105.81	f			M002150	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7490	0	7490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1037.9	f			M002151	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7030	0	7030	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1102.86	f			M002152	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7470	0	7470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1048.23	f			M002153	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7100	0	7100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1095.48	f			M002154	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7420	0	7420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1113.93	f			M002155	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7545	0	7545	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1104.34	f			M002156	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7480	0	7480	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1085.14	f			M002157	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7350	0	7350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1111.72	f			M002158	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7530	0	7530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1111.72	f			M002159	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7530	0	7530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1113.2	f			M002160	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7540	0	7540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1102.86	f			M002161	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7470	0	7470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1111.72	f			M002162	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7530	0	7530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1108.77	f			M002163	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7510	0	7510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1110.24	f			M002164	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7520	0	7520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	143.21	f			M002165	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	970	0	970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1088.1	f			M002166	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7370	0	7370	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1114.67	f			M002167	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7550	0	7550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1110.24	f			M002168	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7520	0	7520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1113.2	f			M002170	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7540	0	7540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*28	0	1096.95	f			M002172	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	7430	0	7430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*20	0	38.57	f			M002184	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	380	0	380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*20	0	373.51	f			M002185	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	3680	0	3680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*20	0	697.28	f			M002186	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*20	0	700.32	f			M002187	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6900	0	6900	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*20	0	668.86	f			M002191	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6590	0	6590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*20	0	701.34	f			M002301	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6910	0	6910	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	544.83	f			M002219	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	8250	0	8250	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	568.6	f			M002220	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	8610	0	8610	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	586.43	f			M002221	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	8880	0	8880	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	478.13	f			M002222	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	7240	0	7240	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	598.98	f			M002223	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	9070	0	9070	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	565.96	f			M002224	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	8570	0	8570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	568.6	f			M002225	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	8610	0	8610	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	583.79	f			M002226	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	8840	0	8840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	552.75	f			M002227	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	8370	0	8370	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	581.81	f			M002228	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	8810	0	8810	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	530.96	f			M002229	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	8040	0	8040	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	561.34	f			M002230	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	538.88	f			M002231	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	8160	0	8160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	591.05	f			M002232	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	8950	0	8950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	509.82	f			M002233	调质110KSI	API SPEC 5CT & FS-T-M-011C	21B-04608	7720	0	7720	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	587.75	f			M002234	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	8900	0	8900	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	558.69	f			M002235	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	8460	0	8460	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	532.94	f			M002236	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	8040	0	8040	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	584.45	f			M002237	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	8850	0	8850	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	526.33	f			L713	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	499.92	f			L715	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	7570	0	7570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	216*28	0	1133.24	f			M004453	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	8730	0	8730	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	216*28	0	1098.19	f			M004448	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	8460	0	8460	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	216*28	0	1142.33	f			M004449	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	8800	0	8800	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	216*28	0	1099.49	f			M004451	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	8470	0	8470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	216*28	0	1112.47	f			M004452	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03587LG	8570	0	8570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1086	f			M002209	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6880	0	6880	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1089.16	f			M002210	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6900	0	6900	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1101.78	f			M002211	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6980	0	6980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1059.16	f			M002212	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6710	0	6710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1095.47	f			M002213	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6940	0	6940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1056.01	f			M002214	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6690	0	6690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1046.54	f			M002215	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6630	0	6630	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1074.95	f			M002216	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6810	0	6810	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	812.92	f			M002217	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	5150	0	5150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	210*33	0	1067.06	f			M002218	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6760	0	6760	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	4.23	f			M001973	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	35	0	35	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	807.17	f			M001974	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6680	0	6680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	764.28	f			M001975	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6325	0	6325	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	580	f			B230110-4	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	4800	0	4800	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	55.58	f			B230110-5	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	460	0	460	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	118.42	f			B230110-6	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	980	0	980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	24.17	f			B230110-7	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	200	0	200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	17.52	f			B230110-8	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	145	0	145	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	810.8	f			B230110-9	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	6710	0	6710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	770.92	f			M003482	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX2206530LG	6380	0	6380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	793.88	f			M003483	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX2206530LG	6570	0	6570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	812	f			M003484	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX2206530LG	6720	0	6720	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	1103.21	f			M005217	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	9130	0	9130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	1093.55	f			M005218	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	9050	0	9050	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	1070.59	f			M005219	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	8860	0	8860	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	1064.55	f			M005220	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	8810	0	8810	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	1104.42	f			M005221	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	9140	0	9140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	1083.88	f			M005223	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	8970	0	8970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	537.87	f			M002248	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6550	0	6550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	547.73	f			M002249	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6670	0	6670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	509.95	f			M002250	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6210	0	6210	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	562.51	f			M002251	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6850	0	6850	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	552.24	f			M002252	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6725	0	6725	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	528.02	f			M002253	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	1000	0	1000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	559.22	f			M002254	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6780	0	6780	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	559.22	f			M002255	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	975	0	975	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	561.69	f			M002256	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6840	0	6840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	562.92	f			M002257	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6855	0	6855	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	562.51	f			M002258	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6850	0	6850	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	562.51	f			M002259	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6850	0	6850	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	525.55	f			M002260	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6400	0	6400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	559.22	f			M002262	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6810	0	6810	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	556.76	f			M002263	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6780	0	6780	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	560.45	f			M002264	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6825	0	6825	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*18	0	554.3	f			M002265	调质110KSI	API SPEC 5CT & FS-T-M-011C	22704942XG	6750	0	6750	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*35	0	54.85	f			B230110-159	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	410	0	410	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*35	0	14.72	f			B230110-160	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06529LG	110	0	110	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	730.99	f			M005163	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6535	0	6535	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	725.96	f			M005164	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6490	0	6490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	734.91	f			M005165	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6570	0	6570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	733.23	f			M005166	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6555	0	6555	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	734.35	f			M005167	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6565	0	6565	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	730.99	f			M005168	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6535	0	6535	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	691.84	f			M005169	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6185	0	6185	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	704.7	f			M005170	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6300	0	6300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	733.79	f			M005272	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6560	0	6560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	731.55	f			M005273	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6540	0	6540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	724.84	f			M005274	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6480	0	6480	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	730.43	f			M005275	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6530	0	6530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	728.19	f			M005276	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6510	0	6510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	190*28	0	737.14	f			M005277	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03586LG	6590	0	6590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	174*28	0	29.23	f			M002576	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	290	0	290	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	174*28	0	103.83	f			M002577	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	1030	0	1030	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	174*28	0	65.02	f			M002580	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	645	0	645	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	174*28	0	657.28	f			M002581	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	6520	0	6520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	174*28	0	13.41	f			M002584	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	133	0	133	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	174*28	0	65.02	f			M002586	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	645	0	645	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	174*28	0	10.08	f			M002588	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	100	0	100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	283.68	f			M002530	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	3465	0	3465	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	615.67	f			M002534	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	7520	0	7520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	623.45	f			M002535	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	7615	0	7615	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	627.95	f			M002538	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	7670	0	7670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	614.85	f			M002539	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	7510	0	7510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	627.54	f			M002540	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	7665	0	7665	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	627.95	f			M002541	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	7670	0	7670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	628.77	f			M002543	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	7680	0	7680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	186*20	0	622.63	f			M002545	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06533LG	7605	0	7605	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	184*20	0	53.42	f			M002176	调质-110KSI		TX22-03076LG	610	0	610	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	592.46	f			M005278	调质-110KSI		E12302999XW	6200	0	6200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	601.06	f			M005279	调质-110KSI		E12302999XW	6290	0	6290	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	598.19	f			M005280	调质-110KSI		E12302999XW	6260	0	6260	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	598.19	f			M005281	调质-110KSI		E12302999XW	6260	0	6260	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	597.23	f			M005282	调质-110KSI		E12302999XW	6250	0	6250	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	607.75	f			M005283	调质-110KSI		E12302999XW	6360	0	6360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	658.39	f			M005284	调质-110KSI		E12302999XW	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	607.75	f			M005285	调质-110KSI		E12302999XW	6360	0	6360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	658.39	f			M005286	调质-110KSI		E12302999XW	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	602.97	f			M005287	调质-110KSI		E12302999XW	6310	0	6310	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	619.21	f			M005288	调质-110KSI		E12302999XW	6480	0	6480	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	623.03	f			M005289	调质-110KSI		E12302999XW	6520	0	6520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	620.17	f			M005290	调质-110KSI		E12302999XW	6490	0	6490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	655.52	f			M005291	调质-110KSI		E12302999XW	6860	0	6860	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	658.39	f			M005292	调质-110KSI		E12302999XW	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	622.08	f			M005293	调质-110KSI		E12302999XW	6510	0	6510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	641.19	f			M005294	调质-110KSI		E12302999XW	6710	0	6710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	649.79	f			M005295	调质-110KSI		E12302999XW	6800	0	6800	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	89.29	f			M001059	调质-110KSI	API SPEC 5CT&	TX22-01720LG	775	0	775	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	82.95	f			B230110-150	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06534LG	720	0	720	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	885.98	f			M004484	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7690	0	7690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	891.16	f			M004485	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7735	0	7735	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	880.22	f			M004486	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7640	0	7640	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	881.94	f			M004487	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7655	0	7655	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	842.2	f			M004488	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7310	0	7310	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	884.82	f			M004489	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7680	0	7680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	849.11	f			M004490	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7370	0	7370	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	860.63	f			M004491	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7470	0	7470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	868.12	f			M004492	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7535	0	7535	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	888.28	f			M004493	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7710	0	7710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	885.98	f			M004494	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7690	0	7690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	891.16	f			M004495	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7735	0	7735	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	832.4	f			M004496	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7225	0	7225	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	880.22	f			M004497	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7640	0	7640	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	891.74	f			M004498	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7740	0	7740	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	887.13	f			M004499	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7700	0	7700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	841.62	f			M004500	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7305	0	7305	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	860.05	f			M004501	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7465	0	7465	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	884.82	f			M004502	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7680	0	7680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	888.28	f			M004503	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7710	0	7710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	887.13	f			M004504	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7700	0	7700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	890.59	f			M004505	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7730	0	7730	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	892.89	f			M004506	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7750	0	7750	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*32	0	887.13	f			M004507	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7700	0	7700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	503.45	f			M004510	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8350	0	8350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	495.61	f			M004511	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8220	0	8220	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	509.48	f			M004512	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8450	0	8450	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	508.28	f			M004513	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8430	0	8430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	511.89	f			M004514	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8490	0	8490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	510.69	f			M004515	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8470	0	8470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	513.1	f			M004516	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8510	0	8510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	513.7	f			M004517	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8520	0	8520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	513.1	f			M004518	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8510	0	8510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	491.39	f			M004519	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8150	0	8150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	510.69	f			M004520	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8470	0	8470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	499.23	f			M004521	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8280	0	8280	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	512.5	f			M004522	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	513.1	f			M004523	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8510	0	8510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	512.5	f			M004524	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	513.7	f			M004525	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8520	0	8520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	512.5	f			M004526	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	512.5	f			M004527	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	483.56	f			M004528	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8020	0	8020	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	511.89	f			M004529	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8490	0	8490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*15	0	492	f			M004530	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8160	0	8160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	888.08	f			M003587		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	8275	0	8275	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	843.54	f			M003588		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	7860	0	7860	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	879.49	f			M003589		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	8195	0	8195	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	851.59	f			M003590		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	7935	0	7935	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	877.34	f			M003591		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	8175	0	8175	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	891.83	f			M003592		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	8310	0	8310	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	892.91	f			M003593		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	8320	0	8320	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	889.69	f			M003594		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	8290	0	8290	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	836.56	f			M003595		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	7795	0	7795	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	875.73	f			M003596		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	8160	0	8160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	841.93	f			M003597		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	7845	0	7845	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*32	0	885.39	f			M003565		API SPEC 5CT&FS-T-M-011B-3	TZ23-03328LG	8250	0	8250	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	626.4	f			M003357	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7350	0	7350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	627.26	f			M003358	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7360	0	7360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	619.59	f			M003359	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7270	0	7270	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	92.9	f			M003360	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	1090	0	1090	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	622.14	f			M003361	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7300	0	7300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	644.3	f			M003362	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7560	0	7560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	657.08	f			M003363	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7710	0	7710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	634.07	f			M003364	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7440	0	7440	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	637.48	f			M003366	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7480	0	7480	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	628.96	f			M003367	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7380	0	7380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	617.88	f			M003368	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7250	0	7250	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*24	0	640.04	f			M003370	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22004749MG	7510	0	7510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	637.68	f			M005171	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7550	0	7550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	616.14	f			M005172	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7295	0	7295	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	650.35	f			M005173	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7700	0	7700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	645.28	f			M005174	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7640	0	7640	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	641.48	f			M005175	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7595	0	7595	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	633.03	f			M005176	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7495	0	7495	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	634.3	f			M005177	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7510	0	7510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	655.84	f			M005178	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7765	0	7765	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	638.94	f			M005179	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7565	0	7565	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	641.9	f			M005180	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7600	0	7600	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	651.19	f			M005181	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7710	0	7710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	589.53	f			M005182	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	6980	0	6980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	662.17	f			M005183	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7840	0	7840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	662.17	f			M005184	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7840	0	7840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	655.84	f			M005185	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7765	0	7765	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	664.7	f			M005186	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7870	0	7870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	162*25	0	662.17	f			M005187	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	7840	0	7840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	870.11	f			M003796	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8130	0	8130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.25	f			M003797	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8150	0	8150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.78	f			M003798	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8155	0	8155	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.25	f			M003799	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8150	0	8150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	867.97	f			M003800	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8110	0	8110	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.25	f			M003801	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8150	0	8150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	874.39	f			M003802	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8170	0	8170	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.78	f			M003803	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8155	0	8155	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.25	f			M003804	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8150	0	8150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	871.18	f			M003805	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8140	0	8140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	877.6	f			M003806	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8200	0	8200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	838	f			M003807	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	7830	0	7830	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	871.18	f			M003808	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8140	0	8140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	869.04	f			M003809	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8120	0	8120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	867.97	f			M003810	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8110	0	8110	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.25	f			M003811	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8150	0	8150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	862.62	f			M003812	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8060	0	8060	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	867.97	f			M003813	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8110	0	8110	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	873.32	f			M003814	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8160	0	8160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.78	f			M003815	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8155	0	8155	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	827.3	f			M003816	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	7730	0	7730	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	876.53	f			M003817	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8190	0	8190	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	870.11	f			M003818	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8130	0	8130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	870.11	f			M003819	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8130	0	8130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	873.32	f			M003820	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8160	0	8160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	870.64	f			M003821	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8135	0	8135	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	873.32	f			M003822	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8160	0	8160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	871.18	f			M003823	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8140	0	8140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	871.71	f			M003824	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8145	0	8145	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	877.6	f			M003825	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8200	0	8200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	879.21	f			M003826	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8215	0	8215	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	851.91	f			M003827	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	7960	0	7960	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	873.85	f			M003828	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8165	0	8165	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	870.11	f			M003829	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8130	0	8130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	226.89	f			M003830	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	2120	0	2120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	871.71	f			M003831	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8145	0	8145	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	868.5	f			M003832	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8115	0	8115	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*35	0	872.25	f			M003833	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TZ23-03328LG	8150	0	8150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	832.15	f			M003495	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7940	0	7940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	836.34	f			M003496	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7980	0	7980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	833.2	f			M003498	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7950	0	7950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	830.06	f			M003499	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7920	0	7920	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	782.89	f			M003500	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7470	0	7470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	835.3	f			M003502	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	415.03	f			M003503	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	3960	0	3960	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	80.7	f			M003505	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	770	0	770	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	833.2	f			M003506	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7950	0	7950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	832.15	f			M003507	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7940	0	7940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*34	0	835.3	f			M003508	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	2308235MJL	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*24	0	618.41	f			M002200	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06533LG	6270	0	6270	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*24	0	620.81	f			M002201	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06533LG	7770	0	7770	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*24	0	626.4	f			M002202	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06533LG	7840	0	7840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*24	0	612.82	f			M002203	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06533LG	7670	0	7670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*24	0	623.21	f			M002204	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06533LG	7800	0	7800	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	159*24	0	625.2	f			M002207	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06533LG	795	0	795	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	47.17	f			M002589	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	770	0	770	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	455.13	f			M002590	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	7430	0	7430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	460.64	f			M002591	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	7520	0	7520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	514.55	f			M002592	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	8400	0	8400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	423.28	f			M002593	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	6910	0	6910	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	483	f			M002594	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	7885	0	7885	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	441.04	f			M002595	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	7200	0	7200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	456.35	f			M002596	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	7450	0	7450	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	453.29	f			M002597	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	7400	0	7400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	431.85	f			M002598	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	7050	0	7050	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	447.16	f			M002599	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	55204783HL	7300	0	7300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	514.55	f			M002954	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22504783HL	8400	0	8400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	516.38	f			M002955	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22504783HL	8430	0	8430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	516.69	f			M002956	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22504783HL	8435	0	8435	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	178.87	f			M002960	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22504783HL	2920	0	2920	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	86.98	f			M003577	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22504783HL	1420	0	1420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	502.29	f			M005131	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8200	0	8200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	517	f			M005132	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8440	0	8440	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	511.79	f			M005133	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8355	0	8355	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	522.51	f			M005134	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8530	0	8530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	518.83	f			M005135	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8470	0	8470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	522.82	f			M005136	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8535	0	8535	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	499.84	f			M005137	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8160	0	8160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	200*45	0	134.16	f			Z23010537	热轧			780	0	780	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	520.36	f			M005138	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8495	0	8495	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	579.78	f			M005139	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	9465	0	9465	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	519.14	f			M005140	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8475	0	8475	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	521.28	f			M005141	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8510	0	8510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	507.2	f			M005142	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8280	0	8280	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	499.84	f			M005143	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8160	0	8160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	497.39	f			M005144	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8120	0	8120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	505.66	f			M005145	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8255	0	8255	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	516.38	f			M005146	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8430	0	8430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	523.43	f			M005147	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8545	0	8545	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	521.9	f			M005148	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8520	0	8520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	509.34	f			M005150	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8315	0	8315	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	519.75	f			M005151	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8485	0	8485	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	520.67	f			M005152	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	519.45	f			M005153	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8480	0	8480	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	515.77	f			M005154	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8420	0	8420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	521.59	f			M005155	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8515	0	8515	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	509.65	f			M005156	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8320	0	8320	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	514.55	f			M005157	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8400	0	8400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	501.99	f			M005158	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8195	0	8195	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	510.56	f			M005159	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8335	0	8335	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	507.81	f			M005160	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8290	0	8290	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	520.06	f			M005161	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8490	0	8490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	156*18	0	521.9	f			M005162	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03328LG	8520	0	8520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	720.15	f			M005072	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	9345	0	9345	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	724.39	f			M005073	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	9400	0	9400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	647.33	f			M005074	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	8400	0	8400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	718.99	f			M005075	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	9330	0	9330	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	646.94	f			M005076	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	8395	0	8395	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	130*20	0	38.52	f			Z23010542	热轧			710	0	710	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_107	80	0	108.59	f			Z23010564	热轧			2750	0	2750	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_107	150	0	149.93	f			Z23010565	热轧			1080	0	1080	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_105	219*25	0	282.26	f			M001946	热轧	GB/T8162-2018	2016314F	2360	0	2360	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_105	219*25	0	1126.04	f			M001947	热轧	GB/T8162-2018	2016314F	9415	0	9415	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_105	219*25	0	1132.62	f			M001948	热轧	GB/T8162-2018	2016314F	9470	0	9470	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_105	219*25	0	1100.33	f			M001949	热轧	GB/T8162-2018	2016314F	9200	0	9200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_105	150*30	0	173.11	f			Z230331-2	未调			1950	0	1950	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_114	65	0	25.55	f			Z23010211	固溶	ASEM SB446-2015	272-0079	980	0	980	0	0	0	宝钢特种	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_114	65	0	14.94	f			Z230413-2	固溶	ASEM SB446-2015	272-0079	573	0	573	0	0	0	宝钢特种	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_106	93*14	0	112.7	f			Z23010228	调质80KSI			3510	0	3510	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	653.1	f			M005077	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	8475	0	8475	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	561.79	f			M005078	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	7290	0	7290	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	467.74	f			L750	调质	API SPEC  5CT 10th	201106026	6660	0	6660	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	446.67	f			L751	调质	API SPEC  5CT 10th	201106026	6360	0	6360	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	474.06	f			L752	调质	API SPEC  5CT 10th	201106026	6750	0	6750	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	516.91	f			L755	调质	API SPEC  5CT 10th	201106026	7360	0	7360	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	505.67	f			M001515	调质	API SPEC  5CT 10th	22105175	7200	0	7200	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	511.29	f			M001519	调质	API SPEC  5CT 10th	22105175	7280	0	7280	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	479.33	f			M001522	调质	API SPEC  5CT 10th	22105175	6825	0	6825	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	457.21	f			M001523	调质	API SPEC  5CT 10th	22105175	6510	0	6510	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_108	121*32	0	311.83	f	内孔大\n3450+1190		M001524	调质	API SPEC  5CT 10th	22105175	4440	0	4440	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	125	0	26.51	f			L051	热轧			275	0	275	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	125	0	22.66	f			L052	热轧			235	0	235	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	130	0	6.26	f			L040	热轧			60	0	60	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	125	0	31.33	f			L053	热轧			325	0	325	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	100	0	183.25	f			Z23010556	热轧			2970	0	2970	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	90	0	74.47	f			Z23010557	热轧			1490	0	1490	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	220	0	95.56	f			Z23010558	热轧			320	0	320	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	125	0	22.66	f			Z23010559	热轧			235	0	235	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	100	0	58	f			Z23010560	热轧			940	0	940	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	120	0	27.99	f			Z230921-75	热轧			315	0	315	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_111	125	0	75.68	f			Z230921-78	热轧			785	0	785	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_112	35	0	11.34	f			Z23010665	调质110KSI			1500	0	1500	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_112	60	0	43.98	f			Z23010566	调质110KSI			1980	0	1980	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	647.33	f			M005079	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	8400	0	8400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	726.31	f			M005080	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	9425	0	9425	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	722.46	f			M005081	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	9375	0	9375	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	720.53	f			M005082	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	9350	0	9350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	545.6	f			M005083	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	7080	0	7080	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	646.17	f			M005084	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	8385	0	8385	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	651.56	f			M005085	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	82304012ZT	8455	0	8455	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	543.29	f			M005086	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7050	0	7050	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	530.58	f			M005087	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	6885	0	6885	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	519.4	f			M005088	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	6740	0	6740	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	559.09	f			M005089	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7255	0	7255	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	562.56	f			M005090	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7300	0	7300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	564.87	f			M005091	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7330	0	7330	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	575.66	f			M005092	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7470	0	7470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	564.1	f			M005093	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7320	0	7320	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	626.52	f			M005094	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	8130	0	8130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	220	0	1742.49	f			M004164	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	5835	0	5835	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	220	0	1929.14	f			M004165	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	6460	0	6460	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	220	0	754.93	f			M004159	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	2528	0	2528	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	220	0	2256.13	f			M004167	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	7555	0	7555	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	200	0	1700.45	f			M004168	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	6890	0	6890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	200	0	1759.68	f			M004169	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	7130	0	7130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	200	0	1789.3	f			M004170	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	7250	0	7250	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	200	0	1763.39	f			M004171	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	7145	0	7145	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	200	0	1722.66	f			M004172	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	6980	0	6980	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	200	0	1672.07	f			M004173	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	6775	0	6775	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	170	0	251.42	f			M001959	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023879	1410	0	1410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	170	0	1401.54	f			M004174	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	7860	0	7860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	170	0	1401.54	f			M004175	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	7860	0	7860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	170	0	1287.42	f			M004176	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	7220	0	7220	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	170	0	1372.12	f			M004177	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	7695	0	7695	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	170	0	1467.52	f			M004178	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	8230	0	8230	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	170	0	1512.09	f			M004179	调质-80KSI	QJ/DT01.24669-2021-B/0	23210023626	8480	0	8480	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	135	0	817.5	f			M002353	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023890	7270	0	7270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	135	0	444.17	f			M002355	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023890	3950	0	3950	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	135	0	10.12	f			M002356	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023890	90	0	90	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	135	0	195.66	f			M002357	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023890	1740	0	1740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	115	0	661.35	f			M002139	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023890	8105	0	8105	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	115	0	636.47	f			M002343	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023890	7800	0	7800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	115	0	638.91	f			M002345	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023890	7830	0	7830	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	115	0	345.57	f			M002351	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023890	4235	0	4235	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	18	0	12.06	f			M001533	热轧		22209120988	6035	0	6035	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	18	0	12.06	f			M001534	热轧		22209120988	6035	0	6035	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	18	0	12.07	f			M001535	热轧		22209120988	6040	0	6040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	18	0	12.05	f			M001536	热轧		22209120988	6030	0	6030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	18	0	12.05	f			M001537	热轧		22209120988	6030	0	6030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	18	0	12.07	f			M001538	热轧		22209120988	6040	0	6040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	18	0	11.96	f			M001539	热轧		22209120988	5985	0	5985	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_108	18	0	12.05	f			M001540	热轧		22209120988	6030	0	6030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	568.72	f			M005095	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7380	0	7380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	544.83	f			M005096	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7070	0	7070	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	560.63	f			M005097	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7275	0	7275	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	572.57	f			M005098	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7430	0	7430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	592.23	f			M005099	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7685	0	7685	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	150*25	0	567.18	f			M005100	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	823040821ZT	7360	0	7360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	549.97	f			M003307	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	6750	0	6750	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	539.78	f			M003308	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	6625	0	6625	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	542.63	f			M003309	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	6660	0	6660	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	348.23	f			M003310	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	4274	0	4274	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	544.26	f			M003311	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	6680	0	6680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	82.29	f			M003312	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	1010	0	1010	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	71.7	f			M003313	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	880	0	880	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	76.59	f			M003314	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	940	0	940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	75.77	f			M003316	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	930	0	930	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	40.74	f			M003485	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	500	0	500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	543.45	f			M003491	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	6670	0	6670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	1.63	f			M003494	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	20	0	20	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	731.25	f			M005053	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8975	0	8975	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	734.51	f			M005054	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9015	0	9015	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	730.85	f			M005055	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8970	0	8970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	725.96	f			M005056	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8910	0	8910	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	724.33	f			M005057	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8890	0	8890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	733.29	f			M005058	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9000	0	9000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	704.77	f			M005059	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8650	0	8650	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	431.71	f			L781	调质-80KSI			11370	0	11370	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	37.97	f			L782	调质-80KSI			1000	0	1000	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	418.04	f			L783	调质-80KSI			11010	0	11010	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	431.71	f			L784	调质-80KSI			11370	0	11370	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	418.42	f			L785	调质-80KSI			11020	0	11020	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	431.71	f			L787	调质-80KSI			11370	0	11370	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	431.71	f			L788	调质-80KSI			11370	0	11370	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	418.8	f			L789	调质-80KSI			11030	0	11030	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	418.04	f			L790	调质-80KSI			11010	0	11010	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	409.69	f			L791	调质-80KSI			10790	0	10790	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	409.69	f			L792	调质-80KSI			10790	0	10790	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	418.8	f			L793	调质-80KSI			11030	0	11030	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	418.8	f			L794	调质-80KSI			11030	0	11030	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	418.8	f			L795	调质-80KSI			11030	0	11030	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	114.3*15.6	0	139.35	f			L796	调质-80KSI			3670	0	3670	0	0	0	大无缝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	139.7*7.72	0	283.92	f			L507				11300	0	11300	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	139.7*7.72	0	283.92	f			L508				11300	0	11300	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	177.8*12.65	0	218.95	f			L510				4250	0	4250	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	177.8*12.65	0	573.55	f			L511				11133	0	11133	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	135*17.5	0	61.36	f	 		M000598	调质-80KSI	 	22213031	1210	0	1210	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	135*17.5	0	521.98	f	 		M000599	调质-80KSI	 	22213031	10294	0	10294	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	135*17.5	0	20.28	f	 		M000600	调质-80KSI	 	22213031	400	0	400	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	135*17.5	0	393.99	f	 		M000601	调质80KSI	 	22213031	7770	0	7770	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	135*17.5	0	514.22	f	 		M000602	调质-80KSI	 	22213031	10141	0	10141	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	190.7*19.5	0	648.97	f	 		M000607	调质-80KSI	 	22212770	7883	0	7883	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	190.7*19.5	0	196.76	f	 		M000609	调质-80KSI	 	22212770	2390	0	2390	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	127*7.52	0	240.86	f	 		M000613	调质-80KSI	 	22211303	11250	0	11250	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	127*7.52	0	240.86	f	 		M000614	调质-80KSI	 	22211303	11250	0	11250	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	127*7.52	0	240.86	f	 		M000615	调质-80KSI	 	22211303	11250	0	11250	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_102	146*28	0	569.52	f	 		M003492	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03583LG	6690	0	6690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	127*7.52	0	241.5	f	 		M000612	调质-80KSI	 	22211303	11280	0	11280	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_109	127*9.19	0	259.06	f			L513				9703	0	9703	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	127*9.19	0	301.7	f			L514				11300	0	11300	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	139.7*7.72	0	283.92	f			L515				11300	0	11300	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	139.7*7.72	0	112.81	f			L516				4490	0	4490	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	200.03*18.5	0	97.31	f			Z23010533	调质-80KSI			1175	0	1175	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_109	200.03*18.5	0	109.73	f			Z23010534	调质-110KSI			1325	0	1325	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	731.66	f			M005060	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8980	0	8980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	732.47	f			M005061	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8990	0	8990	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	729.62	f			M005062	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8955	0	8955	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	726.36	f			M005063	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8915	0	8915	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	695	f			M005064	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8530	0	8530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	731.66	f			M005065	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8980	0	8980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	730.03	f			M005066	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8960	0	8960	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	730.85	f			M005067	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8970	0	8970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	730.44	f			M005068	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8965	0	8965	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.11	f			M005029	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	0	9940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	720.2	f			M005030	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9900	0	9900	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	701.28	f			M005031	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9640	0	9640	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	670	f			M005032	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9210	0	9210	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	697.64	f			M005033	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9590	0	9590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.47	f			M005034	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9945	0	9945	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.83	f			M005035	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9950	0	9950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.83	f			M005036	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9950	0	9950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.11	f			M005037	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	0	9940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	705.65	f			M005038	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9700	0	9700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.47	f			M005039	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9945	0	9945	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.11	f			M005040	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	0	9940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.47	f			M005041	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9945	0	9945	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.83	f			M005042	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9950	0	9950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.11	f			M005043	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	0	9940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.47	f			M005044	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9945	0	9945	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	143*25	0	723.47	f			M005045	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9945	0	9945	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	697.82	f			M004980	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7700	0	7700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	701.89	f			M004981	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7745	0	7745	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	688.75	f			M004982	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7600	0	7600	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	692.83	f			M004983	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7645	0	7645	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	699.18	f			M004984	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7715	0	7715	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	690.11	f			M004985	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7615	0	7615	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	697.82	f			M004986	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7700	0	7700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	696	f			M004987	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7680	0	7680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	695.55	f			M004988	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7675	0	7675	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	652.5	f			M004989	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7200	0	7200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	698.72	f			M004990	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7710	0	7710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	697.82	f			M004991	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7700	0	7700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	669.27	f			M004992	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7385	0	7385	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	696.91	f			M004993	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7690	0	7690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	697.36	f			M004994	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7695	0	7695	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	705.97	f			M004995	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7790	0	7790	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	695.1	f			M004996	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7670	0	7670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	694.64	f			M004997	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7665	0	7665	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	663.83	f			M004998	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7325	0	7325	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	707.79	f			M004999	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7810	0	7810	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*35	0	696.91	f			M005000	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	7690	0	7690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.87	f			M003061	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6880	0	6880	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	499.95	f			M003062	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6840	0	6840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.14	f			M003063	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	500.68	f			M003064	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6850	0	6850	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.87	f			M003065	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6880	0	6880	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	462.67	f			M003066	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6330	0	6330	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.14	f			M003067	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	503.61	f			M003068	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.14	f			M003069	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.14	f			M003070	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	503.61	f			M003071	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	503.61	f			M003072	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.14	f			M003073	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	503.61	f			M003074	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.14	f			M003075	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.87	f			M003076	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6880	0	6880	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	503.61	f			M003077	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	499.95	f			M003078	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6840	0	6840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	475.83	f			M003079	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6510	0	6510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	502.14	f			M003080	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	499.95	f			M003081	调质125KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06534LG	6840	0	6840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	644.92	f			M005001	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9510	0	9510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	626.61	f			M005002	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9240	0	9240	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	660.52	f			M005003	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9740	0	9740	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	660.52	f			M005004	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9740	0	9740	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	661.2	f			M005005	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9750	0	9750	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	639.5	f			M005006	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9430	0	9430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	640.17	f			M005007	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9440	0	9440	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	632.04	f			M005008	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9320	0	9320	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	630.68	f			M005009	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9300	0	9300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	440.8	f			M005010	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6500	0	6500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	444.19	f			M005011	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6550	0	6550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	431.98	f			M005012	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6370	0	6370	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	441.48	f			M005013	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6510	0	6510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	444.87	f			M005014	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6560	0	6560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	442.83	f			M005015	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6530	0	6530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	444.19	f			M005016	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6550	0	6550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	445.54	f			M005017	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6570	0	6570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	437.41	f			M005018	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6450	0	6450	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	441.48	f			M005019	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6510	0	6510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	428.59	f			M005020	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6320	0	6320	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	446.22	f			M005021	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6580	0	6580	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	442.83	f			M005022	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6530	0	6530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	442.15	f			M005023	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	6520	0	6520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	649.33	f			M005024	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9575	0	9575	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	633.73	f			M005025	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9345	0	9345	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	664.25	f			M005026	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9795	0	9795	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	659.84	f			M005027	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9730	0	9730	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	135*25	0	656.79	f			M005028	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302986XW	9685	0	9685	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*25	0	426.38	f			M000801	热轧	GB/T 8162-2018	22B02604	3565	0	3565	0	0	0	海鑫达	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*25	0	528.64	f			M000802	热轧	GB/T 8162-2018	22B02604	4420	0	4420	0	0	0	海鑫达	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	19.81	f			M001530	调质	API SPEC 5CT 10th	TX22-03018LG	230	0	230	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	741.43	f			M004454	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8610	0	8610	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	731.96	f			M004455	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	737.99	f			M004456	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8570	0	8570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	734.54	f			M004457	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8530	0	8530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	741.43	f			M004458	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8610	0	8610	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	738.85	f			M004459	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8580	0	8580	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	736.26	f			M004460	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8550	0	8550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	734.54	f			M004461	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8530	0	8530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	712.15	f			M004462	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8270	0	8270	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	737.99	f			M004463	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8570	0	8570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	740.57	f			M004464	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8600	0	8600	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	730.24	f			M004465	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8480	0	8480	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	730.67	f			M004466	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8485	0	8485	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	740.57	f			M004467	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8600	0	8600	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	731.1	f			M004468	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8490	0	8490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	691.49	f			M004469	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8030	0	8030	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	385.1	f			M004470	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	4472	0	4472	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	718.18	f			M004471	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8340	0	8340	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	729.37	f			M004472	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8470	0	8470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	651.87	f			M004473	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	7570	0	7570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	739.71	f			M004474	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8590	0	8590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	739.71	f			M004475	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8590	0	8590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	723.35	f			M004476	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8400	0	8400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	737.12	f			M004477	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8560	0	8560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	731.96	f			M004478	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	724.21	f			M004479	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8410	0	8410	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	735.4	f			M004480	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8540	0	8540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	737.99	f			M004481	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8570	0	8570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	718.18	f			M004482	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8340	0	8340	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*36	0	733.68	f			M004483	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8520	0	8520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	515.34	f			M003337	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	7740	0	7740	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	529.99	f			M003338	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	7960	0	7960	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	406.48	f			M003340	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	6105	0	6105	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	517.34	f			M003342	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	7770	0	7770	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	506.02	f			M003343	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	7600	0	7600	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	639.19	f			M003345	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	9600	0	9600	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	506.02	f			M003346	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	7600	0	7600	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	633.19	f			M003349	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	9510	0	9510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*25	0	632.53	f			M003354	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12303030XW	9500	0	9500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	96.52	f			M003657	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	1520	0	1520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	541.97	f			M003658	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8535	0	8535	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	539.11	f			M003659	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8490	0	8490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	158.11	f			M003660	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	2490	0	2490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	540.7	f			M003661	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8515	0	8515	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	543.56	f			M003662	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8560	0	8560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	541.02	f			M003663	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8520	0	8520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	544.51	f			M003664	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8575	0	8575	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	542.92	f			M003665	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8550	0	8550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	521.33	f			M003666	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8210	0	8210	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	542.29	f			M003667	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8540	0	8540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	544.83	f			M003668	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8580	0	8580	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	537.84	f			M003669	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8470	0	8470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	541.65	f			M003670	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8530	0	8530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	542.92	f			M003672	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8550	0	8550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	541.02	f			M003673	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8520	0	8520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	543.56	f			M003674	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8560	0	8560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	542.29	f			M003675	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8540	0	8540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	544.19	f			M003676	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8570	0	8570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	539.75	f			M003677	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8500	0	8500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	128*25	0	525.14	f			M003678	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	8270	0	8270	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	530.43	f			M003633	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	6680	0	6680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	49.63	f			M003634	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	625	0	625	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	566.16	f			M003635	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	7130	0	7130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	563.78	f			M003636	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	7100	0	7100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	558.62	f			M003637	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	7035	0	7035	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	563.78	f			M003638	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	7100	0	7100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	569.73	f			M003639	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	7175	0	7175	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	532.41	f			M003640	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	6705	0	6705	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	451.82	f			M003641	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	5690	0	5690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	79.41	f			M003642	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	1000	0	1000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	3.18	f			M003643	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	40	0	40	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	551.47	f			M003644	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	6945	0	6945	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	127*35	0	530.82	f			M003645	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	823040121ZT	6685	0	6685	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	417.54	f			M004919	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8300	0	8300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	402.7	f			M004920	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8005	0	8005	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	419.56	f			M004921	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8340	0	8340	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	421.57	f			M004922	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8380	0	8380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	421.06	f			M004923	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8370	0	8370	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	420.81	f			M004924	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8365	0	8365	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	419.05	f			M004925	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8330	0	8330	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	386.35	f			M004926	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	7680	0	7680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	422.07	f			M004927	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8390	0	8390	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	420.56	f			M004928	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8360	0	8360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	422.07	f			M004929	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8390	0	8390	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	420.81	f			M004930	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8365	0	8365	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	420.56	f			M004931	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8360	0	8360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	400.94	f			M004932	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	421.57	f			M004933	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8380	0	8380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	421.32	f			M004934	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8375	0	8375	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	421.57	f			M004935	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8380	0	8380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	398.93	f			M004936	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	7930	0	7930	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	423.58	f			M004937	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8420	0	8420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	423.58	f			M004938	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8420	0	8420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	420.81	f			M004939	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8365	0	8365	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	403.46	f			M004940	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8020	0	8020	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	423.58	f			M004941	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8420	0	8420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	422.57	f			M004942	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8400	0	8400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	122*20	0	423.08	f			M004943	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	8410	0	8410	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	18.26	f			M001443	调质-110KSI	GB/T 8162-2018	22215036	260	0	260	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	9.97	f			M001444	调质-110KSI	GB/T 8162-2018	22215036	142	0	142	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	3.16	f			M001451	调质-110KSI	GB/T 8162-2018	22215036	45	0	45	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	94.81	f			M003693	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	1350	0	1350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	639.11	f			M003696	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	9100	0	9100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	34.76	f			M003697	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	495	0	495	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	632.09	f			M003698	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	9000	0	9000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	29.15	f			M003701	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	415	0	415	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	717.77	f			M003702	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	10220	0	10220	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	718.47	f			M003704	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	10230	0	10230	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	716.36	f			M003705	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	10200	0	10200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	713.55	f			M003706	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	10160	0	10160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	714.26	f			M003707	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	10170	0	10170	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	718.47	f			M003708	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	10230	0	10230	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*32	0	718.47	f			M003710	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03584LG	10230	0	10230	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*30	0	47.2	f			Z23010544	热轧			550	0	550	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	79.63	f			B230110-54	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06531LG	115	0	115	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	398.13	f			M005101	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6200	0	6200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	442.76	f			M005102	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6895	0	6895	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	403.91	f			M005103	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6290	0	6290	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	421.89	f			M005104	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6570	0	6570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	443.08	f			M005105	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6900	0	6900	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	407.76	f			M005106	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6350	0	6350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	408.08	f			M005107	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6355	0	6355	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	420.61	f			M005108	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6550	0	6550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	427.67	f			M005109	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6660	0	6660	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	410.65	f			M005110	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6395	0	6395	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	414.18	f			M005111	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6450	0	6450	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	403.59	f			M005112	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6285	0	6285	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	416.75	f			M005113	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6490	0	6490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	409.05	f			M005114	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6370	0	6370	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	416.75	f			M005115	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6490	0	6490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	422.53	f			M005116	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6580	0	6580	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	406.8	f			M005117	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6335	0	6335	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	430.88	f			M005118	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6710	0	6710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	415.15	f			M005119	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6465	0	6465	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	425.42	f			M005120	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6625	0	6625	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	441.15	f			M005121	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	402.63	f			M005122	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6270	0	6270	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	441.15	f			M005123	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6870	0	6870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	410.97	f			M005124	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6400	0	6400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	445.01	f			M005125	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6930	0	6930	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	442.76	f			M005126	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6895	0	6895	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	405.84	f			M005127	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6320	0	6320	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	436.98	f			M005128	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6805	0	6805	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	412.9	f			M005129	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6430	0	6430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*28	0	418.04	f			M005130	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	E12302990XW	6510	0	6510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.33	f			M002964	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8420	0	8420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	477.61	f			M002965	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8070	0	8070	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.92	f			M002966	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8430	0	8430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	501.29	f			M002967	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8470	0	8470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	500.7	f			M002968	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8460	0	8460	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	499.51	f			M002969	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8440	0	8440	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	470.51	f			M002970	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	7950	0	7950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.33	f			M002971	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8420	0	8420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	479.39	f			M002972	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8100	0	8100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	500.1	f			M002973	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8450	0	8450	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.92	f			M002974	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8430	0	8430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	500.7	f			M002975	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8460	0	8460	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	500.7	f			M002976	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8460	0	8460	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.92	f			M002977	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8430	0	8430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	500.1	f			M002979	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8450	0	8450	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	506.02	f			M002980	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8550	0	8550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.92	f			M002981	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8430	0	8430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.33	f			M002982	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8420	0	8420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.33	f			M002983	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8420	0	8420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	23.67	f			M003051	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	400	0	400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	12.72	f			M003052	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	215	0	215	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	497.74	f			M003053	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8410	0	8410	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	500.1	f			M003054	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8450	0	8450	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	142.04	f			M003055	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	2400	0	2400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	502.47	f			M003056	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8490	0	8490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	498.92	f			M003058	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8430	0	8430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	501.29	f			M003059	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8470	0	8470	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*25	0	505.14	f			M003060	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	622120689ZT	8535	0	8535	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	122.86	f			M003653	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	623050389ZT	2190	0	2190	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	11.67	f			M003655	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	623050389ZT	208	0	208	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	375.88	f			M004790	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6700	0	6700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	373.07	f			M004791	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6650	0	6650	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	375.32	f			M004792	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6690	0	6690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	383.73	f			M004793	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6840	0	6840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	380.93	f			M004903	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6790	0	6790	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	391.59	f			M004904	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6980	0	6980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	384.3	f			M004905	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6850	0	6850	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	376.44	f			M004906	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6710	0	6710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	380.37	f			M004907	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6780	0	6780	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	382.61	f			M004908	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6820	0	6820	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	364.66	f			M004909	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6500	0	6500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	387.66	f			M004910	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6910	0	6910	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	376.44	f			M004911	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6710	0	6710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	386.54	f			M004912	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	388.22	f			M004913	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6920	0	6920	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	368.03	f			M004914	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6560	0	6560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	388.22	f			M004915	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6920	0	6920	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	389.34	f			M004916	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6940	0	6940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	384.3	f			M004917	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6850	0	6850	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	116*25	0	382.05	f			M004918	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623050389ZT	6810	0	6810	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	376.23	f			M003317	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6520	0	6520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	376.81	f			M003318	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6530	0	6530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	376.81	f			M003319	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6530	0	6530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	382.58	f			M003320	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6630	0	6630	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	384.31	f			M003321	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6660	0	6660	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	377.96	f			M003322	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6550	0	6550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	377.39	f			M003323	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6540	0	6540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	23.08	f			M003324	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	400	0	400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	380.27	f			M003325	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6590	0	6590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	180.04	f			M003326	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	3120	0	3120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	377.96	f			M003327	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6550	0	6550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	383.16	f			M003328	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6640	0	6640	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	377.39	f			M003329	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6540	0	6540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	365.85	f			M003330	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6340	0	6340	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	376.23	f			M003331	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6520	0	6520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	382	f			M003332	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6620	0	6620	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	375.08	f			M003333	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6500	0	6500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	384.31	f			M003334	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6660	0	6660	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	379.69	f			M003335	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6580	0	6580	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	383.73	f			M003336	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6650	0	6650	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	379.69	f			M003523	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6580	0	6580	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	375.66	f			M003524	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6510	0	6510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	382	f			M003525	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6620	0	6620	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	382.58	f			M003527	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	6630	0	6630	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	388.64	f			M005069	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6735	0	6735	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	384.6	f			M005070	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6665	0	6665	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	386.62	f			M005071	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6700	0	6700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	386.04	f			M005296	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6690	0	6690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	385.47	f			M005297	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6680	0	6680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	371.04	f			M005298	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6430	0	6430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	369.31	f			M005299	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6400	0	6400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	387.2	f			M005300	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6710	0	6710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	368.15	f			M005301	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6380	0	6380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	385.75	f			M005302	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6685	0	6685	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	386.04	f			M005303	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6690	0	6690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	388.93	f			M005304	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6740	0	6740	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	386.91	f			M005305	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6705	0	6705	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	387.77	f			M005306	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6720	0	6720	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	388.06	f			M005307	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6725	0	6725	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	388.35	f			M005308	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6730	0	6730	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	388.35	f			M005309	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6730	0	6730	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	388.93	f			M005310	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6740	0	6740	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	388.35	f			M005311	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6730	0	6730	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	367	f			M005312	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6360	0	6360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	385.47	f			M005313	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6680	0	6680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	384.89	f			M005314	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6670	0	6670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	389.5	f			M005315	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6750	0	6750	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	400.15	f			M002993	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	7820	0	7820	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	351.02	f			M002994	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	6860	0	6860	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	376.1	f			M002998	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	7350	0	7350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	371.49	f			M002999	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	7260	0	7260	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	64.47	f			M003000	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	1260	0	1260	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	352.56	f			M003001	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	6890	0	6890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	211.84	f			M003002	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	4140	0	4140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	353.58	f			M003003	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	6910	0	6910	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	400.66	f			M003004	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	7830	0	7830	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	353.07	f			M003005	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23802277XG	6900	0	6900	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	495.32	f			M003679	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9680	0	9680	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	496.34	f			M003680	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9700	0	9700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	496.86	f			M003681	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9710	0	9710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	495.83	f			M003682	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9690	0	9690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	485.09	f			M003683	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9480	0	9480	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	487.13	f			M003684	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9520	0	9520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	481.5	f			M003685	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9410	0	9410	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	448.24	f			M003686	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	8760	0	8760	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	494.3	f			M003687	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9660	0	9660	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	497.37	f			M003688	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9720	0	9720	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	496.34	f			M003689	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9700	0	9700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	500.95	f			M003690	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9790	0	9790	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	495.83	f			M003691	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	9690	0	9690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	445.17	f			M003692	调质-110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03228LG	8700	0	8700	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	405.26	f			M004944	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7920	0	7920	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	406.8	f			M004945	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7950	0	7950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	394.52	f			M004946	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7710	0	7710	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	405.26	f			M004947	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7920	0	7920	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	405.26	f			M004948	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7920	0	7920	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	405.52	f			M004949	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7925	0	7925	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	403.47	f			M004950	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7885	0	7885	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	406.29	f			M004951	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7940	0	7940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	410.89	f			M004952	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	8030	0	8030	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	406.8	f			M004953	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7950	0	7950	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	392.47	f			M004954	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7670	0	7670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	408.84	f			M004955	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7990	0	7990	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	407.82	f			M004956	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	406.29	f			M004957	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7940	0	7940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	409	f			M004958	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7993	0	7993	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	406.29	f			M004959	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7940	0	7940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	400.15	f			M004960	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7820	0	7820	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	408.33	f			M004961	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7980	0	7980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	407.05	f			M004962	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7955	0	7955	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	400.66	f			M004963	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7830	0	7830	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	408.84	f			M004964	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7990	0	7990	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	365.35	f			M004965	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7140	0	7140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	359.21	f			M004966	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7020	0	7020	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	381.72	f			M004967	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7460	0	7460	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	407.31	f			M004968	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7960	0	7960	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	405.77	f			M004969	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7930	0	7930	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	389.91	f			M004970	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7620	0	7620	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	397.84	f			M004971	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7775	0	7775	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	496.09	f			M004972	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	9695	0	9695	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	406.29	f			M004973	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7940	0	7940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	448.5	f			M004974	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	8765	0	8765	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	413.96	f			M004975	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	8090	0	8090	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	399.12	f			M004976	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7800	0	7800	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	389.4	f			M004977	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	7610	0	7610	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*25	0	448.24	f			M004978	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03228LG	8760	0	8760	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	13.77	f			M002946	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	290	0	290	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	92	f			M002947	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	1938	0	1938	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	178.25	f			M002951	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	3755	0	3755	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	177.78	f			M002952	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	3745	0	3745	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	19.46	f			M002953	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	410	0	410	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	16.38	f			M002937	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	345	0	345	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	16.61	f			M002938	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	350	0	350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	16.14	f			M002939	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	340	0	340	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	16.85	f			M002940	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	355	0	355	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	16.61	f			M002941	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	350	0	350	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	5.22	f			M002942	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	110	0	110	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	18.51	f			M002943	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	390	0	390	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*25	0	16.85	f			M002945	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TX22-06532LG	355	0	355	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	396.51	f			M002507	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7960	0	7960	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	12.45	f			M002510	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	250	0	250	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002512	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002513	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	396.51	f			M002514	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7960	0	7960	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002515	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002517	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002518	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	396.76	f			M002519	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7965	0	7965	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	396.76	f			M002520	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7965	0	7965	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	396.51	f			M002521	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7960	0	7960	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.26	f			M002522	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7975	0	7975	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002523	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002524	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	396.76	f			M002525	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7965	0	7965	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002526	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002527	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*20	0	397.01	f			M002528	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	TX22-06531LG	7970	0	7970	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*24	0	9.69	f			M002552	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011C	622120688ZT	195	0	195	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*22	0	8.68	f			M001191	调质-110KSI	API SPEC 5CT&	22605904HL	200	0	200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	81.16	f			M003006	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	1870	0	1870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	81.16	f			M003007	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	1870	0	1870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	82.68	f			M003008	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	1905	0	1905	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	81.16	f			M003010	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	1870	0	1870	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	82.46	f			M003011	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	1900	0	1900	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	82.46	f			M003012	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	1900	0	1900	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	347.21	f			M003013	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	8000	0	8000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	342.66	f			M003014	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	7895	0	7895	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	347.21	f			M003015	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	8000	0	8000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	346.78	f			M003016	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	7990	0	7990	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	347.21	f			M003017	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	8000	0	8000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	347.21	f			M003018	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	8000	0	8000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	347.21	f			M003019	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	8000	0	8000	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	332.46	f			M003020	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	7660	0	7660	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	348.51	f			M003021	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	8030	0	8030	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	326.38	f			M003024	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	7520	0	7520	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	346.56	f			M003025	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	7985	0	7985	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	346.78	f			M003027	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	7990	0	7990	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*20	0	346.78	f			M003028	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	22511845XG	7990	0	7990	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	327.99	f			M003435	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8110	0	8110	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	306.96	f			M003436	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7590	0	7590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	288.76	f			M003437	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7140	0	7140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	319.09	f			M003438	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7890	0	7890	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	266.52	f			M003439	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	6590	0	6590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	307.36	f			M003440	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7600	0	7600	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	326.37	f			M003441	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8070	0	8070	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	287.95	f			M003442	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7120	0	7120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	327.58	f			M003443	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8100	0	8100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	264.49	f			M003444	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	6540	0	6540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	319.9	f			M003445	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7910	0	7910	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	334.05	f			M003446	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8260	0	8260	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	262.88	f			M003447	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	6500	0	6500	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	327.58	f			M003448	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8100	0	8100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	329.2	f			M003449	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8140	0	8140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	328.39	f			M003450	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8120	0	8120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	334.05	f			M003451	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8260	0	8260	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	262.47	f			M003452	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	6490	0	6490	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	334.05	f			M003453	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8260	0	8260	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	331.63	f			M003454	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8200	0	8200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	314.24	f			M003455	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7770	0	7770	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	308.58	f			M003456	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7630	0	7630	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	304.94	f			M003457	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7540	0	7540	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	311	f			M003458	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7690	0	7690	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	305.74	f			M003459	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7560	0	7560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	302.51	f			M003460	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7480	0	7480	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	292.4	f			M003461	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7230	0	7230	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	313.43	f			M003462	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7750	0	7750	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	263.28	f			M003463	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	6510	0	6510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	305.74	f			M003464	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7560	0	7560	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	331.63	f			M003465	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8200	0	8200	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	304.53	f			M003466	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7530	0	7530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	326.77	f			M003467	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	8080	0	8080	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	290.38	f			M003468	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	7180	0	7180	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	102*20	0	264.9	f			M003469	调质-80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623010673ZT	6550	0	6550	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	373.58	f			M003470	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	8530	0	8530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	375.77	f			M003471	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	8580	0	8580	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	367.89	f			M003472	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	8400	0	8400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	375.33	f			M003473	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	8570	0	8570	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	367.45	f			M003474	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	8390	0	8390	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	367.45	f			M003475	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	8390	0	8390	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	329.79	f			M003476	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	7530	0	7530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	347.74	f			M003477	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	7940	0	7940	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	355.62	f			M003478	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	8120	0	8120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	373.58	f			M003479	调质80KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040107ZT	8530	0	8530	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	356.5	f			M003598	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	8140	0	8140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	325.84	f			M003599	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7440	0	7440	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	323.22	f			M003600	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7380	0	7380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	328.91	f			M003601	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7510	0	7510	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	325.19	f			M003602	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7425	0	7425	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	325.23	f			M003603	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7426	0	7426	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	325.62	f			M003604	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7435	0	7435	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	323.43	f			M003605	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7385	0	7385	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	373.8	f			M003606	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	8535	0	8535	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	323	f			M003607	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7375	0	7375	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	324.75	f			M003608	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7415	0	7415	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	5.69	f			M003609	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	130	0	130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	8.98	f			M003610	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	205	0	205	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	305.48	f			M003611	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	6975	0	6975	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	289.49	f			M003612	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	6610	0	6610	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	324.31	f			M003613	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7405	0	7405	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	270	f			M003614	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	6165	0	6165	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	319.49	f			M003615	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7295	0	7295	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	326.06	f			M003616	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7445	0	7445	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	324.97	f			M003617	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7420	0	7420	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	372.05	f			M003618	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	8495	0	8495	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	325.84	f			M003619	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7440	0	7440	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	354.97	f			M003620	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	8105	0	8105	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	325.19	f			M003621	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7425	0	7425	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	325.19	f			M003622	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7425	0	7425	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	292.12	f			M003623	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	6670	0	6670	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	293.22	f			M003624	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	6695	0	6695	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	311.83	f			M003625	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7120	0	7120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	327.38	f			M003626	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7475	0	7475	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	156.26	f			M003627	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	3568	0	3568	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	272.63	f			M003628	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	6225	0	6225	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	267.81	f			M003629	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	6115	0	6115	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	270.66	f			M003630	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	6180	0	6180	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	325.41	f			M003631	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7430	0	7430	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	326.94	f			M003632	调质110KSI	API SPEC 5CT&FS-T-M-011B-3	TZ23-03229LG	7465	0	7465	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	235.82	f			M005236	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6130	0	6130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	236.2	f			M005237	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6140	0	6140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	238.13	f			M005238	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6190	0	6190	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	234.66	f			M005239	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6100	0	6100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	235.05	f			M005240	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6110	0	6110	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	237.36	f			M005241	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6170	0	6170	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	237.36	f			M005242	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6170	0	6170	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	340.07	f			M005243	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	8840	0	8840	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	342.76	f			M005244	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	8910	0	8910	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	355.46	f			M005245	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9240	0	9240	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	361.61	f			M005246	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9400	0	9400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	360.84	f			M005247	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9380	0	9380	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	355.07	f			M005248	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9230	0	9230	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	345.84	f			M005249	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	8990	0	8990	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	237.36	f			M005250	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6170	0	6170	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	235.43	f			M005251	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6120	0	6120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	235.24	f			M005252	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6115	0	6115	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	233.9	f			M005253	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6080	0	6080	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	236.2	f			M005254	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6140	0	6140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	235.82	f			M005255	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6130	0	6130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	236.59	f			M005256	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6150	0	6150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	359.31	f			M005257	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9340	0	9340	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	345.46	f			M005258	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	8980	0	8980	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	363.15	f			M005259	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9440	0	9440	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	362	f			M005260	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9410	0	9410	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	355.46	f			M005261	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9240	0	9240	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	361.61	f			M005262	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9400	0	9400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	361.61	f			M005263	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	9400	0	9400	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	235.05	f			M005264	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6110	0	6110	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	236.97	f			M005265	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6160	0	6160	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	235.43	f			M005266	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6120	0	6120	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	237.36	f			M005267	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6170	0	6170	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	236.59	f			M005268	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6150	0	6150	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	236.2	f			M005269	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6140	0	6140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	236.2	f			M005270	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	6140	0	6140	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*20	0	210.04	f			M005271	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	623040105ZT	5460	0	5460	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	42.03	f			B230110-58	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06236LG	1235	0	1235	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	94.95	f			B230110-59	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06236LG	2790	0	2790	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	2.21	f			B230110-62	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06236LG	65	0	65	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	44.92	f			B230110-63	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06236LG	1320	0	1320	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	45.26	f			B230110-65	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06236LG	1330	0	1330	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	38.45	f			B230110-66	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06236LG	1130	0	1130	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	40.16	f			B230110-67	调质-110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06236LG	1180	0	1180	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	43.56	f			M002912	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1280	0	1280	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	44.24	f			M002913	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1300	0	1300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	43.22	f			M002914	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1270	0	1270	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	8.34	f			M002915	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	245	0	245	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	40.97	f			M002916	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1204	0	1204	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	44.24	f			M002917	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1300	0	1300	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	37.09	f			M002919	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1090	0	1090	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	40.16	f			M002920	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1180	0	1180	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	26.2	f			M002921	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	770	0	770	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	44.38	f			M002924	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1304	0	1304	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	168*30	0	168.45	f			Z23010548	热轧			1650	0	1650	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	40.5	f			M002925	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1190	0	1190	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	3.4	f			M002926	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	100	0	100	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	40.16	f			M002927	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1180	0	1180	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*20	0	41.52	f			M002929	调质-110KSI	API SPEC 5CT 10th & FS-T-M-011B	TX22-06236LG	1220	0	1220	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	83*14	0	179.38	f			M003961	调质110KSI	XYGN4525.2-2021-01	3016362Z	7530	0	7530	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	83*14	0	19.06	f			M004044	调质110KSI	XYGN4525.2-2021-01	3016362Z	800	0	800	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	83*14	0	95.31	f			M004054	调质110KSI	XYGN4525.2-2021-01	3016362Z	4001	0	4001	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	83*14	0	180.81	f			M004055	调质110KSI	XYGN4525.2-2021-01	3016362Z	7590	0	7590	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	24.52	f			L451	调质-110KSI	API SPEC 5CT 10th&技术协议 P110	0300486MSG	425	0	425	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	4.04	f			L456	调质-110KSI	API SPEC 5CT 10th&技术协议 P110	0300486MSG	70	0	70	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*30	0	23.19	f			L484	热轧			285	0	285	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*28	0	512.34	f			L487	热轧			4240	0	4240	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*16	0	79.54	f			L490	热轧	TJBY-1911-1合同/API 5CT 9th	R1913247-1	1920	0	1920	0	0	0	新兴铸管	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*40	0	951.69	f			L493	未调			5390	0	5390	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*32	0	419.81	f			L497	热轧			7000	0	7000	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	184*20	0	583.99	f			L520	调质-110KSI			7220	0	7220	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*45	0	794.26	f			L597	热轧			4530	0	4530	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*13	0	41.6	f			L710	调质-110KSI			630	0	630	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	38.1	f			M001829	调质-80KSI	GB/T 8162-2018	22215036	870	0	870	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	35.47	f			M001830	调质-80KSI	GB/T 8162-2018	22215036	810	0	810	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	6.35	f			M001831	调质-80KSI	GB/T 8162-2018	22215036	145	0	145	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	8.76	f			M001832	调质-80KSI	GB/T 8162-2018	22215036	200	0	200	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	5.91	f			M001833	调质-80KSI	GB/T 8162-2018	22215036	135	0	135	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	262.78	f			M001834-1	调质-80KSI	GB/T 8162-2018	22215036	6000	0	6000	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	195.77	f			M001834-2	调质-80KSI	GB/T 8162-2018	22215036	4470	0	4470	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	13.14	f			M001835	调质-80KSI	GB/T 8162-2018	22215036	300	0	300	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	1.75	f			M001836	调质-80KSI	GB/T 8162-2018	22215036	40	0	40	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	44.23	f			M001837	调质-80KSI	GB/T 8162-2018	22204584	1010	0	1010	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	524.46	f			M001838	调质-80KSI	GB/T 8162-2018	22204584	11975	0	11975	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	98*24	0	63.94	f			M001839	调质-80KSI	GB/T 8162-2018	22204584	1460	0	1460	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	142.18	f			M001840-2	调质-80KSI	GB/T 8162-2018	22104584	4335	0	4335	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	17.38	f			M001841	调质-80KSI	GB/T 8162-2018	22104584	530	0	530	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	272.22	f			M001843	调质-80KSI	GB/T 8162-2018	22104584	8300	0	8300	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	128.24	f			M001844-2	调质-80KSI	GB/T 8162-2018	22104584	3910	0	3910	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	129.55	f			M001845-2	调质-80KSI	GB/T 8162-2018	22104584	3950	0	3950	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	2.95	f			M001847	调质-80KSI	GB/T 8162-2018	22104584	90	0	90	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	129.55	f			M001848-2	调质-80KSI	GB/T 8162-2018	22104584	3950	0	3950	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	180.72	f			M001849	调质-80KSI	GB/T 8162-2018	22104584	5510	0	5510	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	138.41	f			M001852-2	调质-80KSI	GB/T 8162-2018	22104584	4220	0	4220	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	89*19	0	16.4	f			M001854	调质-80KSI	GB/T 8162-2018	22104584	500	0	500	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	225.52	f			L764	调质-110KSI			2360	0	2360	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	1.46	f			L475	热轧			20	0	20	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*26	0	2.92	f			L482	热轧			40	0	40	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	53.99	f			Z23010549	热轧			565	0	565	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	64.98	f			Z23010550	热轧			680	0	680	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*25	0	35.84	f			Z23010504	调质110KSI			380	0	380	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*16	0	29	f			Z23010505	调质110KSI			700	0	700	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	178*25	0	75.46	f			Z23010506	调质110KSI			800	0	800	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*12	0	22.05	f			Z23010507	调质110KSI			360	0	360	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	200*25	0	87.93	f			Z23010508	调质110KSI			815	0	815	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	200*20	0	82.56	f			Z23010509	调质110KSI			930	0	930	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*35	0	98.24	f			Z23010510	调质110KSI			785	0	785	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	174*30	0	96.94	f			Z23010511	调质110KSI			910	0	910	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	180*25	0	86	f			Z23010514	调质110KSI			900	0	900	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	146*28	0	10.18	f			Z23010517	调质110KSI			125	0	125	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	200*15	0	75.62	f			Z23010518	调质110KSI			1105	0	1105	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	108*30	0	15	f			Z23010521	调质110KSI			260	0	260	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*20	0	124.55	f			Z23010522	调质110KSI			1380	0	1380	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*12	0	66.16	f			Z23010523	调质110KSI			1080	0	1080	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*35	0	34.68	f			Z23010524	调质110KSI			410	0	410	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	203*20	0	143.51	f			Z23010525	调质110KSI			1590	0	1590	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	219*25	0	236.21	f			Z23010527	调质110KSI			1975	0	1975	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	184*20	0	7.68	f			L519	调质			95	0	95	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	140*30	0	289.71	f			L488	热轧			3560	0	3560	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	120*40	0	159.4	f			Z230331-1	未调			2020	0	2020	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*17	0	22.24	f			Z230510-17	未调			510	0	510	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*17	0	22.24	f			Z230510-18	未调			510	0	510	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	121*17	0	22.24	f			Z230510-20	未调			510	0	510	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	133*20	0	27.87	f			Z230510-21	未调			500	0	500	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_102	83*14	0	18.1	f			Z230510-22	未调			760	0	760	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_107	110	0	83.62	f	 		M000844-B	热轧	 	 	1120	0	1120	0	0	0	 	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_110	110	0	223.97	f			M000844-A	热轧	GB/T3077-2015	179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000	3000	0	3000	0	0	0	鑫禹泽	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_110	150	0	480.33	f			M001787	热轧	GB/T3077-2015	179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000	3460	0	3460	0	0	0	重庆钢铁	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_110	120	0	266.54	f			Z23010562	热轧			3000	0	3000	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	203*28	0	1087.5	f	 		M005565	调质-80KSI	YTG 001-2021	23106840	9000	0	9000	0	0	0	衡钢	天津	否	是			86	0	0	0	0	0	f	f	f	室内	RK202312-06
3_110	160	0	154.79	f			M003855	热轧	GB/T3077-2015	179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000	980	0	980	0	0	0	重庆钢铁	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_110	220	0	132.89	f			M005364	未正火	GB/T3077-2015	179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000	445	0	445	0	0	0	重庆钢铁	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1692.35	f			M001235	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121255	5185	0	5185	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1689.08	f			M001236	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121255	5175	0	5175	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1130.95	f			M001239	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121255	3465	0	3465	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1693.98	f			M001557	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121255	5190	0	5190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1693.98	f			M001559	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121255	5190	0	5190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1693.98	f			M001561	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121255	5190	0	5190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1445.92	f			M003104	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120491	4430	0	4430	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1292.52	f			M003105	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120491	3960	0	3960	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	2049.75	f			M003106	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120491	6280	0	6280	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	2049.75	f			M003107	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120491	6280	0	6280	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	230	0	1853.91	f			M003108	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120491	5680	0	5680	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	8.96	f			M001701	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	30	0	30	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	34.34	f			L395	调质-110KSI	QJ/DT01.24548-2021-A/0	21209122762	115	0	115	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	119.45	f	黑皮		Z23010214	调质-110KSI	QJ/DT01.24548-2021-A/0	21209122762	400	0	400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1496.13	f			M002651	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	5010	0	5010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1540.92	f			M002652	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	5160	0	5160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1549.88	f			M002653	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	5190	0	5190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1028.77	f			M002654	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	3445	0	3445	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1033.25	f			M002655	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	3460	0	3460	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1039.23	f			M002657	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	3480	0	3480	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1030.27	f			M002658	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	3450	0	3450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1033.25	f			M002659	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	3460	0	3460	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1027.28	f			M002660	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120039	3440	0	3440	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1912.71	f			M003092	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6405	0	6405	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1956.01	f			M003093	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6550	0	6550	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1929.14	f			M003094	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6460	0	6460	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1956.01	f			M003095	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6550	0	6550	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1836.56	f			M003096	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1948.55	f			M003097	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6525	0	6525	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1966.47	f	有缺陷		M003098	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6585	0	6585	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1973.93	f			M003099	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6610	0	6610	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	2003.79	f			M003100	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6710	0	6710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1997.82	f			M003101	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6690	0	6690	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1914.21	f			M003102	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6410	0	6410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1981.4	f			M003103	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120492	6635	0	6635	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1549.88	f			M004626	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121074	5190	0	5190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1548.39	f			M004627	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121074	5185	0	5185	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	400.16	f			M004628	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121074	1340	0	1340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1549.88	f			M004629	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121074	5190	0	5190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	220	0	1030.27	f			M004630	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121074	3450	0	3450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	210	0	1844.82	f			M002336	调质-110KSI	QJ/DT01.24548-2021-B/0	22209122786	6780	0	6780	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	210	0	1842.1	f			M002337	调质-110KSI	QJ/DT01.24548-2021-B/0	22209122786	6770	0	6770	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	210	0	1858.42	f			M002338	调质-110KSI	QJ/DT01.24548-2021-B/0	22209122786	6830	0	6830	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	210	0	1844.82	f			M002339	调质-110KSI	QJ/DT01.24548-2021-B/0	22209122786	6780	0	6780	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	210	0	1289.74	f			M000812	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111769	4740	0	4740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	210	0	95.23	f			Z23010215	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111769	350	0	350	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	49.36	f			M001243	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	200	0	200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1409.23	f			M001244	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	5710	0	5710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1431.44	f			M001245	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	5800	0	5800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1422.8	f			M001247	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	5765	0	5765	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1411.7	f			M001248	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	5720	0	5720	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1445.01	f			M001249	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	5855	0	5855	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	97.49	f			M001250	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	395	0	395	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	301.1	f			M001252	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	1220	0	1220	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	7.9	f			L373	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111772	32	0	32	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1380.35	f			L354	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111772	5593	0	5593	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1406.76	f			L355	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111772	5700	0	5700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1332.72	f			L353	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111772	5400	0	5400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1244.61	f			L352	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111772	5043	0	5043	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1290.76	f			L351	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111772	5230	0	5230	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1195.75	f			L350	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111772	4845	0	4845	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1113.07	f			L349	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111772	4510	0	4510	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	200	0	1389.98	f			M001594	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121256	5632	0	5632	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1189.42	f			L240	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5340	0	5340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1275.61	f			L241	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5727	0	5727	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1301.9	f			L242	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5845	0	5845	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1189.42	f			L156	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5340	0	5340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1313.03	f			L391	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5895	0	5895	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1311.92	f			L390	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5890	0	5890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1184.96	f			L387	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5320	0	5320	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1282.97	f			L389	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5760	0	5760	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1300.78	f			L386	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5840	0	5840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1262.92	f			L388	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5670	0	5670	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	1294.77	f			L253	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	5813	0	5813	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	537.91	f			L375	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	2415	0	2415	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	190	0	445.47	f			L374	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111775	2000	0	2000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	675.69	f			L367	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	3380	0	3380	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	703.68	f			L380	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	3520	0	3520	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	683.69	f			L378	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	3420	0	3420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	661.7	f			L368	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	3310	0	3310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	29.99	f			L366	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	150	0	150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	239.89	f			L376	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	1200	0	1200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	71.97	f			L205	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	360	0	360	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	52.98	f			L192	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	265	0	265	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	180	0	95.96	f			M371	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111778	480	0	480	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	1053.83	f			M001576	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	5910	0	5910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	1056.5	f			M001577	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	5925	0	5925	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	1063.64	f			M001578	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	5965	0	5965	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	47.25	f			M001579	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	265	0	265	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	173.86	f			M001581	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	975	0	975	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	2.67	f			M001586	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	15	0	15	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	1069.88	f			M001589	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	6000	0	6000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	1055.61	f			M001590	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	5920	0	5920	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	1050.26	f			M001591	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	5890	0	5890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	1052.94	f			M001592	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	5905	0	5905	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	170	0	1044.91	f			M001593	调质-110KSI	QJ/DT01.24548-2021-A/0	22209121261	5860	0	5860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	165	0	4.2	f			L196	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111779	25	0	25	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1115.14	f			M004606	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121074	7060	0	7060	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1122.25	f			M004607	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121074	7105	0	7105	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1143.57	f			M004608	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121074	7240	0	7240	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1156.21	f			M004609	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121074	7320	0	7320	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1072.49	f			M004610	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121074	6790	0	6790	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1118.3	f			M004611	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121074	7080	0	7080	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1124.62	f			M004612	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121074	7120	0	7120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1138.83	f			M004613	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121074	7210	0	7210	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	155	0	140.82	f			M003267	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120311	950	0	950	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	155	0	316.33	f			M003268	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120311	2134	0	2134	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	155	0	1236.27	f			M003270	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120311	8340	0	8340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	155	0	1257.77	f			M003271	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120311	8485	0	8485	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	155	0	1307.43	f			M003272	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120311	8820	0	8820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	155	0	1265.18	f			M003273	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120311	8535	0	8535	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	854.47	f			M004614	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6155	0	6155	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	855.86	f			M004615	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6165	0	6165	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	862.1	f			M004616	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6210	0	6210	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	855.16	f			M004618	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	832.95	f			M004619	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6000	0	6000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	855.16	f			M004620	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	857.94	f			M004621	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	852.39	f			M004622	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	832.95	f			M004623	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6000	0	6000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	839.89	f			M004624	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	6050	0	6050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	39.57	f			M004625	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121068	285	0	285	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	846.83	f			M005350	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	839.89	f			M005351	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	6050	0	6050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	856.55	f			M005352	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	845.44	f			M005353	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	6090	0	6090	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	860.72	f			M005354	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	857.94	f			M005355	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	842.67	f			M005356	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	823.23	f			M005357	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	5930	0	5930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	824.62	f			M005358	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	5940	0	5940	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	799.63	f			M005359	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121068	5760	0	5760	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	807.22	f			M004203	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121054	6675	0	6675	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	834.91	f			M004204	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121054	6904	0	6904	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	830.2	f			M004205	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121054	6865	0	6865	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	846.52	f			M004206	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121054	7000	0	7000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	846.52	f			M004207	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121054	7000	0	7000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	844.11	f			M004208	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121054	6980	0	6980	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	817.5	f			M004209	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121054	6760	0	6760	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	355.54	f			M005344	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	2940	0	2940	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	857.41	f			M005345	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	7090	0	7090	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	853.78	f			M005346	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	7060	0	7060	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	832.01	f			M005347	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	6880	0	6880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	854.99	f			M005348	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	7070	0	7070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	790.9	f			M005349	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	6540	0	6540	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	802.99	f			M005360	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	6640	0	6640	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	825.97	f			M005361	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	6830	0	6830	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	749.78	f			M005362	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	805.41	f			M005363	调质-110KSI	QJ/DT01.24548-2021-B/0	23209121054	6660	0	6660	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	9	f			L143	调质-110KSI	QJ/DT01.24548-2021-A/0	2120911874	80	0	80	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	2.81	f			L134	调质-110KSI	QJ/DT01.24548-2021-A/0	2120911874	25	0	25	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	94.91	f	302+302+240		L128	调质-110KSI	QJ/DT01.24548-2021-A/0	2120911874	844	0	844	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	18.89	f			L124	调质-110KSI	QJ/DT01.24548-2021-A/0	2120911874	168	0	168	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	9	f			L123	调质-110KSI	QJ/DT01.24548-2021-A/0	2120911874	80	0	80	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	1.91	f			L137	调质-110KSI	QJ/DT01.24548-2021-A/0	2120911874	17	0	17	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	8.21	f			L131	调质-110KSI	QJ/DT01.24548-2021-A/0	2120911874	73	0	73	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	638.15	f			M003279	调质-110KSI	QJ/DT01.24548-2021-B/0	21209120311	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	326.17	f			M003280	调质-110KSI	QJ/DT01.24548-2021-B/0	21209120311	3128	0	3128	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	605.83	f			M003281	调质-110KSI	QJ/DT01.24548-2021-B/0	21209120311	5810	0	5810	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	95.41	f			M003282	调质-110KSI	QJ/DT01.24548-2021-B/0	21209120311	915	0	915	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	878.5	f			M003865	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	8425	0	8425	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	852.95	f			M003866	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	8180	0	8180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	15.12	f			M003867	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	145	0	145	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	858.69	f			M003868	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	8235	0	8235	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	860.77	f			M003869	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	8255	0	8255	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	875.37	f			M003870	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	8395	0	8395	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	662.65	f			M003871	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	6355	0	6355	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	643.89	f			M003872	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	6175	0	6175	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	668.39	f			M003873	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	6410	0	6410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	53.18	f			M003874	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	510	0	510	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	859.21	f			M003875	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	8240	0	8240	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	844.61	f			M003876	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	8100	0	8100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	27.63	f			M003877	调质-110KSI	QJ/DT01.24548-2021-B/O	23209120491	265	0	265	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	624.6	f			M005336	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121103	5990	0	5990	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	601.66	f			M005337	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121103	5770	0	5770	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	583.93	f			M005338	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121103	5600	0	5600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	641.28	f			M005339	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121103	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	641.28	f			M005340	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121103	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	641.28	f			M005341	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121103	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	625.64	f			M005342	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121103	6000	0	6000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	641.28	f			M005343	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121103	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	6.22	f			L155	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	70	0	70	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	9.77	f			L345	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	110	0	110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	11.55	f			L348	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	130	0	130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	11.55	f			L231	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	130	0	130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	8.53	f			Z230405-1	调质-110KSI	QJ/DT01.24548-2021-A/0		96	0	96	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	584.18	f			M004210	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6575	0	6575	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	599.72	f			M004211	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6750	0	6750	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	611.27	f			M004215	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6880	0	6880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	596.17	f			M004216	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6710	0	6710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	610.39	f			M004217	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6870	0	6870	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	609.5	f			M004218	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6860	0	6860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	541.97	f			M004219	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	442.02	f			M004221	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	4975	0	4975	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	610.39	f			M004226	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6870	0	6870	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	609.94	f			M004233	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121037	6865	0	6865	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	115	0	63.16	f			L271	调质-110KSI	QJ/DT01.24548-2021-A/0	2021135317	774	0	774	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	10.83	f			M001881	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	145	0	145	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	524.84	f			M001897	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	7030	0	7030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	6.35	f			M001902	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	85	0	85	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	499.08	f			M001904	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	6685	0	6685	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	9.71	f			L279	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	130	0	130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	11.2	f			L174	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	150	0	150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	25.38	f			M003266	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	340	0	340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	606.21	f			M005316	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8120	0	8120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	630.85	f			M005317	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8450	0	8450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	605.47	f			M005318	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8110	0	8110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	586.8	f			M005319	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	7860	0	7860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	604.72	f			M005320	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8100	0	8100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	605.47	f			M005321	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8110	0	8110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	605.47	f			M005322	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8110	0	8110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	605.47	f			M005323	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8110	0	8110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	606.96	f			M005324	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8130	0	8130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	630.85	f			M005325	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8450	0	8450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	601.74	f			M005326	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8060	0	8060	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	602.48	f			M005328	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8070	0	8070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	27.25	f			M005330	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	365	0	365	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	592.78	f			M005331	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	7940	0	7940	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	605.47	f			M005332	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8110	0	8110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	605.47	f			M005333	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8110	0	8110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	604.72	f			M005334	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	8100	0	8100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	592.03	f			M005335	调质-110KSI	QJ/DT01.24548-2021-C/0	23209121218	7930	0	7930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	8.33	f			M003290	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120311	135	0	135	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	53.37	f			M003292	调质-110KSI	QJ/DT01.24548-2021-B/0	23209120311	865	0	865	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	11.49	f			L256	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	220	0	220	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	73.37	f			L340	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	1405	0	1405	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	7.83	f			L338	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	150	0	150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	12.79	f			L339	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	245	0	245	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	0	f			L326	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	18	0	18	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	237.61	f			L274	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	4550	0	4550	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	14.1	f			L273	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	270	0	270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	225.08	f			L259	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	4310	0	4310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	230.3	f			L263	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	4410	0	4410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	15.4	f			M000724	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	390	0	390	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	94.38	f			M000721	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	2390	0	2390	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	95.96	f			M000720	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	2430	0	2430	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	229.03	f			M000718	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5800	0	5800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	93.78	f			M000717	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	2375	0	2375	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	11.45	f			M000716	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	290	0	290	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	229.03	f			M000714	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5800	0	5800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	229.03	f			M000713	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5800	0	5800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	229.03	f			M000712	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5800	0	5800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	229.03	f			M000711	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5800	0	5800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	227.85	f			M000710	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5770	0	5770	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	80	0	211.66	f			M000709	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5360	0	5360	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	129.27	f			L107	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	128.39	f			L108	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5780	0	5780	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	129.27	f			L104	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	129.27	f			L112	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	44.31	f	1395+600		L111	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	1995	0	1995	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	118.95	f			L114	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5355	0	5355	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	129.27	f			L110	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	129.27	f			L118	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	1.89	f			L122	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	85	0	85	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	129.27	f			L119	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	129.27	f			L116	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	108.39	f			L120	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	4880	0	4880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	60	0	129.27	f			L117	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111837	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	4.16	f			Z230510-1	调质-110KSI			30	0	30	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	140	0	71.35	f	打孔70		Z230510-2	调质-110KSI			590	0	590	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	155	0	68.93	f	打孔55		Z230510-3	调质-110KSI			465	0	465	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	92	0	3.86	f			Z230510-5	调质-110KSI	QJ/DT01.24548-2021-A/0	21209111899	74	0	74	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	110	0	24.64	f	打孔55		Z230510-6	调质-110KSI	QJ/DT01.24548-2021-B/0	22209112176	330	0	330	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	310	0	438.18	f			M001870	调质-80KSI	QJ/DT01.24412-2020-B/0	22210023812	739	0	739	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	305	0	401.77	f			M001872	调质-80KSI	QJ/DT01.24412-2020-B/0	22210023855	700	0	700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	58.23	f			M001553	调质-80KSI	QJ/DT01.24412-2020-B/0	22210023579	195	0	195	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	2054.56	f			M002304	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020032	6880	0	6880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	32.85	f			M002305	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020032	110	0	110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	19.41	f	自用		M002307	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020032	65	0	65	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	198.59	f	135+530		M002309	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020032	665	0	665	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	53.75	f			M000646	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021283	180	0	180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	2006.78	f			M001542	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010854	6720	0	6720	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	88.69	f	87+210		M001544	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010854	297	0	297	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	2063.52	f			M001545	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010854	6910	0	6910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	1964.97	f			M001547	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010854	6580	0	6580	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	1636.48	f			M001549	调质-80KSI	QJ/DT01.24412-2020-B/0	22210023579	5480	0	5480	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	5.97	f	自用		M001550	调质-80KSI	QJ/DT01.24412-2020-B/0	22210023579	20	0	20	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	13.44	f			M001570	调质-80KSI	QJ/DT01.24412-2020-B/0	22210023812	45	0	45	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	62.71	f			M001684	调质-80KSI	QJ/DT01.24412-2020-B/0	22210023812	210	0	210	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	220	0	71.67	f			M000512	调质-80KSI	QJ/DT01.24412-2020-B/0	22210023812	240	0	240	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	210	0	1779.51	f			M002312	调质-80KSI	QJ/DT01.24412-2020-B/0	22210024862	6540	0	6540	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	210	0	73.47	f			M002313	调质-80KSI	QJ/DT01.24412-2020-B/0	22210024862	270	0	270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	210	0	480.25	f			M001968	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023855	1765	0	1765	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	210	0	1866.59	f			M001970	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023855	6860	0	6860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	210	0	235.09	f	660+200		M001971	调质-80KSI	QJ/DT01.24669-2021-B/0	22210023855	864	0	864	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	200	0	1554.84	f			M002314	调质-80KSI	QJ/DT01.24412-2020-A/0	23210020022	6300	0	6300	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	200	0	1456.12	f			M002315	调质-80KSI	QJ/DT01.24412-2020-A/0	23210020022	5900	0	5900	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	200	0	128.34	f			M002316	调质-80KSI	QJ/DT01.24412-2020-A/0	23210020022	520	0	520	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	200	0	608.36	f	2255处切断		M002317	调质-80KSI	QJ/DT01.24412-2020-A/0	23210020022	2465	0	2465	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	190	0	38.98	f			M000678	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021288	175	0	175	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	190	0	135.87	f			M000679	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021288	610	0	610	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	190	0	651.51	f			M000680	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021288	2925	0	2925	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	68.97	f			M000661	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021288	345	0	345	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1201.45	f			M000662	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021288	6010	0	6010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1115.49	f			M000663	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021288	5580	0	5580	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1156.47	f			M000698	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021288	5785	0	5785	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1381.36	f			M002320	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020022	6910	0	6910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1347.38	f			M002321	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020022	6740	0	6740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	374.83	f			M002322	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020022	1875	0	1875	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1374.37	f			M002323	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020022	6875	0	6875	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1385.36	f			M002324	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020022	6930	0	6930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1381.36	f			M002325	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020022	6910	0	6910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1373.37	f			M002326	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020022	6870	0	6870	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	1256.42	f			M002327	调质-80KSI	QJ/DT01.24412-2020-B/0	23210020022	6285	0	6285	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	30.31	f			M001680	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	170	0	170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	43.69	f			M001682	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	245	0	245	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1205.4	f			M001683	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6760	0	6760	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1161.71	f			M002329	调质-80KSI	QJ-DT01.24412-2020-B/0	22210025474	6515	0	6515	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1197.37	f			M002330	调质-80KSI	QJ-DT01.24412-2020-B/0	22210025474	6715	0	6715	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1182.22	f			M002331	调质-80KSI	QJ-DT01.24412-2020-B/0	22210025474	6630	0	6630	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1166.17	f			M002332	调质-80KSI	QJ-DT01.24412-2020-B/0	22210025474	6540	0	6540	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1187.56	f			M002333	调质-80KSI	QJ-DT01.24412-2020-B/0	22210025474	6660	0	6660	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1198.26	f			M002334	调质-80KSI	QJ-DT01.24412-2020-B/0	22210025474	6720	0	6720	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1200.05	f			M002335	调质-80KSI	QJ-DT01.24412-2020-B/0	22210025474	6730	0	6730	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	105.2	f			M001676	调质-80KSI	QJ-DT01.24412-2020-B/0	22210025474	590	0	590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	74.89	f			M002626	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	420	0	420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	7.13	f			M002628	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	40	0	40	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	55.28	f			M002629	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	310	0	310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	121.25	f	90+590		M002633	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	680	0	680	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	52.6	f			M002634	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	295	0	295	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1160.82	f			M002637	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	6510	0	6510	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	62.41	f			M002638	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	350	0	350	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	6.24	f			M002640	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	35	0	35	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1157.25	f			M002641	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	6490	0	6490	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1171.52	f			M002642	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	6570	0	6570	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1094.84	f			M002643	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	170	0	1194.7	f			M002644	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020566	6700	0	6700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	160	0	6.79	f			M001598	调质-80KSI	QJ-DT01.24412-2020-B/0	22210010854	43	0	43	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	160	0	12.64	f			M001602	调质-80KSI	QJ-DT01.24412-2020-B/0	22210010854	80	0	80	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	160	0	9.48	f			M001620	调质-80KSI	QJ-DT01.24412-2020-B/0	22210010854	60	0	60	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	160	0	1138.83	f			M004180	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	7210	0	7210	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	160	0	1140.41	f			M004181	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	7220	0	7220	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	160	0	55.28	f			M004182	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	350	0	350	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	160	0	1154.63	f			M004183	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	7310	0	7310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	55.53	f			M001688	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010854	400	0	400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	83.99	f			M001694	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010854	605	0	605	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	7.64	f			M000653	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021293	55	0	55	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	18.05	f			M000659	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021293	130	0	130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	8.33	f			M002804	调质-80KSI	QJ/DT01.24412-2020-B/0	22210020445	60	0	60	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	796.86	f			M004184	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	792.69	f			M004185	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	5710	0	5710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	792.69	f			M004186	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	5710	0	5710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	858.63	f			M004187	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6185	0	6185	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	841.97	f			M004188	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6065	0	6065	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	830.17	f			M004189	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	5980	0	5980	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	842.67	f			M004190	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	701.07	f			M004191	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	5050	0	5050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	771.87	f			M004341	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5560	0	5560	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	843.36	f			M004342	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6075	0	6075	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	802.41	f			M004343	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5780	0	5780	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	839.2	f			M004344	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6045	0	6045	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	848.91	f			M004348	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6115	0	6115	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	842.67	f			M004350	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	857.94	f			M004345	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	859.33	f			M004346	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	869.04	f			M004347	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6260	0	6260	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	860.72	f			M004349	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	870.43	f			M004352	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6270	0	6270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	823.23	f			M004353	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	5930	0	5930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	702.45	f			M004354	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	5060	0	5060	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	839.89	f			M004355	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6050	0	6050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	870.43	f			M004356	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6270	0	6270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	860.72	f			M004357	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	842.67	f			M004358	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	860.72	f			M004359	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	870.43	f			M004360	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6270	0	6270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	870.43	f			M004361	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6270	0	6270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	860.72	f			M004362	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	846.83	f			M004363	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023328	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	13.91	f			M002719	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025810	115	0	115	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	9.67	f			M002724	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025810	80	0	80	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	854.99	f			M004192	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	7070	0	7070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	852.57	f			M004193	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	7050	0	7050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	829.59	f			M004194	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6860	0	6860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	850.15	f			M004195	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	7030	0	7030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	812.66	f			M004196	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6720	0	6720	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	852.57	f			M004197	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	7050	0	7050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	796.94	f			M004198	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6590	0	6590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	828.99	f			M004199	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6855	0	6855	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	853.78	f			M004200	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	7060	0	7060	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	735.27	f			M004201	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6080	0	6080	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	748.57	f			M004202	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	833.22	f			M004635	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6890	0	6890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	799.36	f			M004636	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6610	0	6610	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	813.87	f			M004637	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6730	0	6730	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	839.27	f			M004638	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6940	0	6940	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	798.15	f			M004639	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6600	0	6600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	788.48	f			M004640	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6520	0	6520	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	811.45	f			M004641	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6710	0	6710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	763.08	f			M004642	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6310	0	6310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	705.03	f			M004643	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5830	0	5830	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	495.82	f			M004644	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4100	0	4100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	552.66	f			M004645	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4570	0	4570	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	628.85	f			M004646	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5200	0	5200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	620.38	f			M004647	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5130	0	5130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	790.9	f			M004433	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6540	0	6540	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	730.43	f			M004434	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6040	0	6040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	836.85	f			M004435	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6920	0	6920	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	838.06	f			M004436	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6930	0	6930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	754.62	f			M004437	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6240	0	6240	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	771.55	f			M004438	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	6380	0	6380	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	712.29	f			M004439	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	5890	0	5890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	650.61	f			M004440	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023013	5380	0	5380	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	460.75	f			M004441	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	3810	0	3810	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	597.4	f			M004442	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4940	0	4940	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	544.19	f			M004443	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4500	0	4500	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	140	0	753.41	f			M004444	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6230	0	6230	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	1.56	f			L090	调质-80KSI	QJ/DT01.24412-2020-A/0	21209121840	15	0	15	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	6.05	f			L089	调质-80KSI	QJ/DT01.24412-2020-A/0	21209121840	58	0	58	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	2.09	f			L084	调质-80KSI	QJ/DT01.24412-2020-A/0	21209121840	20	0	20	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	3.65	f			M002699	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	35	0	35	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	19.81	f			M002701	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	190	0	190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	52.66	f			M002728	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	505	0	505	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	189.26	f			M002729	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	1815	0	1815	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	201.77	f			M002730	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	1935	0	1935	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	406.66	f			M002731	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	3900	0	3900	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	10.43	f			M002732	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	100	0	100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	641.28	f			M004415	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	637.11	f			M004416	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	6110	0	6110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	734.08	f			M004417	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7040	0	7040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	636.07	f			M004418	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	836.27	f			M004419	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8020	0	8020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	836.79	f			M004420	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8025	0	8025	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	835.23	f			M004421	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8010	0	8010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	836.27	f			M004422	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8020	0	8020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	834.18	f			M004423	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8000	0	8000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	834.18	f			M004424	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8000	0	8000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	804.99	f			M004425	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7720	0	7720	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	834.71	f			M004426	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8005	0	8005	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	796.65	f			M004427	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7640	0	7640	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	804.47	f			M004428	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7715	0	7715	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	802.9	f			M004429	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7700	0	7700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	837.31	f			M004430	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8030	0	8030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	836.27	f			M004431	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8020	0	8020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	833.14	f			M004432	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7990	0	7990	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	791.43	f			M004570	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7590	0	7590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	841.48	f			M004571	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8070	0	8070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	834.18	f			M004572	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8000	0	8000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	821.67	f			M004573	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7880	0	7880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	835.23	f			M004574	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	8010	0	8010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	803.94	f			M004575	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023106	7710	0	7710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	642.32	f			M004407	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023624	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	643.36	f			M004408	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023624	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	640.24	f			M004409	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023624	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	640.24	f			M004410	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023624	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	370.17	f			M004411	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023624	3550	0	3550	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	340.97	f			M004412	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023624	3270	0	3270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	643.36	f			M004413	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023624	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	130	0	642.32	f			M004414	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023624	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	604.17	f			M002812	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	6800	0	6800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	605.94	f			M002813	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	6820	0	6820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	299.42	f			M002814	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	3370	0	3370	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	609.5	f			M002816	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	6860	0	6860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	607.28	f			M002817	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	6835	0	6835	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	619.27	f			M002819	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	6970	0	6970	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	607.72	f			M002820	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	6840	0	6840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	614.83	f			M002825	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	6920	0	6920	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	607.72	f			M002826	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	6840	0	6840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	624.6	f			M002827	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	7030	0	7030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	25.77	f			M002830	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	290	0	290	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	480.22	f			M002832	调质-80KSI	QJ-DT01.24412-2020-B/0	22210020445	5405	0	5405	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	617.49	f			M004631	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6950	0	6950	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	604.17	f			M004632	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6800	0	6800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	615.72	f			M004633	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6930	0	6930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	614.83	f			M004634	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6920	0	6920	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	469.12	f			M004552	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	5280	0	5280	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	508.21	f			M004553	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	5720	0	5720	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	509.99	f			M004554	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	618.38	f			M004559	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6960	0	6960	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	637.04	f			M004560	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	7170	0	7170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	568.63	f			M004561	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6400	0	6400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	648.59	f			M004562	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	7300	0	7300	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	626.38	f			M004563	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	7050	0	7050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	614.83	f			M004564	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6920	0	6920	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	662.36	f			M004565	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	7455	0	7455	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	713.89	f			M004566	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	8035	0	8035	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	715.23	f			M004567	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	8050	0	8050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	715.23	f			M004568	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	8050	0	8050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	715.23	f			M004569	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	8050	0	8050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	621.05	f			M004671	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6990	0	6990	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	613.94	f			M004672	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6910	0	6910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	622.82	f			M004673	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	7010	0	7010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	607.28	f			M004674	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6835	0	6835	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	605.05	f			M004675	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6810	0	6810	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	614.38	f			M004676	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6915	0	6915	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	649.48	f			M004677	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	7310	0	7310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	647.7	f			M004678	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	7290	0	7290	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	523.76	f			M004679	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	5895	0	5895	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	533.98	f			M004680	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6010	0	6010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	586.4	f			M004681	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6600	0	6600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	537.09	f			M004682	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	6045	0	6045	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	715.23	f			M004687	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	8050	0	8050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	715.23	f			M004688	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	8050	0	8050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	677.02	f			M004689	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023136	7620	0	7620	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	590.39	f			M004683	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6645	0	6645	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	617.49	f			M004684	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6950	0	6950	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	612.16	f			M004685	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6890	0	6890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	715.23	f			M004686	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	8050	0	8050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	414.72	f			M000961	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5555	0	5555	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	398.3	f			M000962	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5335	0	5335	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	410.61	f			M000963	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5500	0	5500	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	403.89	f			M000964	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5410	0	5410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	383.36	f			M000965	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5135	0	5135	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	400.16	f			M000966	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5360	0	5360	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	371.79	f			M000971	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	4980	0	4980	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	397.92	f			M000973	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5330	0	5330	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	410.61	f			M000974	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5500	0	5500	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	415.47	f			M000975	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	5565	0	5565	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	3.73	f			M000976	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	50	0	50	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	25.76	f			M000978	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	345	0	345	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	11.2	f			M000979	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	150	0	150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	2.24	f			M000980	调质-80KSI	QJ-DT01.24412-2020-A/0	22210022373	30	0	30	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	5.23	f			M002736	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	70	0	70	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	2.24	f			M002737	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	30	0	30	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	18.29	f			M002738	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	245	0	245	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	1.87	f			M002739	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	25	0	25	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	453.17	f			M002740	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	449.44	f			M002741	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	6020	0	6020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	453.17	f			M002742	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	453.91	f			M002744	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	6080	0	6080	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	453.17	f			M002745	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	451.67	f			M002746	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	6050	0	6050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	453.91	f			M002747	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	6080	0	6080	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	397.18	f			M004555	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010670	5320	0	5320	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	396.43	f			M004556	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010670	5310	0	5310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	437.49	f			M004557	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010670	5860	0	5860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	368.81	f			M004558	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010670	4940	0	4940	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	461.38	f			M004690	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	331.48	f			M004692	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4440	0	4440	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	306.09	f			M004693	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4100	0	4100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	436	f			M004694	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5840	0	5840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	287.43	f			M004695	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	3850	0	3850	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	304.23	f			M004697	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4075	0	4075	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	316.55	f			M004698	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4240	0	4240	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	288.18	f			M004699	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	3860	0	3860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	412.11	f			M004701	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5520	0	5520	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	342.68	f			M004702	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	4590	0	4590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	416.29	f			M004703	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5576	0	5576	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	404.64	f			M004704	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5420	0	5420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	407.25	f			M004705	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5455	0	5455	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	411.36	f			M004706	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5510	0	5510	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	433.76	f			M004707	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5810	0	5810	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	512.15	f			M004708	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6860	0	6860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	428.16	f			M004709	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5735	0	5735	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	430.02	f			M004710	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5760	0	5760	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	609.95	f			M004711	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8170	0	8170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	612.19	f			M004712	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8200	0	8200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	600.24	f			M004713	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8040	0	8040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	620.4	f			M004714	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8310	0	8310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	585.31	f			M004715	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	7840	0	7840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	600.24	f			M004716	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8040	0	8040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	593.52	f			M004717	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	7950	0	7950	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	523.35	f			M004718	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	7010	0	7010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	618.16	f			M004719	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8280	0	8280	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	489.75	f			M004691	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	6560	0	6560	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	212.03	f			M004696	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	2840	0	2840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	384.86	f			M004700	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	5155	0	5155	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	617.41	f			M004582	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8270	0	8270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	568.89	f			M004583	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	7620	0	7620	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	615.92	f			M004584	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8250	0	8250	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	609.2	f			M004585	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8160	0	8160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	479.3	f			M004586	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	6420	0	6420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	582.32	f			M004587	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	7800	0	7800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	615.92	f			M004588	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8250	0	8250	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	605.84	f			M004589	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8115	0	8115	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	662.95	f			M004590	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8880	0	8880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	583.82	f			M004591	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	7820	0	7820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	608.45	f			M004592	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8150	0	8150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	613.68	f			M004593	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8220	0	8220	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	610.69	f			M004594	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8180	0	8180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	620.4	f			M004595	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8310	0	8310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	618.53	f			M004596	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8285	0	8285	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	565.9	f			M004597	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	7580	0	7580	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	608.45	f			M004598	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8150	0	8150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	599.5	f			M004599	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8030	0	8030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	616.67	f			M004600	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8260	0	8260	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	622.27	f			M004601	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8335	0	8335	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	599.5	f			M004602	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8030	0	8030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	486.02	f			M004603	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	6510	0	6510	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	602.48	f			M004604	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8070	0	8070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	110	0	599.5	f			M004605	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023205	8030	0	8030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	15.12	f			L011	调质-80KSI	QJ-DT01.24412-2020-A/0	21209123087	245	0	245	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	3.09	f			M001003	调质-80KSI	QJ-DT01.24412-2020-A/0	22209120311	50	0	50	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	8.02	f			M001004	调质-80KSI	QJ-DT01.24412-2020-A/0	22209120311	130	0	130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	2.78	f			M001006	调质-80KSI	QJ-DT01.24412-2020-A/0	22209120311	45	0	45	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	7.77	f			M001007	调质-80KSI	QJ-DT01.24412-2020-A/0	22209120311	126	0	126	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	4.75	f			M001009	调质-80KSI	QJ-DT01.24412-2020-A/0	22209120311	77	0	77	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	56.76	f			M001011	调质-80KSI	QJ-DT01.24412-2020-A/0	22209120311	920	0	920	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	3.21	f			M001014	调质-80KSI	QJ-DT01.24412-2020-A/0	22209120311	52	0	52	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	29.31	f			L100	调质-80KSI	QJ-DT01.24412-2020-A/0	22209120311	475	0	475	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	1.11	f			M002748	调质-80KSI	QJ-DT01.24412-2020-B/0	23210020445	18	0	18	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	398.58	f			M004374	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6460	0	6460	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	20	12.96	f	 		L010	调质-80KSI	QJ-DT01.24412-2020-A/0	21209123087	210	0	210	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	100	0	411.23	f			M004375	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6665	0	6665	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	388.09	f			M004376	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6290	0	6290	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	399.2	f			M004377	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6470	0	6470	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	389.94	f			M004378	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6320	0	6320	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	400.43	f			M004379	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6490	0	6490	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	370.82	f			M004380	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6010	0	6010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	377.3	f			M004381	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6115	0	6115	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	368.04	f			M004391	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5965	0	5965	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	354.78	f			M004392	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5750	0	5750	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	364.03	f			M004393	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5900	0	5900	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	366.19	f			M004394	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5935	0	5935	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	362.18	f			M004395	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5870	0	5870	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	329.48	f			M004396	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5340	0	5340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	374.52	f			M004397	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	371.43	f			M004398	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6020	0	6020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	410.31	f			M004399	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6650	0	6650	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	375.14	f			M004400	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6080	0	6080	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	389.33	f			M004401	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6310	0	6310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	387.78	f			M004402	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6285	0	6285	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	352.31	f			M004403	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5710	0	5710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	354.16	f			M004404	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	358.17	f			M004405	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	5805	0	5805	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	375.44	f			M004406	调质-80KSI	QJ/DT01.24412-2020-B/0	23210010659	6085	0	6085	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	389.94	f			M004364	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6320	0	6320	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	363.41	f			M004365	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	5890	0	5890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	377.3	f			M004366	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6115	0	6115	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	385.01	f			M004367	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6240	0	6240	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	393.03	f			M004368	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6370	0	6370	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	381.31	f			M004369	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	386.24	f			M004370	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6260	0	6260	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	391.18	f			M004371	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6340	0	6340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	381.31	f			M004372	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	383.77	f			M004373	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6220	0	6220	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	389.94	f			M004382	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6320	0	6320	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	372.36	f			M004383	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6035	0	6035	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	386.86	f			M004384	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6270	0	6270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	395.5	f			M004385	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6410	0	6410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	392.41	f			M004386	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6360	0	6360	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	339.35	f			M004387	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	5500	0	5500	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	335.03	f			M004388	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	5430	0	5430	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	371.74	f			M004389	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6025	0	6025	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	383.77	f			M004390	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6220	0	6220	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	368.35	f			M004648	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	5970	0	5970	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	381.92	f			M004649	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	376.99	f			M004650	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6110	0	6110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	367.12	f			M004651	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	5950	0	5950	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	370.2	f			M004652	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6000	0	6000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	386.86	f			M004653	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6270	0	6270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	373.9	f			M004654	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6060	0	6060	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	395.5	f			M004655	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6410	0	6410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	396.73	f			M004656	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6430	0	6430	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	385.01	f			M004657	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6240	0	6240	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	382.54	f			M004658	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	384.39	f			M004659	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6230	0	6230	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	386.24	f			M004660	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6260	0	6260	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	394.88	f			M004661	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6400	0	6400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	389.33	f			M004662	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6310	0	6310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	386.86	f			M004663	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6270	0	6270	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	374.52	f			M004664	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	385.63	f			M004665	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6250	0	6250	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	385.63	f			M004666	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6250	0	6250	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	397.97	f			M004667	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6450	0	6450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	382.54	f			M004668	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	381.92	f			M004669	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	100	0	391.18	f			M004670	调质-80KSI	QJ/DT01.24412-2020-B/0	23210023179	6340	0	6340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	90	0	72.47	f			L630	调质-80KSI	QJ/DT01.24412-2020-A/0	21209123087	1450	0	1450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	290.98	f			M002835	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6090	0	6090	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	274.5	f			M002836	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	5745	0	5745	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	291.46	f			M002837	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	292.89	f			M002838	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	293.37	f			M002839	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	290.98	f			M002840	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6090	0	6090	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	290.98	f			M002841	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6090	0	6090	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	292.42	f			M002842	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	291.94	f			M002843	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6110	0	6110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	291.46	f			M002844	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	291.46	f			M002845	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	292.42	f			M002846	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	292.42	f			M002847	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	291.46	f			M002848	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	79.79	f			M002849	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	1670	0	1670	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	24.37	f			M002853	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	510	0	510	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	88	0	8.12	f			M002854	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025713	170	0	170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	17.77	f			M002866	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	450	0	450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	243.25	f			M002868	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	14.81	f			M002869	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	375	0	375	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	18.16	f			M002871	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	460	0	460	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	218.76	f			M002876	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	5540	0	5540	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	238.9	f			M002878	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6050	0	6050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	12.44	f			M002880	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	315	0	315	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	237.32	f			M002882	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6010	0	6010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	252.72	f			M002883	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6400	0	6400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	253.51	f			M002884	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6420	0	6420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	252.33	f			M002885	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6390	0	6390	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	253.12	f			M002886	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6410	0	6410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	200.6	f			M002887	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	5080	0	5080	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	253.51	f			M002888	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6420	0	6420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	253.51	f			M002889	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6420	0	6420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	252.72	f			M002890	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6400	0	6400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	238.11	f			M002891	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6030	0	6030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	238.9	f			M002892	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6050	0	6050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	237.72	f			M002893	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6020	0	6020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	238.51	f			M002894	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6040	0	6040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	16.39	f			M002895	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	415	0	415	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	144.53	f			M002896	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	3660	0	3660	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	236.93	f			M002897	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6000	0	6000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	228.24	f			M002898	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	5780	0	5780	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	239.69	f			M002899	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6070	0	6070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	231.4	f			M002900	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	5860	0	5860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	35.54	f			M002901	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	900	0	900	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	237.72	f			M002902	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6020	0	6020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	238.51	f			M002903	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6040	0	6040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	237.72	f			M002904	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6020	0	6020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	237.72	f			M002905	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6020	0	6020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	237.32	f			M002906	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6010	0	6010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	238.11	f			M002907	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6030	0	6030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	238.51	f			M002909	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6040	0	6040	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	238.11	f			M002910	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6030	0	6030	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	80	0	237.72	f			M002911	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6020	0	6020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	4.23	f			M000754	调质-80KSI	QJ/DT01.24412-2020-A/0	21209123087	140	0	140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	6.95	f			M000760	调质-80KSI	QJ/DT01.24412-2020-A/0	21209123087	230	0	230	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	51.4	f	1200+500		M000762	调质-80KSI	QJ/DT01.24412-2020-A/0	21209123087	1700	0	1700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	30.23	f			M000763	调质-80KSI	QJ/DT01.24412-2020-A/0	21209123087	1000	0	1000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	2.12	f			M000764	调质-80KSI	QJ/DT01.24412-2020-A/0	21209123087	70	0	70	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	75.88	f			M002661	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	2510	0	2510	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	190.47	f			M002662	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6300	0	6300	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	182.91	f			M002663	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6050	0	6050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	189.86	f			M002664	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6280	0	6280	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	190.17	f			M002665	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6290	0	6290	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	185.03	f			M002666	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	190.17	f			M002668	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6290	0	6290	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	201.65	f			M002669	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6670	0	6670	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	201.65	f			M002676	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6670	0	6670	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	202.86	f			M002677	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6710	0	6710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	201.96	f			M002678	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	6680	0	6680	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	5.29	f			M002680	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	175	0	175	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	70	0	2.72	f			M002681	调质-80KSI	QJ/DT01.24412-2020-B/0	22209122737	90	0	90	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000904	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.72	f			M000905	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5750	0	5750	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.72	f			M000906	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5750	0	5750	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000907	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000908	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.27	f			M000909	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5730	0	5730	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000910	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000911	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.94	f			M000913	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5760	0	5760	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000914	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.61	f			M000915	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5745	0	5745	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.61	f			M000918	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5745	0	5745	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	4.22	f			M000922	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	190	0	190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	16.21	f			M000925	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	730	0	730	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	2.22	f			M000928	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	100	0	100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	33.98	f			M000930	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	1530	0	1530	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000931	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000933	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.27	f			M000934	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5730	0	5730	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000937	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.61	f			M000938	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5745	0	5745	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000939	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	60	0	127.5	f			M000940	调质-80KSI	QJ/DT01.24412-2020-A/0	22210021787	5740	0	5740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.73	f			M003878	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6595	0	6595	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.65	f			M003879	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6590	0	6590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.65	f			M003880	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6590	0	6590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	89.7	f			M003881	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	5815	0	5815	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	97.95	f			M003882	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6350	0	6350	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.42	f			M003883	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6575	0	6575	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.65	f			M003884	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6590	0	6590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.34	f			M003885	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6570	0	6570	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.73	f			M003886	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6595	0	6595	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.81	f			M003887	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6600	0	6600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.5	f			M003888	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6580	0	6580	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.81	f			M003889	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6600	0	6600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	94.63	f			M003890	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6135	0	6135	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.65	f			M003891	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6590	0	6590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.57	f			M003892	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6585	0	6585	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.81	f			M003893	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6600	0	6600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.5	f			M003894	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6580	0	6580	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.57	f			M003895	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6585	0	6585	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.57	f			M003896	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6585	0	6585	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	79.52	f			M003897	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	5155	0	5155	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	47.89	f			M003898	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	3105	0	3105	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.57	f			M003899	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6585	0	6585	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.81	f			M003900	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6600	0	6600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	101.65	f			M003901	调质-80KSI	QJ/DT01.24412-2020-B/0	23210021903	6590	0	6590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	63.38	f			M002424	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6420	0	6420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	63.18	f			M002425	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6400	0	6400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	63.18	f			M002426	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6400	0	6400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	63.18	f			M002427	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6400	0	6400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	63.28	f			M002428	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6410	0	6410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	63.18	f			M002430	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6400	0	6400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	63.38	f			M002431	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6420	0	6420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	37.71	f			M002436	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	3820	0	3820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	63.38	f			M002441	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6420	0	6420	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	40	0	47.09	f			M002451	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	4770	0	4770	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002452	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	33.93	f			M002453	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6110	0	6110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	28.1	f			M002454	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	5060	0	5060	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	33.76	f			M002455	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6080	0	6080	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.32	f			M002456	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.26	f			M002457	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.1	f			M002458	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	33.87	f			M002459	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002460	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.37	f			M002461	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002462	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	33.98	f			M002463	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.21	f			M002464	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.21	f			M002465	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.1	f			M002466	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	33.87	f			M002467	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	33.82	f			M002468	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6090	0	6090	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.37	f			M002469	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002470	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.21	f			M002471	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.26	f			M002472	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.04	f			M002473	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.43	f			M002474	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6200	0	6200	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	35.04	f			M002475	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6310	0	6310	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.37	f			M002476	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.21	f			M002477	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.26	f			M002478	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002479	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.37	f			M002480	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002481	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.21	f			M002482	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002483	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.1	f			M002484	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	33.93	f			M002485	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6110	0	6110	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002486	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.54	f			M002487	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6220	0	6220	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.21	f			M002488	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.15	f			M002489	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	33.87	f			M002490	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6100	0	6100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.26	f			M002492	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	20.05	f			M002493	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	3610	0	3610	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.1	f			M002494	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.26	f			M002495	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.1	f			M002496	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.1	f			M002497	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.04	f			M002498	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.04	f			M002499	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	34.1	f			M002500	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	30	0	5.19	f			M002501	调质-80KSI	QJ/DT01.24412-2020-B/0	22210010849	935	0	935	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	120	0	8	f			M000190	调质-80KSI	QJ/DT01.24412-2020-A/0	22209120311	90	0	90	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	90	0	72.47	f			L030	调质-80KSI	QJ/DT01.24412-2020-A/0	21209123087	1450	0	1450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	210	0	57.14	f			Z23010314	调质-80KSI	QJ/DT01.24412-2020-A/0		210	0	210	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	185	0	156.26	f			L027	调质-80KSI	QJ/DT01.24412-2020-A/0		740	0	740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	185	0	21.12	f			L065	调质-80KSI	QJ/DT01.24412-2020-A/0		100	0	100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	185	0	5.28	f			Z23020323	调质-80KSI	QJ/DT01.24412-2020-A/0		25	0	25	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	185	0	80.24	f			Z23010313	调质-80KSI	QJ/DT01.24412-2020-A/0		380	0	380	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	185	0	10.14	f			Z23010315	调质-80KSI	QJ/DT01.24412-2020-A/0		48	0	48	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	185	0	36.95	f			Z23010316	调质-80KSI	QJ/DT01.24412-2020-A/0		175	0	175	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	185	0	66.52	f			Z23010318	调质-80KSI	QJ/DT01.24412-2020-A/0		315	0	315	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	67.97	f			Z23010307	调质-80KSI	QJ/DT01.24412-2020-A/0		340	0	340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	180	0	67.97	f			Z23010317	调质-80KSI	QJ/DT01.24412-2020-A/0		340	0	340	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	165	0	23.52	f			Z23010310	调质-80KSI	QJ/DT01.24412-2020-A/0		140	0	140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	165	0	9.24	f			Z23010311	调质-80KSI	QJ/DT01.24412-2020-A/0		55	0	55	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	165	0	31.08	f			Z23010319	调质-80KSI	QJ/DT01.24412-2020-A/0		185	0	185	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	90	0	24.99	f			Z230510-23-A	调质-80KSI			500	0	500	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	90	0	19.74	f			Z230510-36	调质-80KSI			395	0	395	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	50	0	10.49	f			Z230510-37	调质-80KSI			680	0	680	0	0	0		天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	17.92	f	110*32打孔 110*32		M002125	调质110KSI	XYGN5189.2-2022-01	2031049Z	240	0	240	0	0	0	大冶特殊	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	162*25	0	814.2	f	 		M005510	调质-80KSI	YTG 001-2021	23106841	9640	0	9640	0	0	0	衡钢	天津	否	是			31	0	0	0	0	0	f	f	f	室内	RK202312-06
3_105	140	0	16.76	f	一端偏壁 140*50.8		M003835	调质110KSI	JX-2021-01	F22306309XA	150	0	150	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	547.54	f	一端偏壁 140*50.8		M003836	调质110KSI	JX-2021-01	F22306309XA	4900	0	4900	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	547.54	f	一端偏壁 140*50.8		M003837	调质110KSI	JX-2021-01	F22306309XA	4900	0	4900	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	547.54	f	一端偏壁 140*50.8		M003838	调质110KSI	JX-2021-01	F22306309XA	4900	0	4900	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	546.98	f	一端偏壁 140*50.8		M003839	调质110KSI	JX-2021-01	F22306309XA	4895	0	4895	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	548.66	f	一端偏壁 140*50.8		M003840	调质110KSI	JX-2021-01	F22306309XA	4910	0	4910	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	547.54	f	一端偏壁 140*50.8		M003841	调质110KSI	JX-2021-01	F22306309XA	4900	0	4900	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	547.54	f	一端偏壁 140*50.8		M003842	调质110KSI	JX-2021-01	F22306309XA	4900	0	4900	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	162*25	0	815.9	f	 		M005511	调质-80KSI	YTG 001-2021	23106841	9660	0	9660	0	0	0	衡钢	天津	否	是			32	0	0	0	0	0	f	f	f	室内	RK202312-06
3_105	140	0	299.51	f	一端偏壁 140*50.8		M003843	调质110KSI	JX-2021-01	F22306309XA	4880	4	2840	0	0	0	兴澄特钢+浩运	天津	是				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_105	140	0	0	f	一端偏壁 140*50.8		M003834	调质110KSI	JX-2021-01	F22306309XA	300	1	0	0	0	0	兴澄特钢+浩运	天津	是				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	162*25	0	833.6	f	 		M005512	调质-80KSI	YTG 001-2021	23106841	9870	0	9870	0	0	0	衡钢	天津	否	是			33	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	834.5	f	 		M005513	调质-80KSI	YTG 001-2021	23106841	9880	0	9880	0	0	0	衡钢	天津	否	是			34	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	831.1	f	 		M005514	调质-80KSI	YTG 001-2021	23106841	9840	0	9840	0	0	0	衡钢	天津	否	是			35	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	809.1	f	 		M005515	调质-80KSI	YTG 001-2021	23106841	9580	0	9580	0	0	0	衡钢	天津	否	是			36	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	804.1	f	 		M005516	调质-80KSI	YTG 001-2021	23106841	9520	0	9520	0	0	0	衡钢	天津	否	是			37	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	825.2	f	 		M005517	调质-80KSI	YTG 001-2021	23106841	9770	0	9770	0	0	0	衡钢	天津	否	是			38	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	829.4	f	 		M005518	调质-80KSI	YTG 001-2021	23106841	9820	0	9820	0	0	0	衡钢	天津	否	是			39	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	830.2	f	 		M005519	调质-80KSI	YTG 001-2021	23106841	9830	0	9830	0	0	0	衡钢	天津	否	是			40	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	823.5	f	 		M005520	调质-80KSI	YTG 001-2021	23106841	9750	0	9750	0	0	0	衡钢	天津	否	是			41	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	830.2	f	 		M005521	调质-80KSI	YTG 001-2021	23106841	9830	0	9830	0	0	0	衡钢	天津	否	是			42	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	162*25	0	815	f	 		M005522	调质-80KSI	YTG 001-2021	23106841	9650	0	9650	0	0	0	衡钢	天津	否	是			43	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	846.2	f	 		M005523	调质-80KSI	YTG 001-2021	23106841	9860	0	9860	0	0	0	衡钢	天津	否	是			44	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	935.4	f	 		M005524	调质-80KSI	YTG 001-2021	23106841	10900	0	10900	0	0	0	衡钢	天津	否	是			45	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	830.7	f	 		M005525	调质-80KSI	YTG 001-2021	23106841	9680	0	9680	0	0	0	衡钢	天津	否	是			46	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	937.1	f	 		M005526	调质-80KSI	YTG 001-2021	23106841	10920	0	10920	0	0	0	衡钢	天津	否	是			47	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	909.7	f	 		M005527	调质-80KSI	YTG 001-2021	23106841	10600	0	10600	0	0	0	衡钢	天津	否	是			48	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	833.3	f	 		M005528	调质-80KSI	YTG 001-2021	23106841	9710	0	9710	0	0	0	衡钢	天津	否	是			49	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	824.7	f	 		M005529	调质-80KSI	YTG 001-2021	23106841	9610	0	9610	0	0	0	衡钢	天津	否	是			50	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	839.3	f	 		M005530	调质-80KSI	YTG 001-2021	23106841	9780	0	9780	0	0	0	衡钢	天津	否	是			51	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	918.2	f	 		M005531	调质-80KSI	YTG 001-2021	23106841	10700	0	10700	0	0	0	衡钢	天津	否	是			52	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	839.3	f	 		M005532	调质-80KSI	YTG 001-2021	23106841	9780	0	9780	0	0	0	衡钢	天津	否	是			53	0	0	0	0	0	f	f	f	室内	RK202312-06
3_105	140	0	547.54	f	一端偏壁 140*50.8		M003844	调质110KSI	JX-2021-01	F22306309XA	4900	0	4900	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	545.87	f	一端偏壁 140*50.8		M003845	调质110KSI	JX-2021-01	F22306309XA	4885	0	4885	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	140	0	548.1	f	一端偏壁 140*50.8		M003846	调质110KSI	JX-2021-01	F22306309XA	4905	0	4905	0	0	0	兴澄特钢+浩运	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	170.41	f	一端偏壁 180*50.8		M003848	调质110KSI	XYGN1992.6-2022-01	2016234Z	1525	0	1525	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	537.49	f	一端偏壁 180*50.8		M003849	调质110KSI	XYGN1992.6-2022-01	2016234Z	4810	0	4810	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	540.84	f	一端偏壁 180*50.8		M003850	调质110KSI	XYGN1992.6-2022-01	2016234Z	4840	0	4840	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	167.62	f	一端偏壁 180*50.8		M003851	调质110KSI	XYGN1992.6-2022-01	2016234Z	1500	0	1500	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	180	0	539.72	f	一端偏壁 180*50.8		M003852	调质110KSI	XYGN1992.6-2022-01	2016234Z	4830	0	4830	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	537.49	f	一端偏壁 150*50.8		M003853	调质110KSI	XYGN5189.2-2022-01	3014166Z	4810	0	4810	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	150	0	365.4	f	一端偏壁 150*50.8		M003854	调质110KSI	XYGN5189.2-2022-01	3014166Z	3270	0	3270	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	159*24	0	687.1	f			M005439	调质80KSI	XYGN5203-2022-01	3075911M	8600	0	8600	0	0	0	冶钢	天津		是			1	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	700.7	f			M005440	调质80KSI	XYGN5203-2022-01	3075911M	8770	0	8770	0	0	0	冶钢	天津		是			2	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	704.7	f			M005441	调质80KSI	XYGN5203-2022-01	3075911M	8820	0	8820	0	0	0	冶钢	天津		是			3	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	706.3	f			M005442	调质80KSI	XYGN5203-2022-01	3075911M	8840	0	8840	0	0	0	冶钢	天津		是			4	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	695.9	f			M005443	调质80KSI	XYGN5203-2022-01	3075911M	8710	0	8710	0	0	0	冶钢	天津		是			5	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	689.1	f			M005444	调质80KSI	XYGN5203-2022-01	3075911M	8625	0	8625	0	0	0	冶钢	天津		是			6	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	701.1	f			M005445	调质80KSI	XYGN5203-2022-01	3075911M	8775	0	8775	0	0	0	冶钢	天津		是			7	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	657.6	f			M005446	调质80KSI	XYGN5203-2022-01	3075911M	8230	0	8230	0	0	0	冶钢	天津		是			8	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	695.9	f			M005447	调质80KSI	XYGN5203-2022-01	3075911M	8710	0	8710	0	0	0	冶钢	天津		是			9	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	704.7	f			M005448	调质80KSI	XYGN5203-2022-01	3075911M	8820	0	8820	0	0	0	冶钢	天津		是			10	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	497.8	f			M005449	调质80KSI	XYGN5203-2022-01	3075911M	6230	0	6230	0	0	0	冶钢	天津		是			11	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	527.3	f			M005450	调质80KSI	XYGN5203-2022-01	3075911M	6600	0	6600	0	0	0	冶钢	天津		是			12	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	680.3	f			M005451	调质80KSI	XYGN5203-2022-01	3075911M	8515	0	8515	0	0	0	冶钢	天津		是			13	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	674.3	f			M005452	调质80KSI	XYGN5203-2022-01	3075911M	8440	0	8440	0	0	0	冶钢	天津		是			14	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	700.7	f			M005453	调质80KSI	XYGN5203-2022-01	3075911M	8770	0	8770	0	0	0	冶钢	天津		是			15	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	671.1	f			M005454	调质80KSI	XYGN5203-2022-01	3075911M	8400	0	8400	0	0	0	冶钢	天津		是			16	0	0	0	0	0	f	f	f	室内	RK202312-02
4_103	159*24	0	667.2	f			M005455	调质80KSI	XYGN5203-2022-01	3075911M	8350	0	8350	0	0	0	冶钢	天津		是			17	0	0	0	0	0	f	f	f	室内	RK202312-02
4_107	146*30	0	864.2	f	 		M005533	调质-80KSI	YTG 001-2021	23106841	10070	0	10070	0	0	0	衡钢	天津	否	是			54	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	855.6	f	 		M005534	调质-80KSI	YTG 001-2021	23106841	9970	0	9970	0	0	0	衡钢	天津	否	是			55	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	146*30	0	856.5	f	 		M005535	调质-80KSI	YTG 001-2021	23106841	9980	0	9980	0	0	0	衡钢	天津	否	是			56	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	848	f	 		M005536	调质-80KSI	YTG 001-2021	23216546	8640	0	8640	0	0	0	衡钢	天津	否	是			57	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	826.4	f	 		M005537	调质-80KSI	YTG 001-2021	23216546	8420	0	8420	0	0	0	衡钢	天津	否	是			58	0	0	0	0	0	f	f	f	室内	RK202312-06
4_102	143*25	0	-723.09	f	 		M005049	调质110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	TZ23-03584LG	9940	2	0	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_103	190*35	0	1072.9	f			M005456	调质80KSI	XYGN5203-2022-01	3076208A	8020	0	8020	0	0	0	冶钢	天津		是			1	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1070.2	f			M005457	调质80KSI	XYGN5203-2022-01	3076208A	8000	0	8000	0	0	0	冶钢	天津		是			2	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1101	f			M005458	调质80KSI	XYGN5203-2022-01	3076208A	8230	0	8230	0	0	0	冶钢	天津		是			3	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1057.5	f			M005459	调质80KSI	XYGN5203-2022-01	3076208A	7905	0	7905	0	0	0	冶钢	天津		是			4	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1070.2	f			M005460	调质80KSI	XYGN5203-2022-01	3076208A	8000	0	8000	0	0	0	冶钢	天津		是			5	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1095.7	f			M005461	调质80KSI	XYGN5203-2022-01	3076208A	8190	0	8190	0	0	0	冶钢	天津		是			6	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1094.3	f			M005462	调质80KSI	XYGN5203-2022-01	3076208A	8180	0	8180	0	0	0	冶钢	天津		是			7	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1102.4	f			M005463	调质80KSI	XYGN5203-2022-01	3076208A	8240	0	8240	0	0	0	冶钢	天津		是			8	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1070.2	f			M005464	调质80KSI	XYGN5203-2022-01	3076208A	8000	0	8000	0	0	0	冶钢	天津		是			9	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1092.3	f			M005465	调质80KSI	XYGN5203-2022-01	3076208A	8165	0	8165	0	0	0	冶钢	天津		是			10	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1093	f			M005466	调质80KSI	XYGN5203-2022-01	3076208A	8170	0	8170	0	0	0	冶钢	天津		是			11	0	0	0	0	0	f	f	f	室内	RK202312-03
4_103	190*35	0	1070.2	f			M005467	调质80KSI	XYGN5203-2022-01	3076208A	8000	0	8000	0	0	0	冶钢	天津		是			12	0	0	0	0	0	f	f	f	室内	RK202312-03
4_107	159*35	0	1037.1	f	 		M005480	调质-80KSI	YTG 001-2021	23106840	9690	0	9690	0	0	0	衡钢	天津	否	是			1	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	159*35	0	1027.4	f	 		M005481	调质-80KSI	YTG 001-2021	23106840	9600	0	9600	0	0	0	衡钢	天津	否	是			2	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	159*35	0	1030.6	f	 		M005482	调质-80KSI	YTG 001-2021	23106840	9630	0	9630	0	0	0	衡钢	天津	否	是			3	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	159*35	0	1039.2	f	 		M005484	调质-80KSI	YTG 001-2021	23106840	9710	0	9710	0	0	0	衡钢	天津	否	是			5	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	159*35	0	1030.6	f	 		M005485	调质-80KSI	YTG 001-2021	23106840	9630	0	9630	0	0	0	衡钢	天津	否	是			6	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	159*35	0	988.9	f	 		M005486	调质-80KSI	YTG 001-2021	23106840	9240	0	9240	0	0	0	衡钢	天津	否	是			7	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	159*35	0	1001.2	f	 		M005487	调质-80KSI	YTG 001-2021	23106840	9355	0	9355	0	0	0	衡钢	天津	否	是			8	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	462.8	f	 		M005488	调质-80KSI	YTG 001-2021	23215087	7840	0	7840	0	0	0	衡钢	天津	否	是			9	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	472.3	f	 		M005489	调质-80KSI	YTG 001-2021	23215087	8000	0	8000	0	0	0	衡钢	天津	否	是			10	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	467.6	f	 		M005490	调质-80KSI	YTG 001-2021	23215087	7920	0	7920	0	0	0	衡钢	天津	否	是			11	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	473.5	f	 		M005491	调质-80KSI	YTG 001-2021	23215087	8020	0	8020	0	0	0	衡钢	天津	否	是			12	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	484.1	f	 		M005492	调质-80KSI	YTG 001-2021	23215087	8200	0	8200	0	0	0	衡钢	天津	否	是			13	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	471.1	f	 		M005493	调质-80KSI	YTG 001-2021	23215087	7980	0	7980	0	0	0	衡钢	天津	否	是			14	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	472.3	f	 		M005494	调质-80KSI	YTG 001-2021	23215087	8000	0	8000	0	0	0	衡钢	天津	否	是			15	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	479.4	f	 		M005495	调质-80KSI	YTG 001-2021	23215087	8120	0	8120	0	0	0	衡钢	天津	否	是			16	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	483.5	f	 		M005496	调质-80KSI	YTG 001-2021	23215087	8190	0	8190	0	0	0	衡钢	天津	否	是			17	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	459.9	f	 		M005497	调质-80KSI	YTG 001-2021	23215087	7790	0	7790	0	0	0	衡钢	天津	否	是			18	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	468.2	f	 		M005498	调质-80KSI	YTG 001-2021	23215087	7930	0	7930	0	0	0	衡钢	天津	否	是			19	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	464	f	 		M005500	调质-80KSI	YTG 001-2021	23215087	7860	0	7860	0	0	0	衡钢	天津	否	是			21	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	474.1	f	 		M005501	调质-80KSI	YTG 001-2021	23215087	8030	0	8030	0	0	0	衡钢	天津	否	是			22	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	483.5	f	 		M005502	调质-80KSI	YTG 001-2021	23215087	8190	0	8190	0	0	0	衡钢	天津	否	是			23	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	487.6	f	 		M005503	调质-80KSI	YTG 001-2021	23215087	8260	0	8260	0	0	0	衡钢	天津	否	是			24	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	468.2	f	 		M005504	调质-80KSI	YTG 001-2021	23215087	7930	0	7930	0	0	0	衡钢	天津	否	是			25	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	455.8	f	 		M005505	调质-80KSI	YTG 001-2021	23215087	7720	0	7720	0	0	0	衡钢	天津	否	是			26	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	478.2	f	 		M005506	调质-80KSI	YTG 001-2021	23215087	8100	0	8100	0	0	0	衡钢	天津	否	是			27	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	451	f	 		M005507	调质-80KSI	YTG 001-2021	23215087	7640	0	7640	0	0	0	衡钢	天津	否	是			28	0	0	0	0	0	f	f	f	室内	RK202312-06
4_102	114*20	0	445.5	f			M005417	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9610	0	9610	0	0	0	常宝	天津		是			1	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	424.7	f			M005418	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9160	0	9160	0	0	0	常宝	天津		是			2	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	423.7	f			M005419	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9140	0	9140	0	0	0	常宝	天津		是			3	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	423.7	f			M005420	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9140	0	9140	0	0	0	常宝	天津		是			4	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	421.4	f			M005421	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9090	0	9090	0	0	0	常宝	天津		是			5	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	423.3	f			M005422	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9130	0	9130	0	0	0	常宝	天津		是			6	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	423.7	f			M005423	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9140	0	9140	0	0	0	常宝	天津		是			7	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	421.9	f			M005424	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9100	0	9100	0	0	0	常宝	天津		是			8	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	404.7	f			M005425	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	8730	0	8730	0	0	0	常宝	天津		是			9	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	421	f			M005426	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9080	0	9080	0	0	0	常宝	天津		是			10	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	425.6	f			M005427	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9180	0	9180	0	0	0	常宝	天津		是			11	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	420.5	f			M005428	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9070	0	9070	0	0	0	常宝	天津		是			12	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	422.1	f			M005429	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9105	0	9105	0	0	0	常宝	天津		是			13	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	404	f			M005430	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	8715	0	8715	0	0	0	常宝	天津		是			14	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	422.8	f			M005431	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9120	0	9120	0	0	0	常宝	天津		是			15	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	424.2	f			M005432	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9150	0	9150	0	0	0	常宝	天津		是			16	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	418.2	f			M005433	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9020	0	9020	0	0	0	常宝	天津		是			17	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	422.3	f			M005434	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9110	0	9110	0	0	0	常宝	天津		是			18	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	423.7	f			M005435	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9140	0	9140	0	0	0	常宝	天津		是			19	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	422.8	f			M005436	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9120	0	9120	0	0	0	常宝	天津		是			20	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	424.7	f			M005437	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9160	0	9160	0	0	0	常宝	天津		是			21	0	0	0	0	0	f	f	f	室内	RK202312-01
4_102	114*20	0	419.6	f			M005438	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	23E104515YG	9050	0	9050	0	0	0	常宝	天津		是			22	0	0	0	0	0	f	f	f	室内	RK202312-01
4_103	273*32	0	1677.4	f			M005478	调质80KSI	XYGN4972-2022-01	3060175X	8820	0	8820	0	0	0	冶钢-钢管	天津		是			1	0	0	0	0	0	f	f	f	室内	RK202312-05
4_103	273*32	0	1850.4	f			M005479	调质80KSI	XYGN4972-2022-01	3060175X	9730	0	9730	0	0	0	冶钢-钢管	天津		是			2	0	0	0	0	0	f	f	f	室内	RK202312-05
4_107	219*20	0	770.5	f	 		M005539	调质-80KSI	YTG 001-2021	23216546	7850	0	7850	0	0	0	衡钢	天津	否	是			60	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	855.8	f	 		M005540	调质-80KSI	YTG 001-2021	23216546	8720	0	8720	0	0	0	衡钢	天津	否	是			61	0	0	0	0	0	f	f	f	室内	RK202312-06
4_103	219*20	0	710.6	f	 		M005468	调质80KSI	XYGN4972-2022-01	3076208A	7240	0	7240	0	0	0	大冶特殊钢	天津	否	是			1	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	219*20	0	699.3	f	 		M005469	调质80KSI	XYGN4972-2022-01	3076208A	7125	0	7125	0	0	0	大冶特殊钢	天津	否	是			2	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	219*20	0	696.8	f	 		M005470	调质80KSI	XYGN4972-2022-01	3076208A	7100	0	7100	0	0	0	大冶特殊钢	天津	否	是			3	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	219*20	0	727.3	f	 		M005471	调质80KSI	XYGN4972-2022-01	3076208A	7410	0	7410	0	0	0	大冶特殊钢	天津	否	是			4	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	219*20	0	693.9	f	 		M005472	调质80KSI	XYGN4972-2022-01	3076208A	7070	0	7070	0	0	0	大冶特殊钢	天津	否	是			5	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	219*20	0	758.7	f	 		M005473	调质80KSI	XYGN4972-2022-01	3076208A	7730	0	7730	0	0	0	大冶特殊钢	天津	否	是			6	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	219*20	0	727.3	f	 		M005474	调质80KSI	XYGN4972-2022-01	3076208A	7410	0	7410	0	0	0	大冶特殊钢	天津	否	是			7	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	219*20	0	727.3	f	 		M005475	调质80KSI	XYGN4972-2022-01	3076208A	7410	0	7410	0	0	0	大冶特殊钢	天津	否	是			8	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	219*20	0	678.2	f	 		M005477	调质80KSI	XYGN4972-2022-01	3076208A	6910	0	6910	0	0	0	大冶特殊钢	天津	否	是			10	0	0	0	0	0	f	f	f	室内	RK202312-04
4_103	222.25*25.4	0	832.2733	f	待验		M005767	调质80KSI	XYGN5203-2022-01	3076635F	6750	0	6750	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	850.7683	f	待验		M005768	调质80KSI	XYGN5203-2022-01	3076635F	6900	0	6900	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	865.5643	f	待验		M005769	调质80KSI	XYGN5203-2022-01	3076635F	7020	0	7020	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	927.2142	f	待验		M005770	调质80KSI	XYGN5203-2022-01	3076635F	7520	0	7520	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	914.88416	f	待验		M005771	调质80KSI	XYGN5203-2022-01	3076635F	7420	0	7420	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	928.44714	f	待验		M005772	调质80KSI	XYGN5203-2022-01	3076635F	7530	0	7530	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	917.35016	f	待验		M005773	调质80KSI	XYGN5203-2022-01	3076635F	7440	0	7440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	928.44714	f	待验		M005774	调质80KSI	XYGN5203-2022-01	3076635F	7530	0	7530	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	1131.8917	f	待验		M005775	调质80KSI	XYGN5203-2022-01	3076635F	9180	0	9180	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	1114.6298	f	待验		M005776	调质80KSI	XYGN5203-2022-01	3076635F	9040	0	9040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	1114.6298	f	待验		M005777	调质80KSI	XYGN5203-2022-01	3076635F	9040	0	9040	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	1104.7657	f	待验		M005778	调质80KSI	XYGN5203-2022-01	3076635F	8960	0	8960	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	917.35016	f	待验		M005779	调质80KSI	XYGN5203-2022-01	3076635F	7440	0	7440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*20	0	858.8	f	 		M005542	调质-80KSI	YTG 001-2021	23216546	8750	0	8750	0	0	0	衡钢	天津	否	是			63	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	825.4	f	 		M005543	调质-80KSI	YTG 001-2021	23216546	8410	0	8410	0	0	0	衡钢	天津	否	是			64	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	818.5	f	 		M005544	调质-80KSI	YTG 001-2021	23216546	8340	0	8340	0	0	0	衡钢	天津	否	是			65	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	771.4	f	 		M005545	调质-80KSI	YTG 001-2021	23216546	7860	0	7860	0	0	0	衡钢	天津	否	是			66	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	700.8	f	 		M005546	调质-80KSI	YTG 001-2021	23216546	7140	0	7140	0	0	0	衡钢	天津	否	是			67	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	748.1	f	 		M005547	调质-80KSI	YTG 001-2021	23106841	9600	0	9600	0	0	0	衡钢	天津	否	是			68	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	776.1	f	 		M005548	调质-80KSI	YTG 001-2021	23106841	9960	0	9960	0	0	0	衡钢	天津	否	是			69	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	753.5	f	 		M005549	调质-80KSI	YTG 001-2021	23106841	9670	0	9670	0	0	0	衡钢	天津	否	是			70	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	847.8	f	 		M005550	调质-80KSI	YTG 001-2021	23106841	10880	0	10880	0	0	0	衡钢	天津	否	是			71	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	828.3	f	 		M005551	调质-80KSI	YTG 001-2021	23106841	10630	0	10630	0	0	0	衡钢	天津	否	是			72	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	826	f	 		M005552	调质-80KSI	YTG 001-2021	23106841	10600	0	10600	0	0	0	衡钢	天津	否	是			73	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	845.5	f	 		M005553	调质-80KSI	YTG 001-2021	23106841	10850	0	10850	0	0	0	衡钢	天津	否	是			74	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	789.4	f	 		M005555	调质-80KSI	YTG 001-2021	23106841	10130	0	10130	0	0	0	衡钢	天津	否	是			76	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	777.7	f	 		M005556	调质-80KSI	YTG 001-2021	23106841	9980	0	9980	0	0	0	衡钢	天津	否	是			77	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	795.6	f	 		M005557	调质-80KSI	YTG 001-2021	23106841	10210	0	10210	0	0	0	衡钢	天津	否	是			78	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	804.2	f	 		M005558	调质-80KSI	YTG 001-2021	23106841	10320	0	10320	0	0	0	衡钢	天津	否	是			79	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1083.9	f	 		M005559	调质-80KSI	YTG 001-2021	23106840	8970	0	8970	0	0	0	衡钢	天津	否	是			80	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1076.6	f	 		M005560	调质-80KSI	YTG 001-2021	23106840	8910	0	8910	0	0	0	衡钢	天津	否	是			81	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1076.6	f	 		M005561	调质-80KSI	YTG 001-2021	23106840	8910	0	8910	0	0	0	衡钢	天津	否	是			82	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1067	f	 		M005562	调质-80KSI	YTG 001-2021	23106840	8830	0	8830	0	0	0	衡钢	天津	否	是			83	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1025.9	f	 		M005563	调质-80KSI	YTG 001-2021	23106840	8490	0	8490	0	0	0	衡钢	天津	否	是			84	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1057.3	f	 		M005564	调质-80KSI	YTG 001-2021	23106840	8750	0	8750	0	0	0	衡钢	天津	否	是			85	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1087.5	f	 		M005566	调质-80KSI	YTG 001-2021	23106840	9000	0	9000	0	0	0	衡钢	天津	否	是			87	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1070.6	f	 		M005567	调质-80KSI	YTG 001-2021	23106840	8860	0	8860	0	0	0	衡钢	天津	否	是			88	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	203*28	0	1081.5	f	 		M005568	调质-80KSI	YTG 001-2021	23106840	8950	0	8950	0	0	0	衡钢	天津	否	是			89	0	0	0	0	0	f	f	f	室内	RK202312-06
4_103	222.25*25.4	0	907.4862	f	待验		M005780	调质80KSI	XYGN5203-2022-01	3076635F	7360	0	7360	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	222.25*25.4	0	1048.0479	f	待验		M005781	调质80KSI	XYGN5203-2022-01	3076635F	8500	0	8500	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	697.8237	f	待验		M005782	调质80KSI	XYGN5203-2022-01	3076208A	7110	0	7110	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	674.2685	f	待验		M005783	调质80KSI	XYGN5203-2022-01	3076208A	6870	0	6870	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	729.2307	f	待验		M005784	调质80KSI	XYGN5203-2022-01	3076208A	7430	0	7430	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	654.63916	f	待验		M005785	调质80KSI	XYGN5203-2022-01	3076208A	6670	0	6670	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	716.4716	f	待验		M005786	调质80KSI	XYGN5203-2022-01	3076208A	7300	0	7300	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	696.8423	f	待验		M005787	调质80KSI	XYGN5203-2022-01	3076208A	7100	0	7100	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	676.23145	f	待验		M005788	调质80KSI	XYGN5203-2022-01	3076208A	6890	0	6890	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_103	219*20	0	726.2863	f	待验		M005789	调质80KSI	XYGN5203-2022-01	3076208A	7400	0	7400	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	837.84	f	待验		M005790	调质110KSI	XYGN5189.2-2022-01	3030153Z	9430	0	9430	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	842.28	f	待验		M005791	调质110KSI	XYGN5189.2-2022-01	3030153Z	9480	0	9480	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	841.39	f	待验		M005792	调质110KSI	XYGN5189.2-2022-01	3030153Z	9470	0	9470	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	570.4	f	待验		M005793	调质110KSI	XYGN5189.2-2022-01	3030153Z	6420	0	6420	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	860.05	f	待验		M005822	调质110KSI	XYGN5189.2-2022-01	3030153Z	9680	0	9680	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	860.94	f	待验		M005823	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	852.94	f	待验		M005824	调质110KSI	XYGN5189.2-2022-01	3030153Z	9600	0	9600	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	120	0	860.94	f	待验		M005825	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	692.82	f	待验		M005794	调质110KSI	XYGN5189.2-2022-01	3030153Z	9280	0	9280	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	686.84	f	待验		M005795	调质110KSI	XYGN5189.2-2022-01	3030153Z	9200	0	9200	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	695.06	f	待验		M005796	调质110KSI	XYGN5189.2-2022-01	3030153Z	9310	0	9310	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	665.27	f	待验		M005797	调质110KSI	XYGN5189.2-2022-01	3030153Z	8911	0	8911	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	704.76	f	待验		M005798	调质110KSI	XYGN5189.2-2022-01	3030153Z	9440	0	9440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	704.76	f	待验		M005799	调质110KSI	XYGN5189.2-2022-01	3030153Z	9440	0	9440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	704.76	f	待验		M005800	调质110KSI	XYGN5189.2-2022-01	3030153Z	9440	0	9440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	110	0	704.76	f	待验		M005801	调质110KSI	XYGN5189.2-2022-01	3030153Z	9440	0	9440	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005802	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005803	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005804	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005805	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005806	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005807	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	604.66	f	待验		M005808	调质110KSI	XYGN5189.2-2022-01	3030153Z	9800	0	9800	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005809	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005810	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	598.49	f	待验		M005811	调质110KSI	XYGN5189.2-2022-01	3030153Z	9700	0	9700	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	597.87	f	待验		M005812	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	528.77	f	待验		M005813	调质110KSI	XYGN5189.2-2022-01	3030153Z	8570	0	8570	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	529.39	f	待验		M005814	调质110KSI	XYGN5189.2-2022-01	3030153Z	8580	0	8580	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*35	0	1696.1	f	待验		M005759	调质80KSI	TTG 001-2021	23307331	10680	0	10680	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	100	0	528.77	f	待验		M005815	调质110KSI	XYGN5189.2-2022-01	3030153Z	8570	0	8570	0	0	0	大冶特殊钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	611.27	f	待验		M005594	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6880	0	6880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	610.39	f	待验		M005595	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6870	0	6870	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	610.39	f	待验		M005596	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6870	0	6870	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	607.72	f	待验		M005597	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6840	0	6840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	606.83	f	待验		M005598	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6830	0	6830	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	611.27	f	待验		M005599	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6880	0	6880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	613.05	f	待验		M005600	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6900	0	6900	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	618.38	f	待验		M005601	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6960	0	6960	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	612.16	f	待验		M005602	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6890	0	6890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	613.94	f	待验		M005603	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6910	0	6910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	597.95	f	待验		M005604	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6730	0	6730	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	613.94	f	待验		M005605	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6910	0	6910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	588.17	f	待验		M005606	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6620	0	6620	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	612.16	f	待验		M005607	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6890	0	6890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	627.27	f	待验		M005608	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	7060	0	7060	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	612.16	f	待验		M005609	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6890	0	6890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	612.16	f	待验		M005610	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6890	0	6890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	610.39	f	待验		M005611	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6870	0	6870	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	615.72	f	待验		M005612	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6930	0	6930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	120	0	611.27	f	待验		M005613	调质110KSI	QJ/DT01.24548-2021-C/0	23209121037	6880	0	6880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	674.65	f	待验		M005614	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6470	0	6470	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	666.3	f	待验		M005615	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6390	0	6390	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	645.45	f	待验		M005616	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	954.1	f	待验		M005617	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	9150	0	9150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	652.75	f	待验		M005618	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6260	0	6260	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	645.45	f	待验		M005619	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	641.28	f	待验		M005620	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	639.19	f	待验		M005621	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	639.19	f	待验		M005622	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	642.32	f	待验		M005623	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	644.41	f	待验		M005624	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	130	0	640.24	f	待验		M005625	调质110KSI	QJ/DT01.24548-2021-C/0	23209121103	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	775.89	f	待验		M005667	调质110KSI	QJ/DT01.24548-2021-B/0	23209121103	6900	0	6900	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	846.74	f	待验		M005668	调质110KSI	QJ/DT01.24548-2021-B/0	23209121103	7530	0	7530	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	813	f	待验		M005669	调质110KSI	QJ/DT01.24548-2021-B/0	23209121103	7230	0	7230	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	868.1	f	待验		M005670	调质110KSI	QJ/DT01.24548-2021-B/0	23209121103	7720	0	7720	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	857.98	f	待验		M005671	调质110KSI	QJ/DT01.24548-2021-B/0	23209121103	7630	0	7630	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	135	0	789.39	f	待验		M005672	调质110KSI	QJ/DT01.24548-2021-B/0	23209121103	7020	0	7020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1181.48	f	待验		M005673	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7480	0	7480	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1167.27	f	待验		M005674	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7390	0	7390	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1135.67	f	待验		M005675	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7190	0	7190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1168.84	f	待验		M005676	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7400	0	7400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1244.66	f	待验		M005677	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7880	0	7880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1222.55	f	待验		M005678	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7740	0	7740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1232.03	f	待验		M005679	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7800	0	7800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1246.24	f	待验		M005680	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7890	0	7890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1208.33	f	待验		M005681	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7650	0	7650	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	160	0	1164.11	f	待验		M005682	调质110KSI	QJ/DT01.24548-2021-B/0	23209121218	7370	0	7370	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	397.97	f	待验		M005666	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6450	0	6450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	397.97	f	待验		M005683	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6450	0	6450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	418.94	f	待验		M005684	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6790	0	6790	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	413.39	f	待验		M005685	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6700	0	6700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	397.35	f	待验		M005569	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6440	0	6440	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	398.58	f	待验		M005570	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6460	0	6460	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	401.05	f	待验		M005571	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6500	0	6500	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	404.75	f	待验		M005572	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6560	0	6560	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	402.28	f	待验		M005573	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6520	0	6520	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	404.14	f	待验		M005575	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6550	0	6550	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	408.45	f	待验		M005576	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6620	0	6620	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	416.48	f	待验		M005577	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6750	0	6750	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	420.49	f	待验		M005578	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6815	0	6815	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	418.94	f	待验		M005579	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6790	0	6790	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	397.97	f	待验		M005580	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6450	0	6450	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	414.01	f	待验		M005581	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6710	0	6710	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	394.26	f	待验		M005582	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6390	0	6390	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	413.39	f	待验		M005583	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6700	0	6700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	418.94	f	待验		M005584	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6790	0	6790	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	418.94	f	待验		M005585	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6790	0	6790	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	397.35	f	待验		M005586	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6440	0	6440	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	422.65	f	待验		M005587	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6850	0	6850	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	418.94	f	待验		M005588	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6790	0	6790	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	404.75	f	待验		M005589	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6560	0	6560	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	416.48	f	待验		M005590	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6750	0	6750	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	402.9	f	待验		M005591	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6530	0	6530	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	385.63	f	待验		M005592	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6250	0	6250	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	100	0	413.39	f	待验		M005593	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6700	0	6700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	857.94	f	待验		M005816	调质110KSI	QJ/DT01.24548-2021-C/0	23209121068	6180	0	6180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	839.89	f	待验		M005817	调质110KSI	QJ/DT01.24548-2021-C/0	23209121068	6050	0	6050	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	852.39	f	待验		M005818	调质110KSI	QJ/DT01.24548-2021-C/0	23209121068	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	859.33	f	待验		M005819	调质110KSI	QJ/DT01.24548-2021-C/0	23209121068	6190	0	6190	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_104	150	0	807.96	f	待验		M005820	调质110KSI	QJ/DT01.24548-2021-C/0	23209121068	5820	0	5820	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	150	0	828.79	f	待验		M005635	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5970	0	5970	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	798.24	f	待验		M005636	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5750	0	5750	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	816.29	f	待验		M005637	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5880	0	5880	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	832.95	f	待验		M005638	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	6000	0	6000	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	820.46	f	待验		M005639	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5910	0	5910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	824.62	f	待验		M005640	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5940	0	5940	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	810.74	f	待验		M005641	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5840	0	5840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	851	f	待验		M005642	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	745.49	f	待验		M005643	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5370	0	5370	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	608.95	f	待验		M005644	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5390	0	5390	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	564.12	f	待验		M005645	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5840	0	5840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	604.78	f	待验		M005646	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5410	0	5410	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	608.43	f	待验		M005647	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5800	0	5800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	627.72	f	待验		M005648	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5835	0	5835	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	626.68	f	待验		M005649	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	6020	0	6020	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	704.89	f	待验		M005650	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	6010	0	6010	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	540.13	f	待验		M005651	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	6760	0	6760	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	592.27	f	待验		M005652	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5180	0	5180	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	618.34	f	待验		M005653	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5680	0	5680	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	608.95	f	待验		M005654	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5930	0	5930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	130	0	608.95	f	待验		M005655	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5840	0	5840	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.9	f	待验		M005686	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7620	0	7620	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	299.71	f	待验		M005687	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7590	0	7590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	281.94	f	待验		M005688	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7140	0	7140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	272.07	f	待验		M005689	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	6890	0	6890	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.11	f	待验		M005690	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7600	0	7600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.9	f	待验		M005691	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7620	0	7620	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	296.16	f	待验		M005692	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7500	0	7500	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	298.92	f	待验		M005693	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7570	0	7570	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	379.08	f	待验		M005695	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	9600	0	9600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.11	f	待验		M005696	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7600	0	7600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.5	f	待验		M005698	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7610	0	7610	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	299.71	f	待验		M005697	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7590	0	7590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.11	f	待验		M005699	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7600	0	7600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	298.53	f	待验		M005700	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7560	0	7560	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	208.89	f	待验		M005701	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	5290	0	5290	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	308.36	f	待验		M005739	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6170	0	6170	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.9	f	待验		M005702	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7620	0	7620	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	301.29	f	待验		M005704	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7630	0	7630	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.5	f	待验		M005703	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7610	0	7610	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	294.58	f	待验		M005706	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7460	0	7460	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.11	f	待验		M005705	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7600	0	7600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.11	f	待验		M005707	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7600	0	7600	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.5	f	待验		M005708	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7610	0	7610	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	300.5	f	待验		M005709	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7610	0	7610	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.36	f	待验		M005737	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.86	f	待验		M005736	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.86	f	待验		M005735	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	307.86	f	待验		M005734	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.86	f	待验		M005733	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.36	f	待验		M005732	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.36	f	待验		M005731	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	305.86	f	待验		M005730	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.86	f	待验		M005729	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	239.89	f	待验		M005728	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	4800	0	4800	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.86	f	待验		M005727	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	307.36	f	待验		M005726	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	307.86	f	待验		M005725	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	305.86	f	待验		M005724	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	305.86	f	待验		M005723	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.36	f	待验		M005722	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	305.86	f	待验		M005721	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6120	0	6120	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.86	f	待验		M005720	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	307.36	f	待验		M005719	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6150	0	6150	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	228.24	f	待验		M005711	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	5780	0	5780	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	299.71	f	待验		M005712	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7590	0	7590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	299.71	f	待验		M005713	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7590	0	7590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	299.32	f	待验		M005714	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7580	0	7580	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	299.71	f	待验		M005715	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7590	0	7590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	299.71	f	待验		M005716	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7590	0	7590	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	289.05	f	待验		M005717	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7320	0	7320	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.36	f	待验		M005718	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6130	0	6130	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	196*40	0	1124.08	f	待验		M005741	调质80KSI	TTG 001-2021	23216546	7305	0	7305	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1106.39	f	待验		M005742	调质80KSI	TTG 001-2021	23216546	7190	0	7190	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1105.62	f	待验		M005743	调质80KSI	TTG 001-2021	23216546	7185	0	7185	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1126.39	f	待验		M005744	调质80KSI	TTG 001-2021	23216546	7320	0	7320	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1267.96	f	待验		M005745	调质80KSI	TTG 001-2021	23216546	8240	0	8240	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1137.16	f	待验		M005746	调质80KSI	TTG 001-2021	23216546	7390	0	7390	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1131.78	f	待验		M005747	调质80KSI	TTG 001-2021	23216546	7355	0	7355	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1104.08	f	待验		M005748	调质80KSI	TTG 001-2021	23216546	7175	0	7175	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1144.86	f	待验		M005749	调质80KSI	TTG 001-2021	23216546	7440	0	7440	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1113.31	f	待验		M005750	调质80KSI	TTG 001-2021	23216546	7235	0	7235	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1087.15	f	待验		M005751	调质80KSI	TTG 001-2021	23216546	7065	0	7065	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1107.16	f	待验		M005752	调质80KSI	TTG 001-2021	23216546	7195	0	7195	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1115.62	f	待验		M005753	调质80KSI	TTG 001-2021	23216546	7250	0	7250	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	196*40	0	1091	f	待验		M005754	调质80KSI	TTG 001-2021	23216546	7090	0	7090	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*20	0	808.24	f	待验		M005766	调质80KSI	TTG 001-2021	23216545	8235	0	8235	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	159*35	0	1000.68	f	待验		M005764	调质80KSI	TTG 001-2021	23106840	9350	0	9350	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	159*35	0	1010.31	f	待验		M005765	调质80KSI	TTG 001-2021	23106840	9440	0	9440	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*35	0	1738.18	f	待验		M005755	调质80KSI	TTG 001-2021	23307331	10945	0	10945	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*35	0	1697.68	f	待验		M005756	调质80KSI	TTG 001-2021	23307331	10690	0	10690	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*35	0	1738.97	f	待验		M005757	调质80KSI	TTG 001-2021	23307331	10950	0	10950	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*35	0	1739.77	f	待验		M005758	调质80KSI	TTG 001-2021	23307331	10955	0	10955	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_103	160	0	1437.36	f	待验		M005627	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	9100	0	9100	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1407.35	f	待验		M005628	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8910	0	8910	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1412.09	f	待验		M005629	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8940	0	8940	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1274.67	f	待验		M005630	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8070	0	8070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1320.48	f	待验		M005631	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8360	0	8360	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1371.02	f	待验		M005632	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8680	0	8680	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1274.67	f	待验		M005656	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8070	0	8070	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1273.88	f	待验		M005657	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8065	0	8065	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1222.55	f	待验		M005658	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	7740	0	7740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1374.18	f	待验		M005659	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8700	0	8700	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1184.64	f	待验		M005660	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	7500	0	7500	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1239.92	f	待验		M005661	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	7850	0	7850	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1394.72	f	待验		M005662	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8830	0	8830	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1403.4	f	待验		M005663	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8885	0	8885	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1479.22	f	待验		M005664	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	9365	0	9365	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1410.51	f	待验		M005665	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8930	0	8930	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	307.86	f	待验		M005740	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6160	0	6160	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	219*35	0	1737.39	f	待验		M005760	调质80KSI	TTG 001-2021	23307331	10940	0	10940	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*35	0	1739.77	f	待验		M005761	调质80KSI	TTG 001-2021	23307331	10955	0	10955	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*35	0	1740.56	f	待验		M005762	调质80KSI	TTG 001-2021	23307331	10960	0	10960	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	219*35	0	1740.56	f	待验		M005763	调质80KSI	TTG 001-2021	23307331	10960	0	10960	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
4_107	178*20	0	526.39	f	待验		M005821	调质80KSI	TTG 001-2021	23106841	6755	0	6755	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	130	0	384.82	f	待验		M004731	固溶时效	GB/T 1220-2007	YX2310-2087	5960	0	3655	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_101	130	0	643.3	f	待验		M004732	固溶时效	GB/T 1220-2007	YX2310-2087	6110	0	6110	0	0	0	劝诚特钢	天津	否				0	0	0	0	0	0	f	f	f		KT202312-01
3_105	90	0	484.3	f	待验		M005826	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			1	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005827	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			2	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005828	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			3	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005829	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			4	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005830	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			5	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	463.8	f	待验		M005831	调质110KSI	XYGN5189.2-2022-01	2041174Z	9280	0	9280	0	0	0	冶钢-圆钢	天津		是			6	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005832	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			7	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005833	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			8	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005834	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			9	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005835	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			10	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005836	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			11	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005837	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			12	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005838	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			13	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005839	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			14	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005840	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			15	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005841	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			16	0	0	0	0	0	f	f	f	室内	RK202401-01
3_105	90	0	484.3	f	待验		M005842	调质110KSI	XYGN5189.2-2022-01	2041174Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			17	0	0	0	0	0	f	f	f	室内	RK202401-01
3_104	100	0	401.67	f			M005574	调质110KSI	QJ/DT01.24548-2021-C/0	23209121257	6510	0	6510	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_102	139.7*7.72	0	703.5	f			M005843	调质-110KSI	API SPEC 5CT 10th PSL2 & FS-T-M-011B	000000	28000	0	28000	0	0	0	达利普	天津		是			1	0	0	0	0	0	f	f	f		RK2401-001
4_107	162*19	0	92.8	f	 		M000591	调质-80KSI	 	22212770	1385	0	1385	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_107	159*35	0	1039.2	f	 		M005483	调质-80KSI	YTG 001-2021	23106840	9710	0	9710	0	0	0	衡钢	天津	否	是			4	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	472.9	f	 		M005499	调质-80KSI	YTG 001-2021	23215087	8010	0	8010	0	0	0	衡钢	天津	否	是			20	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	482.3	f	 		M005508	调质-80KSI	YTG 001-2021	23215087	8170	0	8170	0	0	0	衡钢	天津	否	是			29	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*21	0	441.6	f	 		M005509	调质-80KSI	YTG 001-2021	23215087	7480	0	7480	0	0	0	衡钢	天津	否	是			30	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	844.1	f	 		M005538	调质-80KSI	YTG 001-2021	23216546	8600	0	8600	0	0	0	衡钢	天津	否	是			59	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	219*20	0	856.8	f	 		M005541	调质-80KSI	YTG 001-2021	23216546	8730	0	8730	0	0	0	衡钢	天津	否	是			62	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	178*20	0	804.2	f	 		M005554	调质-80KSI	YTG 001-2021	23106841	10320	0	10320	0	0	0	衡钢	天津	否	是			75	0	0	0	0	0	f	f	f	室内	RK202312-06
4_107	135*17.5	0	519.09	f	 		M000603	调质-80KSI	 	22213031	10237	0	10237	0	0	0	衡阳华菱	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	0	f	待验		M005626	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8640	1	0	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	160	0	1380.5	f	待验		M005633	调质80KSI	QJ/DT01.24412-2020-B/0	23210024195	8740	0	8740	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	150	0	813.51	f	待验		M005634	调质80KSI	QJ/DT01.24412-2020-B/0	23210020445	5860	0	5860	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	90	0	306.86	f	待验		M005738	调质80KSI	QJ/DT01.24412-2020-B/0	23210023205	6140	0	6140	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	298.92	f	待验		M005694	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7570	0	7570	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	80	0	299.32	f	待验		M005710	调质80KSI	QJ/DT01.24412-2020-B/0	23210023179	7580	0	7580	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_103	140	0	1.81	f	 		L037	调质-80KSI	QJ/DT01.24412-2020-A/0	22210022373	75	0	15	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_103	219*20	0	727.3	f	 		M005476	调质80KSI	XYGN4972-2022-01	3076208A	7410	0	7410	0	0	0	大冶特殊钢	天津	否	是			9	0	0	0	0	0	f	f	f	室内	RK202312-04
3_103	140	0	3.39	f	 		M002720	调质-80KSI	QJ/DT01.24412-2020-B/0	22210025810	400	0	400	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
3_105	90	0	484.3	f			M005844	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			1	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	484.3	f			M005845	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			2	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	484.3	f			M005846	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			3	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	484.3	f			M005847	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			4	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	484.3	f			M005848	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			5	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	473.3	f			M005849	调质110KSI	XYGN5189.2-2022-01	3030153Z	9470	0	9470	0	0	0	冶钢-圆钢	天津		是			6	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	473.8	f			M005850	调质110KSI	XYGN5189.2-2022-01	3030153Z	9480	0	9480	0	0	0	冶钢-圆钢	天津		是			7	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	414.8	f			M005851	调质110KSI	XYGN5189.2-2022-01	3030153Z	8300	0	8300	0	0	0	冶钢-圆钢	天津		是			8	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	414.8	f			M005852	调质110KSI	XYGN5189.2-2022-01	3030153Z	8300	0	8300	0	0	0	冶钢-圆钢	天津		是			9	0	0	0	0	0	f	f	f	室内	RK2401-002
3_105	90	0	484.3	f			M005853	调质110KSI	XYGN5189.2-2022-01	3030153Z	9690	0	9690	0	0	0	冶钢-圆钢	天津		是			10	0	0	0	0	0	f	f	f	室内	RK2401-002
4_103	174*18	0	428.6	f			M005866	调质-80KSI	XYGN4972-2022-01	3060104T	6190	0	6190	0	0	0	冶钢-钢管	天津		是			13	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	429	f			M005867	调质-80KSI	XYGN4972-2022-01	3060104T	6195	0	6195	0	0	0	冶钢-钢管	天津		是			14	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	436.2	f			M005868	调质-80KSI	XYGN4972-2022-01	3060104T	6300	0	6300	0	0	0	冶钢-钢管	天津		是			15	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	440.4	f			M005869	调质-80KSI	XYGN4972-2022-01	3060104T	6360	0	6360	0	0	0	冶钢-钢管	天津		是			16	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	499.3	f			M005870	调质-80KSI	XYGN4972-2022-01	3075911M	7210	0	7210	0	0	0	冶钢-钢管	天津		是			17	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	492.3	f			M005871	调质-80KSI	XYGN4972-2022-01	3075911M	7110	0	7110	0	0	0	冶钢-钢管	天津		是			18	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	502.4	f			M005872	调质-80KSI	XYGN4972-2022-01	3075911M	7255	0	7255	0	0	0	冶钢-钢管	天津		是			19	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	483.3	f			M005873	调质-80KSI	XYGN4972-2022-01	3075911M	6980	0	6980	0	0	0	冶钢-钢管	天津		是			20	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	441.1	f			M005874	调质-80KSI	XYGN4972-2022-01	3050996M	6370	0	6370	0	0	0	冶钢-钢管	天津		是			21	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	419.6	f			M005875	调质-80KSI	XYGN4972-2022-01	3050996M	6060	0	6060	0	0	0	冶钢-钢管	天津		是			22	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	415.8	f			M005876	调质-80KSI	XYGN4972-2022-01	3050996M	6005	0	6005	0	0	0	冶钢-钢管	天津		是			23	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	174*18	0	418.2	f			M005877	调质-80KSI	XYGN4972-2022-01	3050996M	6040	0	6040	0	0	0	冶钢-钢管	天津		是			24	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	919.8	f	 		M005854	调质-80KSI	XYGN5203-2022-01	3076635F	7460	0	7460	0	0	0	冶钢-钢管	天津	否	是			1	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	916.1	f	 		M005855	调质-80KSI	XYGN5203-2022-01	3076635F	7430	0	7430	0	0	0	冶钢-钢管	天津	否	是			2	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	881.6	f	 		M005856	调质-80KSI	XYGN5203-2022-01	3076635F	7150	0	7150	0	0	0	冶钢-钢管	天津	否	是			3	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1122	f	 		M005857	调质-80KSI	XYGN5203-2022-01	3060420T	9100	0	9100	0	0	0	冶钢-钢管	天津	否	是			4	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1096.1	f	 		M005865	调质-80KSI	XYGN5203-2022-01	3060420T	8890	0	8890	0	0	0	冶钢-钢管	天津	否	是			12	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1124.5	f	 		M005864	调质-80KSI	XYGN5203-2022-01	3060420T	9120	0	9120	0	0	0	冶钢-钢管	天津	否	是			11	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1104.8	f	 		M005863	调质-80KSI	XYGN5203-2022-01	3060420T	8960	0	8960	0	0	0	冶钢-钢管	天津	否	是			10	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1069	f	 		M005862	调质-80KSI	XYGN5203-2022-01	3060420T	8670	0	8670	0	0	0	冶钢-钢管	天津	否	是			9	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1114.6	f	 		M005861	调质-80KSI	XYGN5203-2022-01	3060420T	9040	0	9040	0	0	0	冶钢-钢管	天津	否	是			8	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1124.5	f	 		M005860	调质-80KSI	XYGN5203-2022-01	3060420T	9120	0	9120	0	0	0	冶钢-钢管	天津	否	是			7	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1115.9	f	 		M005859	调质-80KSI	XYGN5203-2022-01	3060420T	9050	0	9050	0	0	0	冶钢-钢管	天津	否	是			6	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*25.4	0	1122	f	 		M005858	调质-80KSI	XYGN5203-2022-01	3060420T	9100	0	9100	0	0	0	冶钢-钢管	天津	否	是			5	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*41.275	0	1863.8	f	 		M005878	调质-80KSI	XYGN5203-2022-01	3060273T	10118	0	10118	0	0	0	冶钢-钢管	天津	否	是			25	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*41.275	0	1863.8	f	 		M005879	调质-80KSI	XYGN5203-2022-01	3060273T	10118	0	10118	0	0	0	冶钢-钢管	天津	否	是			26	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*41.275	0	1818.1	f	 		M005880	调质-80KSI	XYGN5203-2022-01	3060273T	9870	0	9870	0	0	0	冶钢-钢管	天津	否	是			27	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*41.275	0	1858.6	f	 		M005881	调质-80KSI	XYGN5203-2022-01	3060273T	10090	0	10090	0	0	0	冶钢-钢管	天津	否	是			28	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*41.275	0	758.9	f	 		M005882	调质-80KSI	XYGN5203-2022-01	3060273T	4120	0	4120	0	0	0	冶钢-钢管	天津	否	是			29	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*41.275	0	1184.4	f	 		M005883	调质-80KSI	XYGN5203-2022-01	3060273T	6430	0	6430	0	0	0	冶钢-钢管	天津	否	是			30	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	222.25*41.275	0	822.5	f	 		M005884	调质-80KSI	XYGN5203-2022-01	3060273T	4465	0	4465	0	0	0	冶钢-钢管	天津	否	是			31	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	969.1	f	 		M005885	调质-80KSI	XYGN5203-2022-01	3076208A	9130	0	9130	0	0	0	冶钢-钢管	天津	否	是			32	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	964.9	f	 		M005886	调质-80KSI	XYGN5203-2022-01	3076208A	9090	0	9090	0	0	0	冶钢-钢管	天津	否	是			33	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	944.7	f	 		M005887	调质-80KSI	XYGN5203-2022-01	3076208A	8900	0	8900	0	0	0	冶钢-钢管	天津	否	是			34	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	949	f	 		M005888	调质-80KSI	XYGN5203-2022-01	3076208A	8940	0	8940	0	0	0	冶钢-钢管	天津	否	是			35	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	936.2	f	 		M005889	调质-80KSI	XYGN5203-2022-01	3076208A	8820	0	8820	0	0	0	冶钢-钢管	天津	否	是			36	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	960.1	f	 		M005890	调质-80KSI	XYGN5203-2022-01	3076208A	9045	0	9045	0	0	0	冶钢-钢管	天津	否	是			37	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	932	f	 		M005891	调质-80KSI	XYGN5203-2022-01	3076208A	8780	0	8780	0	0	0	冶钢-钢管	天津	否	是			38	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	902.3	f	 		M005892	调质-80KSI	XYGN5203-2022-01	3076208A	8500	0	8500	0	0	0	冶钢-钢管	天津	否	是			39	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	960.1	f	 		M005893	调质-80KSI	XYGN5203-2022-01	3076208A	9045	0	9045	0	0	0	冶钢-钢管	天津	否	是			40	0	0	0	0	0	f	f	f	室内	RK2401-003
4_103	215.9*22.225	0	964.9	f	 		M005894	调质-80KSI	XYGN5203-2022-01	3076208A	9090	0	9090	0	0	0	冶钢-钢管	天津	否	是			41	0	0	0	0	0	f	f	f	室内	RK2401-003
3_101	210	0	1536.2	f			M005895	固溶时效	ZHSD/JT-20-0136/0+GB/T1220-2007	3MAL21094	5610	0	5610	0	0	0	劝诚	天津		是			1	0	0	0	0	0	f	f	f	室外	RK2401-004
	130	0	1277.34	f	 		M000540	热轧	JX2534-2010-01	E12200905XA	12250	0	12250	0	0	0	江阴兴澄	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
	203*28	0	142.58	f	 		B230110-10	调质110KSI	API SPEC 5CT & FS-T-M-011C	TX22-06530LG	1180	0	1180	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
	100	0	3.7	f	 		L004	调质-80KSI	QJ-DT01.24412-2020-A/0	21209123087	60	0	60	0	0	0	抚顺特钢	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
4_104	171.5*31.75	0	611.65	f	 		B230110-189	调质-80KSI	API SPEC 5CT& FS-T-M-011C	TX22-06595LG	5590	0	5590	0	0	0	江苏常宝	天津	否				0	0	0	0	0	0	f	f	f	 	KT202312-01
\.


--
-- Data for Name: tableset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tableset (id, table_name, field_name, data_type, show_name, show_width, ctr_type, option_value, is_show, show_order, inout_show, inout_order, default_value, all_edit, is_use, inout_width) FROM stdin;
39	供应商	停用	布尔	停用	4	二值选一	是_否	t	6	f	7		t	t	4
40	供应商	备注	文本	备注	10	普通输入		t	7	t	6		t	t	10
38	供应商	地址	文本	公司地址	10	普通输入		t	5	t	4		t	t	10
36	供应商	联系人	文本	联系人	4	普通输入		t	2	t	2		t	t	4
41	供应商	文本字段1	文本	简称	6	普通输入		t	4	t	5		t	t	6
35	供应商	名称	文本	名称	10	普通输入		t	1	t	1		t	t	10
69	客户	地址	文本	公司地址	25	普通输入		t	4	t	4		t	t	12
77	客户	文本字段7	文本	简称	7	普通输入		t	15	t	8		t	t	6
67	客户	联系人	文本	联系人	4	普通输入		t	2	t	2		t	t	4
68	客户	电话	文本	电话	8	普通输入		t	3	t	3		t	t	6
121	商品规格	文本字段8	文本	合格	2	普通输入		f	17	f	6		t	t	3
105	商品规格	文本字段1	文本	物料号	5	普通输入		t	1	f	7		t	t	5
133	商品规格	库位	文本	库位	4	普通输入		t	12	f	8		t	t	4
112	商品规格	文本字段4	文本	炉号	5	普通输入		t	6	f	10		t	t	5
114	商品规格	整数字段1	整数	入库长度	4	普通输入		t	8	f	12		t	t	4
115	商品规格	整数字段2	整数	切分	3	普通输入		t	9	f	13		t	t	3
116	商品规格	整数字段3	整数	库存长度	4	普通输入		t	10	f	14		t	t	4
107	商品规格	出售价格	实数	售价	3	普通输入		t	7	f	15		t	t	3
108	商品规格	库存下限	实数	理论重量	4	普通输入		t	11	f	16		t	t	4
110	商品规格	备注	文本	备注	5	普通输入		t	15	f	17		t	t	5
124	商品规格	整数字段4	整数	顺序	2	普通输入		f	16	f	18		t	t	2
102	商品规格	规格型号	文本	规格	5	普通输入		t	2	t	1		t	t	5
104	商品规格	文本字段2	文本	状态	6	普通输入		t	3	t	2		t	t	6
37	供应商	电话	文本	手机	6	普通输入		t	3	t	3		t	t	6
83	客户	文本字段4	文本	行号	7	普通输入		t	14	f	14		t	t	6
301	库存调出	日期	文本	日期	4	普通输入		t	1	t	2		t	t	5
319	库存调出	经办人	文本	经办人	4	普通输入	张裕华_刘杰同_李正民	t	3	f	5		t	t	4
327	库存调出	文本字段7	文本	区域	6	普通输入		t	6	f	6		t	t	6
324	库存调出	文本字段10	文本	审核	4	普通输入		t	5	f	7		t	t	6
318	库存调出	备注	文本	备注	12	普通输入		t	7	t	3		t	t	12
1	采购单据	日期	文本	日期	5	普通输入		t	2	t	2		t	t	4
10	采购单据	文本字段1	文本	合同编号	6	普通输入		t	1	t	1		t	t	6
2	采购单据	应结金额	实数	金额	4	普通输入		t	3	t	3		t	t	4
8	采购单据	经办人	文本	经办人	4	普通输入		t	5	f	8		t	t	4
283	发货单据	备注	文本	备注	8	普通输入		t	15	t	11		t	t	8
285	发货单据	文本字段7	文本	区域	3	普通输入		t	14	f	15		t	t	3
286	发货单据	布尔字段3	布尔	提交审核	3	二值选一	是_否	t	12	f	13		t	t	4
227	入库单据	文本字段6	文本	采购单号	10	普通输入		t	1	t	1		t	t	8
199	入库单据	日期	文本	入库日期	5	普通输入		t	2	t	2		t	t	4
209	入库单据	实数字段1	实数	来料重量	4	普通输入		t	5	t	4		t	t	2.5
201	入库单据	经办人	文本	经办人	4	普通输入	张继成_刘树芳_李华同	t	4	f	10	李华同	t	t	4
218	入库单据	实数字段2	实数	实际重量	4	普通输入		t	6	t	5		t	t	2.5
226	入库单据	实数字段3	实数	理论重量	4	普通输入		t	7	t	6		t	t	2.5
216	入库单据	文本字段2	文本	质检	4	普通输入		t	10	f	9		t	t	4
204	入库单据	文本字段10	文本	审核	4	普通输入		t	9	f	12		t	t	6
231	入库单据	文本字段7	文本	区域	3	普通输入		t	11	f	11		t	t	3
224	入库单据	备注	文本	备注	8	普通输入		t	12	t	7		t	t	6
194	库存调入	文本字段1	文本	原因	6	下拉列表	下错料_销售退货_盘盈	t	2	t	1		t	t	6
169	库存调入	日期	文本	日期	4	普通输入		t	1	t	2		t	t	5
175	库存调入	经办人	文本	经办人	4	普通输入	张裕华_刘杰同_李正民	t	3	f	5		t	t	4
135	销售单据	应结金额	实数	单据金额	4	普通输入		t	4	t	4		t	t	4
178	库存调入	文本字段10	文本	审核	4	普通输入		t	5	f	7		t	t	6
179	库存调入	备注	文本	备注	12	普通输入		t	7	t	3		t	t	12
80	客户	文本字段1	文本	税号	10	普通输入		t	11	f	11		t	t	6
75	客户	停用	布尔	停用	4	二值选一	是_否	t	16	f	10		t	t	4
81	客户	文本字段2	文本	开户行	20	普通输入		t	12	f	12		t	t	6
138	销售单据	文本字段7	文本	区域	3	普通输入		t	14	f	15		t	t	3
158	销售单据	备注	文本	备注	8	普通输入		t	15	t	6		t	t	10
159	销售单据	文本字段2	文本	交货日期	5	普通输入		t	9	t	5		t	t	4
167	销售单据	布尔字段1	布尔	发货完成	3	二值选一	是_否	t	11	f	10		t	t	3
273	发货单据	日期	文本	发货日期	5	普通输入		t	3	t	3		t	t	4
275	发货单据	经办人	文本	经办人	4	普通输入	张继成_刘树芳_李华同	t	9	f	14	李华同	t	t	4
281	发货单据	文本字段5	文本	客户	10	普通输入		t	5	t	5		t	t	10
134	销售单据	日期	文本	订单日期	5	普通输入		t	3	t	3		t	t	4
331	销售开票	备注	文本	备注	8	普通输入		t	13	t	9		t	t	10
261	出库单据	文本字段6	文本	销售单号	6	普通输入		t	1	t	1		t	t	6
76	客户	备注	文本	备注	6	普通输入		t	17	t	9		t	t	10
262	出库单据	文本字段5	文本	合同编号	8	普通输入		t	2	t	2		t	t	8
82	客户	文本字段3	文本	账号	12	普通输入		t	13	f	13		t	t	6
66	客户	名称	文本	名称	15	普通输入		t	1	t	1		t	t	10
113	商品规格	文本字段6	文本	区域	3	普通输入		t	13	f	11		t	t	3
106	商品规格	文本字段3	文本	执行标准	7	普通输入		t	4	t	3		t	t	12
111	商品规格	文本字段5	文本	生产厂家	5	普通输入		t	5	f	9		t	t	5
73	客户	信用评价	文本	收货人	4	普通输入	极好_优秀_良好_中等_较差	t	5	t	5		t	t	4
256	出库单据	文本字段4	文本	客户	10	普通输入		t	3	t	3		t	t	14
233	出库单据	日期	文本	日期	4	普通输入		t	4	t	4		t	t	4
84	客户	文本字段5	文本	收票人	4	普通输入		t	8	f	15		t	t	6
85	客户	文本字段6	文本	收票电话	6	普通输入		t	9	f	16		t	t	6
74	客户	地区	文本	收货电话	8	普通输入		t	6	t	6		t	t	6
78	客户	文本字段9	文本	收货地址	25	普通输入		t	7	t	7		t	t	6
86	客户	文本字段8	文本	收票地址	25	普通输入		t	10	f	17		t	t	6
122	商品规格	文本字段9	文本	原物料号	4	普通输入		f	18	f	4		t	t	4
120	商品规格	文本字段7	文本	切完	3	下拉列表	否_是	t	14	f	5		t	t	3
235	出库单据	经办人	文本	经办人	4	普通输入	张继成_刘树芳_李华同	t	5	f	9	李华同	t	t	4
238	出库单据	文本字段10	文本	审核	4	普通输入		t	7	f	11		t	t	6
258	出库单据	备注	文本	备注	8	普通输入		t	9	t	5		t	t	6
244	出库单据	布尔字段1	布尔	发货完成	3	二值选一	是_否	f	11	f	6		t	t	3
329	库存调出	布尔字段3	布尔	提交审核	4	二值选一	是_否	t	4	f	4		t	t	4
12	采购单据	文本字段3	文本	到货日期	5	普通输入		t	4	t	4		t	t	4
34	采购单据	布尔字段3	布尔	提交审核	4	二值选一	是_否	t	6	f	7		t	t	4
19	采购单据	文本字段10	文本	审核	4	普通输入		t	7	f	10		t	t	6
33	采购单据	布尔字段2	布尔	入库完成	4	二值选一	是_否	t	8	t	5		t	t	4
16	采购单据	文本字段7	文本	区域	4	普通输入		t	9	f	9		t	t	6
9	采购单据	备注	文本	备注	8	普通输入		t	10	t	6		t	t	6
279	发货单据	文本字段6	文本	销售单号	5	普通输入		t	1	t	1		t	t	8
228	入库单据	文本字段5	文本	到货日期	5	普通输入		t	3	t	3		t	t	4
212	入库单据	布尔字段3	布尔	提交审核	4	二值选一	是_否	t	8	f	8		t	t	4
246	出库单据	布尔字段3	布尔	提交审核	4	二值选一	是_否	t	6	f	7		t	t	4
265	出库单据	文本字段7	文本	区域	3	普通输入		t	8	f	10		t	t	3
250	出库单据	文本字段2	文本	图片	4	普通输入		f	10	f	8		t	t	4
174	库存调入	布尔字段3	布尔	提交审核	4	二值选一	是_否	t	4	f	4		t	t	4
170	库存调入	文本字段7	文本	区域	6	普通输入		t	6	f	6		t	t	6
140	销售单据	文本字段10	文本	审核	4	普通输入		t	8	f	16		t	t	6
153	销售单据	布尔字段2	布尔	出库完成	3	二值选一	是_否	t	10	f	11		t	t	3
338	销售开票	文本字段5	文本	发票金额	4	普通输入		t	10	t	7		t	t	4
337	销售开票	文本字段7	文本	区域	3	普通输入		t	12	f	14		t	t	3
339	销售开票	文本字段10	文本	审核	4	普通输入		t	9	f	15		t	t	6
154	销售单据	布尔字段3	布尔	提交审核	4	二值选一	是_否	t	7	f	13		t	t	4
296	发货单据	文本字段8	文本	收货人	4	普通输入		t	6	t	6		t	t	4
306	库存调出	文本字段1	文本	原因	6	下拉列表	盘亏_下错料	t	2	t	1		t	t	6
335	销售开票	文本字段2	文本	客户名称	5	普通输入		t	3	t	3		t	t	15
336	销售开票	文本字段4	文本	发票号	10	普通输入		t	11	t	8		t	t	10
267	发货单据	文本字段10	文本	审核	4	普通输入		t	13	f	16		t	t	6
269	发货单据	整数字段2	整数	整数字段2	4	普通输入		f	25	f	21		t	f	4
333	销售开票	应结金额	实数	单据金额	4	普通输入		t	5	t	4		t	t	4
340	销售开票	布尔字段3	布尔	提交审核	4	二值选一	是_否	t	8	f	12		t	t	4
334	销售开票	日期	文本	开票日期	5	普通输入		t	4	t	6		t	t	4
297	发货单据	文本字段1	文本	收货地址	10	普通输入		t	8	t	8		t	t	10
295	发货单据	文本字段3	文本	合同号	6	普通输入		t	2	t	2		t	t	8
288	发货单据	文本字段9	文本	收货电话	5	普通输入		t	7	t	7		t	t	5
278	发货单据	文本字段2	文本	发货方式	4	下拉列表	自提_送货上门	t	4	t	4		t	t	5
350	销售开票	实数字段5	实数	实数字段5	4	普通输入		f	33	f	30		t	f	4
341	销售开票	布尔字段2	布尔	出库完成	3	二值选一	是_否	f	16	f	11		t	f	3
160	销售单据	文本字段5	文本	发票金额	4	普通输入		f	12	f	8		t	f	4
70	客户	税率	实数	税率	3	普通输入		f	18	f	9		t	f	3
346	销售开票	文本字段6	文本	销售单号	5	普通输入		t	1	t	1		t	t	6
347	销售开票	是否欠款	布尔	是否欠款	3	二值选一	是_否	t	6	t	5	是	t	t	3
349	销售开票	已记账	布尔	反审	4	二值选一	是_否	f	14	f	11		t	t	4
348	销售开票	经办人	文本	经办人	4	普通输入	张继成_刘树芳_李华同	t	7	f	13	李华同	t	t	4
163	销售单据	文本字段4	文本	发票号	10	普通输入		f	13	f	9		t	f	10
364	销售开票	实数字段6	实数	实数字段6	4	普通输入		f	34	f	31		t	f	4
354	销售开票	实数字段2	实数	实数字段2	4	普通输入		f	30	f	27		t	f	4
352	销售开票	是否含税	布尔	是否含税	4	二值选一	是_否	f	18	f	5	是	t	f	4
353	销售开票	文本字段1	文本	交货日期	4	普通输入		f	21	f	5		t	f	4
229	入库单据	已记账	布尔	反审	4	二值选一	是_否	f	15	f	9		t	t	4
345	销售开票	整数字段2	整数	整数字段2	4	普通输入		f	24	f	21		t	f	4
344	销售开票	实数字段1	实数	实数字段1	4	普通输入		f	29	f	26		t	f	4
365	发货单据	文本字段11	文本	提货车牌	4	普通输入		t	10	t	9		t	t	6
366	发货单据	文本字段12	文本	司机电话	5	普通输入		t	11	t	10		t	t	6
356	销售开票	文本字段3	文本	图片	4	普通输入		f	15	f	10		t	t	8
180	库存调入	已记账	布尔	反审	4	二值选一	是_否	f	11	f	9		t	t	4
6	采购单据	已记账	布尔	反审	4	二值选一	是_否	f	13	f	7	否	t	t	4
322	库存调出	已记账	布尔	反审	4	二值选一	是_否	f	10	f	9		t	t	4
351	销售开票	实数字段3	实数	实数字段3	4	普通输入		f	31	f	28		t	f	4
355	销售开票	实数字段4	实数	实数字段4	4	普通输入		f	32	f	29		t	f	4
361	销售开票	已结金额	实数	已结金额	4	普通输入		f	19	f	4		t	f	4
357	销售开票	其他费用	实数	其他费用	4	普通输入		f	20	f	8		t	f	4
360	销售开票	整数字段1	整数	整数字段1	4	普通输入		f	23	f	20		t	f	4
362	销售开票	整数字段4	整数	整数字段4	4	普通输入		f	26	f	23		t	f	4
293	发货单据	实数字段2	实数	实数字段2	4	普通输入		f	31	f	27		t	f	4
263	出库单据	已记账	布尔	反审	4	二值选一	是_否	f	12	f	8		t	t	4
284	发货单据	已记账	布尔	反审	4	二值选一	是_否	f	16	f	12		t	t	4
358	销售开票	整数字段6	整数	整数字段6	4	普通输入		f	28	f	25		t	f	4
189	库存调入	实数字段6	实数	实数字段6	4	普通输入		f	28	f	31		t	f	4
211	入库单据	布尔字段2	布尔	布尔字段2	4	二值选一	是_否	f	34	f	33		t	f	4
101	客户	布尔字段3	布尔	布尔字段3	4	二值选一	是_否	f	36	f	36		t	f	4
94	客户	实数字段5	实数	实数字段5	4	普通输入		f	29	f	29		t	f	4
230	入库单据	其他费用	实数	其他费用	4	普通输入		f	21	f	8		t	f	4
287	发货单据	已结金额	实数	已结金额	4	普通输入		f	22	f	4		t	f	4
168	销售单据	经办人	文本	经办人	4	普通输入	张继成_刘树芳_李华同	t	6	f	14	李华同	t	t	4
161	销售单据	已记账	布尔	反审	4	二值选一	是_否	f	16	f	12		t	t	4
359	销售开票	文本字段8	文本	合同编号	5	普通输入		t	2	t	2		t	t	8
137	销售单据	文本字段6	文本	合同编号	5	普通输入		t	1	t	2		t	t	8
342	销售开票	文本字段9	文本	文本字段9	6	普通输入		f	22	f	18		t	f	6
330	库存调出	实数字段3	实数	实数字段3	4	普通输入		f	25	f	28		t	f	4
22	采购单据	整数字段3	整数	整数字段3	4	普通输入		f	25	f	22		t	f	4
100	客户	布尔字段2	布尔	布尔字段2	4	二值选一	是_否	f	35	f	35		t	f	4
363	销售开票	整数字段3	整数	整数字段3	4	普通输入		f	25	f	22		t	f	4
139	销售单据	文本字段9	文本	文本字段9	6	普通输入		f	22	f	18		t	f	6
142	销售单据	整数字段2	整数	整数字段2	4	普通输入		f	24	f	21		t	f	4
146	销售单据	整数字段5	整数	整数字段5	4	普通输入		f	27	f	24		t	f	4
294	发货单据	整数字段4	整数	整数字段4	4	普通输入		f	27	f	23		t	f	4
155	销售单据	是否欠款	布尔	是否欠款	3	二值选一	是_否	t	5	f	7	是	t	t	3
147	销售单据	实数字段1	实数	实数字段1	4	普通输入		f	29	f	26		t	f	4
343	销售开票	整数字段5	整数	整数字段5	4	普通输入		f	27	f	24		t	f	4
103	商品规格	单位	文本	单位	2	普通输入		f	21	f	1		t	f	2
326	库存调出	文本字段4	文本	文本字段4	6	普通输入		f	12	f	13		t	f	6
45	供应商	文本字段5	文本	文本字段5	6	普通输入		f	11	f	11		t	f	6
96	客户	实数字段1	实数	实数字段1	4	普通输入		f	31	f	31		t	f	4
332	销售开票	布尔字段1	布尔	发货完成	3	二值选一	是_否	f	17	f	10		t	f	3
48	供应商	文本字段8	文本	文本字段8	6	普通输入		f	14	f	14		t	f	6
61	供应商	实数字段5	实数	实数字段5	4	普通输入		f	27	f	27		t	f	4
303	库存调出	文本字段9	文本	文本字段9	6	普通输入		f	16	f	18		t	f	6
18	采购单据	文本字段9	文本	文本字段9	6	普通输入		f	22	f	18		t	f	6
257	出库单据	文本字段8	文本	文本字段8	6	普通输入		f	20	f	17		t	f	6
282	发货单据	文本字段4	文本	提货车牌	6	普通输入		f	17	f	9		t	f	6
277	发货单据	布尔字段1	布尔	发货完成	3	二值选一	是_否	f	20	f	6		t	f	3
97	客户	实数字段2	实数	实数字段2	4	普通输入		f	32	f	32		t	f	4
205	入库单据	整数字段1	整数	整数字段1	4	普通输入		f	25	f	20		t	f	4
213	入库单据	是否含税	布尔	是否含税	4	二值选一	是_否	f	19	f	5	是	t	f	4
304	库存调出	整数字段2	整数	整数字段2	4	普通输入		f	18	f	21		t	f	4
43	供应商	文本字段3	文本	文本字段3	6	普通输入		f	9	f	9		t	f	6
259	出库单据	文本字段1	文本	交货日期	4	普通输入		f	19	f	5		t	f	4
173	库存调入	实数字段4	实数	实数字段4	4	普通输入		f	26	f	29		t	f	4
72	客户	优惠折扣	实数	优惠折扣	4	普通输入		f	20	f	7		t	f	4
44	供应商	文本字段4	文本	文本字段4	6	普通输入		f	10	f	10		t	f	6
42	供应商	文本字段2	文本	收货地址	10	普通输入		f	8	f	8		t	f	6
59	供应商	实数字段3	实数	实数字段3	4	普通输入		f	25	f	25		t	f	4
207	入库单据	整数字段5	整数	整数字段5	4	普通输入		f	29	f	24		t	f	4
247	出库单据	是否含税	布尔	是否含税	4	二值选一	是_否	f	16	f	5	是	t	f	4
264	出库单据	其他费用	实数	其他费用	4	普通输入		f	18	f	8		t	f	4
64	供应商	布尔字段2	布尔	布尔字段2	4	二值选一	是_否	f	30	f	30		t	f	4
21	采购单据	整数字段2	整数	整数字段2	4	普通输入		f	24	f	21		t	f	4
208	入库单据	整数字段6	整数	整数字段6	4	普通输入		f	30	f	25		t	f	4
234	出库单据	应结金额	实数	单据金额	4	普通输入		f	13	f	3		t	f	4
176	库存调入	文本字段2	文本	文本字段2	6	普通输入		f	9	f	6		t	f	6
181	库存调入	整数字段3	整数	整数字段3	4	普通输入		f	19	f	22		t	f	4
222	入库单据	文本字段4	文本	发票号	10	普通输入		f	18	f	5		t	f	10
117	商品规格	实数字段1	实数	面积	4	普通输入		f	22	f	16		t	f	4
151	销售单据	实数字段5	实数	实数字段5	4	普通输入		f	33	f	30		t	f	4
290	发货单据	实数字段4	实数	实数字段4	4	普通输入		f	33	f	29		t	f	4
300	发货单据	实数字段6	实数	实数字段6	4	普通输入		f	35	f	31		t	f	4
223	入库单据	文本字段8	文本	文本字段8	6	普通输入		f	23	f	17		t	f	6
196	库存调入	文本字段3	文本	文本字段3	6	普通输入		f	8	f	12		t	f	6
191	库存调入	整数字段2	整数	整数字段2	4	普通输入		f	18	f	21		t	f	4
197	库存调入	文本字段8	文本	文本字段8	6	普通输入		f	15	f	17		t	f	6
245	出库单据	布尔字段2	布尔	布尔字段2	4	二值选一	是_否	f	34	f	33		t	f	4
248	出库单据	实数字段4	实数	实数字段4	4	普通输入		f	31	f	29		t	f	4
270	发货单据	整数字段5	整数	整数字段5	4	普通输入		f	28	f	24		t	f	4
210	入库单据	布尔字段1	布尔	已质检	3	二值选一	是_否	f	16	f	7		t	f	3
221	入库单据	是否欠款	布尔	是否欠款	3	二值选一	是_否	f	14	f	7	是	t	f	3
25	采购单据	整数字段6	整数	整数字段6	4	普通输入		f	28	f	25		t	f	4
315	库存调出	布尔字段1	布尔	布尔字段1	4	二值选一	是_否	f	29	f	32		t	f	4
317	库存调出	实数字段4	实数	实数字段4	4	普通输入		f	26	f	29		t	f	4
305	库存调出	实数字段1	实数	实数字段1	4	普通输入		f	23	f	26		t	f	4
92	客户	整数字段6	整数	整数字段6	4	普通输入		f	27	f	27		t	f	4
328	库存调出	布尔字段2	布尔	布尔字段2	4	二值选一	是_否	f	30	f	33		t	f	4
236	出库单据	已结金额	实数	已结金额	4	普通输入		f	17	f	4		t	f	4
253	出库单据	整数字段4	整数	整数字段4	4	普通输入		f	25	f	23		t	f	4
47	供应商	文本字段7	文本	文本字段7	6	普通输入		f	13	f	13		t	f	6
274	发货单据	应结金额	实数	单据金额	4	普通输入		f	18	f	3		t	f	4
289	发货单据	是否含税	布尔	是否含税	4	二值选一	是_否	f	21	f	5	是	t	f	4
149	销售单据	实数字段3	实数	实数字段3	4	普通输入		f	31	f	28		t	f	4
58	供应商	实数字段2	实数	实数字段2	4	普通输入		f	24	f	24		t	f	4
71	客户	含税	布尔	含税	4	二值选一	是_否	f	19	f	10	是	t	f	4
254	出库单据	文本字段3	文本	文本字段3	4	普通输入		f	14	f	9		t	f	4
98	客户	实数字段3	实数	实数字段3	4	普通输入		f	33	f	33		t	f	4
237	出库单据	文本字段9	文本	文本字段9	6	普通输入		f	21	f	18		t	f	6
123	商品规格	文本字段10	文本	文本字段10	6	普通输入		f	25	f	22		t	f	6
165	销售单据	是否含税	布尔	是否含税	4	二值选一	是_否	f	18	f	5	是	t	f	4
162	销售单据	文本字段1	文本	交货日期	4	普通输入		f	21	f	5		t	f	4
119	商品规格	实数字段3	实数	实数字段3	4	普通输入		f	24	f	18		t	f	4
53	供应商	整数字段3	整数	整数字段3	4	普通输入		f	19	f	19		t	f	4
89	客户	整数字段3	整数	整数字段3	4	普通输入		f	24	f	24		t	f	4
79	客户	文本字段10	文本	文本字段10	6	普通输入		f	21	f	14		t	f	6
131	商品规格	布尔字段2	布尔	布尔字段2	3	二值选一	是_否	f	31	f	30		t	f	3
87	客户	整数字段1	整数	整数字段1	4	普通输入		f	22	f	22		t	f	4
88	客户	整数字段2	整数	整数字段2	4	普通输入		f	23	f	23		t	f	4
321	库存调出	实数字段2	实数	实数字段2	4	普通输入		f	24	f	27		t	f	4
4	采购单据	是否含税	布尔	是否含税	4	二值选一	是_否	f	14	f	4	是	t	f	4
132	商品规格	布尔字段3	布尔	布尔字段3	3	二值选一	正确_错误	f	32	f	31		t	f	3
13	采购单据	文本字段4	文本	文本字段4	6	普通输入		f	18	f	13		t	f	6
26	采购单据	实数字段1	实数	实数字段1	4	普通输入		f	29	f	26		t	f	4
195	库存调入	文本字段4	文本	文本字段4	6	普通输入		f	12	f	13		t	f	6
188	库存调入	实数字段5	实数	实数字段5	4	普通输入		f	27	f	30		t	f	4
190	库存调入	布尔字段2	布尔	布尔字段2	4	二值选一	是_否	f	30	f	33		t	f	4
266	出库单据	实数字段6	实数	实数字段6	4	普通输入		f	33	f	31		t	f	4
302	库存调出	文本字段8	文本	文本字段8	6	普通输入		f	15	f	17		t	f	6
91	客户	整数字段5	整数	整数字段5	4	普通输入		f	26	f	26		t	f	4
95	客户	实数字段6	实数	实数字段6	4	普通输入		f	30	f	30		t	f	4
242	出库单据	整数字段6	整数	整数字段6	4	普通输入		f	27	f	25		t	f	4
171	库存调入	文本字段9	文本	文本字段9	6	普通输入		f	16	f	18		t	f	6
177	库存调入	文本字段5	文本	文本字段5	6	普通输入		f	13	f	14		t	f	6
7	采购单据	其他费用	实数	其他费用	4	普通输入		f	16	f	6		t	f	4
316	库存调出	文本字段2	文本	文本字段2	6	普通输入		f	11	f	6		t	f	6
320	库存调出	其他费用	实数	相关费用	4	普通输入		f	9	f	2		t	f	4
325	库存调出	文本字段5	文本	文本字段5	6	普通输入		f	13	f	14		t	f	6
50	供应商	文本字段10	文本	文本字段10	6	普通输入		f	16	f	16		t	f	6
20	采购单据	整数字段1	整数	整数字段1	4	普通输入		f	23	f	20		t	f	4
130	商品规格	布尔字段1	布尔	布尔字段1	3	二值选一	是_否	f	19	f	29	是	t	f	3
32	采购单据	布尔字段1	布尔	已到货	4	二值选一	是_否	f	11	f	4		t	f	4
29	采购单据	实数字段4	实数	实数字段4	4	普通输入		f	32	f	29		t	f	4
219	入库单据	整数字段4	整数	整数字段4	4	普通输入		f	28	f	23		t	f	4
255	出库单据	是否欠款	布尔	是否欠款	3	二值选一	是_否	f	15	f	4	是	t	f	3
243	出库单据	实数字段1	实数	实数字段1	4	普通输入		f	28	f	26		t	f	4
148	销售单据	实数字段2	实数	实数字段2	4	普通输入		f	30	f	27		t	f	4
150	销售单据	实数字段4	实数	实数字段4	4	普通输入		f	32	f	29		t	f	4
272	发货单据	实数字段1	实数	实数字段1	4	普通输入		f	30	f	26		t	f	4
90	客户	整数字段4	整数	整数字段4	4	普通输入		f	25	f	25		t	f	4
215	入库单据	实数字段5	实数	实数字段5	4	普通输入		f	32	f	30		t	f	4
217	入库单据	整数字段3	整数	整数字段3	4	普通输入		f	27	f	22		t	f	4
225	入库单据	文本字段1	文本	交货日期	4	普通输入		f	22	f	5		t	f	4
309	库存调出	整数字段4	整数	整数字段4	4	普通输入		f	20	f	23		t	f	4
172	库存调入	实数字段3	实数	实数字段3	4	普通输入		f	25	f	28		t	f	4
184	库存调入	整数字段1	整数	整数字段1	4	普通输入		f	17	f	20		t	f	4
182	库存调入	整数字段4	整数	整数字段4	4	普通输入		f	20	f	23		t	f	4
214	入库单据	实数字段4	实数	实数字段4	4	普通输入		f	31	f	29		t	f	4
206	入库单据	整数字段2	整数	整数字段2	4	普通输入		f	26	f	21		t	f	4
187	库存调入	实数字段1	实数	实数字段1	4	普通输入		f	23	f	26		t	f	4
198	库存调入	布尔字段1	布尔	布尔字段1	4	二值选一	是_否	f	29	f	32		t	f	4
183	库存调入	文本字段6	文本	文本字段6	6	普通输入		f	14	f	15		t	f	6
241	出库单据	整数字段5	整数	整数字段5	4	普通输入		f	26	f	24		t	f	4
299	发货单据	其他费用	实数	其他费用	4	普通输入		f	23	f	8		t	f	4
292	发货单据	整数字段3	整数	整数字段3	4	普通输入		f	26	f	22		t	f	4
271	发货单据	整数字段6	整数	整数字段6	4	普通输入		f	29	f	25		t	f	4
311	库存调出	整数字段1	整数	整数字段1	4	普通输入		f	17	f	20		t	f	4
17	采购单据	文本字段8	文本	文本字段8	6	普通输入		f	21	f	17		t	f	6
14	采购单据	文本字段5	文本	文本字段5	6	普通输入		f	19	f	14		t	f	6
99	客户	布尔字段1	布尔	布尔字段1	4	二值选一	是_否	f	34	f	34		t	f	4
127	商品规格	实数字段4	实数	实数字段4	4	普通输入		f	28	f	26		t	f	4
109	商品规格	停用	布尔	停用	3	二值选一	是_否	f	20	f	9		t	f	3
62	供应商	实数字段6	实数	实数字段6	4	普通输入		f	28	f	28		t	f	4
164	销售单据	文本字段3	文本	文本字段3	4	普通输入		f	17	f	1		t	f	8
129	商品规格	实数字段6	实数	实数字段6	4	普通输入		f	30	f	28		t	f	4
54	供应商	整数字段4	整数	整数字段4	4	普通输入		f	20	f	20		t	f	4
56	供应商	整数字段6	整数	整数字段6	4	普通输入		f	22	f	22		t	f	4
118	商品规格	实数字段2	实数	进货价格	4	普通输入		f	23	f	17		t	f	4
260	出库单据	实数字段3	实数	实数字段3	4	普通输入		f	30	f	28		t	f	4
308	库存调出	整数字段6	整数	整数字段6	4	普通输入		f	22	f	25		t	f	4
65	供应商	布尔字段3	布尔	布尔字段3	4	二值选一	是_否	f	31	f	31		t	f	4
239	出库单据	整数字段1	整数	整数字段1	4	普通输入		f	22	f	20		t	f	4
251	出库单据	整数字段3	整数	整数字段3	4	普通输入		f	24	f	22		t	f	4
252	出库单据	实数字段2	实数	实数字段2	4	普通输入		f	29	f	27		t	f	4
220	入库单据	文本字段3	文本	文本字段3	4	普通输入		f	17	f	10		t	f	4
232	入库单据	实数字段6	实数	实数字段6	4	普通输入		f	33	f	31		t	f	4
193	库存调入	其他费用	实数	相关费用	4	普通输入		f	10	f	2		t	f	4
186	库存调入	整数字段6	整数	整数字段6	4	普通输入		f	22	f	25		t	f	4
192	库存调入	实数字段2	实数	实数字段2	4	普通输入		f	24	f	27		t	f	4
200	入库单据	应结金额	实数	单据金额	4	普通输入		f	13	f	6		t	f	4
156	销售单据	其他费用	实数	其他费用	4	普通输入		f	20	f	8		t	f	4
268	发货单据	整数字段1	整数	整数字段1	4	普通输入		f	24	f	20		t	f	4
298	发货单据	实数字段3	实数	实数字段3	4	普通输入		f	32	f	28		t	f	4
291	发货单据	实数字段5	实数	实数字段5	4	普通输入		f	34	f	30		t	f	4
276	发货单据	布尔字段2	布尔	布尔字段2	4	二值选一	是_否	f	36	f	33		t	f	4
166	销售单据	文本字段8	文本	客户PO	5	普通输入		t	2	t	1		t	t	8
240	出库单据	整数字段2	整数	整数字段2	4	普通输入		f	23	f	21		t	f	4
202	入库单据	已结金额	实数	已结金额	4	普通输入		f	20	f	4		t	f	4
23	采购单据	整数字段4	整数	整数字段4	4	普通输入		f	26	f	23		t	f	4
31	采购单据	实数字段6	实数	实数字段6	4	普通输入		f	34	f	31		t	f	4
3	采购单据	已结金额	实数	已结金额	4	普通输入		f	15	f	3		t	f	4
143	销售单据	整数字段6	整数	整数字段6	4	普通输入		f	28	f	25		t	f	4
280	发货单据	是否欠款	布尔	是否欠款	3	二值选一	是_否	f	19	f	4	是	t	f	3
125	商品规格	整数字段5	整数	整数字段5	4	普通输入		f	26	f	24		t	f	4
128	商品规格	实数字段5	实数	实数字段5	4	普通输入		f	29	f	27		t	f	4
93	客户	实数字段4	实数	实数字段4	4	普通输入		f	28	f	28		t	f	4
60	供应商	实数字段4	实数	实数字段4	4	普通输入		f	26	f	26		t	f	4
126	商品规格	整数字段6	整数	整数字段6	4	普通输入		f	27	f	25		t	f	4
313	库存调出	整数字段5	整数	整数字段5	4	普通输入		f	21	f	24		t	f	4
314	库存调出	实数字段5	实数	实数字段5	4	普通输入		f	27	f	30		t	f	4
141	销售单据	整数字段1	整数	整数字段1	4	普通输入		f	23	f	20		t	f	4
52	供应商	整数字段2	整数	整数字段2	4	普通输入		f	18	f	18		t	f	4
55	供应商	整数字段5	整数	整数字段5	4	普通输入		f	21	f	21		t	f	4
310	库存调出	文本字段6	文本	文本字段6	6	普通输入		f	14	f	15		t	f	6
307	库存调出	实数字段6	实数	实数字段6	4	普通输入		f	28	f	31		t	f	4
5	采购单据	是否欠款	布尔	是否欠款	4	二值选一	是_否	f	12	f	5	是	t	f	4
28	采购单据	实数字段3	实数	实数字段3	4	普通输入		f	31	f	28		t	f	4
136	销售单据	已结金额	实数	已结金额	4	普通输入		f	19	f	4		t	f	4
51	供应商	整数字段1	整数	整数字段1	4	普通输入		f	17	f	17		t	f	4
249	出库单据	实数字段5	实数	实数字段5	4	普通输入		f	32	f	30		t	f	4
185	库存调入	整数字段5	整数	整数字段5	4	普通输入		f	21	f	24		t	f	4
24	采购单据	整数字段5	整数	整数字段5	4	普通输入		f	27	f	24		t	f	4
312	库存调出	整数字段3	整数	整数字段3	4	普通输入		f	19	f	22		t	f	4
57	供应商	实数字段1	实数	实数字段1	4	普通输入		f	23	f	23		t	f	4
63	供应商	布尔字段1	布尔	布尔字段1	4	二值选一	是_否	f	29	f	29		t	f	4
323	库存调出	文本字段3	文本	文本字段3	6	普通输入		f	8	f	12		t	f	6
145	销售单据	整数字段4	整数	整数字段4	4	普通输入		f	26	f	23		t	f	4
144	销售单据	整数字段3	整数	整数字段3	4	普通输入		f	25	f	22		t	f	4
203	入库单据	文本字段9	文本	文本字段9	6	普通输入		f	24	f	18		t	f	6
15	采购单据	文本字段6	文本	文本字段6	6	普通输入		f	20	f	15		t	f	6
11	采购单据	文本字段2	文本	文本字段2	4	普通输入		f	17	f	7		t	f	4
49	供应商	文本字段9	文本	文本字段9	6	普通输入		f	15	f	15		t	f	6
46	供应商	文本字段6	文本	文本字段6	6	普通输入		f	12	f	12		t	f	6
27	采购单据	实数字段2	实数	实数字段2	4	普通输入		f	30	f	27		t	f	4
30	采购单据	实数字段5	实数	实数字段5	4	普通输入		f	33	f	30		t	f	4
152	销售单据	实数字段6	实数	实数字段6	4	普通输入		f	34	f	31		t	f	4
\.


--
-- Data for Name: tmp; Type: TABLE DATA; Schema: public; Owner: sam
--

COPY public.tmp (id, table_name, field_name, data_type, show_name, show_width, ctr_type, option_value, is_show, show_order, inout_show, inout_order, default_value, all_edit, is_use, inout_width) FROM stdin;
158	销售开票	备注	文本	备注	8	普通输入		t	15	t	6		t	t	10
167	销售开票	布尔字段1	布尔	发货完成	3	二值选一	是_否	t	11	f	10		t	t	3
135	销售开票	应结金额	实数	单据金额	4	普通输入		t	4	t	4		t	t	4
134	销售开票	日期	文本	订单日期	5	普通输入		t	3	t	3		t	t	4
159	销售开票	文本字段2	文本	交货日期	5	普通输入		t	9	t	5		t	t	4
163	销售开票	文本字段4	文本	发票号	10	普通输入		t	13	f	9		t	t	10
138	销售开票	文本字段7	文本	区域	3	普通输入		t	14	f	15		t	t	3
160	销售开票	文本字段5	文本	发票金额	4	普通输入		t	12	f	8		t	t	4
140	销售开票	文本字段10	文本	审核	4	普通输入		t	8	f	16		t	t	6
154	销售开票	布尔字段3	布尔	提交审核	4	二值选一	是_否	t	7	f	13		t	t	4
153	销售开票	布尔字段2	布尔	出库完成	3	二值选一	是_否	t	10	f	11		t	t	3
139	销售开票	文本字段9	文本	文本字段9	6	普通输入		f	22	f	18		t	f	6
146	销售开票	整数字段5	整数	整数字段5	4	普通输入		f	27	f	24		t	f	4
147	销售开票	实数字段1	实数	实数字段1	4	普通输入		f	29	f	26		t	f	4
142	销售开票	整数字段2	整数	整数字段2	4	普通输入		f	24	f	21		t	f	4
137	销售开票	文本字段6	文本	合同编号	5	普通输入		t	1	t	2		t	t	8
155	销售开票	是否欠款	布尔	是否欠款	3	二值选一	是_否	t	5	f	7	是	t	t	3
168	销售开票	经办人	文本	经办人	4	普通输入	张继成_刘树芳_李华同	t	6	f	14	李华同	t	t	4
161	销售开票	已记账	布尔	反审	4	二值选一	是_否	f	16	f	12		t	t	4
151	销售开票	实数字段5	实数	实数字段5	4	普通输入		f	33	f	30		t	f	4
149	销售开票	实数字段3	实数	实数字段3	4	普通输入		f	31	f	28		t	f	4
165	销售开票	是否含税	布尔	是否含税	4	二值选一	是_否	f	18	f	5	是	t	f	4
162	销售开票	文本字段1	文本	交货日期	4	普通输入		f	21	f	5		t	f	4
148	销售开票	实数字段2	实数	实数字段2	4	普通输入		f	30	f	27		t	f	4
150	销售开票	实数字段4	实数	实数字段4	4	普通输入		f	32	f	29		t	f	4
164	销售开票	文本字段3	文本	文本字段3	4	普通输入		f	17	f	1		t	f	8
156	销售开票	其他费用	实数	其他费用	4	普通输入		f	20	f	8		t	f	4
143	销售开票	整数字段6	整数	整数字段6	4	普通输入		f	28	f	25		t	f	4
166	销售开票	文本字段8	文本	客户PO	5	普通输入		t	2	t	1		t	t	8
141	销售开票	整数字段1	整数	整数字段1	4	普通输入		f	23	f	20		t	f	4
136	销售开票	已结金额	实数	已结金额	4	普通输入		f	19	f	4		t	f	4
145	销售开票	整数字段4	整数	整数字段4	4	普通输入		f	26	f	23		t	f	4
144	销售开票	整数字段3	整数	整数字段3	4	普通输入		f	25	f	22		t	f	4
152	销售开票	实数字段6	实数	实数字段6	4	普通输入		f	34	f	31		t	f	4
\.


--
-- Data for Name: tree; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tree (num, pnum, node_name, pinyin, not_use) FROM stdin;
3_106	3	20CrMnMo 圆钢	20crmnmoyg	f
3_110	3	20CrNiMo 圆钢	20crnimoyg	f
3_105	3	4145H 圆钢	4145hyg	f
3_102	3	42CrMo 圆钢	42crmoyg	f
3_112	3	45号钢 圆钢	45hgyg	f
3_109	3	718 圆钢	718yg	f
3_103	3	L80-13Cr 圆钢	l8013cryg	f
3_108	3	L80-9Cr 圆钢	l809cryg	f
3_104	3	Super13Cr 圆钢	super13cryg	f
3	#	圆钢	yg	f
4	#	无缝钢管	wfgg	f
4_101	4	17-4 无缝钢管	174wfgg	f
4_104	4	4140 无缝钢管	4140wfgg	f
4_102	4	42CrMo 无缝钢管	42crmowfgg	f
4_108	4	C110 无缝钢管	c110wfgg	f
4_103	4	L80-13Cr 无缝钢管	l8013crwfgg	f
4_106	4	L80-9Cr 无缝钢管	l809crwfgg	f
3_101	3	17-4 圆钢	174yg	f
3_113	3	4130M7 圆钢	4130m7yg	f
4_110	4	Supper13Cr 无缝钢管	supper13crwfgg	f
3_107	3	20CrMnTi 圆钢	20crmntiyg	f
4_105	4	20CrMnTi 无缝钢管	20crmntiwfgg	f
3_114	3	625 圆钢	625yg	f
4_111	4	-- 锯口费	jkf	f
4_113	4	P110 无缝钢管	p110wfgg	f
4_109	4	P110 套管接箍料	p110tgjgl	f
4_107	4	L80-3Cr 无缝钢管	l803crwfgg	f
4_112	4	L80-1 无缝钢管	l801wfgg	f
3_115	3	新节点	xjd	f
3_111	3	20Cr13 圆钢	20cr13yg	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (name, password, phone, failed, get_pass, rights, confirm, theme, area, duty) FROM stdin;
朱玉琢	c3e5ab42b3749eb0a934d970921f10d4		0	0	材料采购，商品销售，库存状态，客户管理，入库明细，采购查询，销售查询，采购入库，供应商管理，出库明细，跨区查库存，销售出库，业务往来，单据审核，调整库存，反审单据，入库查询，出库查询，导出数据，调库查询，	t		天津	财务
张金宝	1080dcf0f283701d426fefa224667a8a	13102101346	0	0	材料采购，商品销售，库存状态，客户管理，入库明细，采购查询，销售查询，采购入库，供应商管理，出库明细，跨区查库存，销售出库，业务往来，单据审核，调整库存，反审单据，入库查询，出库查询，导出数据，调库查询，	t		天津	销售
唐文静	f87374f9b1c985c17f454025fb11283e		0	0	材料采购，商品销售，库存状态，客户管理，入库明细，采购查询，销售查询，采购入库，供应商管理，出库明细，库存设置，跨区查库存，销售出库，业务往来，调整库存，入库查询，批量导入，出库查询，导出数据，调库查询，	t		天津	库管
admin	f44f1d43c7e4b8eeaabb5526198dfd8c	13920953285	0	5	材料采购，商品销售，库存状态，客户管理，入库明细，用户设置，采购查询，销售查询，采购入库，供应商管理，出库明细，库存设置，跨区查库存，销售出库，业务往来，单据审核，调整库存，反审单据，入库查询，出库查询, 批量导入，调库查询，导出数据,财务开票，删除单据	t	blue	天津	总经理
sam	f44f1d43c7e4b8eeaabb5526198dfd8c		0	0	材料采购，商品销售，库存状态，客户管理，入库明细，采购查询，销售查询，采购入库，供应商管理，出库明细，跨区查库存，销售出库，业务往来，调整库存，入库查询，出库查询，调库查询，	t		天津	财务
朱玉树	522c17b35905d7f09edc671b6db0c44b	18522561838	0	0	材料采购，商品销售，库存状态，客户管理，入库明细，用户设置，采购查询，销售查询，采购入库，供应商管理，出库明细，库存设置，跨区查库存，销售出库，业务往来，单据审核，财务开票，调整库存，反审单据，入库查询，批量导入，出库查询，导出数据，调库查询，，删除单据	t		天津	总经理
\.


--
-- Name: customers_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."customers_ID_seq"', 84, true);


--
-- Name: help_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.help_id_seq', 81, true);


--
-- Name: tableset2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tableset2_id_seq', 364, true);


--
-- Name: documents buy_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT buy_documents_pkey PRIMARY KEY ("单号");


--
-- Name: customers customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: document_items document_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT document_items_pkey PRIMARY KEY (id);


--
-- Name: help help_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.help
    ADD CONSTRAINT help_pkey PRIMARY KEY (id);


--
-- Name: kp_items kp_items_pkey; Type: CONSTRAINT; Schema: public; Owner: sam
--

ALTER TABLE ONLY public.kp_items
    ADD CONSTRAINT kp_items_pkey PRIMARY KEY (id);


--
-- Name: lu lu_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lu
    ADD CONSTRAINT lu_pkey PRIMARY KEY ("炉号");


--
-- Name: pout_items pout_items_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pout_items
    ADD CONSTRAINT pout_items_pk PRIMARY KEY (id);


--
-- Name: products products_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pk PRIMARY KEY ("文本字段1");


--
-- Name: tableset tableset2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tableset
    ADD CONSTRAINT tableset2_pkey PRIMARY KEY (id);


--
-- Name: tree tree_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tree
    ADD CONSTRAINT tree_pkey PRIMARY KEY (num);


--
-- Name: users 用户_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "用户_pkey" PRIMARY KEY (name);


--
-- Name: document_items document_items_单号id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT "document_items_单号id_fkey" FOREIGN KEY ("单号id") REFERENCES public.documents("单号") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_items document_items_商品id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT "document_items_商品id_fkey" FOREIGN KEY ("商品id") REFERENCES public.tree(num);


--
-- Name: documents documents_客商id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_客商id_fkey" FOREIGN KEY ("客商id") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: kp_items kp_items_单号id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sam
--

ALTER TABLE ONLY public.kp_items
    ADD CONSTRAINT "kp_items_单号id_fkey" FOREIGN KEY ("单号id") REFERENCES public.documents("单号") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pout_items pout_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pout_items
    ADD CONSTRAINT pout_items_fk FOREIGN KEY ("单号id") REFERENCES public.documents("单号");


--
-- Name: products products_单号id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_单号id_fkey" FOREIGN KEY ("单号id") REFERENCES public.documents("单号");


--
-- Name: document_items products_商品id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_items
    ADD CONSTRAINT "products_商品id_fkey" FOREIGN KEY ("商品id") REFERENCES public.tree(num);


--
-- PostgreSQL database dump complete
--

